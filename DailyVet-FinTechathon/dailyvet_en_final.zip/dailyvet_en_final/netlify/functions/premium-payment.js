const admin = require('firebase-admin');

if (!admin.apps.length) {
  try {
    admin.initializeApp({
      credential: admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_KEY))
    });
  } catch (e) {
    console.error('Firebase init failed:', e.message);
  }
}

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers: CORS, body: '' };
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: CORS, body: JSON.stringify({ ok: false, error: 'Method not allowed' }) };
  }

  let body;
  try { body = JSON.parse(event.body || '{}'); }
  catch { return { statusCode: 400, headers: CORS, body: JSON.stringify({ ok: false, error: 'Invalid JSON' }) }; }

  const { phone, amount, method, payNumber, animal, district } = body;

  if (!phone || !amount || amount < 1) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ ok: false, error: 'Invalid amount or phone' }) };
  }
  if (!/^01\d{9}$/.test(payNumber || '')) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ ok: false, error: 'Invalid mobile number' }) };
  }
  if (!['bkash', 'nagad', 'rocket'].includes(method)) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ ok: false, error: 'Invalid payment method' }) };
  }

  const txnId = 'DVPAY' + Date.now();

  try {
    // ============================================================
    // DEMO MODE — no real money moves. Replace with bKash/Nagad API.
    // PRODUCTION: bKash Tokenized Checkout API →
    //   1. POST https://tokenized.pay.bka.sh/v1.2.0-beta/tokenized/checkout/create
    //   2. Redirect user to bKash payment page
    //   3. POST .../execute to confirm
    // ============================================================

    await admin.firestore()
      .collection('payments')
      .doc(txnId)
      .set({
        userPhone: phone,
        amount: Number(amount),
        method,
        payNumber,
        animal: animal || null,
        district: district || null,
        type: 'premium',
        status: 'paid',
        demoMode: true,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        createdAtMs: Date.now()
      });

    return {
      statusCode: 200,
      headers: CORS,
      body: JSON.stringify({ ok: true, txnId, demoMode: true })
    };
  } catch (err) {
    console.error('Premium payment failed:', err);
    return {
      statusCode: 500,
      headers: CORS,
      body: JSON.stringify({ ok: false, error: err.message || 'Server error' })
    };
  }
};