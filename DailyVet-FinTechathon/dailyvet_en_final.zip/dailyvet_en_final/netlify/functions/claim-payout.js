const admin = require('firebase-admin');

if (!admin.apps.length) {
  try {
    admin.initializeApp({
      credential: admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_KEY))
    });
  } catch (e) {
    console.error('Firebase init failed:', e.message);
  }
}

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS'
};

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers: CORS, body: '' };
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, headers: CORS, body: JSON.stringify({ ok: false, error: 'Method not allowed' }) };
  }

  let body;
  try { body = JSON.parse(event.body || '{}'); }
  catch { return { statusCode: 400, headers: CORS, body: JSON.stringify({ ok: false, error: 'Invalid JSON' }) }; }

  const { phone, policyId, amount, method, number, bankName, accountName, trigger, evidence } = body;

  if (!phone || !policyId || !amount || amount < 1) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ ok: false, error: 'Invalid input' }) };
  }
  if (!['bkash', 'nagad', 'rocket', 'bank'].includes(method)) {
    return { statusCode: 400, headers: CORS, body: JSON.stringify({ ok: false, error: 'Invalid payout method' }) };
  }

  const txnId = 'DVPAYOUT' + Date.now();

  try {
    // ============================================================
    // DEMO MODE — no real money moves. Replace with real payout API.
    // PRODUCTION bKash B2C:
    //   POST https://checkout.pay.bka.sh/v1.2.0-beta/checkout/payment/b2c
    //   headers: { Authorization: <token>, X-APP-Key: <appKey> }
    // ============================================================

    await admin.firestore()
      .collection('payouts')
      .doc(txnId)
      .set({
        userPhone: phone,
        policyId,
        amount: Number(amount),
        method,
        number,
        bankName: bankName || null,
        accountName: accountName || null,
        trigger: trigger || null,
        evidence: evidence || null,
        status: 'sent',
        demoMode: true,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        createdAtMs: Date.now()
      });

    return {
      statusCode: 200,
      headers: CORS,
      body: JSON.stringify({ ok: true, txnId, demoMode: true })
    };
  } catch (err) {
    console.error('Claim payout failed:', err);
    return {
      statusCode: 500,
      headers: CORS,
      body: JSON.stringify({ ok: false, error: err.message || 'Server error' })
    };
  }
};