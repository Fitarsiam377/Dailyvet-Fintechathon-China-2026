/* DailyVet — BD Division fallback points (when GeoJSON not yet loaded)
   Provides window.BD_DIVISIONS as a minimal FeatureCollection of points.
   Real polygons should be loaded by leaflet-geojson-loader.js from data/*.geojson.
*/
(function () {
'use strict';

const DIVS = [
    { key: 'dhaka',      name: 'Dhaka',      lat: 23.8103, lng: 90.4125 },
    { key: 'chittagong', name: 'Chittagong', lat: 22.3569, lng: 91.7832 },
    { key: 'rajshahi',   name: 'Rajshahi',   lat: 24.3745, lng: 88.6042 },
    { key: 'khulna',     name: 'Khulna',     lat: 22.8456, lng: 89.5403 },
    { key: 'barisal',    name: 'Barisal',    lat: 22.7010, lng: 90.3535 },
    { key: 'sylhet',     name: 'Sylhet',     lat: 24.8949, lng: 91.8687 },
    { key: 'rangpur',    name: 'Rangpur',    lat: 25.7439, lng: 89.2752 },
    { key: 'mymensingh', name: 'Mymensingh', lat: 24.7471, lng: 90.4203 }
];

window.BD_DIVISIONS = {
    type: 'FeatureCollection',
    features: DIVS.map(d => ({
        type: 'Feature',
        properties: { ADM1_EN: d.name, ADM1_BN: d.name, name: d.name, nameBn: d.name },
        geometry: { type: 'Point', coordinates: [d.lng, d.lat] }
    }))
};

window.BD_DISTRICTS = { type: 'FeatureCollection', features: [] };
window.BD_UPAZILAS = { type: 'FeatureCollection', features: [] };

console.log('✅ BD_DIVISIONS fallback points loaded (8 divisions)');
})();