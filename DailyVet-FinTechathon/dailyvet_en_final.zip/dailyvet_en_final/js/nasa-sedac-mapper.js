/* DailyVet — NASA SEDAC Impact Mapper v2.0
   Population: NASA SEDAC GPW v4.11
   Livestock:  DLS Bangladesh (2022-23 estimate)
   v2.0: Detailed calculation steps + economic loss
*/
(function () {
'use strict';

const SEDAC_COLLECTION = 'sedac_data';
const CACHE_TTL_MS = 10 * 60 * 1000;
const _fs = () => firebase.firestore();
const _cache = new Map();

/* ===== FALLBACK DATA (SEDAC GPW v4.11 + DLS) ===== */
const FALLBACK_DATA = {
    dhaka: {
        name: 'Dhaka', nameBn: 'Dhaka',
        population: 44_215_759, ruralPopulation: 27_582_000,
        marginalFarmers: 82_000,
        livestock: { cattle: 385_000, goat: 195_000, sheep: 28_000, poultry: 5_200_000 },
        vulnerabilityIndex: 0.72
    },
    chittagong: {
        name: 'Chittagong', nameBn: 'Chittagong',
        population: 33_202_326, ruralPopulation: 24_120_000,
        marginalFarmers: 78_000,
        livestock: { cattle: 340_000, goat: 175_000, sheep: 32_000, poultry: 4_600_000 },
        vulnerabilityIndex: 0.78
    },
    rajshahi: {
        name: 'Rajshahi', nameBn: 'Rajshahi',
        population: 20_810_000, ruralPopulation: 15_680_000,
        marginalFarmers: 68_000,
        livestock: { cattle: 295_000, goat: 155_000, sheep: 24_000, poultry: 3_100_000 },
        vulnerabilityIndex: 0.65
    },
    khulna: {
        name: 'Khulna', nameBn: 'Khulna',
        population: 17_415_000, ruralPopulation: 13_250_000,
        marginalFarmers: 58_000,
        livestock: { cattle: 245_000, goat: 128_000, sheep: 18_000, poultry: 2_800_000 },
        vulnerabilityIndex: 0.70
    },
    barisal: {
        name: 'Barisal', nameBn: 'Barisal',
        population: 9_325_000, ruralPopulation: 7_480_000,
        marginalFarmers: 42_000,
        livestock: { cattle: 145_000, goat: 82_000, sheep: 12_000, poultry: 1_700_000 },
        vulnerabilityIndex: 0.68
    },
    sylhet: {
        name: 'Sylhet', nameBn: 'Sylhet',
        population: 11_415_000, ruralPopulation: 8_620_000,
        marginalFarmers: 38_000,
        livestock: { cattle: 175_000, goat: 88_000, sheep: 14_000, poultry: 2_100_000 },
        vulnerabilityIndex: 0.74
    },
    rangpur: {
        name: 'Rangpur', nameBn: 'Rangpur',
        population: 17_610_000, ruralPopulation: 14_380_000,
        marginalFarmers: 72_000,
        livestock: { cattle: 265_000, goat: 142_000, sheep: 22_000, poultry: 2_500_000 },
        vulnerabilityIndex: 0.61
    },
    mymensingh: {
        name: 'Mymensingh', nameBn: 'Mymensingh',
        population: 12_368_000, ruralPopulation: 9_820_000,
        marginalFarmers: 55_000,
        livestock: { cattle: 210_000, goat: 105_000, sheep: 15_000, poultry: 2_300_000 },
        vulnerabilityIndex: 0.66
    }
};

/* ===== FETCH ===== */
async function fetchSedacData(district) {
    if (!district) return null;
    const key = String(district).toLowerCase().trim();
    
    const hit = _cache.get(key);
    if (hit && Date.now() - hit.at < CACHE_TTL_MS) return hit.data;
    
    const base = FALLBACK_DATA[key] || {};
    let result = null;
    
    try {
        const doc = await _fs().collection(SEDAC_COLLECTION).doc(key).get();
        if (doc.exists) {
            const data = doc.data();
            if (data && data.population && data.livestock) {
                result = { ...base, ...data, id: doc.id, source: 'firestore' };
            }
        }
    } catch (err) {
        console.warn('[SEDAC] Firestore fetch failed:', err.message);
    }
    
    if (!result && FALLBACK_DATA[key]) {
        result = { ...base, id: key, source: 'fallback-gpw411' };
    }
    
    if (result) _cache.set(key, { at: Date.now(), data: result });
    return result;
}

/* ===== IMPACT CALCULATION with detailed steps ===== */
const EXPOSURE_MULTIPLIER = { critical: 0.85, alert: 0.65, watch: 0.35, safe: 0.10 };

const EXPECTED_LOSS_RATE = { critical: 0.08, alert: 0.05, watch: 0.02, safe: 0.005 };

const LIVESTOCK_VALUE_BDT = {
    cattle: 80000,
    buffalo: 100000,
    goat: 12000,
    sheep: 10000,
    poultry: 400
};

function calculateImpactDetailed(sedac, riskCtx) {
    if (!sedac) return null;
    
    const riskLevel = String((riskCtx && riskCtx.level) || 'safe').toLowerCase();
    const riskScore = Number(riskCtx && riskCtx.score) || 0;
    const multiplier = EXPOSURE_MULTIPLIER[riskLevel] !== undefined
        ? EXPOSURE_MULTIPLIER[riskLevel]
        : EXPOSURE_MULTIPLIER.safe;
    
    const livestock = sedac.livestock || {};
    const exposed = n => Math.round((Number(n) || 0) * multiplier);
    
    const cattle = exposed(livestock.cattle);
    const goat = exposed(livestock.goat);
    const sheep = exposed(livestock.sheep);
    const poultry = exposed(livestock.poultry);
    
    const populationAtRisk = exposed(sedac.ruralPopulation);
    const farmersAtRisk = exposed(sedac.marginalFarmers);
    const livestockAtRisk = cattle + goat + sheep + poultry;
    
    /* ===== Economic loss ===== */
    const lossRate = EXPECTED_LOSS_RATE[riskLevel] !== undefined
        ? EXPECTED_LOSS_RATE[riskLevel]
        : EXPECTED_LOSS_RATE.safe;
    const lossOf = (heads, value) => Math.round(heads * lossRate * value);
    const lossCattle  = lossOf(cattle,  LIVESTOCK_VALUE_BDT.cattle);
    const lossGoat    = lossOf(goat,    LIVESTOCK_VALUE_BDT.goat);
    const lossSheep   = lossOf(sheep,   LIVESTOCK_VALUE_BDT.sheep);
    const lossPoultry = lossOf(poultry, LIVESTOCK_VALUE_BDT.poultry);
    const economicLoss = lossCattle + lossGoat + lossSheep + lossPoultry;
    
    /* ===== Vulnerability ===== */
    const vulnerability = Math.min(100, Math.max(0, Math.round((sedac.vulnerabilityIndex || 0.5) * riskScore)));
    
    /* ===== Detailed calculation steps ===== */
    const calculationSteps = [
        {
            step: 'Total rural population',
            stepEn: 'Total rural population',
            value: sedac.ruralPopulation,
            formula: null
        },
        {
            step: 'Exposure multiplier',
            stepEn: 'Exposure multiplier',
            value: `×${multiplier}`,
            formula: `(risk level: ${riskLevel})`
        },
        {
            step: 'Population at risk',
            stepEn: 'Population at risk',
            value: populationAtRisk,
            formula: `${formatNumber(sedac.ruralPopulation)} × ${multiplier}`
        },
        {
            step: 'Marginal farmers',
            stepEn: 'Marginal farmers',
            value: sedac.marginalFarmers,
            formula: null
        },
        {
            step: 'Farmers at risk',
            stepEn: 'Farmers at risk',
            value: farmersAtRisk,
            formula: `${formatNumber(sedac.marginalFarmers)} × ${multiplier}`
        },
        {
            step: 'Livestock at risk',
            stepEn: 'Livestock at risk',
            value: livestockAtRisk,
            formula: `Cattle + goats + sheep + poultry (each × ${multiplier})`
        },
        {
            step: 'Expected loss rate',
            stepEn: 'Expected loss rate',
            value: `${(lossRate * 100).toFixed(1)}%`,
            formula: 'Share of at-risk animals that may be lost (estimate)'
        },
        {
            step: 'Estimated economic loss',
            stepEn: 'Estimated economic loss',
            value: `৳${(economicLoss / 10000000).toFixed(2)} Crore`,
            formula: 'Animals × loss rate × average market value'
        }
    ];
    
    return {
        riskLevel,
        riskScore,
        multiplier,
        lossRate,
        populationAtRisk,
        farmersAtRisk,
        livestockAtRisk,
        breakdown: { cattle, goat, sheep, poultry },
        vulnerability,
        districtName: sedac.name,
        districtNameBn: sedac.nameBn,
        dataSource: sedac.source || 'unknown',
        calculationSteps,
        economicLoss: {
            total: Math.round(economicLoss),
            min: Math.round(economicLoss * 0.7),
            max: Math.round(economicLoss * 1.3),
            minCrore: (economicLoss * 0.7 / 10000000).toFixed(2),
            maxCrore: (economicLoss * 1.3 / 10000000).toFixed(2),
            currency: '৳',
            breakdown: {
                cattle: lossCattle,
                goat: lossGoat,
                sheep: lossSheep,
                poultry: lossPoultry
            }
        },
        rawLivestock: livestock,
        rawPopulation: {
            total: sedac.population,
            rural: sedac.ruralPopulation,
            farmers: sedac.marginalFarmers
        }
    };
}

function calculateImpact(sedac, riskCtx) {
    return calculateImpactDetailed(sedac, riskCtx);
}

/* ===== NUMBER FORMATTER ===== */
function formatNumber(n) {
    const v = Number(n);
    if (n === null || n === undefined || !Number.isFinite(v)) return '0';
    if (v >= 1_000_000) return (v / 1_000_000).toFixed(1) + 'M';
    if (v >= 1_000) {
        const k = Math.round(v / 1_000);
        return k >= 1000 ? '1.0M' : k + 'K';
    }
    return String(Math.round(v));
}

/* ===== ENGLISH SUMMARY with numbers ===== */
function generateImpactSummary(impact) {
    if (!impact) return '';
    
    const { riskLevel, populationAtRisk, farmersAtRisk, livestockAtRisk, districtName, economicLoss } = impact;
    const pop = formatNumber(populationAtRisk);
    const farm = formatNumber(farmersAtRisk);
    const live = formatNumber(livestockAtRisk);
    
    switch (riskLevel) {
        case 'safe':
            return `No major risk at present in ${districtName}. Normal conditions prevail.`;
        case 'watch':
            return `About ${pop} people and ${live} livestock in ${districtName} are under observation. Stay alert and take preventive measures.`;
        case 'alert':
            return `About ${farm} marginal farmers and ${live} livestock in ${districtName} may face livelihood and food-security risk. Estimated loss ৳${economicLoss.minCrore}–${economicLoss.maxCrore} Crore. Take urgent preparation.`;
        case 'critical':
            return `🚨 About ${pop} people and ${live} livestock in ${districtName} are at serious risk. Estimated loss ৳${economicLoss.minCrore}–${economicLoss.maxCrore} Crore. Immediate preventive measures and veterinary support required.`;
        default:
            return `Risk information for ${districtName} not available.`;
    }
}

/* ===== PUBLIC API ===== */
window.NasaSedac = {
    fetchSedacData,
    calculateImpact,
    calculateImpactDetailed,
    generateImpactSummary,
    formatNumber,
    listDistricts: () => Object.keys(FALLBACK_DATA),
    FALLBACK_DATA,
    LIVESTOCK_VALUE_BDT,
    EXPECTED_LOSS_RATE,
    SOURCE: 'NASA SEDAC GPW v4.11',
    GEE_COLLECTION: 'CIESIN/GPWv411/GPW_Population_Count'
};

})();
