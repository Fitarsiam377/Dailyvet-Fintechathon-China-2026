/* Global key decoder — only on window, never redeclare in other files */
window._dvDec = window._dvDec || function (s) { try { return atob(s); } catch (e) { return ''; } };

/* ============================================================
   DailyVet — Console Guard v1.1
   ------------------------------------------------------------
   Purpose:
   - Prevent API keys / endpoint URLs from leaking to browser console
   - Silence noisy logs in production
   - Scrub fetch/XHR error messages + unhandled errors

   How to use:
   1. Save as js/console-guard.js
   2. Load BEFORE all other scripts on every page:

      <script src="js/console-guard.js"></script>
      <script defer src="js/firebase-config.js"></script>
      <script defer src="js/auth.js"></script>
      ...

   NOTE: This masks console output only. Real keys still exist in
   JS source + Network tab. For true protection, move keys to a
   Netlify Function proxy. This file is a defense-in-depth layer.
   ============================================================ */
(function () {
  'use strict';


  /* ---------- CONFIG ---------- */
  const PROD = location.hostname !== 'localhost' &&
               location.hostname !== '127.0.0.1' &&
               !location.hostname.startsWith('192.168.') &&
               !location.hostname.endsWith('.local');

  const REDACTED = '***REDACTED***';

  /* ---------- SENSITIVE PATTERNS ---------- */
  const PATTERNS = [
    // URL query params: ?key=...  &api_key=...  &apikey=...
    [/([?&](?:key|api_key|apikey|token|access_token)=)[^&\s"'`<>]+/gi, '$1' + REDACTED],

    // Authorization headers
    [/(Bearer\s+)[A-Za-z0-9._\-]{8,}/gi, '$1' + REDACTED],
    [/(xi-api-key["':\s=]+)[A-Za-z0-9._\-]{8,}/gi, '$1' + REDACTED],

    // Groq
    [/gsk_[A-Za-z0-9]{20,}/g, REDACTED],

    // OpenRouter
    [/sk-or-v1-[A-Za-z0-9]{20,}/g, REDACTED],

    // Gemini
    [/AQ\.Ab8RN6[A-Za-z0-9._\-]{10,}/g, REDACTED],

    // Firebase apiKey
    [/AIzaSy[A-Za-z0-9_\-]{20,}/g, REDACTED],

    // LocationIQ
    [/pk\.[a-f0-9]{40,}/gi, REDACTED],

    // ElevenLabs
    [/"apiKey"\s*:\s*"[^"]+"/gi, '"apiKey":"' + REDACTED + '"'],

    // Generic long alphanumeric tokens in URLs (defensive)
    [/([?&][a-z_]+=)([A-Za-z0-9_\-]{32,})/gi, '$1' + REDACTED],
  ];

  function scrubString(str) {
    let out = String(str);
    for (const [re, rep] of PATTERNS) out = out.replace(re, rep);
    return out;
  }

  function scrub(value, depth) {
    depth = depth || 0;
    if (depth > 4) return '[deep]';
    if (value == null) return value;

    if (typeof value === 'string') return scrubString(value);
    if (typeof value === 'number' || typeof value === 'boolean') return value;
    if (typeof value === 'function') return '[function]';

    if (value instanceof Error) {
      return {
        name: value.name,
        message: scrubString(value.message || ''),
        stack: '(hidden)'
      };
    }

    if (value instanceof Node) return '[DOMNode]';
    if (value instanceof Response) return '[Response]';

    if (Array.isArray(value)) {
      return value.slice(0, 50).map(v => scrub(v, depth + 1));
    }

    if (typeof value === 'object') {
      try {
        const out = {};
        let count = 0;
        for (const k of Object.keys(value)) {
          if (count++ > 50) { out['…'] = '[truncated]'; break; }
          if (/^(key|apikey|api_key|token|secret|password|authorization|auth|bearer)$/i.test(k)) {
            out[k] = REDACTED;
          } else if (/key|token|secret|password/i.test(k)) {
            out[k] = REDACTED;
          } else {
            out[k] = scrub(value[k], depth + 1);
          }
        }
        return out;
      } catch (_) {
        return '[object]';
      }
    }
    return String(value);
  }

  /* ---------- NATIVE CONSOLE REFS ---------- */
  const native = {
    log:     console.log.bind(console),
    info:    console.info.bind(console),
    warn:    console.warn.bind(console),
    error:   console.error.bind(console),
    debug:   console.debug.bind(console),
    table:   console.table.bind(console),
    group:   console.group.bind(console),
    groupCollapsed: console.groupCollapsed
      ? console.groupCollapsed.bind(console) : null,
    groupEnd: console.groupEnd.bind(console),
    trace:   console.trace ? console.trace.bind(console) : null,
    dir:     console.dir ? console.dir.bind(console) : null,
  };

  /* ---------- INSTALL CONSOLE OVERRIDES ---------- */
  if (PROD) {
    // Production: silence noise logs (keep warn/error, scrubbed)
    console.log   = function () {};
    console.info  = function () {};
    console.debug = function () {};
    console.table = function () {};
    console.group = function () {};
    console.groupCollapsed = function () {};
    console.groupEnd = function () {};
    console.dir   = function () {};
    console.trace = function () {};
  } else {
    // Dev: keep logs, but scrub
    console.log   = (...a) => native.log(...a.map(v => scrub(v)));
    console.info  = (...a) => native.info(...a.map(v => scrub(v)));
    console.debug = (...a) => native.debug(...a.map(v => scrub(v)));
    console.table = (...a) => native.table(...a.map(v => scrub(v)));
    console.group = (...a) => native.group(...a.map(v => scrub(v)));
    if (native.groupCollapsed)
      console.groupCollapsed = (...a) => native.groupCollapsed(...a.map(v => scrub(v)));
    if (native.dir)
      console.dir = (...a) => native.dir(...a.map(v => scrub(v)));
    if (native.trace)
      console.trace = (...a) => native.trace(...a.map(v => scrub(v)));
  }

  // Always keep warn/error but scrub
  console.warn  = (...a) => native.warn(...a.map(v => scrub(v)));
  console.error = (...a) => native.error(...a.map(v => scrub(v)));
  console.groupEnd = native.groupEnd;

  /* ---------- GLOBAL ERROR HANDLERS ---------- */
  window.addEventListener('error', e => {
    try {
      native.error(
        '[window.onerror]',
        e.message ? scrubString(e.message) : '(no message)',
        'at',
        e.filename || '',
        ':' + (e.lineno || 0)
      );
    } catch (_) {}
    // Prevent default browser console output that may include stack with keys
    // (we already logged a sanitized version above)
    if (PROD) e.preventDefault();
  }, true);

  window.addEventListener('unhandledrejection', e => {
    try {
      const r = e.reason;
      const msg = r && r.message ? r.message : r;
      native.error('[unhandledrejection]', scrub(msg));
    } catch (_) {}
    if (PROD) e.preventDefault();
  });

  /* ---------- SANITIZE FETCH ERRORS ---------- */
  const nativeFetch = window.fetch;
  if (typeof nativeFetch === 'function') {
    window.fetch = function (input, init) {
      const url = typeof input === 'string'
        ? input
        : (input && input.url) || '';

      return nativeFetch.apply(this, arguments).catch(err => {
        // Do NOT log the URL — it may contain keys
        const safe = new Error(
          scrubString(err && err.message ? err.message : 'fetch failed')
        );
        safe.name = 'FetchError';
        throw safe;
      });
    };
  }

  /* ---------- SANITIZE XHR ---------- */
  const XHR = window.XMLHttpRequest;
  if (XHR && XHR.prototype && XHR.prototype.open) {
    const nativeOpen = XHR.prototype.open;
    XHR.prototype.open = function (method, url) {
      // Mask URL in any future error logs
      try {
        this.__dvSafeUrl = scrubString(String(url || ''));
      } catch (_) {}
      return nativeOpen.apply(this, arguments);
    };
  }

  /* ---------- DEV NOTICE ---------- */
  if (!PROD) {
    native.log(
      '%c[ConsoleGuard]%c active — API keys/URLs are redacted from console.',
      'background:#0E7C7B;color:#fff;padding:2px 6px;border-radius:4px;font-weight:700',
      'color:#0E7C7B;font-weight:600'
    );
  }

  /* ---------- PUBLIC API (optional) ---------- */
  window.DVConsoleGuard = {
    isProd: () => PROD,
    scrub: scrubString,
    scrubDeep: scrub,
    /** Manually log a sanitized object (use for debugging) */
    safeLog: (...a) => native.log(...a.map(v => scrub(v))),
  };
})();
