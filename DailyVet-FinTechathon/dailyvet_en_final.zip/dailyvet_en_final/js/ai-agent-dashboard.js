/* ============================================================
   DailyVet — AI Agent Dashboard Logic v3.4
   ============================================================ */
(function () {
'use strict';

function _dvDec(b64) {
    try { return decodeURIComponent(escape(window.atob(b64))); } catch (_) { return ''; }
}

const AGD_GEMINI_KEYS = [
  _dvDec('QVEuQWI4Uk42SWZjSVNqNDhaVWRlelpCdHJlZkhRNmxBWHhRX3Z0WnhYRklKSXRBaEF5VVE='),
  _dvDec('QVEuQWI4Uk42S3JYOTg4UThFWFdORzlpRjlDYnNtcUxJbEw3aEtpQWFYUkNhMWFHZ01vU0E='),
  _dvDec('QVEuQWI4Uk42S1ZieGwxZTBaSjRqUU9rR1oyeXFkRnh4MnU1SmwxeU42QW5DVzRtM2pwSVE='),
  _dvDec('QVEuQWI4Uk42TENMSDBLdjctZEVYNjFMcWhlWnlUM2VXWFpuOXZsamhFd2Fsb2xOcnc1bGc='),
  _dvDec('QVEuQWI4Uk42S3JmTjF2dmUwQTRvOURiUnJLbEp3ZHVJNl9GdkJrQ0Q0Q0dMZVFjR0FveFE=')
];
const AGD_GROQ_KEYS = [
  _dvDec('Z3NrX21WVXRJQThxTHdXUGNIZkFvNHNkV0dkeWIzRllkUk1rTlppMUxYT2gxb1RITVlIM0w3WXI='),
  _dvDec('Z3NrX3o4QkRyYldCbXlhS2l6M3BiVnZRV0dkeWIzRlk1R25haDNrQVptQm1xRUF2a2ZLMTZmd1M='),
  _dvDec('Z3NrX0ExSHo5VDQ3aTA5UndrM1h4UGlaV0dkeWIzRllxT0YxOHdDc0JRV0lUaVlOQjRaM3RheDQ=')
];
const AGD_OPENROUTER_KEYS = [
  _dvDec('c2stb3ItdjEtODg4MDE5MDk4Njc2MjllYWQ5ZGQyMjQ2MTc5YWVlZjE0Y2VkZTFiMGZkOGI2YmQxM2VkNDA2NTU3NWVhZWY3OQ=='),
  _dvDec('c2stb3ItdjEtNGQwZmE1MzM5YWI1YTA3NDlkM2I4ZTEyZTU1NGM3ZWI2MjFjYzNjMmI1YjgwYzk0MjA5YjM0YjhmMzZjZTFlNg==')
];

const AGD_AI = (function (CFG) {
'use strict';

const MODELS = {
    gemini: {
        text: ['gemini-3.5-flash-lite', 'gemini-3.1-flash-lite', 'gemini-2.5-flash-lite', 'gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-2.5-flash'],
        vision: ['gemini-3.5-flash-lite', 'gemini-3.1-flash-lite', 'gemini-2.5-flash-lite', 'gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-2.5-flash']
    },
    groq: {
        text: ['openai/gpt-oss-120b'],
        vision: ['qwen/qwen3.8-27b']
    },
    openrouter: {
        text: ['meta-llama/llama-3.3-70b-instruct:free', 'google/gemma-2-9b-it:free'],
        vision: ['qwen/qwen2.5-vl-72b-instruct:free']
    }
};
const ENDPOINTS = {
    gemini: 'https://generativelanguage.googleapis.com/v1beta/models',
    groq: 'https://api.groq.com/openai/v1/chat/completions',
    openrouter: 'https://openrouter.ai/api/v1/chat/completions'
};
const COOLDOWN = {
    rateLimit: 20e3, rateLimitMax: 12 * 60e3,
    server: 15e3, timeout: 12e3, badRequest: 8 * 60e3,
    authKey: 6 * 3600e3, modelGone: 24 * 3600e3, quotaZero: 6 * 3600e3, perDay: 3 * 3600e3
};
const SAFETY = ['HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH', 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'HARM_CATEGORY_DANGEROUS_CONTENT']
    .map(category => ({ category, threshold: 'BLOCK_ONLY_HIGH' }));
const DEFAULT_TIMING = {
    text: { total: 9000, perCall: 6000, hedge: 2000, parallel: 2 },
    vision: { total: 14000, perCall: 9000, hedge: 3000, parallel: 2 }
};
const MIN_RETRY_MS = 1800;

const _ls = {
    get: k => { try { return localStorage.getItem(k); } catch (_) { return null; } },
    set: (k, v) => { try { localStorage.setItem(k, v); } catch (_) {} }
};

const BLOCK_STORE = 'dvEng_' + CFG.name + '_blocks';
const BLOCK_VERSION = 'v1';
const BLOCK_VERSION_STORE = 'dvEng_' + CFG.name + '_ver';
const _blocks = new Map();
const _strikes = new Map();
const _rot = { gemini: 0, groq: 0, openrouter: 0 };

(function _loadBlocks() {
    try {
        if (_ls.get(BLOCK_VERSION_STORE) !== BLOCK_VERSION) {
            _ls.set(BLOCK_STORE, '{}');
            _ls.set(BLOCK_VERSION_STORE, BLOCK_VERSION);
            return;
        }
        Object.entries(JSON.parse(_ls.get(BLOCK_STORE) || '{}')).forEach(([id, until]) => {
            if (until > Date.now()) _blocks.set(id, until);
        });
    } catch (_) {}
})();

const _keysOf = p => ((CFG.keys && CFG.keys[p]) || []).filter(k => k && !/^(PASTE_|YOUR_)/i.test(String(k)));
const _tail = k => String(k).slice(-8);
const _keyId = s => 'k:' + s.provider + ':' + _tail(s.key);
const _modelId = s => 'm:' + s.provider + ':' + s.model;
const _isBlocked = id => (_blocks.get(id) || 0) > Date.now();
const _slotBlocked = s => _isBlocked(s.id) || _isBlocked(_keyId(s)) || _isBlocked(_modelId(s));

function _block(id, ms) {
    _blocks.set(id, Date.now() + ms);
    const live = {};
    _blocks.forEach((until, k) => { if (until > Date.now()) live[k] = until; });
    _ls.set(BLOCK_STORE, JSON.stringify(live));
}

function _buildSlots(hasImage) {
    const kind = hasImage ? 'vision' : 'text';
    const make = provider => {
        const keys = _keysOf(provider);
        const shift = keys.length ? _rot[provider] % keys.length : 0;
        const rotated = keys.slice(shift).concat(keys.slice(0, shift));
        const seen = new Set();
        const out = [];
        for (const model of MODELS[provider][kind]) {
            for (const key of rotated) {
                const id = 's:' + provider + ':' + model + ':' + _tail(key);
                if (seen.has(id)) continue;
                seen.add(id);
                out.push({ provider, model, key, id });
            }
        }
        return out;
    };
    const arrange = ([g, q, o]) => {
        const out = [];
        let gi = 0, qi = 0, oi = 0;
        const take = (arr, i) => (i < arr.length ? arr[i] : null);
        const steps = [
            () => take(g, gi++), () => take(g, gi++), () => take(q, qi++),
            () => take(g, gi++), () => take(o, oi++), () => take(g, gi++), () => take(q, qi++)
        ];
        for (const step of steps) { const s = step(); if (s) out.push(s); }
        while (gi < g.length) out.push(g[gi++]);
        while (qi < q.length) out.push(q[qi++]);
        while (oi < o.length) out.push(o[oi++]);
        return out;
    };
    const all = ['gemini', 'groq', 'openrouter'].map(make);
    const live = arrange(all.map(list => list.filter(s => !_slotBlocked(s))));
    if (live.length) return live;
    return arrange(all.map(list => list.filter(s => !_isBlocked(_keyId(s)) && !_isBlocked(_modelId(s))))).slice(0, 4);
}

function _parseImage(img) {
    const m = /^data:([^;]+);base64,(.*)$/.exec(img || '');
    return m ? { mime: m[1], data: m[2] } : { mime: 'image/jpeg', data: img };
}
function _history(a) {
    const h = (a.history || []).filter(m => m && m.content);
    while (h.length && h[0].role !== 'user') h.shift();
    return h;
}
const _isReasoning = model => /gpt-oss|qwen3|qwen-3/i.test(model);

function _geminiRequest(slot, a) {
    const hasImage = !!a.image;
    const contents = _history(a).map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] }));
    if (hasImage) {
        const { mime, data } = _parseImage(a.image);
        contents.push({ role: 'user', parts: [{ inline_data: { mime_type: mime, data } }, { text: a.user }] });
    } else {
        contents.push({ role: 'user', parts: [{ text: a.user }] });
    }
    const generationConfig = {
        temperature: a.temperature != null ? a.temperature : 0.3,
        maxOutputTokens: a.maxTokens || 1400, topP: 0.95
    };
    if (a.json) generationConfig.responseMimeType = 'application/json';
    if (slot.model.includes('2.5')) generationConfig.thinkingConfig = { thinkingBudget: 0 };
    const body = { contents, generationConfig, safetySettings: SAFETY };
    if (a.system) body.system_instruction = { parts: [{ text: a.system }] };
    return {
        url: ENDPOINTS.gemini + '/' + slot.model + ':generateContent?key=' + slot.key,
        headers: { 'Content-Type': 'application/json' },
        body
    };
}

function _chatRequest(slot, a) {
    const hasImage = !!a.image;
    const userContent = hasImage
        ? [
            { type: 'text', text: a.user },
            { type: 'image_url', image_url: { url: String(a.image).startsWith('data:') ? a.image : 'data:image/jpeg;base64,' + a.image } }
        ]
        : a.user;
    const reasoning = _isReasoning(slot.model);
    const base = a.maxTokens || 1400;
    const messages = [];
    if (a.system) messages.push({ role: 'system', content: a.system });
    _history(a).forEach(m => messages.push({ role: m.role, content: m.content }));
    messages.push({ role: 'user', content: userContent });
    const body = {
        model: slot.model, messages,
        temperature: a.temperature != null ? a.temperature : 0.3,
        max_tokens: reasoning ? base + 1200 : base
    };
    if (reasoning && slot.provider === 'groq') Object.assign(body, { reasoning_effort: 'low', include_reasoning: false });
    const headers = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + slot.key };
    if (slot.provider === 'openrouter') {
        headers['HTTP-Referer'] = (typeof location !== 'undefined' && location.origin) || 'https://dailyvet.app';
        headers['X-Title'] = 'DailyVet ' + (CFG.title || CFG.name);
    }
    return { url: ENDPOINTS[slot.provider], headers, body };
}

function _onHttpError(slot, status, retryAfter, bodyText) {
    const body = String(bodyText || '').slice(0, 500);
    if (status === 429) {
        const n = (_strikes.get(slot.id) || 0) + 1;
        _strikes.set(slot.id, n);
        const hinted = (parseInt(retryAfter, 10) || 0) * 1000;
        let ms = Math.min(Math.max(hinted, COOLDOWN.rateLimit * Math.pow(2, n - 1)), COOLDOWN.rateLimitMax);
        if (/limit:\s*0/i.test(body)) ms = COOLDOWN.quotaZero;
        else if (/PerDay|per\s*day/i.test(body)) ms = COOLDOWN.perDay;
        _block(slot.id, ms);
    } else if (status === 400) {
        if (/api[_ ]key (?:not valid|invalid|expired)|API_KEY_INVALID|key expired/i.test(body)) _block(_keyId(slot), COOLDOWN.authKey);
        else _block(slot.id, COOLDOWN.badRequest);
    } else if (status === 401 || status === 402 || status === 403) {
        _block(_keyId(slot), COOLDOWN.authKey);
    } else if (status === 404) {
        _block(_modelId(slot), COOLDOWN.modelGone);
    } else if (status >= 500 || status === 408) {
        _block(slot.id, COOLDOWN.server);
    }
}

function stripThink(t) {
    return String(t || '').replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
}
function stripMarkdown(text) {
    if (!text) return '';
    return stripThink(text)
        .replace(/^\s*[*]\s+/gm, '• ')
        .replace(/\*\*(.+?)\*\*/g, '$1')
        .replace(/\*(.+?)\*/g, '$1')
        .replace(/`(.+?)`/g, '$1')
        .replace(/^#+\s*/gm, '')
        .replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}
function parseJSON(raw) {
    const t = stripThink(raw).replace(/```(?:json)?/gi, '').trim();
    try { return JSON.parse(t); } catch (_) {}
    const o = t.match(/\{[\s\S]*\}/);
    if (o) { try { return JSON.parse(o[0]); } catch (_) {} }
    const arr = t.match(/\[[\s\S]*\]/);
    if (arr) { try { return JSON.parse(arr[0]); } catch (_) {} }
    return null;
}

async function _callSlot(slot, a, ctrl, timeoutMs, strict) {
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; ctrl.abort(); }, timeoutMs);
    try {
        if (a.onProvider) { try { a.onProvider(slot.provider); } catch (_) {} }
        const req = slot.provider === 'gemini' ? _geminiRequest(slot, a) : _chatRequest(slot, a);
        const res = await fetch(req.url, { method: 'POST', headers: req.headers, body: JSON.stringify(req.body), signal: ctrl.signal });
        if (!res.ok) {
            const errBody = await res.text().catch(() => '');
            _onHttpError(slot, res.status, res.headers && res.headers.get ? res.headers.get('retry-after') : null, errBody);
            return null;
        }
        const data = await res.json();
        let raw;
        if (slot.provider === 'gemini') {
            const cand = data.candidates && data.candidates[0];
            raw = ((cand && cand.content && cand.content.parts) || []).filter(p => p && p.text && !p.thought).map(p => p.text).join('');
        } else {
            raw = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
        }
        raw = stripThink(raw);
        if (!raw) return null;

        let value = raw;
        if (a.validate) {
            try { value = a.validate(raw, !!strict); } catch (_) { value = null; }
            if (value === null || value === undefined) return null;
        }
        _strikes.delete(slot.id);
        const keys = _keysOf(slot.provider);
        _rot[slot.provider] = keys.indexOf(slot.key) + 1;
        return { raw, data: value };
    } catch (err) {
        if (timedOut) _block(slot.id, COOLDOWN.timeout);
        else if (!ctrl.signal.aborted) _block(slot.id, COOLDOWN.server);
        return null;
    } finally {
        clearTimeout(timer);
    }
}

function _cascade(slots, a, cfg, strict) {
    return new Promise(resolve => {
        let next = 0, inflight = 0, done = false, deadline = null, hedgeT = null;
        const ctrls = new Set();
        const preBlocked = new Set(slots.filter(_slotBlocked).map(sl => sl.id));
        const skipSlot = sl => _slotBlocked(sl) && !preBlocked.has(sl.id);
        const finish = result => {
            if (done) return;
            done = true;
            clearTimeout(deadline);
            clearTimeout(hedgeT);
            ctrls.forEach(c => { try { c.abort(); } catch (_) {} });
            resolve(result);
        };
        const launch = () => {
            if (done || inflight >= cfg.parallel) return;
            while (next < slots.length && skipSlot(slots[next])) next++;
            if (next >= slots.length) {
                if (!inflight) finish(null);
                return;
            }
            const slot = slots[next++];
            const ctrl = new AbortController();
            ctrls.add(ctrl);
            inflight++;
            _callSlot(slot, a, ctrl, cfg.perCall, strict).then(res => {
                ctrls.delete(ctrl);
                inflight--;
                if (res) finish({ provider: slot.provider, model: slot.model, raw: res.raw, data: res.data });
                else launch();
            }).catch(() => {
                ctrls.delete(ctrl);
                inflight--;
                launch();
            });
        };
        const scheduleHedge = () => {
            hedgeT = setTimeout(() => {
                if (done) return;
                launch();
                if (next < slots.length) scheduleHedge();
            }, cfg.hedge);
        };
        deadline = setTimeout(() => finish(null), cfg.total);
        launch();
        scheduleHedge();
    });
}

async function ask(a) {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) return null;
    const hasImage = !!a.image;
    const t = (CFG.timing && CFG.timing[hasImage ? 'vision' : 'text']) || DEFAULT_TIMING[hasImage ? 'vision' : 'text'];
    const total = Math.min(t.total, a.budgetMs || t.total);
    const rounds = a.rounds || 2;
    const start = Date.now();
    for (let r = 1; r <= rounds; r++) {
        const left = total - (Date.now() - start);
        if (left < (r === 1 ? 800 : MIN_RETRY_MS)) break;
        const slots = _buildSlots(hasImage);
        if (!slots.length) return null;
        const strict = rounds > 1 && r === rounds;
        const res = await _cascade(slots, a, Object.assign({}, t, { total: left }), strict);
        if (res) return res;
    }
    return null;
}

function hasKeys() { return ['gemini', 'groq', 'openrouter'].some(p => _keysOf(p).length > 0); }

function status() {
    return {
        name: CFG.name,
        keys: { gemini: _keysOf('gemini').length, groq: _keysOf('groq').length, openrouter: _keysOf('openrouter').length },
        blocked: Array.from(_blocks.entries()).filter(([, u]) => u > Date.now()).map(([id, u]) => id + ' (' + Math.round((u - Date.now()) / 1000) + 's)'),
        order: _buildSlots(false).slice(0, 7).map(s => s.provider + '/' + s.model)
    };
}
function reset() {
    _blocks.clear(); _strikes.clear();
    _ls.set(BLOCK_STORE, '{}');
}

return { ask, parseJSON, stripMarkdown, stripThink, hasKeys, status, reset, MODELS };
})({
    name: 'agentdash',
    title: 'AI Agent Dashboard',
    keys: { gemini: AGD_GEMINI_KEYS, groq: AGD_GROQ_KEYS, openrouter: AGD_OPENROUTER_KEYS },
    timing: {
        text: { total: 9000, perCall: 6000, hedge: 2200, parallel: 2 }
    }
});

const _fs = () => firebase.firestore();
const _el = id => document.getElementById(id);

let _phone = null;
let _district = 'dhaka';
let _risk = null;
let _assets = [];
let _safeLoanLimit = 0;

document.addEventListener('DOMContentLoaded', async () => {
    _phone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
    if (!_phone) return window.location.href = 'login.html';

    initFarmChecklist();
    renderMarketTrends();
    await loadDashboardData();
});

async function loadDashboardData() {
    try {
        const userDoc = await _fs().collection('users').doc(_phone).get();
        if (userDoc.exists) {
            const data = userDoc.data();
            const d = data.district || data.city;
            if (d && window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[String(d).toLowerCase()]) {
                _district = String(d).toLowerCase();
            }
        }

        const assetsSnap = await _fs().collection('users').doc(_phone).collection('wealth_assets').get();
        let netWorth = 0;
        _assets = [];
        assetsSnap.forEach(doc => {
            const d = doc.data();
            netWorth += Number(d.value) || 0;
            _assets.push({ id: doc.id, ...d });
        });
        if (_el('totalNetWorth')) _el('totalNetWorth').textContent = '৳ ' + netWorth.toLocaleString('en-IN');

        if (window.DVCreditReadiness) {
            const creditData = await window.DVCreditReadiness.compute(_phone);
            if (creditData.ok && !creditData.empty) {
                if (_el('creditScore')) _el('creditScore').textContent = creditData.score;
                _safeLoanLimit = creditData.safeLoan ? creditData.safeLoan.limit : 0;
            }
        }

        if (typeof window.fetchLiveRiskData === 'function') {
            _risk = await window.fetchLiveRiskData(_district);
            renderRiskStatus(_risk);
        }

        generateActions(_risk, _safeLoanLimit);
        loadHistory();

    } catch (err) {
        console.error('Dashboard load failed:', err);
        if (_el('actionsContainer')) {
            _el('actionsContainer').innerHTML = '<div style="color:#dc2626;text-align:center;padding:1rem;">Failed to load AI data. Please refresh.</div>';
        }
    }
}

/* ============================================================
   INTERACTIVE FARM CHECKLIST (24-HOUR REWARD COOLDOWN)
   - Complete all 4 tasks  -> +50 points (once per 24 hours)
   - Claim time is stored in Firestore (users/{phone}.lastRewardClaimAt)
     so it can't be repeated by clearing the browser or switching device.
   - Before 24h passes, ticking the checklist again turns it red.
   - 10 points = ৳20  (50 points = ৳100)
   ============================================================ */
const REWARD_COOLDOWN_MS = 24 * 60 * 60 * 1000;
const REWARD_POINTS = 50;
const POINT_TO_TAKA = 2;

/* Total points ever earned. Old accounts have no lifetimePoints field, so rebuild it:
   current points + points already converted to money (৳2 per point). */
function calcLifetimePoints(d) {
    d = d || {};
    if (d.lifetimePoints != null) return Math.floor(d.lifetimePoints);
    return Math.floor((d.farmPoints || 0) + (d.personalBank || 0) / POINT_TO_TAKA);
}

let _lastClaimMs = 0;
let _claiming = false;
let _cooldownTimer = null;

function injectChecklistStyles() {
    if (document.getElementById('dcExtraStyles')) return;
    const st = document.createElement('style');
    st.id = 'dcExtraStyles';
    st.textContent =
        '.dc-item.dc-denied{background:#FEF2F2!important;color:#DC2626!important;border-color:#FCA5A5!important;animation:dcShake .35s}' +
        '@keyframes dcShake{0%,100%{transform:translateX(0)}25%{transform:translateX(-5px)}75%{transform:translateX(5px)}}' +
        '#dcLockMsg{display:none;margin-top:10px;padding:9px 12px;border-radius:10px;background:#FEF2F2;border:1px solid #FCA5A5;color:#B91C1C;font-size:.78rem;font-weight:800;text-align:center}';
    document.head.appendChild(st);
}

function fmtRemaining(ms) {
    const t = Math.max(0, Math.floor(ms / 1000));
    const h = String(Math.floor(t / 3600)).padStart(2, '0');
    const m = String(Math.floor((t % 3600) / 60)).padStart(2, '0');
    const s = String(t % 60).padStart(2, '0');
    return h + ':' + m + ':' + s;
}

function msUntilNextClaim() {
    return Math.max(0, (_lastClaimMs + REWARD_COOLDOWN_MS) - Date.now());
}
function inCooldown() { return msUntilNextClaim() > 0; }

function toMillis(v) {
    if (!v) return 0;
    if (typeof v.toMillis === 'function') return v.toMillis();
    return Number(v) || 0;
}

async function initFarmChecklist() {
    const list = _el('dcList');
    if (!list) return;
    injectChecklistStyles();

    const progKey = 'dv_checklist_progress_' + _phone;
    let saved = {};
    try { saved = JSON.parse(localStorage.getItem(progKey) || '{}'); } catch (_) {}

    const boxes = list.querySelectorAll('input');
    const actions = {
        'ledger': 'account.html',
        'health': 'ai.html',
        'weather': 'climate-dashboard.html',
        'saving': 'finance-copilot.html'
    };

    // Last claim time comes from Firestore (not the browser)
    try {
        const snap = await _fs().collection('users').doc(_phone).get();
        _lastClaimMs = toMillis((snap.data() || {}).lastRewardClaimAt);
    } catch (e) { console.error('Could not read last claim time:', e); }

    // Lock message
    let lockMsg = _el('dcLockMsg');
    if (!lockMsg) {
        lockMsg = document.createElement('div');
        lockMsg.id = 'dcLockMsg';
        list.parentNode.insertBefore(lockMsg, list.nextSibling);
    }
    let lockMsgTimer = null;

    function deny(label) {
        if (label) {
            label.classList.remove('dc-denied');
            void label.offsetWidth;
            label.classList.add('dc-denied');
            setTimeout(() => label.classList.remove('dc-denied'), 2500);
        }
        lockMsg.textContent = '🔒 Reward already claimed. You can claim again in ' + fmtRemaining(msUntilNextClaim());
        lockMsg.style.display = 'block';
        clearTimeout(lockMsgTimer);
        lockMsgTimer = setTimeout(() => { lockMsg.style.display = 'none'; }, 3500);
    }

    function resetChecklist() {
        saved = {};
        try { localStorage.removeItem(progKey); } catch (_) {}
        boxes.forEach(b => { b.checked = false; });
        render();
    }

    function startCountdown() {
        clearInterval(_cooldownTimer);
        _cooldownTimer = setInterval(() => {
            const cdEl = _el('dcCountdown');
            if (inCooldown()) {
                if (cdEl) cdEl.textContent = fmtRemaining(msUntilNextClaim());
            } else {
                clearInterval(_cooldownTimer);
                resetChecklist(); // 24h passed -> new round
            }
        }, 1000);
    }

    function render() {
        const cd = inCooldown();
        let n = 0;
        boxes.forEach(b => {
            if (cd) b.checked = true; // show completed while locked
            if (b.checked) n++;
            b.parentElement.classList.toggle('done', b.checked);
        });

        const countEl = _el('dcCount');
        const barEl = _el('dcBar');
        const rewardBox = _el('dcRewardBox');
        const cdEl = _el('dcCountdown');

        if (countEl) countEl.textContent = n + '/' + boxes.length;
        if (barEl) barEl.style.width = (n / boxes.length * 100) + '%';
        if (rewardBox) rewardBox.style.display = cd ? 'block' : 'none';
        if (cdEl) cdEl.textContent = cd ? fmtRemaining(msUntilNextClaim()) : '';
        if (cd) startCountdown();

        if (!cd && n === boxes.length && boxes.length > 0) claimReward(render);
    }

    boxes.forEach(b => {
        b.checked = !!saved[b.dataset.k];

        // Block ticking/unticking while the 24h lock is active
        b.addEventListener('click', function (e) {
            if (inCooldown()) {
                e.preventDefault();
                deny(b.parentElement);
            }
        });

        b.addEventListener('change', function () {
            if (inCooldown()) return;
            saved[b.dataset.k] = b.checked;
            try { localStorage.setItem(progKey, JSON.stringify(saved)); } catch (_) {}
            render();
        });

        b.parentElement.addEventListener('click', function (e) {
            if (e.target.tagName === 'INPUT') return;
            if (inCooldown()) {
                e.preventDefault();
                deny(b.parentElement);
                return;
            }
            const url = actions[b.dataset.k];
            if (url && confirm('Do you want to complete this task? You will be redirected to the respective page.')) {
                window.location.href = url;
            }
        });
    });

    const convertBtn = _el('dcConvertBtn');
    if (convertBtn) convertBtn.addEventListener('click', convertPointsToBank);

    render();
    refreshPointsLabel();
}

/* Claim the reward. The 24h rule is re-checked inside a transaction. */
async function claimReward(done) {
    if (_claiming || !_phone) return;
    _claiming = true;
    try {
        const ref = _fs().collection('users').doc(_phone);
        const res = await _fs().runTransaction(async tx => {
            const snap = await tx.get(ref);
            const last = toMillis((snap.data() || {}).lastRewardClaimAt);
            if (Date.now() - last < REWARD_COOLDOWN_MS) return { ok: false, last: last };
            const d = snap.data() || {};
            // lifetime total never goes down (old users: start from their current points)
            const life = calcLifetimePoints(d) + REWARD_POINTS;
            tx.set(ref, {
                farmPoints: firebase.firestore.FieldValue.increment(REWARD_POINTS),
                lifetimePoints: life,
                lastRewardClaimAt: firebase.firestore.FieldValue.serverTimestamp()
            }, { merge: true });
            return { ok: true };
        });

        if (res.ok) {
            const snap = await ref.get({ source: 'server' });
            _lastClaimMs = toMillis((snap.data() || {}).lastRewardClaimAt) || Date.now();
        } else {
            _lastClaimMs = res.last; // already claimed within 24h (e.g. on another device)
        }
    } catch (err) {
        console.error('Claim failed:', err);
        alert('❌ Could not claim reward. Please try again.');
    } finally {
        _claiming = false;
        if (typeof done === 'function') done();
        refreshPointsLabel();
    }
}

async function refreshPointsLabel() {
    const el = _el('dcPointsNow');
    const box = _el('dcWalletBox');
    if (!_phone) return;
    try {
        const snap = await _fs().collection('users').doc(_phone).get();
        const pts = Math.floor((snap.data() || {}).farmPoints || 0);
        const life = calcLifetimePoints(snap.data());
        if (el) el.innerHTML = 'Convertible points: ' + pts + ' = ৳' + (pts * POINT_TO_TAKA).toLocaleString('en-IN') +
            '<div style="font-size:.72rem;font-weight:700;margin-top:3px;">Total points earned: ' + life + '</div>';
        if (box) box.style.display = pts >= 10 ? 'block' : 'none';
    } catch (_) {}
}

async function convertPointsToBank() {
    if (!_phone) return;
    const btn = _el('dcConvertBtn');
    if (btn) btn.disabled = true;
    try {
        const ref = _fs().collection('users').doc(_phone);
        const res = await _fs().runTransaction(async tx => {
            const snap = await tx.get(ref);
            const d = snap.data() || {};
            const units = Math.floor((d.farmPoints || 0) / 10) * 10; // blocks of 10 points
            if (units <= 0) return { pts: 0, money: 0 };
            const money = units * POINT_TO_TAKA;
            tx.set(ref, {
                farmPoints: firebase.firestore.FieldValue.increment(-units),
                lifetimePoints: calcLifetimePoints(d), // keep total (computed before this conversion)
                personalBank: firebase.firestore.FieldValue.increment(money)
            }, { merge: true });
            return { pts: units, money: money };
        });
        if (res.pts > 0) {
            alert('✅ ' + res.pts + ' points converted to ৳' + res.money.toLocaleString('en-IN') + ' in your Personal Bank!\nYou can use it in the Marketplace.');
        } else {
            alert('You need at least 10 points to convert.');
        }
    } catch (err) {
        console.error('Convert failed:', err);
        alert('❌ Conversion failed. Please try again.');
    } finally {
        if (btn) btn.disabled = false;
        refreshPointsLabel();
    }
}

/* ============================================================
   AI MARKET TRENDS
   ============================================================ */
const TREND_CACHE_KEY = 'dvAgentTrends_v1';
const TREND_CACHE_MS = 6 * 3600e3;

const FALLBACK_TRENDS = [
    { animal: '🐄 Beef Cattle', trend: 'up', text: 'Demand is usually strong in Dhaka and Chittagong ahead of Eid. Buyers tend to pay more for healthy, well-fed animals.' },
    { animal: '🐐 Black Bengal Goat', trend: 'up', text: 'Steady buyer interest, with good demand in Rajshahi and Jessore markets.' },
    { animal: '🐔 Sonali Chicken', trend: 'down', text: 'Feed costs can squeeze poultry margins. Watch feed prices before restocking.' },
    { animal: '🐃 Murrah Buffalo', trend: 'stable', text: 'Dairy farmers tend to hold high-yield buffaloes, so supply stays fairly stable.' }
];

const TREND_COLORS = { up: '#059669', down: '#dc2626', stable: '#d97706' };

function _readTrendCache() {
    try {
        const c = JSON.parse(localStorage.getItem(TREND_CACHE_KEY) || 'null');
        if (c && Array.isArray(c.items) && c.items.length && Date.now() - c.t < TREND_CACHE_MS) return c.items;
    } catch (_) {}
    return null;
}
function _writeTrendCache(items) {
    try { localStorage.setItem(TREND_CACHE_KEY, JSON.stringify({ t: Date.now(), items })); } catch (_) {}
}

function _validTrends(raw) {
    const p = AGD_AI.parseJSON(raw);
    const arr = Array.isArray(p) ? p : (p && Array.isArray(p.trends) ? p.trends : null);
    if (!arr) return null;
    const items = arr.map(t => ({
        animal: String((t && t.animal) || '').slice(0, 40),
        trend: ['up', 'down', 'stable'].includes(t && t.trend) ? t.trend : 'stable',
        text: String((t && t.text) || '').slice(0, 220)
    })).filter(t => t.animal && t.text);
    return items.length >= 3 ? items.slice(0, 4) : null;
}

async function _fetchAiTrends() {
    if (!AGD_AI.hasKeys()) return null;
    const month = new Date().toLocaleString('en-GB', { month: 'long', year: 'numeric' });
    const res = await AGD_AI.ask({
        system: 'You are a livestock market analyst for Bangladesh. Reply ONLY in clean English. Return ONLY valid JSON. No markdown.',
        user: `It is ${month}. Give a short, practical market outlook for these 4 livestock types in Bangladesh: Beef Cattle, Black Bengal Goat, Sonali Chicken, Murrah Buffalo.
Use general seasonal/market reasoning only. Do NOT invent exact prices or percentage numbers.
Return JSON: {"trends":[{"animal":"🐄 Beef Cattle","trend":"up|down|stable","text":"one practical sentence under 28 words"}]}
Use these emojis: 🐄 🐐 🐔 🐃. Exactly 4 items in the order given.`,
        json: true,
        temperature: 0.4,
        maxTokens: 700,
        validate: raw => _validTrends(raw)
    });
    return res && res.data ? res.data : null;
}

function _paintTrends(container, items, isAi) {
    container.innerHTML = items.map(t => {
        const color = TREND_COLORS[t.trend] || TREND_COLORS.stable;
        const icon = t.trend === 'stable' ? 'up' : t.trend;
        return `
        <div style="display:flex; gap:12px; padding:12px; background:#f8fafc; border-radius:10px; border:1px solid #e2e8f0; border-left:4px solid ${color}; margin-bottom:10px;">
            <div style="font-size:1.25rem; font-weight:bold; color:${color}; display:flex; align-items:center; justify-content:center;">
                <i class="fas fa-arrow-trend-${icon}"></i>
            </div>
            <div>
                <div style="font-weight:800; color:#0f172a; font-size:0.8125rem; margin-bottom:2px;">${_esc(t.animal)}</div>
                <div style="font-size:0.75rem; color:#475569; line-height:1.4;">${_esc(t.text)}</div>
            </div>
        </div>`;
    }).join('') + `<div style="font-size:0.6875rem; color:#94a3b8; text-align:right;">${isAi ? 'AI estimate — not a price quote' : 'General outlook'}</div>`;
}

function _esc(v) {
    const d = document.createElement('div');
    d.textContent = String(v == null ? '' : v);
    return d.innerHTML;
}

async function renderMarketTrends() {
    const container = _el('marketTrendContainer');
    if (!container) return;

    const cached = _readTrendCache();
    if (cached) { _paintTrends(container, cached, true); return; }

    _paintTrends(container, FALLBACK_TRENDS, false);
    try {
        const items = await _fetchAiTrends();
        if (items) {
            _writeTrendCache(items);
            _paintTrends(container, items, true);
        }
    } catch (e) { console.warn('AI trends failed:', e); }
}

/* ============================================================
   RENDER RISK STATUS
   ============================================================ */
function renderRiskStatus(risk) {
    const box = _el('riskStatusContainer');
    if (!box || !risk) return;

    const flood = risk.flood?.score || 0;
    const heat = risk.heat?.level || 'normal';

    let cls = 'risk-safe';
    let text = 'Low Risk';
    if (flood > 70 || heat === 'severe') { cls = 'risk-danger'; text = 'High Risk'; }
    else if (flood > 40 || heat === 'moderate') { cls = 'risk-warning'; text = 'Moderate Risk'; }

    box.innerHTML = `
        <div class="risk-badge ${cls}">${text}</div>
        <div style="font-size:0.75rem; color:#475569; margin-top:4px;">
            Flood: <b>${flood}%</b> | Heat: <b>${heat}</b>
        </div>
    `;
}

/* ============================================================
   GENERATE AI ACTIONS
   ============================================================ */
function generateActions(risk, safeLimit) {
    const container = _el('actionsContainer');
    if (!container) return;

    const actions = [];
    const flood = risk?.flood?.score || 0;
    const heat = risk?.heat?.level || 'normal';

    if (flood > 60 || heat === 'severe') {
        actions.push({
            id: 'claim',
            type: 'danger',
            icon: 'fa-shield-virus',
            title: 'File Parametric Claim',
            desc: `Extreme weather detected in your area (Flood: ${flood}%, Heat: ${heat}). You are eligible for an automatic payout.`,
            btn: 'File Claim',
            action: () => window.location.href = 'insurance-claim.html'
        });
    }

    if (safeLimit > 0) {
        actions.push({
            id: 'loan',
            type: 'success',
            icon: 'fa-hand-holding-dollar',
            title: 'Safe Loan Limit Available',
            desc: `Based on your cashflow and weather risk, AI recommends you can safely borrow up to ৳${safeLimit.toLocaleString('en-IN')}.`,
            btn: 'Simulate Loan',
            action: () => window.location.href = 'finance-copilot.html'
        });
    }

    if (_assets.length > 1) {
        actions.push({
            id: 'rebalance',
            type: 'warning',
            icon: 'fa-chart-pie',
            title: 'Portfolio Rebalancing',
            desc: `You have ${_assets.length} assets. AI suggests selling older non-productive animals and reinvesting in high-yield breeds.`,
            btn: 'Open Wealth Agent',
            action: () => window.location.href = 'wealth-agent.html'
        });
    }

    if (!actions.length) {
        container.innerHTML = `<div style="text-align:center;padding:2rem;color:#64748b;"><i class="fas fa-check-circle" style="color:#10b981;font-size:2rem;margin-bottom:1rem;"></i><div>All systems normal. No immediate actions required.</div></div>`;
        return;
    }

    container.innerHTML = actions.map(a => `
        <div class="action-card action-${a.type}">
            <div class="action-content">
                <h4><i class="fas ${a.icon}"></i> ${a.title}</h4>
                <p>${a.desc}</p>
            </div>
            <button class="action-btn" onclick="window.__agentAction_${a.id}()">${a.btn}</button>
        </div>
    `).join('');

    actions.forEach(a => { window[`__agentAction_${a.id}`] = a.action; });
    renderAdvisorNote(risk, safeLimit);
}

/* ============================================================
   AI ADVISOR NOTE
   ============================================================ */
async function renderAdvisorNote(risk, safeLimit) {
    const container = _el('actionsContainer');
    if (!container || !AGD_AI.hasKeys()) return;

    const flood = risk?.flood?.score || 0;
    const heat = risk?.heat?.level || 'normal';
    const key = `dvAgentNote_${_district}_${flood}_${heat}_${_assets.length}_${safeLimit}`;
    let note = null;
    try { note = sessionStorage.getItem(key); } catch (_) {}

    if (!note) {
        try {
            const res = await AGD_AI.ask({
                system: 'You are DailyVet Farm Finance Advisor for Bangladesh. Reply ONLY in clean English, plain text, no markdown, no lists.',
                user: `Farmer data: district ${_district}; flood risk ${flood}%; heat level ${heat}; ${_assets.length} livestock assets; safe loan limit ৳${safeLimit}.
Write exactly 2 short practical sentences (max 45 words total) on what the farmer should do first today. Do not promise returns or payouts.`,
                temperature: 0.4,
                maxTokens: 220,
                validate: raw => {
                    const t = AGD_AI.stripMarkdown(raw);
                    return t && t.length > 20 && t.length < 500 ? t : null;
                }
            });
            note = res && res.data;
            if (note) { try { sessionStorage.setItem(key, note); } catch (_) {} }
        } catch (_) { note = null; }
    }
    if (!note || !document.body.contains(container)) return;

    const old = _el('agentAdvisorNote');
    if (old) old.remove();
    container.insertAdjacentHTML('afterbegin', `
        <div id="agentAdvisorNote" style="padding:12px 14px; margin-bottom:12px; background:#f0fdf4; border:1px solid #bbf7d0; border-left:4px solid #059669; border-radius:10px;">
            <div style="font-weight:800; color:#065f46; font-size:0.8125rem; margin-bottom:2px;"><i class="fas fa-robot"></i> AI Advisor</div>
            <div style="font-size:0.75rem; color:#166534; line-height:1.5;">${_esc(note)}</div>
        </div>`);
}

/* ============================================================
   LOAD HISTORY
   ============================================================ */
async function loadHistory() {
    const container = _el('recentActionsContainer');
    if (!container) return;

    try {
        const snap = await _fs().collection('users').doc(_phone)
            .collection('ai_action_plans')
            .orderBy('createdAtMs', 'desc')
            .limit(5)
            .get();

        if (snap.empty) {
            container.innerHTML = '<div style="color:#64748b;font-size:0.8125rem;text-align:center;padding:1rem;">No recent actions executed.</div>';
            return;
        }

        container.innerHTML = snap.docs.map(doc => {
            const d = doc.data();
            const statusCls = d.status === 'executed' ? 'status-executed' : 'status-pending';
            const dateStr = new Date(d.createdAtMs).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
            
            let title = 'Financial Action';
            if (d.action === 'micro_investment') title = 'Micro-Investment';
            else if (d.action === 'carbon_credit') title = 'Carbon Credit Earned';
            else if (d.action === 'roi_claim') title = 'ROI Claimed';
            else if (d.sell) title = `Sold ${d.sell.animalType} -> Bought ${d.buy?.animalType}`;

            return `
                <div class="history-item">
                    <div class="history-item-left">
                        <div class="history-item-title">${title}</div>
                        <div class="history-item-date">${dateStr} • ${d.summary || ''}</div>
                    </div>
                    <span class="history-status ${statusCls}">${(d.status || 'DONE').toUpperCase()}</span>
                </div>
            `;
        }).join('');

    } catch (err) {
        console.warn('History load failed:', err);
        container.innerHTML = '<div style="color:#64748b;font-size:0.8125rem;text-align:center;padding:1rem;">Could not load history.</div>';
    }
}

})();