/* DailyVet — Grass Health Score v2.0
   Combines 5 factors into a 0-100 grass health score:
   NDVI (35%) + Soil moisture (30%) + Nitrogen (15%) + pH (10%) + SOC (10%)

   Data sources:
   - NDVI: NasaModisNdvi (NASA GIBS MODIS 8-day)
   - Soil moisture: NasaPower.GWETTOP
   - Nitrogen/pH/SOC: NasaSoilGrids (ISRIC)

   v2.0 changes:
   • Now uses NasaClimate.calculateGrassHealthScore() as single source
   • Returns available:false if ALL factors missing (no silent fallback)
*/
(function () {
'use strict';

const DISTRICTS = {
    dhaka:      { lat: 23.8103, lng: 90.4125 },
    savar:      { lat: 23.8583, lng: 90.2667 },
    chittagong: { lat: 22.3569, lng: 91.7832 },
    sylhet:     { lat: 24.8949, lng: 91.8687 },
    khulna:     { lat: 22.8456, lng: 89.5403 },
    rajshahi:   { lat: 24.3745, lng: 88.6042 },
    barisal:    { lat: 22.7010, lng: 90.3535 },
    rangpur:    { lat: 25.7439, lng: 89.2752 },
    mymensingh: { lat: 24.7471, lng: 90.4203 },
    sirajganj:  { lat: 24.4533, lng: 89.7009 }
};

async function computeGrassHealthScore(districtKey) {
    const key = String(districtKey || '').toLowerCase().trim();
    const coords = DISTRICTS[key] || DISTRICTS.dhaka;

    const [ndviResult, powerData, soilData] = await Promise.all([
        (window.NasaModisNdvi && NasaModisNdvi.getNDVI) ? NasaModisNdvi.getNDVI(key).catch(() => null) : Promise.resolve(null),
        (window.NasaPower && NasaPower.getPowerData) ? NasaPower.getPowerData(coords.lat, coords.lng, 7).catch(() => null) : Promise.resolve(null),
        (window.NasaSoilGrids && NasaSoilGrids.getSoilData) ? NasaSoilGrids.getSoilData(key).catch(() => null) : Promise.resolve(null)
    ]);

    const ndvi = ndviResult && ndviResult.available ? ndviResult.ndvi : null;
    const gwettop = powerData && NasaPower.getLatest(powerData, 'GWETTOP') ? NasaPower.getLatest(powerData, 'GWETTOP').value : null;
    const nitrogen = soilData && soilData.available ? soilData.nitrogen_gkg : null;
    const ph = soilData && soilData.available ? soilData.ph : null;
    const soc = soilData && soilData.available ? soilData.soc_gkg : null;

    if (ndvi == null && gwettop == null && nitrogen == null && ph == null && soc == null) {
        return { available: false, district: key, error: 'All data sources failed' };
    }

    if (!window.NasaClimate || typeof NasaClimate.calculateGrassHealthScore !== 'function') {
        return { available: false, district: key, error: 'NasaClimate engine not loaded' };
    }

    const score = NasaClimate.calculateGrassHealthScore(ndvi, gwettop, nitrogen, ph, soc);

    return {
        available: score != null,
        district: key,
        score,
        factors: {
            ndvi: { value: ndvi, weight: 0.35, available: ndvi != null, level: ndviResult && ndviResult.level },
            soilMoisture: { value: gwettop, weight: 0.30, available: gwettop != null },
            nitrogen: { value: nitrogen, weight: 0.15, available: nitrogen != null },
            ph: { value: ph, weight: 0.10, available: ph != null },
            soc: { value: soc, weight: 0.10, available: soc != null }
        },
        timestamp: new Date().toISOString()
    };
}

window.GrassHealthScore = { computeGrassHealthScore };

console.log('[GrassHealthScore] v2.0 loaded');
})();