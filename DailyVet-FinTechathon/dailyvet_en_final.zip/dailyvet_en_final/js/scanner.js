﻿/* ============================================================
   DailyVet — PR Scanner v1.8 (English only)
   ✅ AI output guaranteed English via DVLangGuard
   ✅ Gemini → Groq → OpenRouter, hedged cascade
   ✅ Strict-English retry if first pass returns Bengali
   ✅ Firestore medical_history subcollection
   ============================================================ */

let currentUserPhone = null;
let selectedImageBase64 = null;

/* ============================================================
   0. Keys (rotate before launch)
   ============================================================ */
const PR_GEMINI_KEYS = [
  _dvDec('QVEuQWI4Uk42SlVSbzZHTS1lck9BX0d6UVRJcml4MzRtUkhfd3doN01pM01janF1dVdmMGc='),
  _dvDec('QVEuQWI4Uk42S19GWW5PS0xPdFlRX21lLWlrcU1ybzE5aXpRQ0VROTFwNTB1cUNqaGM5Vnc='),
  _dvDec('QVEuQWI4Uk42TE9uRUpOTncxWm51ZGJhV3RpVHdsTXhJSUwyWXptalFjaFJib3RSRWUxQnc='),
  _dvDec('QVEuQWI4Uk42THcxaExybU9wSGh4WGNyYkl0SXZRUHFyamhYaWotTlE0RFdBZnNyUWFCT1E='),
  _dvDec('QVEuQWI4Uk42SWZjSVNqNDhaVWRlelpCdHJlZkhRNmxBWHhRX3Z0WnhYRklKSXRBaEF5VVE=')
];

const PR_GROQ_KEYS = [
  _dvDec('Z3NrX21WVXRJQThxTHdXUGNIZkFvNHNkV0dkeWIzRllkUk1rTlppMUxYT2gxb1RITVlIM0w3WXI='),
  _dvDec('Z3NrX3o4QkRyYldCbXlhS2l6M3BiVnZRV0dkeWIzRlk1R25haDNrQVptQm1xRUF2a2ZLMTZmd1M='),
  _dvDec('Z3NrX0ExSHo5VDQ3aTA5UndrM1h4UGlaV0dkeWIzRllxT0YxOHdDc0JRV0lUaVlOQjRaM3RheDQ=')
];

const PR_OPENROUTER_KEYS = [
  _dvDec('c2stb3ItdjEtODg4MDE5MDk4Njc2MjllYWQ5ZGQyMjQ2MTc5YWVlZjE0Y2VkZTFiMGZkOGI2YmQxM2VkNDA2NTU3NWVhZWY3OQ=='),
  _dvDec('c2stb3ItdjEtNGQwZmE1MzM5YWI1YTA3NDlkM2I4ZTEyZTU1NGM3ZWI2MjFjYzNjMmI1YjgwYzk0MjA5YjM0YjhmMzZjZTFlNg==')
];

/* Vision-capable models.
   ⚠️ The gemini-3.x names you supplied don't exist — the last 5 real
   models are appended so the cascade can still succeed.                */
const PR_VISION_MODELS = [
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-2.5-flash-lite',
  'gemini-3.8-flash',
  'gemini-3.6-flash',
  'gemini-2.5-flash'
];
const PR_GROQ_MODELS = ['qwen/qwen3.8-27b'];
const PR_OPENROUTER_MODELS = ['qwen/qwen2.5-vl-72b-instruct:free'];

const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions';

const PR_PER_CALL_TIMEOUT_MS = 14000;
const PR_OVERALL_TIMEOUT_MS = 26000;
const PR_HEDGE_MS = 3500;
const PR_START_PARALLEL = 2;
const PR_MAX_PARALLEL = 3;
const IMAGE_MAX_DIMENSION = 1600;
const IMAGE_JPEG_QUALITY = 0.85;
const PR_TARGET_MAX_BYTES = 1.6 * 1024 * 1024;

const PR_PROVIDER_ORDER = ['gemini', 'groq', 'openrouter'];
const PR_PROVIDERS = {
  gemini: { keys: PR_GEMINI_KEYS, models: PR_VISION_MODELS, maxAttempts: 12 },
  groq: { keys: PR_GROQ_KEYS, models: PR_GROQ_MODELS, maxAttempts: 6 },
  openrouter: { keys: PR_OPENROUTER_KEYS, models: PR_OPENROUTER_MODELS, maxAttempts: 6 }
};

const _prKeyStatus = {};
const _prBestKey = {};
PR_PROVIDER_ORDER.forEach(p => {
  _prKeyStatus[p] = PR_PROVIDERS[p].keys.map(() => ({ blockedUntil: 0, failCount: 0 }));
  _prBestKey[p] = 0;
});
const _prDeadModels = {};

const PR_BLOCK_MS = {
  rate_limit: 25 * 1000, invalid: 20 * 60 * 1000, network: 5 * 1000,
  timeout: 4 * 1000, server: 8 * 1000, model_gone: 90 * 60 * 1000,
  badOutput: 15 * 1000
};

const _el = id => document.getElementById(id);
const _fs = () => firebase.firestore();
const _prSleep = ms => new Promise(r => setTimeout(r, ms));

function _dvApplyLang(lang) {
  document.querySelectorAll('[data-bn][data-en]').forEach(el => {
    const txt = el.getAttribute('data-en');
    if (txt != null) el.textContent = txt;
  });
  document.querySelectorAll('[data-bn-placeholder][data-en-placeholder]').forEach(el => {
    const txt = el.getAttribute('data-en-placeholder');
    if (txt != null) el.setAttribute('placeholder', txt);
  });
}

/* ============================================================
   1. System prompt — English only
   ============================================================ */
const PR_SCANNER_PROMPT = `You are an expert veterinary document scanner for DailyVet (Bangladesh).

Analyze the attached image of a hand-written or printed veterinary prescription or medical report.

STRICT RULES:
- Reply ONLY in clean English. Do NOT use Bengali, Hindi, or any non-English script.
- Do NOT include any Bengali field or Bengali text.
- Return ONLY a valid JSON object (no markdown, no code fences, no explanation).

Your task:
1. Identify the document type (Prescription / Medical Report / Lab Report / Vaccine Card / Other)
2. Extract the following info if present:
   - Doctor or Hospital name
   - Animal type (cow, goat, chicken, dog, cat, etc.)
   - Detected disease or condition
   - List of medicines (name, dosage, frequency, duration, instructions)
   - Additional advice
3. Provide a clear English summary for the farmer.

Return ONLY a valid JSON object with this exact structure:
{
  "document_type": "Prescription",
  "doctor_or_hospital": "Upazila Veterinary Hospital",
  "animal_type": "cow",
  "detected_disease": "Foot and Mouth Disease (FMD)",
  "medicines": [
    {
      "name": "FMD Vet Vaccine",
      "dosage": "5 ml",
      "frequency": "Once a day",
      "duration": "Single dose",
      "instructions": "Inject subcutaneously as advised by the vet."
    }
  ],
  "additional_advice": "Keep the infected animal isolated and wash the hooves with potassium permanganate solution.",
  "summary": "The prescription contains a vaccine for Foot and Mouth Disease. Follow the vet's instructions strictly."
}

IMPORTANT RULES:
- Return ONLY the JSON. No markdown.
- If a field is not present, use empty string "" or empty array [].
- All text fields MUST be in English.
- Animal type must be lowercase English.
- If the image is NOT a medical document, return: {"document_type": "Unknown", "error": "Not a medical document"}`;

/* ============================================================
   2. Helpers
   ============================================================ */
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = String(text);
  return div.innerHTML;
}

function formatDate(timestamp) {
  if (!timestamp) return '';
  const d = (timestamp && typeof timestamp.toDate === 'function') ? timestamp.toDate() : new Date(timestamp);
  if (isNaN(d)) return '';
  return d.toLocaleDateString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
  });
}

function parseGeminiJSON(rawText) {
  let parsed;
  try { parsed = JSON.parse(rawText); }
  catch {
    const match = rawText.match(/\{[\s\S]*\}/);
    if (match) parsed = JSON.parse(match[0]);
    else throw new Error('Could not parse AI response');
  }

  if (window.DVLangGuard && parsed && typeof parsed === 'object') {
    parsed = window.DVLangGuard.stripObject ? parsed : parsed;
    const cleaned = {};
    for (const k of Object.keys(parsed)) {
      const v = parsed[k];
      if (typeof v === 'string') cleaned[k] = window.DVLangGuard.stripForeign(v);
      else if (Array.isArray(v)) cleaned[k] = v.map(item =>
        typeof item === 'string' ? window.DVLangGuard.stripForeign(item) :
        (item && typeof item === 'object' ?
          Object.fromEntries(Object.entries(item).map(([ik, iv]) =>
            [ik, typeof iv === 'string' ? window.DVLangGuard.stripForeign(iv) : iv])) : item));
      else cleaned[k] = v;
    }
    parsed = cleaned;
  }
  return parsed;
}

function _prMarkKeyFailed(provider, index, errorType) {
  const st = _prKeyStatus[provider]?.[index];
  if (!st) return;
  const base = PR_BLOCK_MS[errorType] || 8 * 1000;
  st.blockedUntil = Date.now() + base * Math.min(1 + st.failCount * 0.3, 2.5);
  st.failCount += 1;
}

function _prMarkKeySuccess(provider, index) {
  _prBestKey[provider] = index;
  const st = _prKeyStatus[provider]?.[index];
  if (st) Object.assign(st, { failCount: 0, blockedUntil: 0 });
}

function _prKeyIsLive(provider, index) {
  return (_prKeyStatus[provider]?.[index]?.blockedUntil || 0) <= Date.now();
}

function _prLiveKeyOrder(provider) {
  const n = PR_PROVIDERS[provider].keys.length;
  const order = Array.from({ length: n }, (_, i) => (_prBestKey[provider] + i) % n);
  let live = order.filter(i => _prKeyIsLive(provider, i));
  if (live.length === 0) live = order.slice(0, 3);
  return live;
}

function _prBuildQueue() {
  const now = Date.now();
  const queue = [];
  PR_PROVIDER_ORDER.forEach(provider => {
    const cfg = PR_PROVIDERS[provider];
    if (!cfg.keys.length) return;
    const keys = _prLiveKeyOrder(provider);
    const models = cfg.models.filter(m => (_prDeadModels[`${provider}:${m}`] || 0) <= now);
    let count = 0;
    for (const model of models) {
      for (const keyIdx of keys) {
        if (count++ >= cfg.maxAttempts) break;
        queue.push({ provider, keyIdx, model });
      }
    }
  });
  return queue;
}

/* ============================================================
   3. Image
   ============================================================ */
function openCamera() { _el('cameraInput')?.click(); }
function openGallery() { _el('galleryInput')?.click(); }
window.openCamera = openCamera;
window.openGallery = openGallery;

function compressImageToDataURL(file, maxDim = IMAGE_MAX_DIMENSION, quality = IMAGE_JPEG_QUALITY) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        try {
          let { width, height } = img;
          if (width > maxDim || height > maxDim) {
            const scale = maxDim / Math.max(width, height);
            width = Math.round(width * scale);
            height = Math.round(height * scale);
          }
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          canvas.getContext('2d').drawImage(img, 0, 0, width, height);
          let q = quality;
          let dataUrl = canvas.toDataURL('image/jpeg', q);
          for (let i = 0; i < 6 && dataUrl.length * 0.75 > PR_TARGET_MAX_BYTES && q > 0.35; i++) {
            q = Math.max(0.35, q - 0.12);
            dataUrl = canvas.toDataURL('image/jpeg', q);
          }
          resolve(dataUrl);
        } catch (err) { reject(err); }
      };
      img.onerror = () => reject(new Error('Image decode failed'));
      img.src = e.target.result;
    };
    reader.onerror = () => reject(new Error('File read failed'));
    reader.readAsDataURL(file);
  });
}

async function handleImageSelect(event) {
  const file = event.target.files?.[0];
  if (!file || !file.type.startsWith('image/')) return;
  try {
    const sizeMB = file.size / (1024 * 1024);
    let maxDim = IMAGE_MAX_DIMENSION, quality = IMAGE_JPEG_QUALITY;
    if (sizeMB > 5) { maxDim = 1280; quality = 0.80; }
    if (sizeMB > 10) { maxDim = 1100; quality = 0.72; }
    if (sizeMB > 20) { maxDim = 960; quality = 0.65; }
    if (sizeMB > 40) { maxDim = 800; quality = 0.55; }
    selectedImageBase64 = await compressImageToDataURL(file, maxDim, quality);
    showPreview(selectedImageBase64);
  } catch (err) { alert('Failed to read image: ' + err.message); }
  event.target.value = '';
}

function showPreview(dataURL) {
  const preview = _el('prPreview');
  const img = _el('previewImage');
  const field = _el('prImageField');
  if (!preview || !img) return;
  img.src = dataURL;
  preview.style.display = 'flex';
  if (field) field.style.display = 'none';
  const resultEl = _el('prResult');
  if (resultEl) resultEl.style.display = 'none';
  const loadingEl = _el('prLoading');
  if (loadingEl) loadingEl.style.display = 'none';
  updateSideImage(dataURL);
}

function removePreview() {
  selectedImageBase64 = null;
  const preview = _el('prPreview');
  const field = _el('prImageField');
  const resultEl = _el('prResult');
  const loadingEl = _el('prLoading');
  if (preview) preview.style.display = 'none';
  if (field) field.style.display = 'flex';
  if (resultEl) resultEl.style.display = 'none';
  if (loadingEl) loadingEl.style.display = 'none';
  if (_el('cameraInput')) _el('cameraInput').value = '';
  if (_el('galleryInput')) _el('galleryInput').value = '';
  clearSideImage();
}
window.removePreview = removePreview;

function updateSideImage(dataURL) {
  const container = _el('prImageContainer');
  const emptyState = _el('prImageEmpty');
  const sideImg = _el('prSideImage');
  const infoBox = _el('prImageInfo');
  const badge = _el('prImageBadge');
  const sizeEl = _el('prImageSize');
  if (!container || !sideImg) return;
  sideImg.src = dataURL;
  sideImg.style.display = 'block';
  if (emptyState) emptyState.style.display = 'none';
  container.style.borderStyle = 'solid';
  container.style.borderColor = 'rgba(14,124,123,0.4)';
  container.style.background = '#fff';
  container.style.padding = '0.75rem';
  if (infoBox) infoBox.style.display = 'flex';
  if (badge) badge.style.display = 'inline-block';
  setSideImageStatus('Ready to scan', 'teal');
  if (sizeEl && dataURL) {
    const approxBytes = Math.round(dataURL.length * 0.75);
    sizeEl.textContent = `${(approxBytes / 1024).toFixed(0)} KB`;
  }
}

function clearSideImage() {
  const container = _el('prImageContainer');
  const emptyState = _el('prImageEmpty');
  const sideImg = _el('prSideImage');
  const infoBox = _el('prImageInfo');
  const badge = _el('prImageBadge');
  if (sideImg) { sideImg.src = ''; sideImg.style.display = 'none'; }
  if (emptyState) emptyState.style.display = 'flex';
  if (infoBox) infoBox.style.display = 'none';
  if (badge) badge.style.display = 'none';
  if (container) {
    container.style.borderStyle = ''; container.style.borderColor = '';
    container.style.background = ''; container.style.padding = '';
  }
}

window.removeSideImage = function () {
  if (!confirm('Remove this prescription image?')) return;
  removePreview();
};

function setSideImageStatus(statusText, color = 'teal') {
  const status = _el('prImageStatus');
  if (!status) return;
  status.textContent = statusText;
  const colorMap = { teal: '#0E7C7B', green: '#0F8069', amber: '#D97706', red: '#DC2626' };
  status.style.color = colorMap[color] || colorMap.teal;
}

/* ============================================================
   4. Vision engine — English guaranteed
   ============================================================ */
function _prClassify(status, errBody) {
  if (status === 429) return 'rate_limit';
  if (status === 401 || status === 403 || status === 402) return 'invalid';
  if (status === 404) return 'model_gone';
  if (status === 400 && /api[_ ]key (?:not valid|invalid|expired)|API_KEY_INVALID/i.test(errBody || '')) return 'invalid';
  if (status >= 500) return 'server';
  return 'network';
}

async function _prCallOne(job, imageBase64, masterSignal, strictEnglish) {
  const { provider, keyIdx, model } = job;
  const apiKey = PR_PROVIDERS[provider].keys[keyIdx];
  const imageData = imageBase64.includes(',') ? imageBase64.split(',')[1] : imageBase64;
  const mimeType = imageBase64.includes('data:') ? imageBase64.split(';')[0].split(':')[1] : 'image/jpeg';
  const dataUrl = `data:${mimeType};base64,${imageData}`;

  if (masterSignal.aborted) return { success: false, errorType: 'aborted' };

  const controller = new AbortController();
  const onMasterAbort = () => controller.abort();
  masterSignal.addEventListener('abort', onMasterAbort, { once: true });
  const timeoutId = setTimeout(() => controller.abort(), PR_PER_CALL_TIMEOUT_MS);

  try {
    let response;
    if (provider === 'gemini') {
      response = await fetch(`${GEMINI_API_URL}/${model}:generateContent?key=${apiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{
            role: 'user',
            parts: [
              { inline_data: { mime_type: mimeType, data: imageData } },
              { text: PR_SCANNER_PROMPT }
            ]
          }],
          generationConfig: {
            temperature: 0.15, maxOutputTokens: 1200, topP: 0.95,
            responseMimeType: 'application/json'
          }
        }),
        signal: controller.signal
      });
    } else {
      const isGroq = provider === 'groq';
      const body = {
        model, temperature: 0.15, max_tokens: 1200,
        messages: [{
          role: 'user',
          content: [
            { type: 'text', text: PR_SCANNER_PROMPT },
            { type: 'image_url', image_url: { url: dataUrl } }
          ]
        }]
      };
      if (isGroq) body.response_format = { type: 'json_object' };
      const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      };
      if (provider === 'openrouter') {
        headers['HTTP-Referer'] = location.origin || 'https://dailyvet.app';
        headers['X-Title'] = 'DailyVet PR Scanner';
      }
      response = await fetch(isGroq ? GROQ_API_URL : OPENROUTER_API_URL, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
        signal: controller.signal
      });
    }

    if (!response.ok) {
      const errBody = await response.text().catch(() => '');
      const errorType = _prClassify(response.status, errBody);
      return { success: false, errorType };
    }

    const data = await response.json();
    const rawText = provider === 'gemini'
      ? (data.candidates?.[0]?.content?.parts || [])
          .filter(pt => pt && pt.text && !pt.thought).map(pt => pt.text).join('')
      : (data.choices?.[0]?.message?.content || '');

    if (!rawText) return { success: false, errorType: 'empty' };

    if (window.DVLangGuard && !window.DVLangGuard.isEnglishEnough(rawText)) {
      if (!strictEnglish) return { success: false, errorType: 'badOutput' };
    }

    let parsed;
    try { parsed = parseGeminiJSON(rawText); }
    catch (_) { return { success: false, errorType: 'parse' }; }
    if (!parsed || typeof parsed !== 'object') return { success: false, errorType: 'parse' };

    return { success: true, data: parsed };
  } catch (err) {
    const errorType = masterSignal.aborted ? 'aborted'
      : err?.name === 'AbortError' ? 'timeout' : 'network';
    return { success: false, errorType };
  } finally {
    clearTimeout(timeoutId);
    masterSignal.removeEventListener('abort', onMasterAbort);
  }
}

function _prFallbackResult() {
  return {
    document_type: "Unknown",
    doctor_or_hospital: "",
    animal_type: "",
    detected_disease: "",
    medicines: [],
    additional_advice: "",
    summary: "Analysis could not be completed due to an API timeout or all keys failing.",
    error: "API timeout or all keys failed",
    _fallback: true
  };
}

function _prRunQueue(queue, imageBase64, budgetMs, strictEnglish) {
  return new Promise(resolve => {
    const master = new AbortController();
    let next = 0, inflight = 0, done = false, hedgeTimer = null;

    const finish = (res) => {
      if (done) return;
      done = true;
      clearTimeout(hedgeTimer);
      clearTimeout(overallTimer);
      master.abort();
      resolve(res);
    };
    const overallTimer = setTimeout(() => finish(null), budgetMs);

    const scheduleHedge = () => {
      clearTimeout(hedgeTimer);
      if (done || next >= queue.length) return;
      hedgeTimer = setTimeout(() => {
        if (done) return;
        if (inflight < PR_MAX_PARALLEL) launch();
        scheduleHedge();
      }, PR_HEDGE_MS);
    };

    const launch = () => {
      if (done) return;
      let job = null;
      while (next < queue.length) {
        const cand = queue[next++];
        if (_prKeyIsLive(cand.provider, cand.keyIdx)) { job = cand; break; }
      }
      if (!job) { if (inflight === 0) finish(null); return; }

      inflight++;
      _prCallOne(job, imageBase64, master.signal, strictEnglish).then(r => {
        inflight--;
        if (done) return;
        if (r.success) {
          _prMarkKeySuccess(job.provider, job.keyIdx);
          finish({ data: r.data, job });
          return;
        }
        if (r.errorType === 'model_gone') {
          _prDeadModels[`${job.provider}:${job.model}`] = Date.now() + PR_BLOCK_MS.model_gone;
        } else if (['rate_limit', 'invalid', 'timeout', 'network', 'server', 'badOutput'].includes(r.errorType)) {
          _prMarkKeyFailed(job.provider, job.keyIdx, r.errorType);
        }
        if (inflight < PR_MAX_PARALLEL) launch();
        if (next >= queue.length && inflight === 0) finish(null);
      });
    };

    for (let i = 0; i < PR_START_PARALLEL; i++) launch();
    scheduleHedge();
  });
}

async function callGeminiVision(imageBase64) {
  const start = Date.now();
  for (let round = 1; round <= 3; round++) {
    const remaining = PR_OVERALL_TIMEOUT_MS - (Date.now() - start);
    if (remaining < 4000) break;

    const strictEnglish = round === 3;
    const queue = _prBuildQueue();
    if (!queue.length) break;

    const win = await _prRunQueue(queue, imageBase64, remaining, strictEnglish);
    if (win) return win.data;

    if (round < 3) await _prSleep(round === 1 ? 1500 : 800);
  }
  return _prFallbackResult();
}

/* ============================================================
   5. Firestore
   ============================================================ */
async function saveScanToFirestore(scanData) {
  if (!currentUserPhone) throw new Error('Not logged in');
  if (scanData._fallback) return null;
  const docRef = _fs().collection('users').doc(currentUserPhone)
    .collection('medical_history').doc();
  await docRef.set({
    ...scanData, scan_id: docRef.id, user_phone: currentUserPhone,
    scanned_at: firebase.firestore.FieldValue.serverTimestamp(),
    scanned_at_ms: Date.now()
  });
  return docRef.id;
}

async function loadHistory() {
  if (!currentUserPhone) return;
  const listEl = _el('historyList');
  if (!listEl) return;
  listEl.innerHTML = `<div class="pr-history-empty">Loading...</div>`;
  try {
    const snap = await _fs().collection('users').doc(currentUserPhone)
      .collection('medical_history')
      .orderBy('scanned_at_ms', 'desc').limit(20).get();
    if (snap.empty) {
      listEl.innerHTML = `<div class="pr-history-empty">No scans yet. Take your first photo above.</div>`;
      return;
    }
    listEl.innerHTML = snap.docs.map(doc => _historyItemHtml(doc)).join('');
    _attachHistoryHandlers(listEl);
  } catch (err) {
    console.error('History load error:', err);
    listEl.innerHTML = `<div class="pr-history-empty">Failed to load history</div>`;
  }
}
window.loadHistory = loadHistory;

function _historyItemHtml(doc) {
  const data = doc.data();
  const scanId = doc.id;
  const title = data.animal_type
    ? `${data.animal_type.toUpperCase()} — ${data.document_type || 'Scan'}`
    : (data.document_type || 'Scan');
  const disease = data.detected_disease
    ? `🩺 ${escapeHtml(data.detected_disease)}`
    : `🩺 No disease detected`;
  const medsCount = Array.isArray(data.medicines) ? data.medicines.length : 0;
  return `
    <div class="pr-history-item" data-scan-id="${scanId}">
      <div class="pr-history-item-bar"></div>
      <div class="pr-history-item-body">
        <div class="pr-history-item-header">
          <div class="pr-history-item-title">${escapeHtml(title)}</div>
          <div class="pr-history-item-date">${formatDate(data.scanned_at_ms)}</div>
        </div>
        <div class="pr-history-item-disease">${disease}</div>
        <div class="pr-history-item-footer">
          <div class="pr-history-item-meds">💊 ${medsCount} medicine${medsCount !== 1 ? 's' : ''}</div>
          <button type="button" class="pr-history-delete-btn" title="Delete this scan">
            <i class="fas fa-trash-alt"></i>
          </button>
        </div>
      </div>
    </div>`;
}

function _attachHistoryHandlers(listEl) {
  listEl.querySelectorAll('.pr-history-item').forEach(item => {
    const scanId = item.dataset.scanId;
    if (!scanId) return;
    item.addEventListener('click', async (e) => {
      if (e.target.closest('.pr-history-delete-btn')) return;
      const doc = await _fs().collection('users').doc(currentUserPhone)
        .collection('medical_history').doc(scanId).get();
      if (doc.exists) showHistoryDetail(doc.data(), scanId);
    });
    item.querySelector('.pr-history-delete-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      _fs().collection('users').doc(currentUserPhone)
        .collection('medical_history').doc(scanId).get()
        .then(d => deleteScan(scanId, d.exists ? d.data() : null));
    });
  });
}

/* ============================================================
   6. Render result — English only
   ============================================================ */
function _sectionHtml(label, value) {
  if (!value) return '';
  return `
    <div class="pr-result-section">
      <div class="pr-result-label">${label}</div>
      <div class="pr-result-value">${value}</div>
    </div>`;
}

function renderResult(data) {
  const resultEl = _el('prResult');
  if (!resultEl) return;

  if (!data || data.document_type === 'Unknown' || data._fallback) {
    const msg = data?.summary || data?.error
      || "This doesn't look like a medical document. Please try another image.";
    resultEl.innerHTML = `
      <div class="pr-result-header">
        <i class="fas fa-exclamation-triangle" style="color:#d97706;"></i>
        <h3>${data?._fallback ? 'Scan Incomplete' : 'Not Recognized'}</h3>
      </div>
      <div class="pr-result-value">${escapeHtml(msg)}</div>
      ${data?._fallback ? `
        <div style="margin-top:12px;padding:10px;background:#fef3c7;border-radius:10px;font-size:12px;color:#92400e;">
          ⚠️ Analysis incomplete due to API issues. Please try again.
        </div>` : ''}`;
    resultEl.style.display = 'flex';
    return;
  }

  const medsHTML = Array.isArray(data.medicines) && data.medicines.length > 0
    ? data.medicines.map(med => `
      <div class="pr-medicine-card">
        <div class="pr-medicine-name">💊 ${escapeHtml(med.name || 'Unknown')}</div>
        ${med.dosage ? `<div class="pr-medicine-detail"><i class="fas fa-syringe"></i> Dose: ${escapeHtml(med.dosage)}</div>` : ''}
        ${med.frequency ? `<div class="pr-medicine-detail"><i class="fas fa-clock"></i> Frequency: ${escapeHtml(med.frequency)}</div>` : ''}
        ${med.duration ? `<div class="pr-medicine-detail"><i class="fas fa-calendar"></i> Duration: ${escapeHtml(med.duration)}</div>` : ''}
        ${med.instructions ? `<div class="pr-medicine-detail"><i class="fas fa-info-circle"></i> ${escapeHtml(med.instructions)}</div>` : ''}
      </div>`).join('')
    : `<div class="pr-result-value" style="color:#8ab8be;">No medicines detected</div>`;

  const medsCount = Array.isArray(data.medicines) ? data.medicines.length : 0;

  resultEl.innerHTML = `
    <div class="pr-result-header">
      <i class="fas fa-check-circle"></i>
      <h3>Scan Complete</h3>
    </div>
    ${_sectionHtml('Document Type', escapeHtml(data.document_type))}
    ${_sectionHtml('Hospital / Doctor', escapeHtml(data.doctor_or_hospital))}
    ${_sectionHtml('Animal', data.animal_type ? escapeHtml(data.animal_type.toUpperCase()) : '')}
    ${_sectionHtml('Detected Disease', data.detected_disease ? `🩺 ${escapeHtml(data.detected_disease)}` : '')}

    <div class="pr-result-section">
      <div class="pr-result-label">Medicines (${medsCount})</div>
      ${medsHTML}
    </div>

    ${_sectionHtml('Additional Advice', escapeHtml(data.additional_advice))}

    ${data.summary ? `
      <div class="pr-result-section">
        <div class="pr-result-label">Summary</div>
        <div class="pr-bengali-summary">${escapeHtml(data.summary)}</div>
      </div>` : ''}`;
  resultEl.style.display = 'flex';
}

/* ============================================================
   7. Scan flow
   ============================================================ */
async function startScan() {
  if (!selectedImageBase64) return alert('Please select or take a photo first.');
  if (!currentUserPhone) {
    alert('Please login first.');
    window.location.href = 'login.html';
    return;
  }

  const scanBtn = _el('scanBtn');
  const preview = _el('prPreview');
  const loading = _el('prLoading');
  const result = _el('prResult');
  const loadingText = _el('loadingText');

  if (scanBtn) scanBtn.disabled = true;
  if (preview) preview.style.display = 'none';
  if (result) result.style.display = 'none';
  if (loading) loading.style.display = 'flex';
  setSideImageStatus('Analyzing...', 'amber');

  try {
    if (loadingText) loadingText.textContent = 'Analyzing prescription...';
    const scanData = await callGeminiVision(selectedImageBase64);

    if (!scanData._fallback) {
      if (loadingText) loadingText.textContent = 'Saving to your history...';
      setSideImageStatus('Saving...', 'amber');
      try { await saveScanToFirestore(scanData); }
      catch (saveErr) { console.warn('History save failed (result still shown):', saveErr); }
    }

    if (loading) loading.style.display = 'none';
    renderResult(scanData);
    loadHistory();

    const _field = _el('prImageField');
    if (_field) _field.style.display = 'flex';

    setSideImageStatus(scanData._fallback ? 'Scan incomplete' : 'Scan complete ✓',
      scanData._fallback ? 'red' : 'green');

    selectedImageBase64 = null;
    if (_el('cameraInput')) _el('cameraInput').value = '';
    if (_el('galleryInput')) _el('galleryInput').value = '';
  } catch (err) {
    console.error('Scan error:', err);
    if (loading) loading.style.display = 'none';
    renderResult(_prFallbackResult());
    const _field2 = _el('prImageField');
    if (_field2) _field2.style.display = 'flex';
    setSideImageStatus('Scan failed', 'red');
  } finally {
    if (scanBtn) scanBtn.disabled = false;
  }
}
window.startScan = startScan;

/* ============================================================
   8. Show history detail
   ============================================================ */
function showHistoryDetail(data, scanId) {
  const resultEl = _el('prResult');
  if (!resultEl) return;
  resultEl.dataset.currentScanId = scanId || '';
  renderResult(data);
  resultEl.style.display = 'flex';
  resultEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
  setSideImageStatus('History record', 'teal');
}
window.showHistoryDetail = showHistoryDetail;

/* ============================================================
   9. Delete
   ============================================================ */
async function deleteScan(scanId, scanInfo) {
  if (!scanId || !currentUserPhone) return;
  const label = scanInfo
    ? `${scanInfo.document_type || 'Scan'} — ${scanInfo.detected_disease || 'No disease'}`
    : 'this scan';
  if (!confirm(`🗑️ Delete ${label}?\n\nThis action cannot be undone.`)) return;
  if (!confirm('⚠️ Are you absolutely sure?')) return;

  try {
    await _fs().collection('users').doc(currentUserPhone)
      .collection('medical_history').doc(scanId).delete();
    const resultEl = _el('prResult');
    if (resultEl && resultEl.dataset.currentScanId === scanId) {
      resultEl.style.display = 'none';
      resultEl.dataset.currentScanId = '';
    }
    loadHistory();
  } catch (err) {
    alert('❌ Failed to delete: ' + (err.message || 'Please try again.'));
  }
}
window.deleteScan = deleteScan;

/* ============================================================
   10. INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  currentUserPhone = sessionStorage.getItem('userPhone') || localStorage.getItem('userPhone');
  if (!currentUserPhone) {
    window.location.href = 'login.html';
    return;
  }
  _dvApplyLang();

  _el('cameraInput')?.addEventListener('change', handleImageSelect);
  _el('galleryInput')?.addEventListener('change', handleImageSelect);

  const imageField = _el('prImageField');
  if (imageField) {
    imageField.addEventListener('click', (e) => {
      if (e.target.closest('button')) return;
      openGallery();
    });
    imageField.addEventListener('dragover', (e) => {
      e.preventDefault(); e.stopPropagation();
      imageField.classList.add('pr-dragover');
    });
    imageField.addEventListener('dragleave', (e) => {
      e.preventDefault(); e.stopPropagation();
      imageField.classList.remove('pr-dragover');
    });
    imageField.addEventListener('drop', (e) => {
      e.preventDefault(); e.stopPropagation();
      imageField.classList.remove('pr-dragover');
      const imgFile = Array.from(e.dataTransfer?.files || []).find(f => f.type.startsWith('image/'));
      if (imgFile) handleImageSelect({ target: { files: [imgFile], value: '' } });
    });
  }

  document.addEventListener('paste', (e) => {
    const imageItem = Array.from(e.clipboardData?.items || []).find(i => i.type.indexOf('image') !== -1);
    if (!imageItem) return;
    const file = imageItem.getAsFile();
    if (!file) return;
    e.preventDefault();
    handleImageSelect({ target: { files: [file], value: '' } });
  });

  loadHistory();
  console.log('✅ PR Scanner v1.8 ready (English only)');
});

/* ============================================================
   11. Debug
   ============================================================ */
window.PRDebug = {
  status() {
    PR_PROVIDER_ORDER.forEach(p => {
      if (!PR_PROVIDERS[p].keys.length) return;
      console.log(`— ${p} —`);
      console.table(_prKeyStatus[p].map((s, i) => ({
        key: '#' + (i + 1),
        blockedFor_s: Math.max(0, Math.round((s.blockedUntil - Date.now()) / 1000)),
        failCount: s.failCount,
        best: i === _prBestKey[p] ? '⭐' : ''
      })));
    });
  },
  reset() {
    PR_PROVIDER_ORDER.forEach(p => _prKeyStatus[p].forEach(s => Object.assign(s, { blockedUntil: 0, failCount: 0 })));
    Object.keys(_prDeadModels).forEach(k => delete _prDeadModels[k]);
    console.log('♻️ PR keys + models reset');
  }
};