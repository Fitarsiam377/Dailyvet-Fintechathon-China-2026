/* DailyVet — Combined Farm Risk Score v1.0
   Combines THI, AQI, Flood, Outbreak, Forage into a single 0-100 score.

   Depends on (must be loaded before):
   - js/nasa-power-api.js
   - js/nasa-climate-engine.js
   - js/nasa-outbreak-engine.js
   - js/nasa-sedac-mapper.js
   - js/nasa-flood-engine.js
   - js/open-meteo-forecast.js

   Public API (window.DVFarmRisk):
   - computeFarmRiskScore(districtKey) -> Promise<FarmRiskResult>
   - getTopRiskCategory(result) -> { key, label, score, color, icon, action }
   - computeAllDivisionsRanking() -> Promise<Array<{key, name, score, level}>>
   - LEVELS

   Weights (sum = 1.0):
     THI        0.30  (heat stress is #1 livestock killer in BD)
     Flood      0.25  (seasonal, catastrophic)
     Outbreak   0.20  (disease risk)
     AQI        0.15  (respiratory, slower)
     Forage     0.10  (inverse: worse forage = higher risk)
*/
(function () {
'use strict';

const WEIGHTS = {
    thi:      0.30,
    flood:    0.25,
    outbreak: 0.20,
    aqi:      0.15,
    forage:   0.10
};

const DISTRICT_COORDS = {
    dhaka:      { lat: 23.8103, lng: 90.4125, name: 'Dhaka' },
    chittagong: { lat: 22.3569, lng: 91.7832, name: 'Chittagong' },
    rajshahi:   { lat: 24.3745, lng: 88.6042, name: 'Rajshahi' },
    khulna:     { lat: 22.8456, lng: 89.5403, name: 'Khulna' },
    barisal:    { lat: 22.7010, lng: 90.3535, name: 'Barisal' },
    sylhet:     { lat: 24.8949, lng: 91.8687, name: 'Sylhet' },
    rangpur:    { lat: 25.7439, lng: 89.2752, name: 'Rangpur' },
    mymensingh: { lat: 24.7471, lng: 90.4203, name: 'Mymensingh' }
};

const LEVELS = [
    { min: 75, level: 'critical', color: '#dc2626', bg: '#fef2f2', icon: '🚨', label: 'Critical' },
    { min: 55, level: 'alert',    color: '#c2410c', bg: '#fff7ed', icon: '⚠️', label: 'Alert' },
    { min: 35, level: 'watch',    color: '#d97706', bg: '#fef9e7', icon: '👀', label: 'Watch' },
    { min: 0,  level: 'safe',     color: '#059669', bg: '#ecfdf5', icon: '✅', label: 'Safe' }
];

const CATEGORY_LABELS = {
    thi:      { label: 'Heat Stress (THI)',          icon: '🌡️', action: 'Provide shade, water, cooling fans' },
    flood:    { label: 'Flood Risk',                 icon: '🌊', action: 'Relocate livestock, stockpile feed' },
    outbreak: { label: 'Disease Outbreak',           icon: '🦟', action: 'Vaccinate, clear standing water' },
    aqi:      { label: 'Air Quality & UV',           icon: '🌫️', action: 'Ventilation, clean litter, shade' },
    forage:   { label: 'Forage Shortage',            icon: '🌱', action: 'Irrigate, plan alternate feed' }
};

const _levelFor = score => LEVELS.find(l => score >= l.min) || LEVELS[LEVELS.length - 1];
const _num = v => (v === null || v === undefined || v === '') ? NaN : Number(v);
const _clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

/**
 * Compute sub-scores for a district (each 0..100, higher = worse).
 * Returns null sub-score if data missing.
 */
async function computeSubScores(districtKey) {
    const coords = DISTRICT_COORDS[districtKey];
    if (!coords) return null;

    const sub = { thi: null, flood: null, outbreak: null, aqi: null, forage: null };

    // ---- NASA POWER: base data ----
    let parameter = null;
    try {
        parameter = await NasaPower.getPowerData(coords.lat, coords.lng, 7);
    } catch (_) {}

    const t2m = parameter ? NasaPower.getLatest(parameter, 'T2M') : null;
    const rh  = parameter ? NasaPower.getLatest(parameter, 'RH2M') : null;
    const rainLatest = parameter ? NasaPower.getLatest(parameter, 'PRECTOTCORR') : null;
    const soilTop = parameter ? NasaPower.getLatest(parameter, 'GWETTOP') : null;
    const soilRoot = parameter ? NasaPower.getLatest(parameter, 'GWETROOT') : null;
    const rainSeries = parameter ? NasaPower.getSeries(parameter, 'PRECTOTCORR') : [];

    // ---- 1. THI (0-100, higher = worse) ----
    if (t2m && rh && window.NasaClimate) {
        const thi = NasaClimate.calculateTHI(t2m.value, rh.value);
        if (Number.isFinite(thi)) {
            // Map THI to 0-100 risk: 65 = 0, 92 = 100
            sub.thi = _clamp(Math.round((thi - 65) / 27 * 100), 0, 100);
            sub.thi_value = thi;
        }
    }

    // ---- 2. Flood (0-100) ----
    if (window.NasaFlood) {
        try {
            const rain7dayMm = rainSeries.reduce((s, d) => s + (d.value > 0 ? d.value : 0), 0);
            const rain72h = window.OpenMeteo && OpenMeteo.getRainfallCumulative
                ? await OpenMeteo.getRainfallCumulative(coords.lat, coords.lng, 72).catch(() => null)
                : null;
            const floodRisk = NasaFlood.calculateFloodRisk({
                rain7dayMm,
                soilRoot: soilRoot ? soilRoot.value : 0,
                soilTop: soilTop ? soilTop.value : 0,
                rain48hForecast: rain72h && rain72h.rain48hMm ? rain72h.rain48hMm : 0,
                rain72hForecast: rain72h && rain72h.rain72hMm ? rain72h.rain72hMm : 0,
                district: districtKey
            });
            sub.flood = floodRisk.score;
            sub.flood_level = floodRisk.level;
        } catch (_) {}
    }

    // ---- 3. Outbreak (0-100) ----
    if (window.NasaOutbreak && rainLatest && t2m && rh) {
        try {
            const rain7dayMm = rainSeries.reduce((s, d) => s + (d.value > 0 ? d.value : 0), 0);
            const soilMoisture = soilTop ? soilTop.value : 0;
            const risk = NasaOutbreak.calculateRainfallRiskDetailed(rainLatest.value, rh.value, t2m.value);
            // Boost from disease priors
            const diseases = NasaOutbreak.calculateDiseaseRisks({
                rainMm: rainLatest.value,
                humidity: rh.value,
                temp: t2m.value,
                rain7dayMm,
                soilMoisture,
                district: districtKey
            });
            const topDiseaseScore = diseases.length ? diseases[0].score : 0;
            // Blend aggregate rainfall risk + top disease risk (both 0-100)
            sub.outbreak = Math.round(risk.score * 0.6 + topDiseaseScore * 0.4);
            sub.outbreak_level = risk.level;
            sub.top_disease = diseases.length ? diseases[0].nameEn || diseases[0].nameBn : null;
        } catch (_) {}
    }

    // ---- 4. AQI (0-100) ----
    if (window.OpenMeteo && OpenMeteo.getAQI) {
        try {
            const aqiData = await OpenMeteo.getAQI(coords.lat, coords.lng).catch(() => null);
            if (aqiData && Number.isFinite(aqiData.usAqi)) {
                // Map AQI 0-300 to 0-100 risk
                sub.aqi = _clamp(Math.round(aqiData.usAqi / 300 * 100), 0, 100);
                sub.aqi_value = aqiData.usAqi;
            }
        } catch (_) {}
    }

    // ---- 5. Forage (0-100, higher = worse = forage shortage) ----
    if (window.NasaClimate && window.NasaClimate.classifySoilMoisture && soilTop) {
        try {
            const cls = NasaClimate.classifySoilMoisture(soilTop.value);
            // Forage shortage risk: drought=90, dry=60, optimal=10, wet=50
            const forageRiskMap = { drought: 90, dry: 60, optimal: 10, wet: 50, unknown: 50 };
            sub.forage = forageRiskMap[cls.level] || 50;
            sub.forage_level = cls.level;
        } catch (_) {}
    }

    return sub;
}

/**
 * Compute combined farm risk score (0-100, higher = worse).
 * Missing sub-scores are skipped and weights re-normalized.
 *
 * @returns {Promise<{
 *   district: string,
 *   districtName: string,
 *   score: number,
 *   level: string,
 *   levelInfo: object,
 *   components: { thi, flood, outbreak, aqi, forage },
 *   contributions: { thi, flood, outbreak, aqi, forage },
 *   topCategory: object,
 *   timestamp: number
 * }>}
 */
async function computeFarmRiskScore(districtKey) {
    const sub = await computeSubScores(districtKey);
    if (!sub) return null;

    // Compute weighted sum with renormalized weights (skip missing)
    let totalWeight = 0;
    let weightedSum = 0;
    const contributions = {};

    Object.keys(WEIGHTS).forEach(k => {
        const val = sub[k];
        if (Number.isFinite(val)) {
            totalWeight += WEIGHTS[k];
            weightedSum += val * WEIGHTS[k];
            contributions[k] = Math.round(val * WEIGHTS[k] * 10) / 10;
        } else {
            contributions[k] = 0;
        }
    });

    const score = totalWeight > 0
        ? Math.round(weightedSum / totalWeight)
        : 0;

    const levelInfo = _levelFor(score);
    const topCategory = pickTopCategory(sub);

    return {
        district: districtKey,
        districtName: DISTRICT_COORDS[districtKey].name,
        score,
        level: levelInfo.level,
        levelInfo,
        components: {
            thi:      Number.isFinite(sub.thi) ? sub.thi : null,
            flood:    Number.isFinite(sub.flood) ? sub.flood : null,
            outbreak: Number.isFinite(sub.outbreak) ? sub.outbreak : null,
            aqi:      Number.isFinite(sub.aqi) ? sub.aqi : null,
            forage:   Number.isFinite(sub.forage) ? sub.forage : null
        },
        details: {
            thi_value: sub.thi_value,
            aqi_value: sub.aqi_value,
            forage_level: sub.forage_level,
            top_disease: sub.top_disease,
            flood_level: sub.flood_level,
            outbreak_level: sub.outbreak_level
        },
        contributions,
        weights: WEIGHTS,
        totalWeight,
        topCategory,
        timestamp: Date.now()
    };
}

/**
 * Pick the component with the highest contribution to the total score.
 * Returns { key, label, icon, action, subScore, contribution }.
 */
function pickTopCategory(sub) {
    const entries = Object.keys(WEIGHTS)
        .map(k => {
            const subScore = sub[k];
            if (!Number.isFinite(subScore)) return null;
            return {
                key: k,
                subScore,
                contribution: subScore * WEIGHTS[k],
                ...CATEGORY_LABELS[k]
            };
        })
        .filter(Boolean);

    if (!entries.length) {
        return { key: null, label: 'No data', icon: '❓', action: 'Data unavailable', subScore: null, contribution: 0 };
    }

    entries.sort((a, b) => b.contribution - a.contribution);
    return entries[0];
}

/**
 * Public helper — get top risk category from a computed result.
 */
function getTopRiskCategory(result) {
    if (!result) return null;
    return result.topCategory || null;
}

/**
 * Compute scores for all 8 divisions, sorted by risk (highest first).
 * Uses Promise.allSettled so one failure does not kill the ranking.
 */
async function computeAllDivisionsRanking() {
    const keys = Object.keys(DISTRICT_COORDS);
    const results = await Promise.allSettled(keys.map(k => computeFarmRiskScore(k)));
    const rows = results
        .filter(r => r.status === 'fulfilled' && r.value)
        .map(r => r.value)
        .sort((a, b) => b.score - a.score);
    return rows;
}

/* ============================================================
   UI: renderFarmRiskCard(result, targetElementId)
   A compact, drop-in widget. Optional — callers may render
   their own UI from the returned data.
   ============================================================ */
function renderFarmRiskCard(result, targetEl) {
    const el = typeof targetEl === 'string' ? document.getElementById(targetEl) : targetEl;
    if (!el || !result) return;

    const lv = result.levelInfo;
    const top = result.topCategory;
    const componentEntries = [
        { key: 'thi',      label: 'Heat (THI)',    value: result.components.thi,      detail: result.details.thi_value ? result.details.thi_value.toFixed(1) + ' THI' : null },
        { key: 'flood',    label: 'Flood',         value: result.components.flood,    detail: result.details.flood_level },
        { key: 'outbreak', label: 'Disease',       value: result.components.outbreak, detail: result.details.top_disease },
        { key: 'aqi',      label: 'Air (AQI)',     value: result.components.aqi,      detail: result.details.aqi_value ? result.details.aqi_value + ' AQI' : null },
        { key: 'forage',   label: 'Forage',        value: result.components.forage,   detail: result.details.forage_level }
    ].map(c => {
        const v = c.value;
        const color = !Number.isFinite(v) ? '#94a3b8'
            : v >= 75 ? '#dc2626' : v >= 55 ? '#c2410c' : v >= 35 ? '#d97706' : '#059669';
        const pct = Number.isFinite(v) ? v : 0;
        return `
            <div style="display:flex;flex-direction:column;gap:4px;padding:10px 12px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;">
                <div style="display:flex;justify-content:space-between;align-items:center;font-size:11px;font-weight:800;color:#475569;text-transform:uppercase;letter-spacing:0.04em;">
                    <span>${c.label}</span>
                    <span style="color:${color};font-family:monospace;">${Number.isFinite(v) ? Math.round(v) : '—'}</span>
                </div>
                <div style="height:6px;background:#E2E8F0;border-radius:999px;overflow:hidden;">
                    <div style="height:100%;width:${pct}%;background:${color};border-radius:999px;transition:width 0.6s ease;"></div>
                </div>
                ${c.detail ? `<div style="font-size:10px;color:#94A3B8;font-weight:600;">${escapeHtml(String(c.detail))}</div>` : ''}
            </div>`;
    }).join('');

    el.innerHTML = `
        <div class="dvfr-card" style="position:relative;overflow:hidden;padding:1.5rem;background:linear-gradient(180deg,#FFFFFF 0%,#FAFCFF 100%);border:1.5px solid #E2E8F0;border-radius:22px;box-shadow:0 12px 28px -12px rgba(15,44,89,0.14);font-family:Inter,system-ui,sans-serif;">
            <div style="position:absolute;top:0;left:0;right:0;height:4px;background:linear-gradient(90deg,${lv.color},${lv.color}99);"></div>
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:1rem;">
                <div>
                    <div style="font-size:11px;font-weight:800;color:#64748B;text-transform:uppercase;letter-spacing:0.06em;">Combined Farm Risk</div>
                    <div style="font-size:1.15rem;font-weight:900;color:#0F172A;margin-top:2px;">${escapeHtml(result.districtName)}</div>
                </div>
                <span style="padding:6px 12px;border-radius:999px;background:${lv.bg};color:${lv.color};border:1px solid ${lv.color}40;font-size:12px;font-weight:800;white-space:nowrap;">${lv.icon} ${lv.label}</span>
            </div>

            <div style="text-align:center;margin:1rem 0;">
                <div style="font-size:3.5rem;font-weight:900;line-height:1;color:${lv.color};letter-spacing:-0.04em;">${result.score}</div>
                <div style="font-size:11px;font-weight:800;color:#64748B;text-transform:uppercase;letter-spacing:0.1em;margin-top:4px;">Out of 100</div>
            </div>

            <div style="padding:10px 14px;border-radius:12px;background:${lv.bg};border-left:4px solid ${lv.color};margin-bottom:1rem;">
                <div style="font-size:11px;font-weight:800;color:${lv.color};text-transform:uppercase;letter-spacing:0.04em;">Top Risk: ${top.icon || ''} ${escapeHtml(top.label || '')}</div>
                <div style="font-size:12.5px;color:#475569;margin-top:3px;line-height:1.5;">${escapeHtml(top.action || '')}</div>
            </div>

            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:8px;">
                ${componentEntries}
            </div>

            <div style="margin-top:14px;padding-top:10px;border-top:1px dashed #E2E8F0;font-size:10.5px;color:#94A3B8;text-align:center;">
                Weighted from THI, Flood, Outbreak, AQI, Forage · NASA POWER + Open-Meteo
            </div>
        </div>`;
}

function escapeHtml(t) {
    return String(t == null ? '' : t).replace(/[&<>"']/g, c => (
        { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
    ));
}

/* ============================================================
   PUBLIC API
   ============================================================ */
window.DVFarmRisk = {
    computeFarmRiskScore,
    computeSubScores,
    computeAllDivisionsRanking,
    getTopRiskCategory,
    renderFarmRiskCard,
    LEVELS,
    WEIGHTS,
    DISTRICT_COORDS
};

})();
