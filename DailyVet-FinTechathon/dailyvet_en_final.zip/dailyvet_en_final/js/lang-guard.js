/* ============================================================
   DailyVet — Language Guard v1.0
   Hard post-filter that guarantees AI output is English-only.
   Use after EVERY AI response, before rendering.

   Why a post-filter (not just a prompt):
   • Models drift — Groq/Qwen/llama sometimes reply in Bangla
     or Hindi even when the system prompt says "English only".
   • "Please answer in English" is a request, not a guarantee.
   • This module strips foreign scripts AND can request one
     strict retry from the caller.

   Exposes: window.DVLangGuard
   ============================================================ */
(function () {
'use strict';

/* Unicode ranges we consider "not English" */
const BN_SCRIPT    = /[\u0980-\u09FF]/g;                  // Bengali
const HI_SCRIPT    = /[\u0900-\u097F]/g;                  // Devanagari
const CJK_SCRIPT   = /[\u4E00-\u9FFF\u3400-\u4DBF]/g;     // Chinese
const ARABIC_SCR   = /[\u0600-\u06FF\u0750-\u077F]/g;     // Arabic
const CYRILLIC_SCR = /[\u0400-\u04FF]/g;                  // Russian
const ANY_FOREIGN  = /[\u0980-\u09FF\u0900-\u097F\u4E00-\u9FFF\u3400-\u4DBF\u0600-\u06FF\u0750-\u077F\u0400-\u04FF]/g;

/* Romanized Bangla / Hindi words that sometimes appear even without native script.
   Kept narrow to avoid false positives ("ache" inside "headache" etc.). */
const BN_ROMAN_WORDS = [
  'achhe', 'nei', 'kore', 'korte', 'korbo', 'kemon', 'bhalo', 'kharap',
  'daktar', 'goru', 'chagol', 'murgi', 'biral', 'kukur',
  'osudh', 'oshudh', 'tika', 'rog', 'birokti', 'paikhana', 'prosrab',
  'bomi', 'jor', 'kashi', 'shash', 'batha'
];
const HI_ROMAN_WORDS = [
  'nahi', 'nahin', 'kya', 'hoga', 'hogi', 'accha', 'acha',
  'theek hai', 'matlab', 'bahut', 'yeh', 'woh', 'mujhe', 'tumhe',
  'tumhara', 'aapka', 'aapki', 'aapko', 'karo', 'kijiye', 'kripya',
  'dhanyavaad', 'dhanyavad', 'shukriya', 'bhai sahab', 'kaise ho', 'kaise hain'
];

/* ---------- Ratio test ---------- */
function foreignRatio(text) {
  if (!text || typeof text !== 'string') return 0;
  const letters = text.replace(/[^\u0980-\u09FF\u0900-\u097F\u4E00-\u9FFF\u3400-\u4DBF\u0600-\u06FF\u0750-\u077F\u0400-\u04FFa-zA-Z]/g, '');
  if (!letters.length) return 0;
  const foreign = (letters.match(ANY_FOREIGN) || []).length;
  return foreign / letters.length;
}

function hasBangla(text) {
  return typeof text === 'string' && BN_SCRIPT.test(text);
}

/* A string is "English enough" when < 5% of its letters are foreign script
   AND it contains no common Bangla/Hindi romanized words as standalone tokens. */
function isEnglishEnough(text) {
  if (typeof text !== 'string') return true;   // non-strings pass through
  const trimmed = text.trim();
  if (!trimmed) return true;
  if (foreignRatio(trimmed) >= 0.05) return false;

  const lower = ' ' + trimmed.toLowerCase() + ' ';
  const all = BN_ROMAN_WORDS.concat(HI_ROMAN_WORDS);
  for (const w of all) {
    const esc = w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/ /g, '\\s+');
    if (new RegExp(`(^|[^a-z])${esc}([^a-z]|$)`, 'i').test(lower)) return false;
  }
  return true;
}

/* ---------- Strip every foreign script ---------- */
function stripForeign(text) {
  if (typeof text !== 'string') return text;
  return text
    .replace(BN_SCRIPT, '')
    .replace(HI_SCRIPT, '')
    .replace(CJK_SCRIPT, '')
    .replace(ARABIC_SCR, '')
    .replace(CYRILLIC_SCR, '')
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/[ \t]+\n/g, '\n')
    .trim();
}

/* Remove romanized Bangla/Hindi filler words (only when standalone) */
function stripRomanizedFiller(text) {
  if (typeof text !== 'string') return text;
  let out = text;
  const all = BN_ROMAN_WORDS.concat(HI_ROMAN_WORDS)
    .slice()
    .sort((a, b) => b.length - a.length);   // longer phrases first
  for (const w of all) {
    const esc = w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/ /g, '\\s+');
    out = out.replace(new RegExp(`(^|[^a-zA-Z])${esc}(?=[^a-zA-Z]|$)`, 'gi'), '$1');
  }
  return out
    .replace(/[ \t]{2,}/g, ' ')
    .replace(/[ \t]+([.!?])/g, '$1')
    .trim();
}

/* ---------- Deep object / array walkers ---------- */
function mapStrings(obj, fn) {
  if (typeof obj === 'string') return fn(obj);
  if (Array.isArray(obj)) return obj.map(v => mapStrings(v, fn));
  if (obj && typeof obj === 'object') {
    const out = {};
    for (const k of Object.keys(obj)) out[k] = mapStrings(obj[k], fn);
    return out;
  }
  return obj;
}

function deepIsEnglish(obj) {
  if (typeof obj === 'string') return isEnglishEnough(obj);
  if (Array.isArray(obj)) return obj.every(deepIsEnglish);
  if (obj && typeof obj === 'object') return Object.values(obj).every(deepIsEnglish);
  return true;
}

/* ------------------------------------------------------------------
   Main entry points.

   ensureEnglish(rawText, { retryFn }) -> { text, wasFixed, wasRetried }
     • If already English → returns unchanged.
     • Else if retryFn provided → calls it, checks again.
     • Final output is always stripped + validated.

   ensureEnglishJson(parsedObj, { retryFn }) -> { data, wasFixed, wasRetried }
     • Same logic for a parsed JSON object.
   ------------------------------------------------------------------ */
async function ensureEnglish(rawText, opts) {
  opts = opts || {};
  if (typeof rawText !== 'string') rawText = String(rawText || '');

  if (isEnglishEnough(rawText)) {
    return { text: rawText, wasFixed: false, wasRetried: false };
  }

  if (typeof opts.retryFn === 'function') {
    try {
      const retry = await opts.retryFn();
      if (retry && typeof retry === 'string' && isEnglishEnough(retry)) {
        return { text: retry, wasFixed: true, wasRetried: true };
      }
    } catch (_) {}
  }

  const cleaned = stripRomanizedFiller(stripForeign(rawText));
  return { text: cleaned, wasFixed: true, wasRetried: false };
}

async function ensureEnglishJson(parsed, opts) {
  opts = opts || {};
  if (!parsed || typeof parsed !== 'object') {
    return { data: parsed, wasFixed: false, wasRetried: false };
  }

  if (deepIsEnglish(parsed)) {
    return { data: parsed, wasFixed: false, wasRetried: false };
  }

  if (typeof opts.retryFn === 'function') {
    try {
      const retry = await opts.retryFn();
      if (retry && typeof retry === 'object' && deepIsEnglish(retry)) {
        return { data: retry, wasFixed: true, wasRetried: true };
      }
    } catch (_) {}
  }

  const cleaned = mapStrings(parsed, s => stripRomanizedFiller(stripForeign(s)));
  return { data: cleaned, wasFixed: true, wasRetried: false };
}

/* ---------- Public API ---------- */
window.DVLangGuard = {
  foreignRatio,
  hasBangla,
  isEnglishEnough,
  stripForeign,
  stripRomanizedFiller,
  deepIsEnglish,
  ensureEnglish,
  ensureEnglishJson
};

console.log('✅ Language Guard v1.0 loaded — English-only enforcement');
})();
