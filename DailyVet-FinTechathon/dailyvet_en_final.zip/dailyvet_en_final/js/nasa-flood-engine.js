/* ============================================================
   DailyVet — NASA Flood Early Warning Engine v2.1
   Inputs : NASA GPM (PRECTOTCORR), SMAP (GWETROOT, GWETTOP, GWETPROF)
            + Open-Meteo 48-72h rainfall forecast
            + Upstream basin rainfall (Assam/Bihar) for Brahmaputra/Ganges
   Output : Flood probability (0-100%), relocation advice,
            safe shelter suggestions, emergency feed plan

   v2.1 changes:
   • Fixed upstream score addition when basin present but rain = 0
   • FLOOD_VULNERABILITY now has all 8 divisions explicitly
   • getSafeShelterAdvice safe when district not found
   • Upstream lag defaults correctly when not provided
   • English-only comments
   ============================================================ */
(function () {
'use strict';

/* ============================================================
   UPSTREAM BASIN MAPPING
   Bangladesh receives ~90% of river flow from upstream (India/Nepal/China).
   NASA POWER point API gives rainfall at a single lat/lng — to get
   "upstream rainfall" we need representative coordinates for each
   basin's upstream area.

   These are representative "choke points" where rainfall correlates
   well with downstream flood peaks (based on Bangladesh flood literature).
   ============================================================ */
const UPSTREAM_BASINS = {
    brahmaputra: {
        name: 'Brahmaputra (Assam)',
        lat: 26.85,
        lng: 94.20,
        altLat: 26.63,
        altLng: 92.80,
        lagDays: 4,
        note: 'Assam tributaries (Beki, Jiabharali, Dikhow, Kopili) — HEC-HMS models run by ASDMA'
    },
    ganges: {
        name: 'Ganges (Bihar/Nepal)',
        lat: 25.60,
        lng: 85.10,
        altLat: 26.70,
        altLng: 85.30,
        lagDays: 7,
        note: 'Bihar CWC forecast stations (Buxar, Patna, Munger) + Nepal tributaries (Koshi, Gandak)'
    },
    meghna: {
        name: 'Meghna / Barak (Assam-Meghalaya)',
        lat: 24.80,
        lng: 92.80,
        altLat: 25.20,
        altLng: 91.70,
        lagDays: 2,
        note: 'Barak River (Silchar) + Meghalaya hills — flash flood prone (Sunamganj haor)'
    }
};

/* ============================================================
   REGIONAL FLOOD VULNERABILITY (Bangladesh-specific)
   All 8 divisions plus high-risk districts covered.
   ============================================================ */
const FLOOD_VULNERABILITY = {
    /* Char areas (Brahmaputra) */
    kurigram:    { score: 95, type: 'char',     name: 'Kurigram (Char Area)',    river: 'Brahmaputra/Dharla', basin: 'brahmaputra' },
    gaibandha:   { score: 92, type: 'char',     name: 'Gaibandha (Char Area)',   river: 'Brahmaputra',        basin: 'brahmaputra' },
    lalmonirhat: { score: 90, type: 'char',     name: 'Lalmonirhat (Char)',      river: 'Teesta/Dharla',      basin: 'brahmaputra' },
    sirajganj:   { score: 88, type: 'riverine', name: 'Sirajganj (Jamuna Bank)', river: 'Jamuna',             basin: 'brahmaputra' },
    jamalpur:    { score: 85, type: 'riverine', name: 'Jamalpur (Brahmaputra)',  river: 'Brahmaputra',        basin: 'brahmaputra' },
    /* Haor areas (Meghna) */
    sunamganj:   { score: 92, type: 'haor',     name: 'Sunamganj (Haor)',        river: 'Surma/Kushiyara',    basin: 'meghna' },
    sylhet:      { score: 85, type: 'haor',     name: 'Sylhet (Haor)',           river: 'Surma',              basin: 'meghna' },
    netrokona:   { score: 80, type: 'haor',     name: 'Netrokona (Haor)',        river: 'Kangsha',            basin: 'meghna' },
    kishoreganj: { score: 82, type: 'haor',     name: 'Kishoreganj (Haor)',      river: 'Old Brahmaputra',    basin: 'meghna' },
    /* Padma riverine */
    faridpur:    { score: 78, type: 'riverine', name: 'Faridpur (Padma)',        river: 'Padma',              basin: 'ganges' },
    shariatpur:  { score: 80, type: 'riverine', name: 'Shariatpur (Padma)',      river: 'Padma',              basin: 'ganges' },
    chandpur:    { score: 82, type: 'riverine', name: 'Chandpur (Meghna)',       river: 'Meghna',             basin: 'meghna' },
    munshiganj:  { score: 85, type: 'riverine', name: 'Munshiganj (Padma-Meghna)', river: 'Padma-Meghna',    basin: 'ganges' },
    bogura:      { score: 75, type: 'riverine', name: 'Bogura (Jamuna)',         river: 'Jamuna',             basin: 'brahmaputra' },
    pabna:       { score: 80, type: 'riverine', name: 'Pabna (Jamuna)',          river: 'Jamuna',             basin: 'brahmaputra' },
    tangail:     { score: 75, type: 'riverine', name: 'Tangail (Jamuna)',        river: 'Jamuna',             basin: 'brahmaputra' },
    manikganj:   { score: 78, type: 'riverine', name: 'Manikganj (Padma)',       river: 'Padma',              basin: 'ganges' },
    /* Division fallbacks (all 8 explicitly) */
    dhaka:       { score: 60, type: 'mixed',    name: 'Dhaka Division',          river: 'Buriganga/Turag',    basin: 'ganges' },
    chittagong:  { score: 70, type: 'coastal',  name: 'Chittagong (Coastal)',    river: 'Karnaphuli',         basin: 'coastal' },
    khulna:      { score: 72, type: 'coastal',  name: 'Khulna (Coastal)',        river: 'Rupsha',             basin: 'coastal' },
    barisal:     { score: 75, type: 'coastal',  name: 'Barisal (Coastal)',       river: 'Meghna',             basin: 'coastal' },
    rajshahi:    { score: 65, type: 'riverine', name: 'Rajshahi (Padma)',        river: 'Padma',              basin: 'ganges' },
    rangpur:     { score: 82, type: 'char',     name: 'Rangpur Division (Char)', river: 'Teesta',             basin: 'brahmaputra' },
    mymensingh:  { score: 78, type: 'riverine', name: 'Mymensingh',              river: 'Old Brahmaputra',    basin: 'brahmaputra' }
};

function getBasinForDistrict(district) {
    const key = String(district || '').toLowerCase().trim();
    const vuln = FLOOD_VULNERABILITY[key];
    return vuln && vuln.basin ? vuln.basin : null;
}

/* ============================================================
   FLOOD RISK LEVELS
   ============================================================ */
const FLOOD_LEVELS = [
    { min: 75, level: 'critical', label: 'Extreme Flood Risk',   color: '#dc2626', bg: '#fef2f2', icon: '🚨',
      action: 'Move livestock NOW — relocate to higher ground within 24 hours' },
    { min: 55, level: 'alert',    label: 'High Flood Risk',      color: '#c2410c', bg: '#fff7ed', icon: '⚠️',
      action: 'Move livestock to safe shelter within 48 hours, stockpile feed' },
    { min: 35, level: 'watch',    label: 'Moderate Flood Risk',  color: '#d97706', bg: '#fef9e7', icon: '👀',
      action: 'Water level may rise — prepare feed, medicine and shelter' },
    { min: 0,  level: 'safe',     label: 'Normal Condition',     color: '#059669', bg: '#ecfdf5', icon: '✅',
      action: 'No immediate flood risk — continue normal operations' }
];

const _isNum = v => v !== null && v !== undefined && v !== '' && Number.isFinite(Number(v));

/* ============================================================
   CORE FLOOD RISK CALCULATOR
   ============================================================ */
function calculateFloodRisk(params) {
    const {
        rain7dayMm = 0,
        soilRoot = 0,
        soilTop = 0,
        rain48hForecast = 0,
        rain72hForecast = 0,
        upstreamRainMm = 0,
        upstreamLagDays = null,
        district = 'dhaka',
        daysOfRain = 0
    } = params || {};

    const breakdown = [];
    let score = 0;

    /* ===== 1. PAST 7-DAY RAINFALL (max 25) ===== */
    let rain7Score = 0;
    if (rain7dayMm > 300)       rain7Score = 25;
    else if (rain7dayMm > 200)  rain7Score = 20;
    else if (rain7dayMm > 120)  rain7Score = 15;
    else if (rain7dayMm > 60)   rain7Score = 10;
    else if (rain7dayMm > 25)   rain7Score = 5;

    score += rain7Score;
    breakdown.push({
        icon: '🌧️',
        label: 'Last 7 Days Rainfall (Local)',
        value: `${Math.round(rain7dayMm)} mm`,
        score: rain7Score,
        max: 25,
        reason: rain7Score >= 20 ? 'Excess local rainfall — rivers already swollen'
                 : rain7Score >= 10 ? 'Moderate rainfall — soil saturation begins'
                 : 'Recent local rainfall is low'
    });

    /* ===== 2. SOIL SATURATION (max 25) ===== */
    const soilAvg = _isNum(soilRoot) && _isNum(soilTop)
        ? (Number(soilRoot) + Number(soilTop)) / 2
        : Number(soilRoot) || Number(soilTop) || 0;

    let soilScore = 0;
    if (soilAvg > 0.85)       soilScore = 25;
    else if (soilAvg > 0.75)  soilScore = 20;
    else if (soilAvg > 0.65)  soilScore = 15;
    else if (soilAvg > 0.50)  soilScore = 8;
    else if (soilAvg > 0.35)  soilScore = 3;

    score += soilScore;
    breakdown.push({
        icon: '💧',
        label: 'Soil Moisture (SMAP)',
        value: `${Math.round(soilAvg * 100)}%`,
        score: soilScore,
        max: 25,
        reason: soilScore >= 20 ? 'Soil nearly saturated — new rain will cause flooding directly'
                 : soilScore >= 15 ? 'Soil is very wet — water absorption capacity is dropping fast'
                 : soilScore >= 8  ? 'Soil is getting wet — keep watching'
                 : 'Soil is dry, will absorb water'
    });

    /* ===== 3. FORECAST RAINFALL 48-72h (max 30) ===== */
    let forecastScore = 0;
    if (rain72hForecast > 200)      forecastScore = 30;
    else if (rain72hForecast > 120) forecastScore = 24;
    else if (rain48hForecast > 80)  forecastScore = 18;
    else if (rain48hForecast > 50)  forecastScore = 12;
    else if (rain48hForecast > 25)  forecastScore = 6;
    else if (rain48hForecast > 10)  forecastScore = 3;

    score += forecastScore;
    breakdown.push({
        icon: '🔮',
        label: 'Rainfall Forecast (Next 48-72h)',
        value: rain72hForecast > 0
            ? `48h: ${Math.round(rain48hForecast)} mm • 72h: ${Math.round(rain72hForecast)} mm`
            : `${Math.round(rain48hForecast)} mm (48h)`,
        score: forecastScore,
        max: 30,
        reason: forecastScore >= 24 ? 'Heavy rainfall expected in the next 72 hours'
                 : forecastScore >= 18 ? 'Significant rainfall coming within 48 hours'
                 : forecastScore >= 6  ? 'Light to moderate rainfall possible'
                 : 'Low chance of rain'
    });

    /* ===== 4. UPSTREAM BASIN RAINFALL (max 20) =====
       Bangladesh receives ~90% of river flow from upstream.
       Even if local rainfall is low, heavy upstream rain can flood us. */
    let upstreamScore = 0;
    const districtKey = String(district || '').toLowerCase().trim();
    const vuln = FLOOD_VULNERABILITY[districtKey] || { score: 50, type: 'mixed', name: 'General Area', river: '—', basin: null };
    const basin = vuln.basin;

    if (basin && _isNum(upstreamRainMm)) {
        const uRain = Number(upstreamRainMm);
        /* Basin weight: char/haor/riverine rely on upstream more than coastal */
        const basinWeight = (vuln.type === 'char' || vuln.type === 'haor' || vuln.type === 'riverine') ? 1.0 : 0.5;

        if (uRain > 300)      upstreamScore = Math.round(20 * basinWeight);
        else if (uRain > 200) upstreamScore = Math.round(16 * basinWeight);
        else if (uRain > 120) upstreamScore = Math.round(12 * basinWeight);
        else if (uRain > 60)  upstreamScore = Math.round(7 * basinWeight);
        else if (uRain > 25)  upstreamScore = Math.round(3 * basinWeight);

        const basinInfo = UPSTREAM_BASINS[basin];
        const basinName = basinInfo ? basinInfo.name : basin;
        /* Use provided lag OR basin default */
        const effectiveLag = (upstreamLagDays != null) ? upstreamLagDays : (basinInfo ? basinInfo.lagDays : null);
        const lagNote = effectiveLag != null ? ` (peak expected in ~${effectiveLag} days)` : '';

        score += upstreamScore;
        breakdown.push({
            icon: '🏔️',
            label: `Upstream Basin Rainfall — ${basinName}`,
            value: `${Math.round(uRain)} mm / 7 days${lagNote}`,
            score: upstreamScore,
            max: 20,
            reason: upstreamScore >= 16 ? `Heavy upstream rain in ${basinName} — downstream rivers will swell`
                     : upstreamScore >= 10 ? `Significant upstream rain in ${basinName} — monitor river levels closely`
                     : upstreamScore >= 4  ? `Moderate upstream rain in ${basinName}`
                     : `Low upstream rainfall in ${basinName}`
        });
    } else if (basin) {
        breakdown.push({
            icon: '🏔️',
            label: `Upstream Basin Rainfall — ${UPSTREAM_BASINS[basin] ? UPSTREAM_BASINS[basin].name : basin}`,
            value: 'Not available',
            score: 0,
            max: 20,
            reason: 'Upstream rainfall data not provided'
        });
    }

    /* ===== 5. REGIONAL VULNERABILITY (max 20, scaled down if upstream used) ===== */
    const vulnMax = basin ? 12 : 20;
    const vulnScore = Math.round(vuln.score / 100 * vulnMax);

    score += vulnScore;
    breakdown.push({
        icon: vuln.type === 'char' ? '🏝️' : vuln.type === 'haor' ? '🌊' : vuln.type === 'coastal' ? '🌅' : '🏞️',
        label: `Regional Flood Vulnerability (${vuln.type})`,
        value: vuln.name,
        score: vulnScore,
        max: vulnMax,
        reason: vuln.type === 'char'    ? `Char area — the ${vuln.river} river can overflow anytime`
                 : vuln.type === 'haor'    ? `Haor area — waterlogging even with light rainfall`
                 : vuln.type === 'coastal' ? `Coastal area — tide + rain = flood`
                 : `Low-lying area along the ${vuln.river}`
    });

    const totalRaw = score;
    const finalScore = Math.min(100, totalRaw);

    const levelDef = FLOOD_LEVELS.find(l => finalScore >= l.min);

    return {
        ...levelDef,
        score: finalScore,
        totalRawScore: totalRaw,
        capped: totalRaw > 100,
        breakdown,
        vulnerability: vuln,
        basin: basin,
        upstreamUsed: basin && _isNum(upstreamRainMm) && Number(upstreamRainMm) > 0,
        inputs: {
            rain7dayMm: Math.round(rain7dayMm),
            soilRoot: soilAvg,
            rain48hForecast: Math.round(rain48hForecast),
            rain72hForecast: Math.round(rain72hForecast),
            upstreamRainMm: Math.round(upstreamRainMm || 0),
            daysOfRain
        }
    };
}

/* ============================================================
   LIVESTOCK RELOCATION ADVICE
   ============================================================ */
function getRelocationPriority(riskLevel, speciesList) {
    const species = Array.isArray(speciesList) && speciesList.length
        ? speciesList : ['Cow', 'Goat', 'Chicken'];

    const PRIORITY = {
        Chicken: { rank: 1, reason: 'Chicken/ducks drown within 24 hours — move them first' },
        Duck:    { rank: 1, reason: 'Ducks tolerate water but get swept away by currents — move first' },
        Pigeon:  { rank: 1, reason: 'Pigeons are trapped in cages — move immediately' },
        Goat:    { rank: 2, reason: 'Goats drown and are smaller than cattle — second priority' },
        Sheep:   { rank: 2, reason: 'Sheep are weak in water — move before cattle' },
        Cow:     { rank: 3, reason: 'Cows can swim — safe to move last' },
        Buffalo: { rank: 3, reason: 'Buffalo can swim — but heavy, hard to move to high ground' }
    };

    return species
        .map(s => ({
            species: s,
            priority: PRIORITY[s] ? PRIORITY[s].rank : 3,
            reason: PRIORITY[s] ? PRIORITY[s].reason : 'Move to higher ground'
        }))
        .sort((a, b) => a.priority - b.priority);
}

/* ============================================================
   SAFE SHELTER SUGGESTIONS
   ============================================================ */
function getSafeShelterAdvice(riskLevel, district) {
    const key = String(district || '').toLowerCase().trim();
    const vuln = FLOOD_VULNERABILITY[key] || {};

    const GENERAL = [
        { icon: '🏫', title: 'Government School / College Building', note: 'Usually 2-3 storeys, suitable for quick shelter' },
        { icon: '🕌', title: 'Mosque / Madrasa',        note: 'Easy to coordinate with local communities' },
        { icon: '🏥', title: 'Upazila Health Complex',   note: 'Medical care + shelter in one place' },
        { icon: '🏛️', title: 'Union Parishad Building',  note: 'Also used as government relief distribution center' },
        { icon: '⛰️', title: 'High Road / Embankment',   note: 'Last resort — tie animals with rope' }
    ];

    const SPECIFIC = vuln.type === 'char'
        ? [{ icon: '🚤', title: 'Boat / Trawler', note: 'Moving animals by boat is safest in char areas' }]
        : vuln.type === 'haor'
        ? [{ icon: '🛖', title: 'Haor Embankment (Pari)', note: 'Move quickly to elevated thatched structures' }]
        : vuln.type === 'coastal'
        ? [{ icon: '🏢', title: 'Cyclone Shelter', note: 'Safest during tide + rain' }]
        : [];

    return [...SPECIFIC, ...GENERAL].slice(0, 5);
}

/* ============================================================
   EMERGENCY FEED PLAN (7-day)
   ============================================================ */
function getEmergencyFeedPlan(riskLevel, speciesList) {
    const species = Array.isArray(speciesList) && speciesList.length ? speciesList : ['Cow'];
    const isCritical = riskLevel === 'critical' || riskLevel === 'alert';
    const days = isCritical ? 7 : 3;

    const perHead = {
        Cow:     { hay: 8,  concentrate: 2,   water: 40,   note: 'Dry hay + molasses-bran mix' },
        Buffalo: { hay: 10, concentrate: 2.5, water: 50,   note: 'Dry hay + oil cake' },
        Goat:    { hay: 1.5, concentrate: 0.4, water: 5,   note: 'Dry grass + bran' },
        Sheep:   { hay: 1.5, concentrate: 0.4, water: 5,   note: 'Dry grass + bran' },
        Chicken: { hay: 0,  concentrate: 0.12, water: 0.25, note: 'Chicken grain mix' },
        Duck:    { hay: 0,  concentrate: 0.15, water: 0.4, note: 'Wet feed + grain' },
        Pigeon:  { hay: 0,  concentrate: 0.05, water: 0.1, note: 'Grain + crushed chickpea' }
    };

    const plan = species.map(s => {
        const p = perHead[s] || perHead.Cow;
        return {
            species: s,
            days,
            hayKg: Math.round(p.hay * days * 10) / 10,
            concentrateKg: Math.round(p.concentrate * days * 10) / 10,
            waterLt: Math.round(p.water * days),
            note: p.note
        };
    });

    const tips = [
        '🧂 Give a small amount of salt-mineral mix daily — reduces stress',
        '💊 ORS / electrolyte water every 2 days',
        '🌾 Never give wet feed — it rots and causes diarrhea',
        '🥇 Feed pregnant and lactating animals first',
        '📦 Wrap feed in polythene bags and store on high shelves'
    ];

    return { plan, tips, days };
}

/* ============================================================
   PUBLIC API
   ============================================================ */
window.NasaFlood = {
    calculateFloodRisk,
    getRelocationPriority,
    getSafeShelterAdvice,
    getEmergencyFeedPlan,
    getBasinForDistrict,
    FLOOD_VULNERABILITY,
    FLOOD_LEVELS,
    UPSTREAM_BASINS
};

console.log('[NasaFlood] v2.1 loaded');
})();