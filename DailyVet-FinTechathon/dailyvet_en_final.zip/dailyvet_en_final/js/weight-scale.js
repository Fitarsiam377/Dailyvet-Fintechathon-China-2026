/* ============================================================
   DailyVet - Animal Body Weight Estimator v7.1 (English only)
   - Bangladesh species/breed weight ranges (desi + cross + exotic)
   - Age classes (juvenile / growing / adult)
   - Prompt with height + reference object + anti-overestimate
   - Breed-confidence demotion + height cap + species calibration
   - Multi-provider cascade: Gemini -> Groq -> OpenRouter
   - Tape Measure (Schaeffer Formula) tab
   - SEGMENT 1 FIX: WS_KEYS populated with advisor.js keys.
     Model names unchanged.
   ============================================================ */
'use strict';
(function () {
const _dvDec = (s) => { try { return atob(s); } catch (e) { return ''; } };

let wsSelectedImage = null;
let wsCurrentPhone = null;
let wsPendingWeight = null;
let wsPendingFromAI = false;
let wsScanning = false;

/* SEGMENT 1 FIX: API keys were empty arrays.
   Reuse the same 5 Gemini + 3 Groq + 2 OpenRouter keys as advisor.js.
   Model names (WS_MODELS below) are unchanged. */
const WS_KEYS = window.DV_WS_KEYS || {
  gemini: [
    _dvDec('QVEuQWI4Uk42SlVSbzZHTS1lck9BX0d6UVRJcml4MzRtUkhfd3doN01pM01janF1dVdmMGc='),
    _dvDec('QVEuUWI4Uk42S19GWW5PS0xPdFlRX21lLWlrcU1ybzE5aXpRQ0VROTFwNTB1cUNqaGM5Vnc='),
    _dvDec('QVEuUWI4Uk42TE9uRUpOTncxWm51ZGJhV3RpVHdsTXhJSUwyWXptalFjaFJib3RSRWUxQnc='),
    _dvDec('QVEuUWI4Uk42THcxaExybU9wSGh4WGNyYkl0SXZRUHFyamhYaWotTlE0RFdBZnNyUWFCT1E='),
    _dvDec('QVEuUWI4Uk42SWZjSVNqNDhaVWRlelpCdHJlZkhRNmxBWHhRX3Z0WnhYRklKSXRBaEF5VVE=')
  ],
  groq: [
    _dvDec('Z3NrX21WVXRJQThxTHdXUGNIZkFvNHNkV0dkeWIzRllkUk1rTlppMUxYT2gxb1RITVlIM0w3WXI='),
    _dvDec('Z3NrX3o4QkRyYldCbXlhS2l6M3BiVnZRV0dkeWIzRlk1R25haDNrQVptQm1xRUF2a2ZLMTZmd1M='),
    _dvDec('Z3NrX0ExSHo5VDQ3aTA5UndrM1h4UGlaV0dkeWIzRllxT0YxOHdDc0JRV0lUaVlOQjRaM3RheDQ=')
  ],
  openrouter: [
    _dvDec('c2stb3ItdjEtODg4MDE5MDk4Njc2MjllYWQ5ZGQyMjQ2MTc5YWVlZjE0Y2VkZTFiMGZkOGI2YmQxM2VkNDA2NTU3NWVhZWY3OQ=='),
    _dvDec('c2stb3ItdjEtNGQwZmE1MzM5YWI1YTA3NDlkM2I4ZTEyZTU1NGM3ZWI2MjFjYzNjMmI1YjgwYzk0MjA5YjM0YjhmMzZjZTFlNg==')
  ]
};

const WS_PROVIDER_ORDER = ['gemini', 'groq', 'openrouter'];

const WS_MODELS = {
  gemini: [
    'gemini-3.5-flash-lite',
    'gemini-3.1-flash-lite',
    'gemini-2.5-flash-lite',
    'gemini-3.8-flash',
    'gemini-3.6-flash',
    'gemini-2.5-flash'
  ],
  groq: ['qwen/qwen3.8-27b'],
  openrouter: ['qwen/qwen2.5-vl-72b-instruct:free']
};

const WS_ENDPOINTS = {
  gemini: 'https://generativelanguage.googleapis.com/v1beta/models',
  groq: 'https://api.groq.com/openai/v1/chat/completions',
  openrouter: 'https://openrouter.ai/api/v1/chat/completions'
};

const WS_TIMING = { total: 9000, perCall: 6000, hedge: 500, parallel: 2 };
const WS_WATCHDOG_EXTRA_MS = 1500;

const WS_COOLDOWN = {
  rateLimit: 20e3, rateLimitMax: 12 * 60e3, server: 15e3, timeout: 12e3,
  badRequest: 60e3, badOutput: 15e3, authKey: 6 * 3600e3,
  modelGone: 24 * 3600e3, quotaZero: 6 * 3600e3, perDay: 3 * 3600e3
};

const WS_GEMINI_SAFETY = ['HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH', 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'HARM_CATEGORY_DANGEROUS_CONTENT']
  .map(category => ({ category, threshold: 'BLOCK_ONLY_HIGH' }));

const WS_MAX_IMAGE_MB = 25;
const WS_TARGET_MAX_BYTES = 1.5 * 1024 * 1024;
const WS_MAX_SANE_KG = 1500;
const WS_CACHE_TTL_MS = 60 * 60 * 1000;
const WS_CACHE_MAX = 20;

const _el = id => document.getElementById(id);
const _wsLsGet = k => { try { return localStorage.getItem(k); } catch (_) { return null; } };
const _wsLsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (_) {} };

const WS_BREED_RANGES = {
  cow: {
    label: 'Cow', emoji: '🐄', youngName: 'calf',
    juvenile: [25, 120],
    growing: [100, 300],
    desi:   { min: 100, max: 250, small: [100, 150], medium: [150, 200], large: [200, 250] },
    cross:  { min: 300, max: 550, small: [300, 380], medium: [380, 470], large: [470, 550] },
    exotic: { min: 400, max: 800, small: [400, 520], medium: [520, 660], large: [660, 800] },
    overall: { min: 25, max: 800 }
  },
  buffalo: {
    label: 'Buffalo', emoji: '🐃', youngName: 'calf',
    juvenile: [30, 150],
    growing: [150, 400],
    desi:   { min: 300, max: 450, small: [300, 350], medium: [350, 400], large: [400, 450] },
    cross:  { min: 400, max: 650, small: [400, 480], medium: [480, 560], large: [560, 650] },
    exotic: { min: 500, max: 800, small: [500, 600], medium: [600, 700], large: [700, 800] },
    overall: { min: 30, max: 800 }
  },
  goat: {
    label: 'Goat', emoji: '🐐', youngName: 'kid',
    juvenile: [2, 12],
    growing: [10, 25],
    desi:   { min: 15, max: 30, small: [15, 20], medium: [20, 25], large: [25, 30] },
    cross:  { min: 30, max: 55, small: [30, 38], medium: [38, 47], large: [47, 55] },
    exotic: { min: 40, max: 100, small: [40, 60], medium: [60, 80], large: [80, 100] },
    overall: { min: 2, max: 100 }
  },
  sheep: {
    label: 'Sheep', emoji: '🐑', youngName: 'lamb',
    juvenile: [2, 12],
    growing: [10, 22],
    desi:   { min: 15, max: 25, small: [15, 18], medium: [18, 22], large: [22, 25] },
    cross:  { min: 25, max: 50, small: [25, 33], medium: [33, 42], large: [42, 50] },
    exotic: { min: 40, max: 90, small: [40, 57], medium: [57, 73], large: [73, 90] },
    overall: { min: 2, max: 90 }
  },
  chicken: {
    label: 'Chicken', emoji: '🐔', youngName: 'chick',
    juvenile: [0.05, 0.6],
    growing: [0.5, 1.5],
    desi:   { min: 1, max: 1.5, small: [1, 1.2], medium: [1.2, 1.35], large: [1.35, 1.5] },
    cross:  { min: 1.2, max: 1.8, small: [1.2, 1.4], medium: [1.4, 1.6], large: [1.6, 1.8] },
    exotic: { min: 1.5, max: 2.5, small: [1.5, 1.8], medium: [1.8, 2.2], large: [2.2, 2.5] },
    overall: { min: 0.05, max: 2.5 }
  },
  duck: {
    label: 'Duck', emoji: '🦆', youngName: 'duckling',
    juvenile: [0.05, 0.7],
    growing: [0.6, 1.8],
    desi:   { min: 1.5, max: 2, small: [1.5, 1.7], medium: [1.7, 1.9], large: [1.9, 2] },
    cross:  { min: 2, max: 3, small: [2, 2.3], medium: [2.3, 2.7], large: [2.7, 3] },
    exotic: { min: 3.5, max: 4.5, small: [3.5, 3.8], medium: [3.8, 4.2], large: [4.2, 4.5] },
    overall: { min: 0.05, max: 4.5 }
  }
};

const WS_ALIASES = {
  cow: 'cow', cattle: 'cow', bull: 'cow', ox: 'cow', calf: 'cow',
  buffalo: 'buffalo',
  goat: 'goat', kid: 'goat',
  sheep: 'sheep', lamb: 'sheep',
  chicken: 'chicken', poultry: 'chicken', hen: 'chicken', rooster: 'chicken', chick: 'chicken',
  duck: 'duck', duckling: 'duck'
};

function wsResolveSpecies(raw) {
  const k = String(raw || '').toLowerCase().trim();
  return WS_ALIASES[k] || null;
}

const WS_CALIBRATION = {
  goat: 0.88, sheep: 0.88,
  cow: 1.0, buffalo: 1.0,
  chicken: 0.97, duck: 0.97
};
const WS_NO_REF_SHRINK = { goat: 0.95, sheep: 0.95 };
const WS_PRIOR_PULL = { goat: 0.25, sheep: 0.25 };
const WS_SMALL_BREED_MIN_CONF = 75;
const WS_EXOTIC_MIN_CONF = 60;
const WS_GROWING_BREED_SCALE = { desi: 1, cross: 1.25, exotic: 1.5 };

const WS_HEIGHT_CAPS = {
  goat:  [[30, 12], [40, 20], [50, 30], [60, 45], [70, 65]],
  sheep: [[35, 12], [45, 20], [55, 30], [65, 45], [75, 65]]
};
function wsHeightCap(species, h) {
  const table = WS_HEIGHT_CAPS[species];
  if (!table || !isFinite(h) || h < 10 || h > 200) return null;
  for (const [upTo, cap] of table) if (h <= upTo) return cap;
  return null;
}

const SMALL_RUMINANTS = new Set(['goat', 'sheep']);

function wsRound(n) {
  return n < 2 ? Math.round(n * 100) / 100 : Math.round(n * 10) / 10;
}
function wsRoundBound(n) {
  return n < 10 ? wsRound(n) : Math.round(n);
}

function wsSizeOf(species, weight, breedType) {
  const r = WS_BREED_RANGES[species];
  if (!r) return null;
  const br = r[breedType] || r.desi;
  if (weight <= br.small[1]) return 'small';
  if (weight <= br.medium[1]) return 'medium';
  return 'large';
}

function wsSizeLabel(species, weight, breedType, ageClass) {
  const r = WS_BREED_RANGES[species];
  if (!r) return '-';
  if (ageClass === 'juvenile') return `Very young (${r.youngName})`;
  if (ageClass === 'growing') return `Growing young ${r.label.toLowerCase()}`;
  const size = wsSizeOf(species, weight, breedType);
  if (!size) return '-';
  const pretty = size.charAt(0).toUpperCase() + size.slice(1);
  const bt = breedType === 'desi' ? 'desi' : breedType === 'cross' ? 'crossbreed' : 'exotic';
  return `${pretty} (for ${bt})`;
}

function wsActiveRange(species, ageClass, breedType) {
  const r = WS_BREED_RANGES[species];
  const br = r[breedType] || r.desi;
  if (ageClass === 'juvenile') return { min: r.juvenile[0], max: r.juvenile[1] };
  if (ageClass === 'growing') {
    const scale = WS_GROWING_BREED_SCALE[breedType] || 1;
    return { min: r.growing[0], max: Math.min(r.growing[1] * scale, br.max) };
  }
  return { min: br.min, max: br.max };
}

const WS_WEIGHT_PROMPT = `You are an expert livestock weight estimation AI for DailyVet (Bangladesh).

STRICT: Reply ONLY in clean English. Do NOT use Bengali, Hindi, or any non-English script in any field. Return ONLY valid JSON. No markdown, no commentary.

Analyze the attached image and estimate the animal's live body weight.

BANGLADESH ADULT WEIGHT REFERENCE:
- COW: Desi 100-250 kg, Cross 300-550 kg, Exotic 400-800 kg
- BUFFALO: Desi 300-450 kg, Cross 400-650 kg, Exotic 500-800 kg
- GOAT: Desi Black Bengal 15-30 kg (most common), Cross 30-55 kg, Exotic 40-100 kg
- SHEEP: Desi 15-25 kg (most common), Cross 25-50 kg, Exotic 40-90 kg
- CHICKEN: Desi 1.0-1.5 kg, Sonali 1.2-1.8 kg, Broiler 1.5-2.5 kg
- DUCK: Desi 1.5-2.0 kg, Cross 2.0-3.0 kg, Exotic 3.5-4.5 kg

YOUNG ANIMALS (not adults):
- JUVENILE (kid/calf/lamb/chick, up to about 4 months): cow/buffalo calf 25-150 kg, goat/sheep kid 2-12 kg, chick 0.05-0.7 kg
- GROWING (4-12 months): cow 100-300 kg, buffalo 150-400 kg, goat 10-25 kg, sheep 10-22 kg, chicken 0.5-1.5 kg, duck 0.6-1.8 kg

REAL-WORLD ANCHORS (Bangladesh):
- Black Bengal goat: shoulder height 35-50 cm. Adult does 15-22 kg, bucks 20-30 kg. Kid at 3 months is 6-8 kg, at 6 months 10-15 kg.
- Bengal sheep: shoulder height 45-60 cm, adult 12-25 kg.
- Desi cow: shoulder height 90-110 cm. Cross/exotic dairy cow: 120-140 cm.

PROCESS:
STEP 1 - SPECIES: cow, buffalo, goat, sheep, chicken, duck.
STEP 2 - AGE CLASS: juvenile, growing, or adult.
STEP 3 - SCALE: find a reference object (person ~160 cm, door ~200 cm, brick ~25 cm, bucket ~30-35 cm, motorbike) and estimate shoulder height in cm. If none visible, say so.
STEP 4 - BREED TYPE: desi, cross, or exotic, with breed_confidence 0-100. When unsure choose desi and low confidence.
STEP 5 - WEIGHT: choose a weight inside the matching range.

CRITICAL RULES:
- Vision models usually OVERESTIMATE small animals. Be conservative for goat and sheep.
- A typical village goat or sheep is 15-30 kg, NOT 40+ kg.
- If NO reference object: set reference_object_seen false, lower confidence by about 20 points, stay in lower half.
- Do not mix species (goat is not sheep, buffalo is not cow).
- Dog, cat, wild bird, or any non-livestock -> return the error JSON.

Return ONLY this JSON structure:
{
  "status": "success",
  "species": "<cow|buffalo|goat|sheep|chicken|duck>",
  "speciesEnglish": "<English name>",
  "age_class": "<juvenile|growing|adult>",
  "breedType": "<desi|cross|exotic>",
  "breed_confidence": <0-100>,
  "sizeCategory": "<small|medium|large>",
  "reference_object_seen": <true|false>,
  "reference_object": "<what you used, or none>",
  "shoulder_height_cm": <number>,
  "body_condition": "<Thin|Average|Good|Fat>",
  "estimated_weight_kg": <number>,
  "weight_range_kg": { "min": <number>, "max": <number> },
  "confidence_percentage": <0-100>,
  "observations": "<one short sentence>",
  "notes": "This weight is an estimate - use a weighing scale for exact weight."
}

If NOT supported:
{
  "status": "error",
  "error": "birds_pets_not_supported",
  "errorEnglish": "This measurement is only for livestock. Please upload a cow, buffalo, goat, sheep, chicken, or duck."
}`;

const WS_USER_NUDGE = 'Analyze this animal image step by step (species, age class, scale/shoulder height, breed type, weight). Be conservative for small animals. Reply with the JSON object only, in English.';

function escapeHtmlWS(text) {
  const div = document.createElement('div');
  div.textContent = String(text ?? '');
  return div.innerHTML;
}

function _wsParseJSON(raw) {
  if (!raw || typeof raw !== 'string') return null;
  const t = raw.replace(/<think>[\s\S]*?<\/think>/gi, '').replace(/```(?:json)?/gi, '').trim();
  let parsed;
  try { parsed = JSON.parse(t); }
  catch (_) {
    const m = t.match(/\{[\s\S]*\}/);
    if (m) { try { parsed = JSON.parse(m[0]); } catch (_) {} }
  }
  if (!parsed) return null;
  if (window.DVLangGuard) {
    const clean = obj => {
      if (typeof obj === 'string') return window.DVLangGuard.stripForeign(obj);
      if (Array.isArray(obj)) return obj.map(clean);
      if (obj && typeof obj === 'object') {
        const out = {};
        for (const k of Object.keys(obj)) out[k] = clean(obj[k]);
        return out;
      }
      return obj;
    };
    parsed = clean(parsed);
  }
  return parsed;
}

function _wsNormalize(d) {
  if (!d || typeof d !== 'object') return null;

  if (d.status === 'error') {
    return {
      status: 'error',
      error: String(d.error || 'not_supported'),
      errorEnglish: String(d.errorEnglish || 'This measurement is only for livestock.')
    };
  }

  const species = wsResolveSpecies(d.species || d.speciesEnglish);
  if (!species) return null;

  const range = WS_BREED_RANGES[species];
  const o = range.overall;
  const isSmall = SMALL_RUMINANTS.has(species);

  let w = Number(d.estimated_weight_kg);
  if (!isFinite(w) || w <= 0 || w > WS_MAX_SANE_KG) return null;
  const rawWeight = w;

  let ageClass = String(d.age_class || d.ageClass || 'adult').toLowerCase().trim();
  if (['kid', 'calf', 'lamb', 'chick', 'duckling', 'newborn', 'baby'].includes(ageClass)) ageClass = 'juvenile';
  if (['young', 'subadult', 'sub-adult', 'yearling'].includes(ageClass)) ageClass = 'growing';
  if (!['juvenile', 'growing', 'adult'].includes(ageClass)) ageClass = 'adult';

  w *= (WS_CALIBRATION[species] || 1);
  const refSeen = d.reference_object_seen !== false;
  if (!refSeen && WS_NO_REF_SHRINK[species]) w *= WS_NO_REF_SHRINK[species];

  const heightCm = Number(d.shoulder_height_cm);
  let heightCapped = false;
  const hCap = wsHeightCap(species, heightCm);
  if (hCap && w > hCap) {
    console.warn(`${species} ${wsRound(w)}kg too heavy for ${heightCm}cm height - cap ${hCap}kg`);
    w = hCap;
    heightCapped = true;
  }

  w = Math.max(o.min, Math.min(o.max, w));

  let breedType = String(d.breedType || '').toLowerCase().trim();
  let bc = Number(d.breed_confidence);
  if (!isFinite(bc)) bc = 60;
  bc = Math.max(0, Math.min(100, bc));

  if (!['desi', 'cross', 'exotic'].includes(breedType)) {
    if (w <= range.desi.max) breedType = 'desi';
    else if (w <= range.cross.max) breedType = 'cross';
    else breedType = 'exotic';
  }
  let breedDemoted = false;
  if (isSmall && breedType !== 'desi' && bc < WS_SMALL_BREED_MIN_CONF) {
    breedType = 'desi'; breedDemoted = true;
  } else if (!isSmall && breedType === 'exotic' && bc < WS_EXOTIC_MIN_CONF) {
    breedType = 'cross'; breedDemoted = true;
  }

  const br = range[breedType] || range.desi;
  const ar = wsActiveRange(species, ageClass, breedType);

  if (isSmall && breedType === 'desi' && ageClass !== 'juvenile' && bc < 85) {
    const mid = (ar.min + ar.max) / 2;
    if (w > mid) w -= (WS_PRIOR_PULL[species] || 0) * (w - mid);
  }

  if (w < ar.min) w = ar.min;
  if (w > ar.max) w = ar.max;
  if (w !== rawWeight) {
    console.info(`${species} (${ageClass}/${breedType}) AI ${rawWeight}kg -> final ${wsRound(w)}kg`);
  }

  const weight = wsRound(w);

  let sizeCategory = String(d.sizeCategory || '').toLowerCase();
  if (ageClass === 'adult' || !['small', 'medium', 'large'].includes(sizeCategory)) {
    sizeCategory = ageClass === 'adult'
      ? wsSizeOf(species, weight, breedType)
      : 'small';
  }

  let conf = Number(d.confidence_percentage);
  if (!isFinite(conf)) conf = 60;
  if (!refSeen) conf = Math.max(35, conf - 20);
  if (heightCapped || breedDemoted) conf = Math.min(conf, 70);
  conf = Math.max(0, Math.min(100, Math.round(conf)));

  const spread = conf >= 75 ? 0.10 : conf >= 55 ? 0.15 : 0.20;
  let min = Number(d.weight_range_kg?.min) * (WS_CALIBRATION[species] || 1);
  let max = Number(d.weight_range_kg?.max) * (WS_CALIBRATION[species] || 1);
  const aiRangeOk = isFinite(min) && isFinite(max) && min > 0 && min <= weight && max >= weight
    && min >= ar.min * 0.75 && max <= ar.max * 1.25 && (max - min) <= weight * 0.6;
  if (!aiRangeOk) {
    min = weight * (1 - spread);
    max = weight * (1 + spread);
  }
  min = wsRoundBound(Math.max(ar.min, Math.min(min, weight)));
  max = wsRoundBound(Math.min(ar.max, Math.max(max, weight)));
  if (min > weight) min = weight;
  if (max < weight) max = weight;

  return {
    status: 'success',
    species,
    speciesEnglish: d.speciesEnglish || range.label,
    ageClass,
    breedType,
    breedConfidence: Math.round(bc),
    sizeCategory,
    sizeLabel: wsSizeLabel(species, weight, breedType, ageClass),
    shoulderHeightCm: (isFinite(heightCm) && heightCm >= 10 && heightCm <= 200) ? Math.round(heightCm) : null,
    estimated_weight_kg: weight,
    weight_range_kg: { min, max },
    confidence_percentage: conf,
    body_condition: d.body_condition || '',
    reference_object_seen: refSeen,
    reference_object: d.reference_object && d.reference_object !== 'none' ? String(d.reference_object) : '',
    observations: d.observations || '',
    notes: d.notes || 'This weight is an estimate - use a weighing scale for exact weight.'
  };
}

function _wsParseImage(img) {
  const m = /^data:([^;]+);base64,(.*)$/.exec(img || '');
  return m ? { mime: m[1], data: m[2] } : { mime: 'image/jpeg', data: img };
}

const WS_BLOCK_STORE = 'dvWsBlocks';
const _wsBlocks = new Map();
const _wsStrikes = new Map();
const _wsRot = { gemini: 0, groq: 0, openrouter: 0 };

(function _wsLoadBlocks() {
  try {
    Object.entries(JSON.parse(_wsLsGet(WS_BLOCK_STORE) || '{}')).forEach(([id, until]) => {
      if (until > Date.now()) _wsBlocks.set(id, until);
    });
  } catch (_) {}
})();

const _wsTail = k => k.slice(-8);
const _wsKeyId = s => `k:${s.provider}:${_wsTail(s.key)}`;
const _wsModelId = s => `m:${s.provider}:${s.model}`;
const _wsIsBlocked = id => (_wsBlocks.get(id) || 0) > Date.now();
const _wsSlotBlocked = s => _wsIsBlocked(s.id) || _wsIsBlocked(_wsKeyId(s)) || _wsIsBlocked(_wsModelId(s));

function _wsBlock(id, ms) {
  _wsBlocks.set(id, Date.now() + ms);
  const live = {};
  _wsBlocks.forEach((until, k) => { if (until > Date.now()) live[k] = until; });
  _wsLsSet(WS_BLOCK_STORE, JSON.stringify(live));
}

function _wsInterleave(lists) {
  const out = [];
  const idx = lists.map(() => 0);
  let added = true;
  while (added) {
    added = false;
    lists.forEach((list, i) => {
      if (idx[i] < list.length) { out.push(list[idx[i]++]); added = true; }
    });
  }
  return out;
}

function _wsBuildSlots() {
  const perProvider = WS_PROVIDER_ORDER.map(provider => {
    const keys = (WS_KEYS[provider] || []).filter(Boolean);
    if (!keys.length) return [];
    const shift = _wsRot[provider] % keys.length;
    const rotated = keys.slice(shift).concat(keys.slice(0, shift));
    const seen = new Set();
    const out = [];
    for (const model of WS_MODELS[provider]) {
      for (const key of rotated) {
        const id = `s:${provider}:${model}:${_wsTail(key)}`;
        if (seen.has(id)) continue;
        seen.add(id);
        out.push({ provider, model, key, id });
      }
    }
    return out;
  });
  const live = _wsInterleave(perProvider.map(list => list.filter(s => !_wsSlotBlocked(s))));
  if (live.length) return live;
  return _wsInterleave(perProvider.map(list => list.filter(s =>
    !_wsIsBlocked(_wsKeyId(s)) && !_wsIsBlocked(_wsModelId(s))
  ))).slice(0, 4);
}

function compressWSImage(file, maxDim = 1400, quality = 0.85) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          const scale = maxDim / Math.max(width, height);
          width = Math.round(width * scale);
          height = Math.round(height * scale);
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        canvas.getContext('2d').drawImage(img, 0, 0, width, height);
        let q = quality;
        let dataUrl = canvas.toDataURL('image/jpeg', q);
        for (let i = 0; i < 5 && dataUrl.length * 0.75 > WS_TARGET_MAX_BYTES && q > 0.4; i++) {
          q -= 0.12;
          dataUrl = canvas.toDataURL('image/jpeg', q);
        }
        resolve(dataUrl);
      };
      img.onerror = () => reject(new Error('Image decode failed'));
      img.src = e.target.result;
    };
    reader.onerror = () => reject(new Error('File read failed'));
    reader.readAsDataURL(file);
  });
}

window.openWeightScale = function () {
  const modal = _el('weightScaleModal');
  if (!modal) return;
  modal.classList.remove('hidden');
  modal.style.display = 'block';
  document.body.style.overflow = 'hidden';

  wsSelectedImage = null;
  wsPendingWeight = null;
  wsPendingFromAI = false;
  const applyBtn = _el('wsApplyBtn');
  if (applyBtn) applyBtn.disabled = true;
  const aiResult = _el('wsAiResult');
  if (aiResult) { aiResult.style.display = 'none'; aiResult.innerHTML = ''; }
  const preview = _el('wsAiPreview');
  if (preview) { preview.style.display = 'none'; preview.classList.add('hidden'); }
  const imageField = _el('wsImageField');
  if (imageField) imageField.style.display = 'flex';
  const girth = _el('wsGirth'), length = _el('wsLength'), tapeWeight = _el('wsTapeWeight');
  if (girth) girth.value = '';
  if (length) length.value = '';
  if (tapeWeight) tapeWeight.textContent = '0';

  switchWsTab('ai');
};

window.closeWeightScale = function () {
  const modal = _el('weightScaleModal');
  if (!modal) return;
  modal.classList.add('hidden');
  modal.style.display = 'none';
  document.body.style.overflow = '';
};

window.switchWsTab = function (tab) {
  const tabTape = _el('wsTabTape'), tabAI = _el('wsTabAI');
  const contentTape = _el('wsContentTape'), contentAI = _el('wsContentAI');
  if (!tabTape || !tabAI || !contentTape || !contentAI) return;
  const activeCls = ['bg-white', 'text-deep', 'shadow-xs'];
  const inactiveCls = ['bg-transparent', 'text-mute'];
  const setActive = (el) => { el.classList.add(...activeCls); el.classList.remove(...inactiveCls); };
  const setInactive = (el) => { el.classList.remove(...activeCls); el.classList.add(...inactiveCls); };
  if (tab === 'tape') {
    setActive(tabTape); setInactive(tabAI);
    contentTape.classList.remove('hidden'); contentTape.style.display = 'flex';
    contentAI.classList.add('hidden'); contentAI.style.display = 'none';
  } else {
    setActive(tabAI); setInactive(tabTape);
    contentAI.classList.remove('hidden'); contentAI.style.display = 'flex';
    contentTape.classList.add('hidden'); contentTape.style.display = 'none';
  }
};

window.calculateTapeWeight = function () {
  const girthIn = parseFloat(_el('wsGirth')?.value) || 0;
  const lengthIn = parseFloat(_el('wsLength')?.value) || 0;
  const weightEl = _el('wsTapeWeight');
  const applyBtn = _el('wsApplyBtn');
  if (girthIn > 0 && lengthIn > 0) {
    const weightKg = (girthIn * girthIn * lengthIn) / 660;
    const rounded = Math.round(weightKg * 10) / 10;
    if (weightEl) weightEl.textContent = rounded.toFixed(1);
    wsPendingWeight = rounded;
    wsPendingFromAI = false;
    if (applyBtn) applyBtn.disabled = false;
  } else {
    if (weightEl) weightEl.textContent = '0';
    wsPendingWeight = null;
    wsPendingFromAI = false;
    if (applyBtn) applyBtn.disabled = true;
  }
};

async function handleWsImage(event) {
  const file = event.target.files?.[0];
  if (file) await processWSImageFile(file);
  event.target.value = '';
}
window.handleWsImage = handleWsImage;

async function processWSImageFile(file) {
  if (!file || !file.type.startsWith('image/')) return;
  if (file.size > WS_MAX_IMAGE_MB * 1024 * 1024) {
    alert(`Image too large. Please choose under ${WS_MAX_IMAGE_MB}MB.`);
    return;
  }
  try {
    wsSelectedImage = await compressWSImage(file);
    showWSPreview(wsSelectedImage);
  } catch (err) {
    alert('Failed to read image: ' + err.message);
  }
}

function showWSPreview(dataURL) {
  const imageField = _el('wsImageField');
  const preview = _el('wsAiPreview');
  const img = _el('wsPreviewImg');
  if (imageField) imageField.style.display = 'none';
  if (preview && img) { img.src = dataURL; preview.classList.remove('hidden'); preview.style.display = 'flex'; }
  const result = _el('wsAiResult');
  if (result) { result.classList.add('hidden'); result.style.display = 'none'; }
  const loading = _el('wsAiLoading');
  if (loading) { loading.classList.add('hidden'); loading.style.display = 'none'; }
}

window.removeWSPreview = function () {
  wsSelectedImage = null;
  const preview = _el('wsAiPreview');
  if (preview) { preview.style.display = 'none'; preview.classList.add('hidden'); }
  const imageField = _el('wsImageField');
  if (imageField) imageField.style.display = 'flex';
  const result = _el('wsAiResult');
  if (result) { result.classList.add('hidden'); result.style.display = 'none'; result.innerHTML = ''; }
  const loading = _el('wsAiLoading');
  if (loading) { loading.classList.add('hidden'); loading.style.display = 'none'; }
  ['wsCameraInput', 'wsGalleryInput'].forEach(id => { const el = _el(id); if (el) el.value = ''; });
  const applyBtn = _el('wsApplyBtn');
  if (applyBtn) applyBtn.disabled = true;
  wsPendingWeight = null;
  wsPendingFromAI = false;
};

function _wsGeminiRequest(slot, img) {
  const { mime, data } = _wsParseImage(img);
  const generationConfig = {
    temperature: 0.1, maxOutputTokens: 1400, topP: 0.9,
    responseMimeType: 'application/json'
  };
  if (slot.model.includes('2.5')) generationConfig.thinkingConfig = { thinkingBudget: 0 };
  return {
    url: `${WS_ENDPOINTS.gemini}/${slot.model}:generateContent?key=${slot.key}`,
    headers: { 'Content-Type': 'application/json' },
    body: {
      contents: [{
        role: 'user',
        parts: [
          { inline_data: { mime_type: mime, data } },
          { text: WS_WEIGHT_PROMPT }
        ]
      }],
      generationConfig,
      safetySettings: WS_GEMINI_SAFETY
    }
  };
}

function _wsChatRequest(slot, img) {
  const url = img.startsWith('data:') ? img : `data:image/jpeg;base64,${img}`;
  const headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${slot.key}` };
  if (slot.provider === 'openrouter') {
    headers['HTTP-Referer'] = location.origin || 'https://dailyvet.app';
    headers['X-Title'] = 'DailyVet Weight';
  }
  return {
    url: WS_ENDPOINTS[slot.provider],
    headers,
    body: {
      model: slot.model,
      messages: [
        { role: 'system', content: WS_WEIGHT_PROMPT },
        {
          role: 'user',
          content: [
            { type: 'text', text: WS_USER_NUDGE },
            { type: 'image_url', image_url: { url } }
          ]
        }
      ],
      temperature: 0.1,
      max_tokens: 1400
    }
  };
}

function _wsOnHttpError(slot, status, retryAfter, bodyText) {
  const body = String(bodyText || '').slice(0, 500);
  if (status === 429) {
    const n = (_wsStrikes.get(slot.id) || 0) + 1;
    _wsStrikes.set(slot.id, n);
    const hinted = (parseInt(retryAfter, 10) || 0) * 1000;
    let ms = Math.min(Math.max(hinted, WS_COOLDOWN.rateLimit * 2 ** (n - 1)), WS_COOLDOWN.rateLimitMax);
    if (/limit:\s*0/i.test(body)) ms = WS_COOLDOWN.quotaZero;
    else if (/PerDay|per\s*day/i.test(body)) ms = WS_COOLDOWN.perDay;
    _wsBlock(slot.id, ms);
  } else if (status === 400) {
    if (/api[_ ]key (?:not valid|invalid|expired)|API_KEY_INVALID|key expired/i.test(body)) _wsBlock(_wsKeyId(slot), WS_COOLDOWN.authKey);
    else _wsBlock(slot.id, WS_COOLDOWN.badRequest);
  } else if (status === 401 || status === 403) {
    _wsBlock(_wsKeyId(slot), WS_COOLDOWN.authKey);
  } else if (status === 404) {
    _wsBlock(_wsModelId(slot), WS_COOLDOWN.modelGone);
  } else if (status >= 500 || status === 408) {
    _wsBlock(slot.id, WS_COOLDOWN.server);
  }
}

async function _wsCallSlot(slot, img, ctrl, timeoutMs, strictEnglish) {
  let timedOut = false;
  const timer = setTimeout(() => { timedOut = true; ctrl.abort(); }, timeoutMs);
  try {
    const req = slot.provider === 'gemini' ? _wsGeminiRequest(slot, img) : _wsChatRequest(slot, img);
    const res = await fetch(req.url, {
      method: 'POST',
      headers: req.headers,
      body: JSON.stringify(req.body),
      signal: ctrl.signal
    });
    if (!res.ok) {
      const errBody = await res.text().catch(() => '');
      _wsOnHttpError(slot, res.status, res.headers.get('retry-after'), errBody);
      return null;
    }
    const data = await res.json();
    let raw;
    if (slot.provider === 'gemini') {
      raw = (data.candidates?.[0]?.content?.parts || [])
        .filter(p => p && p.text && !p.thought).map(p => p.text).join('');
    } else {
      raw = data.choices?.[0]?.message?.content;
    }

    if (window.DVLangGuard && raw && !window.DVLangGuard.isEnglishEnough(raw)) {
      if (!strictEnglish) { _wsBlock(slot.id, WS_COOLDOWN.badOutput); return null; }
    }

    const parsed = _wsNormalize(_wsParseJSON(raw));
    if (!parsed) { _wsBlock(slot.id, WS_COOLDOWN.badOutput); return null; }

    _wsStrikes.delete(slot.id);
    const keys = (WS_KEYS[slot.provider] || []).filter(Boolean);
    _wsRot[slot.provider] = keys.indexOf(slot.key) + 1;
    return parsed;
  } catch (err) {
    if (timedOut) _wsBlock(slot.id, WS_COOLDOWN.timeout);
    else if (!ctrl.signal.aborted) _wsBlock(slot.id, WS_COOLDOWN.server);
    return null;
  } finally {
    clearTimeout(timer);
  }
}

function _wsCascade(slots, img, cfg, strictEnglish) {
  return new Promise(resolve => {
    let next = 0, inflight = 0, done = false;
    let deadline = null, hedgeTimer = null;
    const ctrls = new Set();
    const preBlocked = new Set(slots.filter(_wsSlotBlocked).map(s => s.id));
    const skipSlot = s => _wsSlotBlocked(s) && !preBlocked.has(s.id);

    const finish = result => {
      if (done) return;
      done = true;
      clearTimeout(deadline); clearTimeout(hedgeTimer);
      ctrls.forEach(c => { try { c.abort(); } catch (_) {} });
      resolve(result);
    };

    const launch = () => {
      if (done || inflight >= cfg.parallel) return;
      while (next < slots.length && skipSlot(slots[next])) next++;
      if (next >= slots.length) { if (!inflight) finish(null); return; }
      const slot = slots[next++];
      const ctrl = new AbortController();
      ctrls.add(ctrl);
      inflight++;
      _wsCallSlot(slot, img, ctrl, cfg.perCall, strictEnglish).then(res => {
        ctrls.delete(ctrl);
        inflight--;
        if (res) finish({ provider: slot.provider, model: slot.model, data: res });
        else launch();
      }).catch(() => {
        ctrls.delete(ctrl);
        inflight--;
        launch();
      });
    };

    deadline = setTimeout(() => finish(null), cfg.total);
    launch();
    hedgeTimer = setTimeout(launch, cfg.hedge);
  });
}

const _wsCache = new Map();
function _wsImgKey(img) {
  let h = 2166136261 >>> 0;
  const step = Math.max(1, Math.floor(img.length / 4000));
  for (let i = 0; i < img.length; i += step) {
    h ^= img.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return `${img.length}:${h}`;
}
function _wsCacheGet(key) {
  const e = _wsCache.get(key);
  if (!e) return null;
  if (Date.now() - e.t > WS_CACHE_TTL_MS) { _wsCache.delete(key); return null; }
  return e;
}
function _wsCacheSet(key, data, provider, model) {
  _wsCache.set(key, { data, provider, model, t: Date.now() });
  if (_wsCache.size > WS_CACHE_MAX) _wsCache.delete(_wsCache.keys().next().value);
}

async function wsEstimateWeight(img) {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return { unavailable: true, reason: 'offline' };
  }
  const cacheKey = _wsImgKey(img);
  const hit = _wsCacheGet(cacheKey);
  if (hit) return { data: hit.data, provider: hit.provider, model: hit.model, cached: true };

  const slots = _wsBuildSlots();
  if (!slots.length) return { unavailable: true, reason: 'no_keys' };

  for (let round = 1; round <= 3; round++) {
    const strictEnglish = round === 3;
    let res = null;
    try { res = await _wsCascade(slots, img, WS_TIMING, strictEnglish); }
    catch (_) { res = null; }
    if (res && res.data) {
      _wsCacheSet(cacheKey, res.data, res.provider, res.model);
      return { data: res.data, provider: res.provider, model: res.model, cached: false };
    }
  }
  return { unavailable: true, reason: 'busy' };
}

window.runAiWeightScan = async function () {
  if (wsScanning) return;
  if (!wsSelectedImage) { alert('Please select or take a photo first.'); return; }
  wsScanning = true;

  const scanBtn = _el('wsScanBtn');
  const preview = _el('wsAiPreview');
  const loading = _el('wsAiLoading');
  const result = _el('wsAiResult');
  const applyBtn = _el('wsApplyBtn');

  if (wsPendingFromAI) {
    wsPendingWeight = null;
    wsPendingFromAI = false;
    if (applyBtn) applyBtn.disabled = true;
  }

  if (scanBtn) scanBtn.disabled = true;
  if (preview) preview.style.display = 'none';
  if (result) { result.classList.add('hidden'); result.style.display = 'none'; }
  if (loading) { loading.classList.remove('hidden'); loading.style.display = 'flex'; }

  const hideLoading = () => { if (loading) { loading.classList.add('hidden'); loading.style.display = 'none'; } };

  try {
    const out = await Promise.race([
      wsEstimateWeight(wsSelectedImage),
      new Promise(r => setTimeout(() => r({ unavailable: true, reason: 'busy' }), WS_TIMING.total + WS_WATCHDOG_EXTRA_MS))
    ]);
    hideLoading();
    if (out && out.data) renderWSResult(out.data);
    else renderWSUnavailable(out && out.reason);
  } catch (err) {
    console.error('WS scan error:', err);
    hideLoading();
    renderWSUnavailable('busy');
  } finally {
    wsScanning = false;
    if (scanBtn) scanBtn.disabled = false;
  }
};

function renderWSUnavailable(reason) {
  const resultEl = _el('wsAiResult');
  if (!resultEl) return;
  const msg = reason === 'offline'
    ? 'No internet connection. Try again when online, or use Tape Measure now.'
    : 'AI service is busy, so weight could not be estimated. Try again shortly, or use Tape Measure.';
  const btn = 'border:0;border-radius:10px;padding:8px 14px;font-weight:600;font-size:13px;cursor:pointer;';
  resultEl.innerHTML = `
    <div class="ws-error-box">
      <div class="ws-error-icon"><i class="fas fa-triangle-exclamation"></i></div>
      <div class="ws-error-title">AI is busy</div>
      <div class="ws-error-msg">${escapeHtmlWS(msg)}</div>
      <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:12px;">
        <button type="button" style="${btn}background:#088F8F;color:#fff;" onclick="runAiWeightScan()">Try again</button>
        <button type="button" style="${btn}background:#e0f0f2;color:#035D69;" onclick="switchWsTab('tape')">Tape Measure</button>
      </div>
    </div>`;
  resultEl.classList.remove('hidden');
  resultEl.style.display = 'flex';
}

function renderWSResult(data) {
  const resultEl = _el('wsAiResult');
  if (!resultEl) return;

  if (!data || data.status === 'error') {
    const errMsg = data?.errorEnglish || data?.error || 'Could not analyze this image.';
    resultEl.innerHTML = `
      <div class="ws-error-box">
        <div class="ws-error-icon"><i class="fas fa-triangle-exclamation"></i></div>
        <div class="ws-error-title">Not Supported</div>
        <div class="ws-error-msg">${escapeHtmlWS(errMsg)}</div>
      </div>`;
    resultEl.classList.remove('hidden');
    resultEl.style.display = 'flex';
    return;
  }

  const weight = data.estimated_weight_kg || 0;
  const range = data.weight_range_kg || {};
  const confidence = data.confidence_percentage || 0;

  if (weight > 0) {
    wsPendingWeight = weight;
    wsPendingFromAI = true;
    const applyBtn = _el('wsApplyBtn');
    if (applyBtn) applyBtn.disabled = false;
  }

  const userImageHTML = wsSelectedImage
    ? `<div class="ws-user-image-wrap"><img src="${wsSelectedImage}" alt="Analyzed Animal" /></div>` : '';

  const row = (label, value, isHighlight = false) => `
    <div class="ws-detail-row">
      <span class="ws-detail-label">${label}</span>
      <span class="ws-detail-value ${isHighlight ? 'highlight' : ''}">${value}</span>
    </div>`;

  const breedBase = data.breedType
    ? (data.breedType === 'desi' ? 'Local (Desi)'
      : data.breedType === 'cross' ? 'Crossbreed'
      : 'Exotic')
    : '-';
  const breedLabel = data.breedConfidence ? `${breedBase} - ${data.breedConfidence}% sure` : breedBase;

  const ageLabel = data.ageClass === 'juvenile' ? 'Very young'
    : data.ageClass === 'growing' ? 'Growing (young)'
    : 'Adult';

  const sizeLabel = data.sizeLabel || '-';

  resultEl.innerHTML = `
    <div class="ws-result-header">
      <div class="ws-result-header-left">
        <div class="ws-result-icon"><i class="fas fa-check-circle"></i></div>
        <span class="ws-result-title">AI Analysis Complete</span>
      </div>
      <span class="ws-result-badge">${confidence}% confidence</span>
    </div>

    ${userImageHTML}

    <div class="ws-details-card">
      ${row('Animal', escapeHtmlWS(data.speciesEnglish || '-'))}
      ${row('Age Group', escapeHtmlWS(ageLabel))}
      ${row('Breed Type', escapeHtmlWS(breedLabel))}
      ${row('Size', escapeHtmlWS(sizeLabel))}
      ${data.shoulderHeightCm ? row('Shoulder Height', `~${data.shoulderHeightCm} cm`) : ''}
      ${row('Estimated Weight', `${weight} kg`, true)}
      ${range.min && range.max ? row('Range', `${range.min}-${range.max} kg`) : ''}
      ${data.body_condition ? row('Body Condition', escapeHtmlWS(data.body_condition)) : ''}
      ${data.reference_object ? row('Scale Used', escapeHtmlWS(data.reference_object)) : ''}
      ${data.reference_object_seen === false
        ? row('Reference', 'No reference object - estimate may be off') : ''}
    </div>

    ${data.observations ? `
      <div class="ws-observations">
        <div class="ws-observations-inner">
          <i class="fas fa-eye"></i>
          <div><strong>AI Observations</strong><span>${escapeHtmlWS(data.observations)}</span></div>
        </div>
      </div>` : ''}

    ${data.notes ? `
      <div class="ws-notes">
        <div class="ws-notes-inner">
          <i class="fas fa-info-circle"></i>
          <span>${escapeHtmlWS(data.notes)}</span>
        </div>
      </div>` : ''}`;

  resultEl.classList.remove('hidden');
  resultEl.style.display = 'flex';
  resultEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

window.applyEstimatedWeight = function () {
  if (!wsPendingWeight || wsPendingWeight <= 0) return;
  const weightInput = document.getElementById('petWeight');
  if (weightInput) {
    weightInput.value = Number(wsPendingWeight).toFixed(1);
    weightInput.dispatchEvent(new Event('input', { bubbles: true }));
    weightInput.dispatchEvent(new Event('change', { bubbles: true }));
  }
  closeWeightScale();
};

document.addEventListener('DOMContentLoaded', () => {
  wsCurrentPhone = _wsLsGet('userPhone') || (() => { try { return sessionStorage.getItem('userPhone'); } catch (_) { return null; } })();

  ['wsCameraInput', 'wsGalleryInput'].forEach(id => {
    const el = _el(id);
    if (el) el.addEventListener('change', handleWsImage);
  });

  const imageField = _el('wsImageField');
  if (imageField) {
    imageField.addEventListener('click', (e) => {
      if (e.target.closest('button')) return;
      const input = _el('wsGalleryInput');
      if (input) input.click();
    });
    imageField.addEventListener('dragover', (e) => {
      e.preventDefault(); e.stopPropagation();
      imageField.classList.add('border-teal', 'bg-teal/5');
    });
    imageField.addEventListener('dragleave', (e) => {
      e.preventDefault(); e.stopPropagation();
      imageField.classList.remove('border-teal', 'bg-teal/5');
    });
    imageField.addEventListener('drop', (e) => {
      e.preventDefault(); e.stopPropagation();
      imageField.classList.remove('border-teal', 'bg-teal/5');
      const imgFile = Array.from(e.dataTransfer?.files || []).find(f => f.type.startsWith('image/'));
      if (imgFile) processWSImageFile(imgFile);
    });
  }

  document.addEventListener('paste', (e) => {
    const modal = _el('weightScaleModal');
    if (!modal || modal.classList.contains('hidden')) return;
    const imageItem = Array.from(e.clipboardData?.items || []).find(i => i.type.indexOf('image') !== -1);
    if (!imageItem) return;
    const file = imageItem.getAsFile();
    if (!file) return;
    e.preventDefault();
    processWSImageFile(file);
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const modal = _el('weightScaleModal');
      if (modal && !modal.classList.contains('hidden')) closeWeightScale();
    }
  });

  console.log('Weight Estimator v7.1 ready (SEGMENT 1 fix applied)');
});

window.WSDebug = {
  status() {
    const now = Date.now();
    console.table([..._wsBlocks].filter(([, until]) => until > now)
      .map(([id, until]) => ({ id, secsLeft: Math.round((until - now) / 1000) })));
    console.log('Usable slots:', _wsBuildSlots().length);
  },
  reset() {
    _wsBlocks.clear(); _wsStrikes.clear();
    _wsLsSet(WS_BLOCK_STORE, '{}');
    console.log('WS block cleared');
  },
  clearCache() { _wsCache.clear(); console.log('WS cache cleared'); },
  estimate: wsEstimateWeight,
  normalize: _wsNormalize,
  ranges: WS_BREED_RANGES,
  calibration: WS_CALIBRATION,
  heightCaps: WS_HEIGHT_CAPS,
  sizeOf: wsSizeOf,
  sizeLabel: wsSizeLabel
};

})();