/* DailyVet — Notification Engine v4.2

   All notifications are English only.
   No Bangla strings anywhere in code or output.
   Uses live data from NasaGpm, NasaPower, NasaOutbreak.

   v4.2 changes:
   • scheduleNasaOutbreakAlert() uses districtEn for English title
   • Disease name priority: nameEn > nameBn fallback
   • createNotification() returns null gracefully if Firebase missing
   • Removed unused TEST_MODE branches in reminder timing
   • checkAndFireReminders() skipped if scheduledForMs in future
   • All Bangla comments replaced with English
*/
(function () {
'use strict';

const _store = (name, key) => { try { return window[name].getItem(key); } catch (_) { return null; } };
const TEST_MODE = _store('localStorage', 'dvNotifTest') === '1';
const REAL_DAY_MS = 24 * 60 * 60 * 1000;
const REAL_HOUR_MS = 60 * 60 * 1000;
const DAY_MS = TEST_MODE ? 3000 : REAL_DAY_MS;
const HOUR_MS = TEST_MODE ? 1666 : REAL_HOUR_MS;
const REMINDER_INTERVAL_HOURS = 6;
const MAX_ACTIVE_NOTIFS = 40;
const DEDUPE_LIMIT = 15;
const DEDUPE_WINDOW_MS = TEST_MODE ? 20 * 1000 : 12 * 60 * 60 * 1000;
const GLOBAL_RATE_LIMIT_PER_HOUR = 3;
const RATE_LIMIT_WINDOW_MS = TEST_MODE ? 5 * 1000 : 60 * 60 * 1000;
const RATE_LIMITED_TYPES = new Set(['nasa_outbreak_alert', 'flood_alert', 'aqi_alert', 'weather_alert']);

const _fs = () => {
    try {
        if (typeof firebase === 'undefined' || !firebase.firestore) return null;
        return firebase.firestore();
    } catch (_) { return null; }
};
const _cleanPhone = p => String(p || '').replace(/[^0-9+]/g, '');
const getMyPhone = () => _cleanPhone(_store('localStorage', 'userPhone') || _store('sessionStorage', 'userPhone'));
const _notifRef = () => {
    try {
        const phone = getMyPhone();
        const fs = _fs();
        if (!fs || !phone) return null;
        return fs.collection('users').doc(phone).collection('notifications');
    } catch (_) { return null; }
};

/* ============================================================
   AI REPLY PARSING
   ============================================================ */
const _norm = s => String(s || '').replace(/[০-৯]/g, d => String.fromCharCode(d.charCodeAt(0) - 0x09E6 + 48));

function extractDurationDays(text) {
    if (!text) return null;
    const t = _norm(text);
    let m = t.match(/(\d+)\s*(?:-\s*\d+)?\s*(day|days|din)/i);
    if (m) return Math.min(30, Math.max(1, parseInt(m[1], 10)));
    m = t.match(/(\d+)\s*(week|weeks)/i);
    if (m) return Math.min(30, Math.max(1, parseInt(m[1], 10) * 7));
    m = t.match(/(\d+)\s*(month|months)/i);
    if (m) return Math.min(90, Math.max(1, parseInt(m[1], 10) * 30));
    return null;
}

const _hasAny = (text, kws) => {
    if (!text) return false;
    const l = String(text).toLowerCase();
    return kws.some(k => l.includes(k));
};

const MEDICINE_KEYWORDS = ['medicine', 'tablet', 'antibiotic', 'dose', 'syrup', 'injection', 'meloxicam', 'enrofloxacin', 'albendazole', 'fenbendazole', 'ivermectin', 'oxytetracycline', 'amoxicillin'];
const FOLLOWUP_KEYWORDS = ['follow up', 'follow-up', 'followup', 'check back', 'let me know', 'report back', 'update me'];
const VACCINE_KEYWORDS = ['vaccine', 'vaccination', 'booster', 'immunization'];
const EMERGENCY_RE = /🚨|emergency|seizure|poisoning|unconscious|convulsion/i;

const hasMedicineAdvice = t => _hasAny(t, MEDICINE_KEYWORDS);
const hasFollowUpHint = t => _hasAny(t, FOLLOWUP_KEYWORDS);
const hasVaccineAdvice = t => _hasAny(t, VACCINE_KEYWORDS);
const isEmergencyReply = t => !!t && EMERGENCY_RE.test(t);

/* ============================================================
   DEDUPE + RATE LIMIT
   ============================================================ */
const _inflight = new Set();
const LEVEL_RANK = { watch: 1, alert: 2, critical: 3 };
const _rank = lv => LEVEL_RANK[lv] || 0;

async function _recentDuplicate(ref, type, petName, district, level) {
    try {
        const since = Date.now() - DEDUPE_WINDOW_MS;
        const snap = await ref.where('type', '==', type).where('active', '==', true).limit(DEDUPE_LIMIT).get();
        return snap.docs.some(doc => {
            const d = doc.data();
            if ((d.createdAtMs || 0) < since) return false;
            if (petName && d.petName && d.petName !== petName) return false;
            if (district && d.meta && d.meta.district && d.meta.district !== district) return false;
            if (level && _rank(level) > _rank(d.meta && d.meta.level)) return false;
            return true;
        });
    } catch (e) { return false; }
}

async function _checkGlobalRateLimit(ref, type, level) {
    if (_rank(level) >= LEVEL_RANK.critical) return true;
    if (!RATE_LIMITED_TYPES.has(type)) return true;
    try {
        const since = Date.now() - RATE_LIMIT_WINDOW_MS;
        const snap = await ref.where('type', '==', type).where('active', '==', true).limit(MAX_ACTIVE_NOTIFS).get();
        const recent = snap.docs.filter(doc => (doc.data().createdAtMs || 0) >= since).length;
        if (recent >= GLOBAL_RATE_LIMIT_PER_HOUR) return false;
        return true;
    } catch (_) { return true; }
}

/* ============================================================
   CREATE
   ============================================================ */
async function createNotification(data) {
    const ref = _notifRef();
    if (!ref) return null;

    const type = data.type || 'general';
    const petName = data.petName || null;
    const district = (data.meta && data.meta.district) || null;
    const level = (data.meta && data.meta.level) || null;
    const lockKey = `${type}|${petName || ''}|${district || ''}|${level || ''}`;

    if (_inflight.has(lockKey)) return null;
    _inflight.add(lockKey);

    try {
        if (!(await _checkGlobalRateLimit(ref, type, level))) return null;
        if (await _recentDuplicate(ref, type, petName, district, level)) return null;

        const now = Date.now();
        const docRef = await ref.add({
            title: data.title || 'DailyVet',
            body: data.body || '',
            icon: data.icon || '🔔',
            type,
            priority: data.priority || 'medium',
            petName,
            actionUrl: data.actionUrl || 'ai.html',
            meta: data.meta || {},
            read: false,
            active: true,
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            createdAtMs: now,
            scheduledForMs: data.scheduledFor || now,
            reminderIntervalMs: data.reminderInterval || (REMINDER_INTERVAL_HOURS * HOUR_MS),
            lastRemindedAtMs: 0,
            remindCount: 0,
            maxReminds: data.maxReminds != null ? data.maxReminds : 8
        });
        return docRef.id;
    } catch (err) {
        console.warn('[Notif] Create failed:', err.message);
        return null;
    } finally {
        _inflight.delete(lockKey);
    }
}

async function _fireReminder(ref, id) {
    try {
        await ref.doc(id).update({
            lastRemindedAt: firebase.firestore.FieldValue.serverTimestamp(),
            lastRemindedAtMs: Date.now(),
            remindCount: firebase.firestore.FieldValue.increment(1),
            read: false,
            bumpedAt: Date.now()
        });
    } catch (_) {}
}

/* ============================================================
   AI REPLY ANALYSIS
   ============================================================ */
async function analyzeAndSchedule(aiReplyText, userText, context) {
    if (typeof aiReplyText !== 'string' || !aiReplyText) return;
    context = context || {};
    const petName = context.petName || 'Your animal';
    const species = context.species || null;

    if (aiReplyText.length < 40 && !hasMedicineAdvice(aiReplyText)) return;
    if (/⏸️|Too many requests/.test(aiReplyText)) return;

    if (isEmergencyReply(aiReplyText)) {
        await createNotification({
            title: '🚨 Emergency Care',
            body: `${petName} — emergency situation. Vet / helpline 16358.`,
            icon: '🚨', type: 'emergency', priority: 'high', petName, actionUrl: 'ai.html',
            scheduledFor: Date.now(), maxReminds: 3,
            meta: { species, kind: 'emergency' }
        });
        return;
    }

    const med = hasMedicineAdvice(aiReplyText);
    if (med) {
        const days = extractDurationDays(aiReplyText) || 3;
        await createNotification({
            title: '💊 Start Medicine',
            body: `Give medicine to ${petName} as advised by the vet. Follow-up in ~${days} day(s).`,
            icon: '💊', type: 'medicine_start', priority: 'high', petName, actionUrl: 'ai.html',
            scheduledFor: Date.now(), maxReminds: 4,
            meta: { days, species, kind: 'medicine_start' }
        });
        await createNotification({
            title: '💊 Medicine Course Ending?',
            body: `${petName}'s ~${days}-day medicine course should be finishing. Please report their condition.`,
            icon: '💊', type: 'medicine_followup', priority: 'high', petName, actionUrl: 'ai.html',
            scheduledFor: Date.now() + days * DAY_MS, maxReminds: 6,
            meta: { days, species, kind: 'medicine_followup' }
        });
    }

    if (!med && hasFollowUpHint(aiReplyText)) {
        await createNotification({
            title: '📋 Status Check',
            body: `How is ${petName} doing? Let us know in the AI chat.`,
            icon: '📋', type: 'followup', priority: 'medium', petName, actionUrl: 'ai.html',
            scheduledFor: Date.now() + 2 * DAY_MS, maxReminds: 5,
            meta: { species, kind: 'followup' }
        });
    }

    if (hasVaccineAdvice(aiReplyText)) {
        await createNotification({
            title: '💉 Vaccine Reminder',
            body: `Confirm ${petName}'s vaccine / booster schedule with the vet.`,
            icon: '💉', type: 'vaccine_reminder', priority: 'high', petName, actionUrl: 'ai.html',
            scheduledFor: Date.now() + 7 * DAY_MS, maxReminds: 4,
            meta: { species, kind: 'vaccine' }
        });
    }
}

/* ============================================================
   REMINDER CHECK
   ============================================================ */
async function checkAndFireReminders() {
    const ref = _notifRef();
    if (!ref) return;
    try {
        const snap = await ref.where('active', '==', true).limit(MAX_ACTIVE_NOTIFS).get();
        if (snap.empty) return;

        const now = Date.now();
        const tasks = [];

        snap.docs.forEach(doc => {
            const d = doc.data();
            const scheduledFor = d.scheduledForMs || 0;

            /* Skip notifications that are scheduled for the future */
            if (now < scheduledFor) return;

            const count = d.remindCount || 0;
            const maxR = d.maxReminds != null ? d.maxReminds : 8;

            if (count >= maxR) {
                tasks.push(ref.doc(doc.id).update({ active: false }).catch(() => {}));
                return;
            }

            const interval = d.reminderIntervalMs || (REMINDER_INTERVAL_HOURS * HOUR_MS);
            if (count === 0 || now - (d.lastRemindedAtMs || 0) >= interval) {
                tasks.push(_fireReminder(ref, doc.id));
            }
        });

        await Promise.all(tasks);
    } catch (err) {
        console.warn('[Notif] reminders:', err.message);
    }
}

/* ============================================================
   LOCAL PUSH
   ============================================================ */
const pushSupported = () => typeof window !== 'undefined' && 'Notification' in window;
const pushPermission = () => pushSupported() ? Notification.permission : 'unsupported';

async function requestPushPermission() {
    if (!pushSupported()) return 'unsupported';
    if (Notification.permission !== 'default') return Notification.permission;
    try { return await Notification.requestPermission(); }
    catch (_) { return Notification.permission; }
}

async function showLocalPush(title, body, url, tag) {
    if (!pushSupported() || Notification.permission !== 'granted') return false;
    const opts = { body, tag: tag || 'dailyvet', lang: 'en', data: { url: url || 'climate-dashboard.html' } };
    try {
        if ('serviceWorker' in navigator) {
            const reg = await navigator.serviceWorker.getRegistration();
            if (reg && reg.showNotification) { await reg.showNotification(title, opts); return true; }
        }
        const n = new Notification(title, opts);
        n.onclick = () => {
            try { window.focus(); window.location.href = opts.data.url; n.close(); }
            catch (_) {}
        };
        return true;
    } catch (e) { return false; }
}

/* ============================================================
   NASA ALERT BRIDGE (English only)
   ============================================================ */
async function scheduleNasaOutbreakAlert() {
    const risk = window.__lastOutbreakRisk;
    if (!risk) return null;
    if (risk.level !== 'alert' && risk.level !== 'critical') return null;
    if (risk.stale) return null;

    const districtKey = String(risk.district || '');
    /* English fallback only — never show Bangla in push */
    const districtName = risk.districtEn
        || (districtKey.charAt(0).toUpperCase() + districtKey.slice(1));
    const critical = risk.level === 'critical';
    const diseases = (risk.diseases || []).slice(0, 2);

    let liveRain = null;
    if (window.NasaGpm && NasaGpm.get7DayRainfall) {
        try { liveRain = await NasaGpm.get7DayRainfall(districtKey); } catch (_) {}
    }

    const lines = [];
    lines.push(`📍 ${districtName} area`);
    lines.push('');

    if (liveRain && liveRain.available) {
        lines.push(`🌧️ Rainfall last 7 days: ${liveRain.totalMm} mm`);
    } else if (risk.rainMm) {
        lines.push(`🌧️ Latest rainfall: ${Number(risk.rainMm).toFixed(0)} mm`);
    }

    if (risk.humidity != null) lines.push(`💧 Humidity: ${Number(risk.humidity).toFixed(0)}%`);
    if (risk.temp != null) lines.push(`🌡️ Temperature: ${Number(risk.temp).toFixed(0)}°C`);
    lines.push('');

    lines.push(`🦟 Disease risk: ${risk.score}%`);
    lines.push('');

    if (diseases.length > 0) {
        lines.push('🎯 Highest risk diseases:');
        diseases.forEach((d, i) => {
            const name = d.nameEn || d.nameBn || 'Disease';
            const sc = d.score !== undefined ? ` — ${d.score}%` : '';
            lines.push(`${i + 1}. ${name}${sc}`);
        });
        lines.push('');
    }

    lines.push('⚡ Action steps now:');
    const actions = [];
    if (liveRain && liveRain.totalMm >= 100) actions.push('✓ Drain all standing water (100+ mm rain in 7 days)');
    else if (liveRain && liveRain.totalMm >= 40) actions.push('✓ Keep sheds and yards dry');
    else if (risk.rainMm >= 40) actions.push('✓ Keep sheds and yards dry');

    if (risk.humidity >= 85) actions.push('✓ Increase ventilation (humidity 85%+)');

    if (diseases.length > 0) {
        const topKey = diseases[0].key;
        if (topKey === 'lsd' || topKey === 'fmd') actions.push('✓ Keep animals under mosquito nets after sunset');
        if (topKey === 'ranikhet' || topKey === 'coccidiosis') actions.push('✓ Keep poultry litter dry, provide Vitamin C');
        if (topKey === 'ppr') actions.push('✓ Isolate goats, vaccinate healthy goats with PPR vaccine');
        if (topKey === 'anthrax') actions.push('✓ Do not open carcass, notify vet immediately');
        if (topKey === 'mastitis') actions.push('✓ Clean udders before and after milking');
    }

    actions.push(critical ? '✓ Contact vet immediately' : '✓ Vaccinate as advised by vet');
    actions.forEach(a => lines.push(a));

    if (risk.impact) {
        const farmers = Number(risk.impact.farmersAtRisk || 0);
        const livestock = Number(risk.impact.livestockAtRisk || 0);
        if (farmers > 0 || livestock > 0) {
            lines.push('');
            lines.push('📊 Impact:');
            if (farmers > 0) lines.push(`• ${farmers.toLocaleString('en-IN')} farmers at risk`);
            if (livestock > 0) lines.push(`• ${livestock.toLocaleString('en-IN')} livestock at risk`);
        }
    }

    lines.push('');
    lines.push('📞 Helpline: 16358');

    const body = lines.join('\n');
    const title = critical
        ? `🚨 Emergency Alert — ${districtName}`
        : `⚠️ Disease Risk Rising — ${districtName}`;

    const meta = {
        district: risk.district,
        level: risk.level,
        score: risk.score,
        diseases: (risk.diseases || []).map(d => d.key),
        kind: 'nasa_outbreak',
        source: liveRain && liveRain.available ? 'Open-Meteo + NASA POWER' : 'NASA POWER',
        liveRain7d: liveRain && liveRain.available ? liveRain.totalMm : null
    };

    const id = await createNotification({
        title, body, icon: critical ? '🚨' : '⚠️',
        type: 'nasa_outbreak_alert', priority: 'high', petName: null,
        actionUrl: 'climate-dashboard.html',
        scheduledFor: Date.now(), maxReminds: 2, meta
    });

    if (id) {
        const short = diseases[0]
            ? `${diseases[0].nameEn || 'Disease'} risk ${diseases[0].score}% — use mosquito nets, keep sheds dry.`
            : `Disease risk ${risk.score}% — stay alert.`;
        showLocalPush(title, short, 'climate-dashboard.html', `nasa-${districtKey}-${risk.level}`);
    }
    return id;
}

/* ============================================================
   PUBLIC API
   ============================================================ */
window.DVNotifications = {
    analyzeAndSchedule,
    checkAndFireReminders,
    createNotification,
    scheduleNasaOutbreakAlert,
    requestPushPermission,
    pushPermission,
    showLocalPush,
    extractDurationDays,
    hasMedicineAdvice,
    hasFollowUpHint,
    hasVaccineAdvice,
    get TEST_MODE() { return TEST_MODE; }
};
window.triggerNasaOutbreakAlert = scheduleNasaOutbreakAlert;

console.log('[NotificationEngine] v4.2 loaded (English only)');
})();