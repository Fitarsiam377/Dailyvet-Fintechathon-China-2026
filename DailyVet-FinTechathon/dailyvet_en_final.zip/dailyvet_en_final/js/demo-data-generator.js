/* ============================================================
   DailyVet — DEMO DATA GENERATOR (For Hackathon Presentation)
   Usage: Open Chrome Console, run: generateDemoData()
   ============================================================ */

async function generateDemoData() {
    const phone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
    if (!phone) {
        console.error('❌ No user phone found. Please login first.');
        return;
    }

    console.log('⏳ Generating demo data for', phone, '...');
    const db = firebase.firestore();
    const batch = db.batch();

    try {
        // 1. GENERATE DEMO FINANCE DATA (Current Month)
        const ledgerRef = db.collection('users').doc(phone).collection('ledger');
        
        // Income
        const incomes = [
            { type: 'income', amount: 15000, desc: 'Sold 50L Milk to MilkVita', daysAgo: 2 },
            { type: 'income', amount: 8000, desc: 'Sold 2 Goats in Local Market', daysAgo: 5 },
            { type: 'income', amount: 5000, desc: 'Sold Eggs (500 pcs)', daysAgo: 10 },
        ];
        
        // Expense
        const expenses = [
            { type: 'expense', amount: 6000, desc: 'Bought Cattle Feed (200kg)', daysAgo: 1 },
            { type: 'expense', amount: 1500, desc: 'Veterinary Medicine', daysAgo: 4 },
            { type: 'expense', amount: 2000, desc: 'Paid Labor Salary', daysAgo: 8 },
        ];

        const allTx = [...incomes, ...expenses];
        
        allTx.forEach(tx => {
            const date = new Date();
            date.setDate(date.getDate() - tx.daysAgo);
            
            const ref = ledgerRef.doc();
            batch.set(ref, {
                type: tx.type,
                amount: tx.amount,
                description: tx.desc,
                timestamp: firebase.firestore.Timestamp.fromDate(date)
            });
        });

        // 2. GENERATE DEMO INSURANCE POLICY
        const policyRef = db.collection('users').doc(phone).collection('insurance_policies').doc();
        const policyData = {
            animalType: 'cow',
            district: 'kurigram', // High risk district for demo
            premium: 1200,
            riskLevel: 'High',
            riskScore: 75,
            policyNumber: 'DV-DEMO-' + Math.floor(1000 + Math.random() * 9000),
            status: 'active',
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            createdAtMs: Date.now(),
            claims: [
                {
                    trigger: 'flood',
                    label: 'Flood Risk',
                    icon: '🌊',
                    payout: 1200,
                    evidence: 'Flood risk 85% (critical)',
                    severity: 'critical',
                    status: 'approved',
                    filedAt: Date.now() - 86400000, // 1 day ago
                    filedAtServer: firebase.firestore.FieldValue.serverTimestamp()
                }
            ],
            totalPaidOut: 1200,
            lastClaimAt: Date.now() - 86400000
        };
        batch.set(policyRef, policyData);

        // Commit to Firestore
        await batch.commit();

        console.log('✅ DEMO DATA GENERATED SUCCESSFULLY!');
        alert('✅ Demo Data Generated!\n\n1. Added Finance Transactions (Income/Expense)\n2. Added Active Insurance Policy (Kurigram)\n3. Added 1 Past Claim\n\nGo to Home or Dashboard to see the magic!');
        
        // Reload page to reflect changes
        window.location.reload();

    } catch (err) {
        console.error('❌ Failed to generate demo data:', err);
        alert('Failed: ' + err.message);
    }
}

// Make it available globally
window.generateDemoData = generateDemoData;
