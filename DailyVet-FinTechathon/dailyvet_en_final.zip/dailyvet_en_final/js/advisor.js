// ============================================
// DAILYVET — FEED ADVISOR v2.0 (English only)
// ai.js engine: Gemini → Groq → OpenRouter hedged cascade, own keys
// Species-aware + BMI + Auto Health + Chat Button
// AI output guaranteed English via DVLangGuard
// + Download PDF Feature Added (FULL CONTENT FIX)
// ============================================

let userPhone = null;
let isProcessing = false;
let lastResultData = null;

const _elAdv = id => document.getElementById(id);
const _db = () => firebase.firestore();
const _checkedValue = name =>
  document.querySelector(`input[name="${name}"]:checked`)?.value;
const _checkedValues = name =>
  Array.from(document.querySelectorAll(`input[name="${name}"]:checked`)).map(el => el.value);
const _round1 = n => Math.round(n * 10) / 10;

const _dvApplyLang = () => {
  document.querySelectorAll('[data-bn][data-en]').forEach(el => {
    const txt = el.getAttribute('data-en');
    if (txt != null) el.textContent = txt;
  });
  document.querySelectorAll('[data-bn-placeholder][data-en-placeholder]').forEach(el => {
    const txt = el.getAttribute('data-en-placeholder');
    if (txt != null) el.setAttribute('placeholder', txt);
  });
};

/* ============================================================
   Feed Advisor's API keys: 5 Gemini + 3 Groq + 2 OpenRouter (rotation + fallback).
   Paste real Gemini / OpenRouter keys to enable the fallback chain;
   PASTE_* placeholders are ignored automatically.
   ============================================================ */
const ADV_GEMINI_KEYS = [
  _dvDec('QVEuQWI4Uk42SlVSbzZHTS1lck9BX0d6UVRJcml4MzRtUkhfd3doN01pM01janF1dVdmMGc='),
  _dvDec('QVEuQWI4Uk42S19GWW5PS0xPdFlRX21lLWlrcU1ybzE5aXpRQ0VROTFwNTB1cUNqaGM5Vnc='),
  _dvDec('QVEuQWI4Uk42SUgzMFlLWkVPVndWZF8yOFhlc3Y2akh1bk1WRndjN0JucXlldkR3WTV2U3c='),
  _dvDec('QVEuQWI4Uk42TEJrRGVtblA5NEpzazhqcHlvTWh2LXlFNVVSY3Q0WW5Scy1Ibk0tUjZpaFE='),
  _dvDec('QVEuQWI4Uk42SzJyWmx1MF81UTVEUzd6YkJ2azNmNEQwYVdxUlZCUENjaF83OF9xd25rU3c=')
];
const ADV_GROQ_KEYS = [
  _dvDec('Z3NrX295REtWSElHNWtrUlhiUUlEYzNnV0dkeWIzRll1N1dNeGR5S1pYY2RyYTVrdTdOMmlTNGM='),
  _dvDec('Z3NrX21WVXRJQThxTHdXUGNIZkFvNHNkV0dkeWIzRllkUk1rTlppMUxYT2gxb1RITVlIM0w3WXI='),
  _dvDec('Z3NrX3o4QkRyYldCbXlhS2l6M3BiVnZRV0dkeWIzRlk1R25haDNrQVptQm1xRUF2a2ZLMTZmd1M=')
];
const ADV_OPENROUTER_KEYS = [
  _dvDec('c2stb3ItdjEtZWFiNDAxMTQ0N2NiNDRkMjE3YjdmMDI4NDM1OWQ1YTQ3OTg4ZTMxZjZiNjNkOTQ0ZWZiYzI0ZGZlZjY4YzRlYw=='),
  _dvDec('c2stb3ItdjEtODg4MDE5MDk4Njc2MjllYWQ5ZGQyMjQ2MTc5YWVlZjE0Y2VkZTFiMGZkOGI2YmQxM2VkNDA2NTU3NWVhZWY3OQ==')
];

const ADV_AI = (function (CFG) {
'use strict';

const MODELS = {
    gemini: {
        text: ['gemini-3.5-flash-lite', 'gemini-3.1-flash-lite', 'gemini-2.5-flash-lite', 'gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-2.5-flash'],
        vision: ['gemini-3.5-flash-lite', 'gemini-3.1-flash-lite', 'gemini-2.5-flash-lite', 'gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-2.5-flash']
    },
    groq: {
        text: ['openai/gpt-oss-120b'],
        vision: ['qwen/qwen3.8-27b']
    },
    openrouter: {
        text: ['meta-llama/llama-3.3-70b-instruct:free', 'google/gemma-2-9b-it:free'],
        vision: ['qwen/qwen2.5-vl-72b-instruct:free']
    }
};
const ENDPOINTS = {
    gemini: 'https://generativelanguage.googleapis.com/v1beta/models',
    groq: 'https://api.groq.com/openai/v1/chat/completions',
    openrouter: 'https://openrouter.ai/api/v1/chat/completions'
};
const COOLDOWN = {
    rateLimit: 20e3, rateLimitMax: 12 * 60e3,
    server: 15e3, timeout: 12e3, badRequest: 8 * 60e3,
    authKey: 6 * 3600e3, modelGone: 24 * 3600e3, quotaZero: 6 * 3600e3, perDay: 3 * 3600e3
};
const SAFETY = ['HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH', 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'HARM_CATEGORY_DANGEROUS_CONTENT']
    .map(category => ({ category, threshold: 'BLOCK_ONLY_HIGH' }));
const DEFAULT_TIMING = {
    text: { total: 9000, perCall: 6000, hedge: 2000, parallel: 2 },
    vision: { total: 14000, perCall: 9000, hedge: 3000, parallel: 2 }
};
const MIN_RETRY_MS = 1800;

const _ls = {
    get: k => { try { return localStorage.getItem(k); } catch (_) { return null; } },
    set: (k, v) => { try { localStorage.setItem(k, v); } catch (_) {} }
};

/* ── Block registry (isolated per file) ── */
const BLOCK_STORE = 'dvEng_' + CFG.name + '_blocks';
const BLOCK_VERSION = 'v1';
const BLOCK_VERSION_STORE = 'dvEng_' + CFG.name + '_ver';
const _blocks = new Map();
const _strikes = new Map();
const _rot = { gemini: 0, groq: 0, openrouter: 0 };

(function _loadBlocks() {
    try {
        if (_ls.get(BLOCK_VERSION_STORE) !== BLOCK_VERSION) {
            _ls.set(BLOCK_STORE, '{}');
            _ls.set(BLOCK_VERSION_STORE, BLOCK_VERSION);
            return;
        }
        Object.entries(JSON.parse(_ls.get(BLOCK_STORE) || '{}')).forEach(([id, until]) => {
            if (until > Date.now()) _blocks.set(id, until);
        });
    } catch (_) {}
})();

const _keysOf = p => ((CFG.keys && CFG.keys[p]) || []).filter(k => k && !/^(PASTE_|YOUR_)/i.test(String(k)));
const _tail = k => String(k).slice(-8);
const _keyId = s => 'k:' + s.provider + ':' + _tail(s.key);
const _modelId = s => 'm:' + s.provider + ':' + s.model;
const _isBlocked = id => (_blocks.get(id) || 0) > Date.now();
const _slotBlocked = s => _isBlocked(s.id) || _isBlocked(_keyId(s)) || _isBlocked(_modelId(s));

function _block(id, ms) {
    _blocks.set(id, Date.now() + ms);
    const live = {};
    _blocks.forEach((until, k) => { if (until > Date.now()) live[k] = until; });
    _ls.set(BLOCK_STORE, JSON.stringify(live));
}

function _buildSlots(hasImage) {
    const kind = hasImage ? 'vision' : 'text';
    const make = provider => {
        const keys = _keysOf(provider);
        const shift = keys.length ? _rot[provider] % keys.length : 0;
        const rotated = keys.slice(shift).concat(keys.slice(0, shift));
        const seen = new Set();
        const out = [];
        for (const model of MODELS[provider][kind]) {
            for (const key of rotated) {
                const id = 's:' + provider + ':' + model + ':' + _tail(key);
                if (seen.has(id)) continue;
                seen.add(id);
                out.push({ provider, model, key, id });
            }
        }
        return out;
    };
    const arrange = ([g, q, o]) => {
        const out = [];
        let gi = 0, qi = 0, oi = 0;
        const take = (arr, i) => (i < arr.length ? arr[i] : null);
        const steps = [
            () => take(g, gi++), () => take(g, gi++), () => take(q, qi++),
            () => take(g, gi++), () => take(o, oi++), () => take(g, gi++), () => take(q, qi++)
        ];
        for (const step of steps) { const s = step(); if (s) out.push(s); }
        while (gi < g.length) out.push(g[gi++]);
        while (qi < q.length) out.push(q[qi++]);
        while (oi < o.length) out.push(o[oi++]);
        return out;
    };
    const all = ['gemini', 'groq', 'openrouter'].map(make);
    const live = arrange(all.map(list => list.filter(s => !_slotBlocked(s))));
    if (live.length) return live;
    return arrange(all.map(list => list.filter(s => !_isBlocked(_keyId(s)) && !_isBlocked(_modelId(s))))).slice(0, 4);
}

/* ── Request builders ── */
function _parseImage(img) {
    const m = /^data:([^;]+);base64,(.*)$/.exec(img || '');
    return m ? { mime: m[1], data: m[2] } : { mime: 'image/jpeg', data: img };
}
function _history(a) {
    const h = (a.history || []).filter(m => m && m.content);
    while (h.length && h[0].role !== 'user') h.shift();
    return h;
}
const _isReasoning = model => /gpt-oss|qwen3|qwen-3/i.test(model);

function _geminiRequest(slot, a) {
    const hasImage = !!a.image;
    const contents = _history(a).map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] }));
    if (hasImage) {
        const { mime, data } = _parseImage(a.image);
        contents.push({ role: 'user', parts: [{ inline_data: { mime_type: mime, data } }, { text: a.user }] });
    } else {
        contents.push({ role: 'user', parts: [{ text: a.user }] });
    }
    const generationConfig = {
        temperature: a.temperature != null ? a.temperature : 0.3,
        maxOutputTokens: a.maxTokens || 1400, topP: 0.95
    };
    if (a.json) generationConfig.responseMimeType = 'application/json';
    if (slot.model.includes('2.5')) generationConfig.thinkingConfig = { thinkingBudget: 0 };
    const body = { contents, generationConfig, safetySettings: SAFETY };
    if (a.system) body.system_instruction = { parts: [{ text: a.system }] };
    return {
        url: ENDPOINTS.gemini + '/' + slot.model + ':generateContent?key=' + slot.key,
        headers: { 'Content-Type': 'application/json' },
        body
    };
}

function _chatRequest(slot, a) {
    const hasImage = !!a.image;
    const userContent = hasImage
        ? [
            { type: 'text', text: a.user },
            { type: 'image_url', image_url: { url: String(a.image).startsWith('data:') ? a.image : 'data:image/jpeg;base64,' + a.image } }
        ]
        : a.user;
    const reasoning = _isReasoning(slot.model);
    const base = a.maxTokens || 1400;
    const messages = [];
    if (a.system) messages.push({ role: 'system', content: a.system });
    _history(a).forEach(m => messages.push({ role: m.role, content: m.content }));
    messages.push({ role: 'user', content: userContent });
    const body = {
        model: slot.model, messages,
        temperature: a.temperature != null ? a.temperature : 0.3,
        max_tokens: reasoning ? base + 1200 : base
    };
    if (reasoning && slot.provider === 'groq') Object.assign(body, { reasoning_effort: 'low', include_reasoning: false });
    const headers = { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + slot.key };
    if (slot.provider === 'openrouter') {
        headers['HTTP-Referer'] = (typeof location !== 'undefined' && location.origin) || 'https://dailyvet.app';
        headers['X-Title'] = 'DailyVet ' + (CFG.title || CFG.name);
    }
    return { url: ENDPOINTS[slot.provider], headers, body };
}

function _onHttpError(slot, status, retryAfter, bodyText) {
    const body = String(bodyText || '').slice(0, 500);
    if (status === 429) {
        const n = (_strikes.get(slot.id) || 0) + 1;
        _strikes.set(slot.id, n);
        const hinted = (parseInt(retryAfter, 10) || 0) * 1000;
        let ms = Math.min(Math.max(hinted, COOLDOWN.rateLimit * Math.pow(2, n - 1)), COOLDOWN.rateLimitMax);
        if (/limit:\s*0/i.test(body)) ms = COOLDOWN.quotaZero;
        else if (/PerDay|per\s*day/i.test(body)) ms = COOLDOWN.perDay;
        _block(slot.id, ms);
    } else if (status === 400) {
        if (/api[_ ]key (?:not valid|invalid|expired)|API_KEY_INVALID|key expired/i.test(body)) _block(_keyId(slot), COOLDOWN.authKey);
        else _block(slot.id, COOLDOWN.badRequest);
    } else if (status === 401 || status === 402 || status === 403) {
        _block(_keyId(slot), COOLDOWN.authKey);
    } else if (status === 404) {
        _block(_modelId(slot), COOLDOWN.modelGone);
    } else if (status >= 500 || status === 408) {
        _block(slot.id, COOLDOWN.server);
    }
}

/* ── Text helpers ── */
function stripThink(t) {
    return String(t || '').replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
}
function stripMarkdown(text) {
    if (!text) return '';
    return stripThink(text)
        .replace(/^\s*[*]\s+/gm, '• ')
        .replace(/\*\*(.+?)\*\*/g, '$1')
        .replace(/\*(.+?)\*/g, '$1')
        .replace(/`(.+?)`/g, '$1')
        .replace(/^#+\s*/gm, '')
        .replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
}
function parseJSON(raw) {
    const t = stripThink(raw).replace(/```(?:json)?/gi, '').trim();
    try { return JSON.parse(t); } catch (_) {}
    const o = t.match(/\{[\s\S]*\}/);
    if (o) { try { return JSON.parse(o[0]); } catch (_) {} }
    const arr = t.match(/\[[\s\S]*\]/);
    if (arr) { try { return JSON.parse(arr[0]); } catch (_) {} }
    return null;
}

/* ── One slot call ── */
async function _callSlot(slot, a, ctrl, timeoutMs, strict) {
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; ctrl.abort(); }, timeoutMs);
    try {
        if (a.onProvider) { try { a.onProvider(slot.provider); } catch (_) {} }
        const req = slot.provider === 'gemini' ? _geminiRequest(slot, a) : _chatRequest(slot, a);
        const res = await fetch(req.url, { method: 'POST', headers: req.headers, body: JSON.stringify(req.body), signal: ctrl.signal });
        if (!res.ok) {
            const errBody = await res.text().catch(() => '');
            _onHttpError(slot, res.status, res.headers && res.headers.get ? res.headers.get('retry-after') : null, errBody);
            return null;
        }
        const data = await res.json();
        let raw;
        if (slot.provider === 'gemini') {
            const cand = data.candidates && data.candidates[0];
            raw = ((cand && cand.content && cand.content.parts) || []).filter(p => p && p.text && !p.thought).map(p => p.text).join('');
        } else {
            raw = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
        }
        raw = stripThink(raw);
        if (!raw) return null;

        let value = raw;
        if (a.validate) {
            try { value = a.validate(raw, !!strict); } catch (_) { value = null; }
            if (value === null || value === undefined) return null;
        }
        _strikes.delete(slot.id);
        const keys = _keysOf(slot.provider);
        _rot[slot.provider] = keys.indexOf(slot.key) + 1;
        return { raw, data: value };
    } catch (err) {
        if (timedOut) _block(slot.id, COOLDOWN.timeout);
        else if (!ctrl.signal.aborted) _block(slot.id, COOLDOWN.server);
        return null;
    } finally {
        clearTimeout(timer);
    }
}

/* ── Hedged cascade ── */
function _cascade(slots, a, cfg, strict) {
    return new Promise(resolve => {
        let next = 0, inflight = 0, done = false, deadline = null, hedgeT = null;
        const ctrls = new Set();
        const preBlocked = new Set(slots.filter(_slotBlocked).map(sl => sl.id));
        const skipSlot = sl => _slotBlocked(sl) && !preBlocked.has(sl.id);
        const finish = result => {
            if (done) return;
            done = true;
            clearTimeout(deadline);
            clearTimeout(hedgeT);
            ctrls.forEach(c => { try { c.abort(); } catch (_) {} });
            resolve(result);
        };
        const launch = () => {
            if (done || inflight >= cfg.parallel) return;
            while (next < slots.length && skipSlot(slots[next])) next++;
            if (next >= slots.length) {
                if (!inflight) finish(null);
                return;
            }
            const slot = slots[next++];
            const ctrl = new AbortController();
            ctrls.add(ctrl);
            inflight++;
            _callSlot(slot, a, ctrl, cfg.perCall, strict).then(res => {
                ctrls.delete(ctrl);
                inflight--;
                if (res) finish({ provider: slot.provider, model: slot.model, raw: res.raw, data: res.data });
                else launch();
            }).catch(() => {
                ctrls.delete(ctrl);
                inflight--;
                launch();
            });
        };
        const scheduleHedge = () => {
            hedgeT = setTimeout(() => {
                if (done) return;
                launch();
                if (next < slots.length) scheduleHedge();
            }, cfg.hedge);
        };
        deadline = setTimeout(() => finish(null), cfg.total);
        launch();
        scheduleHedge();
    });
}

/* ── Public: ask ──
   a = { system, user, image?, history?, json?, maxTokens?, temperature?,
         validate?(raw, strict) → value | null, rounds?, budgetMs?, onProvider? }
   returns { provider, model, raw, data } or null                          */
async function ask(a) {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) return null;
    const hasImage = !!a.image;
    const t = (CFG.timing && CFG.timing[hasImage ? 'vision' : 'text']) || DEFAULT_TIMING[hasImage ? 'vision' : 'text'];
    const total = Math.min(t.total, a.budgetMs || t.total);
    const rounds = a.rounds || 2;
    const start = Date.now();
    for (let r = 1; r <= rounds; r++) {
        const left = total - (Date.now() - start);
        if (left < (r === 1 ? 800 : MIN_RETRY_MS)) break;
        const slots = _buildSlots(hasImage);
        if (!slots.length) return null;
        const strict = rounds > 1 && r === rounds;
        const res = await _cascade(slots, a, Object.assign({}, t, { total: left }), strict);
        if (res) return res;
    }
    return null;
}

function hasKeys() { return ['gemini', 'groq', 'openrouter'].some(p => _keysOf(p).length > 0); }

function status() {
    return {
        name: CFG.name,
        keys: { gemini: _keysOf('gemini').length, groq: _keysOf('groq').length, openrouter: _keysOf('openrouter').length },
        blocked: Array.from(_blocks.entries()).filter(([, u]) => u > Date.now()).map(([id, u]) => id + ' (' + Math.round((u - Date.now()) / 1000) + 's)'),
        order: _buildSlots(false).slice(0, 7).map(s => s.provider + '/' + s.model)
    };
}
function reset() {
    _blocks.clear(); _strikes.clear();
    _ls.set(BLOCK_STORE, '{}');
}

return { ask, parseJSON, stripMarkdown, stripThink, hasKeys, status, reset, MODELS };
})({
  name: 'advisor',
  title: 'Feed Advisor',
  keys: { gemini: ADV_GEMINI_KEYS, groq: ADV_GROQ_KEYS, openrouter: ADV_OPENROUTER_KEYS },
  timing: {
    text: { total: 16000, perCall: 11000, hedge: 4000, parallel: 2 }
  }
});

const SPECIES_LIMITS = {
  Dog:     { emoji: '🐕', minWeight: 0.5, maxWeight: 90,  maxAge: 25 },
  Cat:     { emoji: '🐈', minWeight: 0.5, maxWeight: 12,  maxAge: 25 },
  Cow:     { emoji: '🐄', minWeight: 30,  maxWeight: 900, maxAge: 20 },
  Goat:    { emoji: '🐐', minWeight: 5,   maxWeight: 120, maxAge: 15 },
  Chicken: { emoji: '🐔', minWeight: 0.3, maxWeight: 5,   maxAge: 8 }
};

const IDEAL_WEIGHT = {
  Dog: { puppy: { min: 1, max: 25 }, young: { min: 4, max: 35 }, adult: { min: 4, max: 45 }, senior: { min: 4, max: 48 } },
  Cat: { puppy: { min: 0.5, max: 4.5 }, young: { min: 3, max: 5.5 }, adult: { min: 3.5, max: 5.5 }, senior: { min: 3.5, max: 5.5 } },
  Cow: { puppy: { min: 40, max: 200 }, young: { min: 100, max: 350 }, adult: { min: 200, max: 500 }, senior: { min: 220, max: 480 } },
  Goat: { puppy: { min: 5, max: 20 }, young: { min: 15, max: 35 }, adult: { min: 25, max: 50 }, senior: { min: 28, max: 50 } },
  Chicken: { puppy: { min: 0.05, max: 1.5 }, young: { min: 0.7, max: 2.2 }, adult: { min: 1.2, max: 2.5 }, senior: { min: 1.2, max: 2.5 } }
};

const SPECIES_FEED_RULES = {
  Cow: `COW (RUMINANT) FEEDING RULES:
- ALLOWED: green grass (Napier, Para, German, Jumbo), hay, rice straw, rice bran, wheat bran, oil cake (mustard/sesame/soybean), mineral mixture, common salt, fresh silage, fresh water.
- FORBIDDEN: meat, chicken, mutton, egg, ghee, human rice, curd, milk.
- Portions in KG: grass 15-25kg, hay 4-6kg, concentrate 3-5kg. Feed 3 times + water 80-100 L.`,
  Goat: `GOAT (RUMINANT) FEEDING RULES:
- ALLOWED: green grass, tree leaves (neem/mango/jackfruit), hay, rice bran, wheat bran, oil cake, mineral mixture, salt, fresh water.
- FORBIDDEN: meat, egg, ghee, curd, human food, milk. Portions in grams.`,
  Chicken: `CHICKEN (POULTRY) FEEDING RULES:
- ALLOWED: commercial poultry feed (starter/grower/layer), broken rice, maize, soybean meal, fish meal, limestone (layers), vitamin-mineral premix.
- FORBIDDEN: meat, milk, chocolate, onion, garlic, human cooked food. Portions in GRAMS per bird.`,
  Dog: `DOG FEEDING RULES:
- ALLOWED: commercial kibble/wet food, boiled chicken (no bone), boiled egg, plain rice, curd, carrot, pumpkin, green beans, boneless fish, small ghee.
- FORBIDDEN (toxic): chocolate, onion, garlic, grapes, raisins, xylitol, avocado, alcohol, caffeine, macadamia. Feed 2-3 times daily.`,
  Cat: `CAT FEEDING RULES:
- ALLOWED: commercial cat food, boiled chicken, boneless fish, small liver, egg yolk, small curd.
- FORBIDDEN: chocolate, onion, garlic, grapes, raisins, milk, dog food, raw fish in large amounts. Feed 2-3 times daily.`
};

function filterSpeciesAppropriate(aiData, petType) {
  if (!aiData || !aiData.meals) return aiData;
  if (!['Cow', 'Goat', 'Chicken'].includes(petType)) return aiData;

  const forbidden = ['mutton', 'beef', 'pork', 'ghee', 'butter',
    'cheese', 'chicken breast', 'boiled egg', 'omelette', 'human rice'];

  aiData.meals = aiData.meals.map(meal => {
    meal.foods = meal.foods.filter(food => {
      const lf = food.toLowerCase();
      const isBad = forbidden.some(f => lf.includes(f));
      if (isBad) console.warn('⚠️ Filtered forbidden food for', petType, ':', food);
      return !isBad;
    });
    return meal;
  });

  const hasFood = aiData.meals.some(m => m.foods && m.foods.length > 0);
  return hasFood ? aiData : null;
}

function calculateBMI(petType, ageInYears, weight) {
  const limits = IDEAL_WEIGHT[petType];
  if (!limits) return null;

  const stage = ageInYears < 1 ? 'puppy'
    : ageInYears < 3 ? 'young'
    : ageInYears < 7 ? 'adult'
    : 'senior';

  const ideal = limits[stage];
  const midIdeal = (ideal.min + ideal.max) / 2;
  const ratio = weight / midIdeal;

  let status, percent, color, advice;
  if (ratio < 0.75) {
    status = 'Underweight'; percent = Math.round((1 - ratio) * 100); color = '#e67e22';
    advice = `Your animal is ${percent}% under ideal weight. Increase nutritious feed.`;
  } else if (ratio < 0.9) {
    status = 'Slightly Underweight'; percent = Math.round((1 - ratio) * 100); color = '#f39c12';
    advice = 'Slightly underweight. Increase protein in the diet.';
  } else if (ratio <= 1.1) {
    status = 'Ideal'; percent = 0; color = '#27ae60';
    advice = "Excellent! Your animal's weight is ideal. Keep it up.";
  } else if (ratio <= 1.25) {
    status = 'Slightly Overweight'; percent = Math.round((ratio - 1) * 100); color = '#f39c12';
    advice = 'Slightly overweight. Reduce feed amount and increase exercise.';
  } else {
    status = 'Overweight'; percent = Math.round((ratio - 1) * 100); color = '#c0392b';
    advice = `${percent}% above ideal weight. Diet control and exercise are essential.`;
  }

  return { status, percent, color, advice, idealMin: ideal.min, idealMax: ideal.max, midIdeal: _round1(midIdeal), stage, ratio };
}

function autoDetectHealthConditions(data, ageInYears, bmi) {
  const tags = [];
  if (ageInYears < 1) tags.push('Puppy/Kitten');
  const seniorAge = (data.petType === 'Dog' || data.petType === 'Cat') ? 7 : 8;
  if (ageInYears >= seniorAge) tags.push('Senior');
  if (bmi && ['Overweight', 'Slightly Overweight'].includes(bmi.status)) tags.push('Overweight');
  if (bmi && ['Underweight', 'Slightly Underweight'].includes(bmi.status)) tags.push('Underweight');
  return tags;
}

function validateInput(data) {
  const errors = [];
  const warnings = [];
  if (!data.petType) { errors.push('Please select a pet type.'); return { valid: false, errors, warnings }; }
  const limits = SPECIES_LIMITS[data.petType];
  if (!limits) { errors.push('Invalid pet type.'); return { valid: false, errors, warnings }; }

  const ageInYears = data.ageUnit === 'months' ? data.age / 12 : data.age;
  if (isNaN(ageInYears) || ageInYears < 0) errors.push('Please enter a valid age.');
  else if (ageInYears > limits.maxAge) errors.push(`${data.petType} age seems unrealistic (max ${limits.maxAge} years).`);
  if (isNaN(data.weight) || data.weight <= 0) errors.push('Please enter a valid weight.');
  else if (data.weight < limits.minWeight || data.weight > limits.maxWeight)
    errors.push(`${data.petType} weight should be between ${limits.minWeight}–${limits.maxWeight} kg.`);
  if (!data.gender) errors.push('Please select gender.');
  if (!data.activity) errors.push('Please select activity level.');
  if (!data.goal) errors.push('Please select goal.');
  if (data.health.includes('Pregnant') && data.gender === 'Male')
    errors.push('Pregnancy is only possible for female pets.');
  if (data.goal === 'Weight Loss' && data.health.includes('Puppy/Kitten')) {
    warnings.push('Weight loss is not recommended for puppies/kittens. Showing "Maintain" plan.');
    data.goal = 'Maintain';
  }
  if (data.goal === 'Weight Gain' && data.health.includes('Overweight'))
    errors.push('Cannot recommend weight gain for overweight pet.');
  if (data.goal === 'Weight Loss' && data.health.includes('Pregnant'))
    errors.push('Weight loss is unsafe during pregnancy.');
  if (data.health.includes('Sick') && data.goal !== 'Maintain')
    warnings.push('A sick pet should focus on recovery.');
  return { valid: errors.length === 0, errors, warnings, ageInYears };
}

function getActivityMultiplier(data, ageInYears, bmi) {
  const { activity, goal, health } = data;
  if (health.includes('Puppy/Kitten') || ageInYears < 1) return 2.5;
  if (health.includes('Senior')) return 1.2;
  if (health.includes('Pregnant')) return 2.0;
  if (health.includes('Sick')) return 1.2;
  if (bmi) {
    if (bmi.status === 'Overweight') return 1.0;
    if (bmi.status === 'Slightly Overweight') return 1.1;
    if (bmi.status === 'Underweight') return 2.0;
    if (bmi.status === 'Slightly Underweight') return 1.8;
  }
  if (health.includes('Overweight') || goal === 'Weight Loss') return 1.0;
  if (goal === 'Weight Gain') return 1.8;
  return { Low: 1.2, Medium: 1.6, High: 2.0 }[activity] || 1.4;
}

function calculateSmallAnimal(data, ageInYears, bmi) {
  const weight = data.weight;
  const factor = getActivityMultiplier(data, ageInYears, bmi);
  const calories = Math.round(70 * Math.pow(weight, 0.75) * factor);
  let pPct, fPct, cPct;
  if (data.petType === 'Cat') { pPct = 0.35; fPct = 0.30; cPct = 0.15; }
  else if (ageInYears < 1) { pPct = 0.28; fPct = 0.20; cPct = 0.42; }
  else if (data.health.includes('Senior')) { pPct = 0.22; fPct = 0.15; cPct = 0.53; }
  else { pPct = 0.26; fPct = 0.16; cPct = 0.48; }
  return {
    type: 'small', calories,
    protein: Math.round((calories * pPct) / 4),
    fat: Math.round((calories * fPct) / 9),
    carbs: Math.round((calories * cPct) / 4),
    water: Math.round(weight * 55),
    meals: (data.health.includes('Puppy/Kitten') || ageInYears < 0.5) ? 3 : 2
  };
}

function _calculateRuminant(data, bmi, opts) {
  const { dmiFactor, greenPct, hayPct, concPct, waterFactor, meals,
    calFactor, protFactor, fatFactor, carbFactor, type } = opts;
  let dmi = _round1(data.weight * dmiFactor);
  if (bmi) {
    if (bmi.status === 'Overweight') dmi = dmi * 0.85;
    else if (bmi.status === 'Underweight') dmi = dmi * 1.2;
  }
  const boost = data.health.includes('Pregnant') ? 1.2 : 1;
  return {
    type, dmi: _round1(dmi),
    greenFodder: _round1(dmi * greenPct * boost),
    hay: _round1(dmi * hayPct * boost),
    concentrate: _round1(dmi * concPct * boost),
    water: Math.round(dmi * waterFactor),
    meals,
    calories: Math.round(dmi * calFactor),
    protein: Math.round(dmi * protFactor),
    fat: Math.round(dmi * fatFactor),
    carbs: Math.round(dmi * carbFactor)
  };
}

function calculateCow(data, bmi) {
  return _calculateRuminant(data, bmi, {
    type: 'cow', dmiFactor: 0.03, greenPct: 0.65, hayPct: 0.25, concPct: 0.35,
    waterFactor: 40, meals: 3, calFactor: 2000, protFactor: 120, fatFactor: 30, carbFactor: 600
  });
}
function calculateGoat(data, bmi) {
  return _calculateRuminant(data, bmi, {
    type: 'goat', dmiFactor: 0.035, greenPct: 0.60, hayPct: 0.20, concPct: 0.30,
    waterFactor: 30, meals: 2, calFactor: 1800, protFactor: 110, fatFactor: 25, carbFactor: 550
  });
}
function calculateChicken(data, ageInYears, bmi) {
  let dailyFeed, proteinPct;
  if (ageInYears < 0.15) { dailyFeed = 40; proteinPct = 20; }
  else if (ageInYears < 0.4) { dailyFeed = 80; proteinPct = 18; }
  else { dailyFeed = 115; proteinPct = 17; }
  if (data.health.includes('Pregnant')) dailyFeed = Math.round(dailyFeed * 1.1);
  if (bmi) {
    if (bmi.status === 'Overweight') dailyFeed = Math.round(dailyFeed * 0.9);
    else if (bmi.status === 'Underweight') dailyFeed = Math.round(dailyFeed * 1.15);
  }
  return {
    type: 'chicken', dailyFeed,
    calories: dailyFeed * 3,
    protein: Math.round(dailyFeed * proteinPct / 100),
    fat: Math.round(dailyFeed * 0.05),
    carbs: Math.round(dailyFeed * 0.55),
    water: dailyFeed * 2,
    meals: 2
  };
}
function calculateNutrition(data, ageInYears, bmi) {
  const t = data.petType;
  if (t === 'Dog' || t === 'Cat') return calculateSmallAnimal(data, ageInYears, bmi);
  if (t === 'Cow') return calculateCow(data, bmi);
  if (t === 'Goat') return calculateGoat(data, bmi);
  if (t === 'Chicken') return calculateChicken(data, ageInYears, bmi);
  return null;
}

function _advBuildPrompt(data, nutrition, ageInYears, bmi) {
  const petType = data.petType;
  const emoji = SPECIES_LIMITS[petType].emoji;
  const feedRules = SPECIES_FEED_RULES[petType] || '';
  const bmiContext = bmi
    ? `\nWEIGHT STATUS: ${bmi.status} (${data.weight}kg vs ideal ${bmi.idealMin}-${bmi.idealMax}kg)\n`
    : '';

  return `You are DailyVet Feed Advisor — a Bangladesh-licensed veterinary nutritionist.

STRICT: Reply ONLY in clean English. Do NOT use Bengali, Hindi, or any non-English script in any field. Return ONLY valid JSON. No markdown.

TASK: Create a species-correct diet plan for a ${petType}.

=== ${petType.toUpperCase()} — STRICT FEEDING RULES ===
${feedRules}
=================================================

PET INFO:
- Type: ${petType} ${emoji}
- Age: ${data.age} ${data.ageUnit}
- Weight: ${data.weight} kg
- Gender: ${data.gender}
- Activity: ${data.activity}
- Health: ${data.health.join(', ') || 'None'}
- Goal: ${data.goal}
${bmiContext}
CALCULATED DAILY NUTRITION (USE THESE EXACT NUMBERS):
- Total Calories: ${nutrition.calories} kcal
- Protein: ${nutrition.protein} g
- Fat: ${nutrition.fat} g
- Water: ${nutrition.water} ml
- Meals per day: ${nutrition.meals}
${nutrition.greenFodder ? `- Green Fodder: ${nutrition.greenFodder} kg\n- Hay: ${nutrition.hay || 0} kg\n- Concentrate: ${nutrition.concentrate} kg` : ''}
${nutrition.dailyFeed ? `- Daily Feed: ${nutrition.dailyFeed} g/bird` : ''}

OUTPUT FORMAT — Return ONLY valid JSON (no markdown):

{
  "meals": [
    {
      "time": "Morning 7:00 AM",
      "icon": "🌅",
      "foods": ["correct food with quantity in English"],
      "calories": ${Math.round(nutrition.calories / nutrition.meals)}
    }
  ],
  "avoid": ["5-6 species-appropriate items to avoid, in English"],
  "tips": ["5-6 practical tips for this species, in English"],
  "emergencySigns": ["4-5 species-specific warning signs, in English"]
}

CRITICAL RULES:
1. ONLY use foods from the ALLOWED list above for ${petType}.
2. NEVER mix other species' food.
3. Reply ONLY in English. No Bangla, no Hindi, no romanized Bangla words.
4. Provide ${nutrition.meals} meals.
5. Response MUST be valid JSON only — no markdown.
6. For COW: KG for grass/hay/concentrate. For CHICKEN: GRAMS per bird.
7. Include mineral mixture and salt for farm animals.
8. Practical Bangladesh-available foods.

Return ONLY the JSON object.`;
}

const ADV_SYSTEM = `You are a species-specific veterinary nutritionist.
STRICT: Reply ONLY in clean English. Never use Bengali, Hindi, or any non-English script.
Always answer in valid JSON.`;

async function callGroqForDiet(data, nutrition, ageInYears, bmi, strictEnglish) {
  const prompt = _advBuildPrompt(data, nutrition, ageInYears, bmi);
  let res = null;
  try {
    res = await ADV_AI.ask({
      system: ADV_SYSTEM,
      user: prompt,
      json: true,
      temperature: 0.5,
      maxTokens: 2500,
      validate: (raw, strict) => {
        const parsed = ADV_AI.parseJSON(raw);
        if (!parsed || typeof parsed !== 'object' || !Array.isArray(parsed.meals)) return null;
        if (window.DVLangGuard && !window.DVLangGuard.deepIsEnglish(parsed) && !(strict || strictEnglish)) return null;
        return parsed;
      }
    });
  } catch (err) { console.warn('Feed advisor AI failed:', err && err.message); return null; }
  if (!res || !res.data) return null;

  let parsed = res.data;
  if (window.DVLangGuard && !window.DVLangGuard.deepIsEnglish(parsed)) {
    try {
      const cleaned = await window.DVLangGuard.ensureEnglishJson(parsed);
      parsed = cleaned.data;
    } catch (_) { return null; }
  }
  return parsed;
}

const VET_TYPE_MAP = { Dog: 'pet', Cat: 'pet', Cow: 'dairy', Goat: 'dairy', Chicken: 'poultry' };

async function fetchVetsForPet(petType) {
  try {
    const db = _db();
    const vetType = VET_TYPE_MAP[petType] || 'general';
    const snap = await db.collection('vets')
      .where('available', '==', true)
      .where('type', '==', vetType)
      .limit(3).get();
    if (!snap.empty) return snap.docs.map(d => d.data());
    const fb = await db.collection('vets')
      .where('available', '==', true)
      .where('type', '==', 'general')
      .limit(2).get();
    return fb.docs.map(d => d.data());
  } catch (err) { console.warn('Vet fetch error:', err); return []; }
}

const FALLBACK_DATA = {
  Cow: {
    avoid: ['Human food (meat, egg, ghee, rice)', 'Stale or fungus-contaminated hay/silage', 'Excess concentrate (acidosis)', 'Excess salt', 'Cold or stale water'],
    tips: ['Chop hay and green grass into small pieces', 'Introduce new feed gradually over 7-10 days', 'Feed 2-3 times daily in divided portions', 'Always provide clean fresh water (80-100 liters)', 'Weigh monthly', 'Deworm and vaccinate regularly'],
    emergency: ['Sudden stop of eating', 'Bloat (swollen belly)', 'Not chewing cud', 'Rapid weight loss', 'Lying down weak']
  },
  Goat: {
    avoid: ['Human food (meat, egg, ghee)', 'Stale or dirty grass', 'Excess concentrate', 'Toxic tree leaves', 'Excess salt'],
    tips: ['Mix tree leaves and green grass', 'Chop hay into small pieces', 'Feed twice daily', 'Always provide clean fresh water', 'Weigh monthly', 'Deworm twice a year'],
    emergency: ['Not eating', 'Bloat', 'Difficulty walking', 'Breathing difficulty', 'Weakness']
  },
  Chicken: {
    avoid: ['Human cooked food', 'Meat and milk', 'Chocolate, onion, garlic', 'Stale or fungus-contaminated feed', 'Excess salt'],
    tips: ['Follow a regular feed schedule', 'Always provide clean water', 'Add vitamin-mineral premix to poultry feed', 'Deworm and vaccinate regularly', 'Keep the coop clean', 'Control temperature'],
    emergency: ['Sudden death', 'Breathing difficulty', 'Drop in egg production', 'Watery droppings', 'Sitting weakly']
  },
  Dog: {
    avoid: ['Chocolate, cocoa', 'Onion, garlic', 'Grapes, raisins', 'Avocado, alcohol', 'Caffeine, macadamia'],
    tips: ['Always provide clean fresh water', 'Introduce new food gradually', 'Feed 2-3 times daily in divided portions', 'Match food to exercise level', 'Vet checkup every 3 months', 'Weigh regularly'],
    emergency: ['Not eating for 24 hours', 'Bloody stool', 'Breathing difficulty', 'Seizures', 'Collapse / unconscious']
  },
  Cat: {
    avoid: ['Chocolate, onion, garlic', 'Grapes, raisins', 'Cow milk (lactose)', 'Dog food', 'Large amounts of raw fish'],
    tips: ['Always provide fresh water', 'Prefer wet food', 'Feed 2-3 times daily', 'Do not give too much raw fish', 'Vet checkup every 3 months', 'Keep litter box clean'],
    emergency: ['Not eating for 24 hours', 'Breathing difficulty', 'Urinary blockage', 'Seizures', 'Lying down weak']
  }
};
const getFallbackAvoid = t => FALLBACK_DATA[t]?.avoid || [];
const getFallbackTips = t => FALLBACK_DATA[t]?.tips || [];
const getFallbackEmergency = t => FALLBACK_DATA[t]?.emergency || [];

function generateFallbackMeals(data, nutrition) {
  const type = data.petType;
  if (type === 'Cow') {
    const g = _round1(nutrition.greenFodder / 3);
    const h = _round1(nutrition.hay / 3);
    const c = _round1(nutrition.concentrate / 3);
    const w = Math.round(nutrition.water / 3);
    return [
      { time: '7:00 AM', icon: '🌅', foods: [`Green grass ${g} kg`, `Hay ${h} kg`, `Concentrate (bran+oil cake) ${c} kg`, 'Mineral mix 25 g', `Fresh water ${w} L`], calories: null },
      { time: '1:00 PM', icon: '☀️', foods: [`Green grass ${g} kg`, `Hay ${h} kg`, `Fresh water ${w} L`], calories: null },
      { time: '6:00 PM', icon: '🌆', foods: [`Green grass ${g} kg`, `Hay ${h} kg`, `Concentrate (bran+oil cake) ${c} kg`, 'Salt 25 g', `Fresh water ${w} L`], calories: null }
    ];
  }
  if (type === 'Goat') {
    const g = _round1(nutrition.greenFodder / 2);
    const h = _round1((nutrition.hay || 0.5) / 2);
    const c = _round1(nutrition.concentrate / 2);
    return [
      { time: '7:00 AM', icon: '🌅', foods: [`Green grass ${g} kg`, 'Tree leaves (neem, mango, jackfruit)', `Hay ${h} kg`, `Concentrate (bran+oil cake) ${c} kg`, 'Mineral mix 15 g', 'Fresh water'], calories: null },
      { time: '6:00 PM', icon: '🌆', foods: [`Green grass ${g} kg`, `Hay ${h} kg`, `Concentrate (bran+oil cake) ${c} kg`, 'Salt 10 g', 'Fresh water'], calories: null }
    ];
  }
  if (type === 'Chicken') {
    const f = Math.round(nutrition.dailyFeed / 2);
    return [
      { time: '7:00 AM', icon: '🌅', foods: [`Poultry feed ${f} g/bird`, 'Vitamin-mineral premix', 'Fresh water'], calories: null },
      { time: '5:00 PM', icon: '🌆', foods: [`Poultry feed ${f} g/bird`, 'Limestone (if layer)', 'Fresh water'], calories: null }
    ];
  }
  if (type === 'Dog') {
    const cups = _round1(nutrition.calories / 350 / 2);
    const cal = Math.round(nutrition.calories / 2);
    return [
      { time: '7:00 AM', icon: '🌅', foods: [`Dry kibble ${cups} cup`, '1 boiled egg', 'Fresh water'], calories: cal },
      { time: '7:00 PM', icon: '🌆', foods: [`Dry kibble ${cups} cup`, 'Boiled chicken (boneless)', 'Mixed vegetables (carrot, beans)', 'Fresh water'], calories: cal }
    ];
  }
  if (type === 'Cat') {
    const cal = Math.round(nutrition.calories / 2);
    return [
      { time: '7:00 AM', icon: '🌅', foods: ['Wet food 1/2 can', 'Dry kibble 1/4 cup', 'Fresh water'], calories: cal },
      { time: '7:00 PM', icon: '🌆', foods: ['Wet food 1/2 can', 'Boiled chicken/fish (boneless)', 'Fresh water'], calories: cal }
    ];
  }
  return [];
}

function _nutritionItem(label, value, unit) {
  return `<div class="nutrition-item"><span class="label">${label}</span><span class="value">${value}<small>${unit}</small></span></div>`;
}
function _buildVetRows(vets) {
  return vets.map(v => {
    const cleanPhone = (v.phone || '').replace(/\D/g, '');
    const waPhone = cleanPhone.startsWith('880') ? cleanPhone : '88' + cleanPhone;
    const waMsg = encodeURIComponent('Hello, I am contacting from DailyVet Feed Advisor. I need advice about my animal\'s diet.');
    const waURL = `https://wa.me/${waPhone}?text=${waMsg}`;
    return `
      <div class="vet-item">
        <div class="vet-info">
          <div class="vet-name">${v.name}</div>
          <div class="vet-spec">${v.speciality} · ${v.location}</div>
        </div>
        <div class="vet-actions">
          <a href="tel:${v.phone}" class="vet-action-btn call" title="Call"><i class="fas fa-phone"></i></a>
          <a href="${waURL}" target="_blank" rel="noopener" class="vet-action-btn chat" title="Chat on WhatsApp"><i class="fab fa-whatsapp"></i></a>
        </div>
      </div>`;
  }).join('');
}

function buildResultHTML(data, nutrition, aiData, warnings, vets, bmi) {
  const emoji = SPECIES_LIMITS[data.petType].emoji;
  const ageDisplay = data.ageUnit === 'months' ? `${data.age} months` : `${data.age} years`;

  let filteredData = aiData ? filterSpeciesAppropriate(aiData, data.petType) : null;
  if (!filteredData || !filteredData.meals || filteredData.meals.length === 0) {
    filteredData = {
      meals: generateFallbackMeals(data, nutrition),
      avoid: getFallbackAvoid(data.petType),
      tips: getFallbackTips(data.petType),
      emergencySigns: getFallbackEmergency(data.petType)
    };
  }

  const { meals, avoid, tips, emergencySigns: emergency } = filteredData;
  const parts = [];

  if (warnings && warnings.length > 0) {
    parts.push(`
      <div class="result-warnings">
        ${warnings.map(w => `<div class="warning-item"><i class="fas fa-exclamation-triangle"></i><span>${w}</span></div>`).join('')}
      </div>`);
  }

  parts.push(`
    <div class="pet-info-card">
      <div class="pet-info-header">
        <div class="pet-info-emoji">${emoji}</div>
        <div class="pet-info-text">
          <h4>${data.petType} Diet Plan</h4>
          <p>${ageDisplay} · ${data.weight} kg · ${data.gender}</p>
        </div>
      </div>
      <div class="pet-info-details">
        <div class="info-detail"><i class="fas fa-running"></i><span>Activity: <strong>${data.activity}</strong></span></div>
        <div class="info-detail"><i class="fas fa-bullseye"></i><span>Goal: <strong>${data.goal}</strong></span></div>
        ${data.health.length > 0 ? `<div class="info-detail" style="grid-column:1/-1;"><i class="fas fa-heart-pulse"></i><span>Health: <strong>${data.health.join(', ')}</strong></span></div>` : ''}
      </div>
    </div>`);

  if (bmi) {
    const barPercent = Math.min(100, Math.max(0, 50 + (bmi.ratio - 1) * 40));
    parts.push(`
      <div class="bmi-card" style="border-left-color: ${bmi.color};">
        <div class="bmi-header">
          <div class="bmi-icon" style="background: ${bmi.color};"><i class="fas fa-weight-scale"></i></div>
          <div class="bmi-title"><h4>Weight Check</h4><p>Age-based ideal weight</p></div>
          <div class="bmi-status" style="color: ${bmi.color};">${bmi.status}</div>
        </div>
        <div class="bmi-comparison">
          <div class="bmi-item"><span class="bmi-label">Your pet</span><span class="bmi-value">${data.weight} kg</span></div>
          <div class="bmi-arrow"><i class="fas fa-arrow-right"></i></div>
          <div class="bmi-item"><span class="bmi-label">Ideal range</span><span class="bmi-value">${bmi.idealMin}–${bmi.idealMax} kg</span></div>
        </div>
        <div class="bmi-bar-wrap">
          <div class="bmi-bar"><div class="bmi-bar-fill" style="left: ${barPercent}%;"></div></div>
          <div class="bmi-bar-labels"><span>Low</span><span>Ideal</span><span>High</span></div>
        </div>
        <div class="bmi-advice"><i class="fas fa-info-circle"></i><span>${bmi.advice}</span></div>
      </div>`);
  }

  parts.push(`
    <div class="nutrition-summary">
      <div class="nutrition-title">📊 Daily Requirements</div>
      <div class="nutrition-grid">
        ${_nutritionItem('🔥 Energy', nutrition.calories, 'kcal')}
        ${_nutritionItem('🥩 Protein', nutrition.protein, 'g')}
        ${_nutritionItem('🧈 Fat', nutrition.fat, 'g')}
        ${_nutritionItem('💧 Water', nutrition.water, 'ml')}
        ${nutrition.greenFodder ? `${_nutritionItem('🌿 Green Grass', nutrition.greenFodder, 'kg')}${_nutritionItem('🌾 Hay', nutrition.hay || 0, 'kg')}${_nutritionItem('🥜 Concentrate', nutrition.concentrate, 'kg')}` : ''}
        ${nutrition.dailyFeed ? _nutritionItem('🌾 Feed', nutrition.dailyFeed, 'g/bird') : ''}
      </div>
    </div>`);

  parts.push(`
    <div class="meal-schedule">
      <div class="section-label"><i class="fas fa-utensils"></i><span>Meal Schedule</span></div>
      ${meals.map(m => `
        <div class="meal-item">
          <div class="meal-time">
            <span class="time-icon">${m.icon || '🍽️'}</span>
            <span class="time-label">${m.time}</span>
          </div>
          <div class="meal-content">
            <ul>${m.foods.map(f => `<li>${f}</li>`).join('')}</ul>
            ${m.calories ? `<span class="meal-calories">~${m.calories} kcal</span>` : ''}
          </div>
        </div>`).join('')}
    </div>`);

  parts.push(`
    <div class="warnings-box">
      <div class="section-label"><i class="fas fa-ban"></i><span>Foods to Avoid</span></div>
      <ul class="warnings-list">${avoid.map(a => `<li>${a}</li>`).join('')}</ul>
    </div>`);

  parts.push(`
    <div class="tips-box">
      <div class="section-label"><i class="fas fa-lightbulb"></i><span>Care Tips</span></div>
      <ul class="tips-list">${tips.map(t => `<li>${t}</li>`).join('')}</ul>
    </div>`);

  if (emergency && emergency.length > 0) {
    parts.push(`
      <div class="emergency-box">
        <div class="section-label"><i class="fas fa-ambulance"></i><span>Emergency Signs</span></div>
        <ul class="emergency-list">${emergency.map(e => `<li>${e}</li>`).join('')}</ul>
      </div>`);
  }

  if (vets && vets.length > 0) {
    parts.push(`
      <div class="vet-suggestion-box">
        <div class="section-label"><i class="fas fa-user-md"></i><span>Recommended Vets</span></div>
        ${_buildVetRows(vets)}
        <div class="vet-helpline"><i class="fas fa-headset"></i> 24/7 Helpline: <strong>16358</strong></div>
      </div>`);
  }

  parts.push(`
    <div class="disclaimer-box">
      <i class="fas fa-shield-halved"></i>
      This is preliminary advice. Consult a veterinarian for a final diet plan.
    </div>`);

  return parts.join('');
}

async function handleFormSubmit(event) {
  event.preventDefault();
  if (isProcessing) return;

  const data = {
    petType: _elAdv('petType').value,
    age: parseFloat(_elAdv('petAge').value),
    ageUnit: _elAdv('ageUnit').value,
    weight: parseFloat(_elAdv('petWeight').value),
    gender: _checkedValue('gender'),
    activity: _checkedValue('activity'),
    health: _checkedValues('health'),
    goal: _checkedValue('goal')
  };

  const ageInYears = data.ageUnit === 'months' ? data.age / 12 : data.age;
  const bmi = calculateBMI(data.petType, ageInYears, data.weight);
  const autoTags = autoDetectHealthConditions(data, ageInYears, bmi);
  data.health = [...new Set([...data.health, ...autoTags])];

  const validation = validateInput(data);
  if (!validation.valid) { alert('❌ ' + validation.errors.join('\n\n')); return; }
  if (validation.warnings.length > 0) {
    if (!confirm('⚠️ ' + validation.warnings.join('\n\n') + '\n\nContinue?')) return;
  }

  isProcessing = true;
  const btn = _elAdv('submitBtn');
  const originalHTML = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = `<i class="fas fa-spinner fa-spin"></i> <span>Analyzing...</span>`;

  try {
    const nutrition = calculateNutrition(data, ageInYears, bmi);

    /* ai.js engine: hedged cascade + built-in strict-English retry round */
    let aiData = null;
    try { aiData = await callGroqForDiet(data, nutrition, ageInYears, bmi, false); } catch (e) {}

    const vets = await fetchVetsForPet(data.petType);
    lastResultData = { data, nutrition, aiData, warnings: validation.warnings, vets, bmi };

    showReadyMessage(data, bmi);
    saveToHistory(data, nutrition, bmi);
  } catch (error) {
    console.error('Error:', error);
    alert('Something went wrong. Please try again.');
  } finally {
    isProcessing = false;
    btn.disabled = false;
    btn.innerHTML = originalHTML;
  }
}

function showReadyMessage(data, bmi) {
  const resultSection = _elAdv('resultSection');
  const emoji = SPECIES_LIMITS[data.petType].emoji;
  const bmiBadge = bmi ? `
    <div class="bmi-mini-badge" style="background: ${bmi.color}20; color: ${bmi.color}; border-color: ${bmi.color}40;">
      <i class="fas fa-weight-scale"></i><span>${bmi.status}</span>
    </div>` : '';

  const placeholder = _elAdv('placeholderCard');
  if (placeholder) placeholder.style.display = 'none';

  resultSection.style.display = 'flex';
  resultSection.innerHTML = `
    <div class="ready-message">
      <div class="ready-icon"><i class="fas fa-check-circle"></i></div>
      <h3>Your Result is Ready!</h3>
      <p><strong>${emoji} ${data.petType}</strong> · ${data.age} ${data.ageUnit === 'months' ? 'months' : 'years'} · ${data.weight} kg</p>
      ${bmiBadge}
      <button class="view-result-btn" onclick="openResultModal()">
        <i class="fas fa-eye"></i><span>See Result</span>
      </button>
    </div>`;

  setTimeout(() => {
    resultSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, 200);
}

function openResultModal() {
  if (!lastResultData) return;
  const { data, nutrition, aiData, warnings, vets, bmi } = lastResultData;

  let modal = _elAdv('resultModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'resultModal';
    modal.className = 'modal-overlay';
    modal.innerHTML = `
      <div class="modal-content">
        <div class="modal-top">
          <h3><i class="fas fa-clipboard-check"></i> Diet Plan</h3>
          <button class="modal-close-btn" onclick="closeResultModal()"><i class="fas fa-times"></i></button>
        </div>
        <div class="modal-body" id="modalBody"></div>
        <div class="modal-foot">
           <button class="download-pdf-btn" onclick="downloadDietPlan()">
              <i class="fas fa-file-pdf"></i>
              <span>Download PDF</span>
           </button>
        </div>
      </div>`;
    document.body.appendChild(modal);
    modal.addEventListener('click', (e) => { if (e.target === modal) closeResultModal(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeResultModal(); });
  }

  _elAdv('modalBody').innerHTML = buildResultHTML(data, nutrition, aiData, warnings, vets, bmi);
  modal.style.display = 'flex';
  document.body.style.overflow = 'hidden';
}

function closeResultModal() {
  const modal = _elAdv('resultModal');
  if (modal) modal.style.display = 'none';
  document.body.style.overflow = '';
}

async function saveToHistory(data, nutrition, bmi) {
  if (!userPhone) return;
  try {
    await _db().collection('feed_plans').add({
      userPhone,
      petType: data.petType, age: data.age, ageUnit: data.ageUnit,
      weight: data.weight, gender: data.gender, activity: data.activity,
      goal: data.goal, health: data.health, nutrition,
      bmi: bmi ? { status: bmi.status, percent: bmi.percent } : null,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
  } catch (err) { console.warn('History save failed:', err.message); }
}

function resetForm() {
  _elAdv('resultSection').style.display = 'none';
  const placeholder = _elAdv('placeholderCard');
  if (placeholder) placeholder.style.display = '';
  _elAdv('advisorForm').reset();
  lastResultData = null;
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ============================================
// 🆕 FIXED PDF GENERATION (FULL CONTENT)
// ============================================
window.downloadDietPlan = function() {
    const modal = _elAdv('resultModal');
    const element = _elAdv('modalBody');
    if (!element || !modal) {
        alert('Result not found. Please generate a plan first.');
        return;
    }

    const animalName = lastResultData ? lastResultData.data.petType : 'Animal';
    const btn = document.querySelector('.download-pdf-btn');
    const originalHTML = btn ? btn.innerHTML : '';

    // 1. Save current styles to restore later
    const modalContent = modal.querySelector('.modal-content');
    const restore = {
        elOverflow: element.style.overflow,
        elMaxH: element.style.maxHeight,
        elHeight: element.style.height,
        mcMaxH: modalContent ? modalContent.style.maxHeight : '',
        mcOverflow: modalContent ? modalContent.style.overflow : '',
        mcHeight: modalContent ? modalContent.style.height : '',
        bodyOverflow: document.body.style.overflow
    };

    // 2. Remove all scrolling/height constraints to render full content
    element.style.overflow = 'visible';
    element.style.maxHeight = 'none';
    element.style.height = 'auto';
    if (modalContent) {
        modalContent.style.maxHeight = 'none';
        modalContent.style.overflow = 'visible';
        modalContent.style.height = 'auto';
    }
    document.body.style.overflow = 'visible';

    if (btn) {
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>Generating PDF...</span>';
        btn.disabled = true;
    }

    // 3. Wait for DOM update, then generate PDF
    setTimeout(() => {
        const opt = {
            margin:      [10, 10, 12, 10],
            filename:    `DailyVet_Diet_Plan_${animalName}.pdf`,
            image:       { type: 'jpeg', quality: 0.98 },
            html2canvas: {
                scale: 2,
                useCORS: true,
                backgroundColor: '#ffffff',
                scrollY: 0,
                scrollX: 0,
                windowWidth: document.documentElement.offsetWidth,
                windowHeight: element.scrollHeight
            },
            jsPDF:       { unit: 'mm', format: 'a4', orientation: 'portrait' },
            pagebreak:   { mode: ['css', 'legacy'], avoid: '.meal-item, .bmi-card, .nutrition-summary, .vet-item, .pet-info-card, .warnings-box, .tips-box, .emergency-box, .vet-suggestion-box, .disclaimer-box' }
        };

        html2pdf().set(opt).from(element).save().then(() => {
            // Restore styles
            element.style.overflow = restore.elOverflow;
            element.style.maxHeight = restore.elMaxH;
            element.style.height = restore.elHeight;
            if (modalContent) {
                modalContent.style.maxHeight = restore.mcMaxH;
                modalContent.style.overflow = restore.mcOverflow;
                modalContent.style.height = restore.mcHeight;
            }
            document.body.style.overflow = restore.bodyOverflow;

            if (btn) {
                btn.innerHTML = originalHTML;
                btn.disabled = false;
            }
        }).catch(err => {
            console.error('PDF generation failed:', err);
            alert('Failed to generate PDF. Please try again.');

            // Restore styles on error
            element.style.overflow = restore.elOverflow;
            element.style.maxHeight = restore.elMaxH;
            element.style.height = restore.elHeight;
            if (modalContent) {
                modalContent.style.maxHeight = restore.mcMaxH;
                modalContent.style.overflow = restore.mcOverflow;
                modalContent.style.height = restore.mcHeight;
            }
            document.body.style.overflow = restore.bodyOverflow;

            if (btn) {
                btn.innerHTML = originalHTML;
                btn.disabled = false;
            }
        });
    }, 300);
};

document.addEventListener('DOMContentLoaded', function () {
  userPhone = sessionStorage.getItem('userPhone') || localStorage.getItem('userPhone');
  if (!userPhone) { window.location.href = 'login.html'; return; }
  _dvApplyLang();
  const form = _elAdv('advisorForm');
  if (form) form.addEventListener('submit', handleFormSubmit);
  ['petWeight', 'petAge'].forEach(id => {
    const el = _elAdv(id);
    if (el) el.addEventListener('input', e => {
      e.target.value = e.target.value.replace(/[^0-9.]/g, '');
    });
  });
  console.log('🍽️ Feed Advisor loaded (English only)');
});

window.resetForm = resetForm;
window.openResultModal = openResultModal;
window.closeResultModal = closeResultModal;