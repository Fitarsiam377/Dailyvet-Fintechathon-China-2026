/* ============================================================
   DailyVet — Universal Risk Map Engine v3.0
   Modes: 'policy' | 'claim' | 'finance'
   Different color themes for different purposes:
   - Policy: Green (Safe), Yellow (Medium), Red (High)
   - Claim:  Blue (Low), Yellow (Medium), Red (High)
   - Finance: Cyan (Safe), Light Blue (Medium), Violet (High)
   ============================================================ */
(function () {
'use strict';

const COORDS = {
  dhaka:      { lat: 23.8103, lng: 90.4125, name: 'Dhaka' },
  chittagong: { lat: 22.3569, lng: 91.7832, name: 'Chittagong' },
  rajshahi:   { lat: 24.3745, lng: 88.6042, name: 'Rajshahi' },
  khulna:     { lat: 22.8456, lng: 89.5403, name: 'Khulna' },
  barisal:    { lat: 22.7010, lng: 90.3535, name: 'Barisal' },
  sylhet:     { lat: 24.8949, lng: 91.8687, name: 'Sylhet' },
  rangpur:    { lat: 25.7439, lng: 89.2752, name: 'Rangpur' },
  mymensingh: { lat: 24.7471, lng: 90.4203, name: 'Mymensingh' }
};

const CENTER = [23.7, 90.35];
const ZOOM_START = 6.4;
const BUBBLE_BASE = 28;
const BUBBLE_MAX = 44;
const LABEL_OFFSET = { division: 0.28, district: 0.10, upazila: 0.05 };
const CONCURRENCY = 4;

// Mode detection (set by the HTML page)
const MODE = window.MAP_MODE || 'policy';

/* ===== Risk Thresholds ===== */
const RISK = {
  flood: { med: 15, high: 30 },
  thi:   { med: 76, high: 78 }
};

/* ===== Color themes ===== */
const COLORS = {
  policy: { safe: '#10b981', med: '#f59e0b', high: '#ef4444', none: '#94a3b8' }, // Green, Yellow, Red
  claim:  { safe: '#3b82f6', med: '#f59e0b', high: '#ef4444', none: '#475569' }, // Blue, Yellow, Red
  finance:{ safe: '#06b6d4', med: '#0ea5e9', high: '#8b5cf6', none: '#475569' }  // Cyan, Light Blue, Violet
};

const THEME = COLORS[MODE] || COLORS.policy;

const DIV_ALIAS = { chattogram: 'chittagong', chattagram: 'chittagong', barishal: 'barisal', dacca: 'dhaka' };
const divKey = s => { const k = String(s || '').trim().toLowerCase(); return DIV_ALIAS[k] || k; };

/* Shared base layers (identical to the climate maps):
   Street (OpenStreetMap) + Satellite (Esri imagery + place labels). Registers the map for GPS. */
function dvAddBaseLayers(map, mobile) {
  const street = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    { attribution: '&copy; OpenStreetMap contributors', maxZoom: 19 });
  const sat = L.layerGroup([
    L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
      { attribution: 'Tiles &copy; Esri', maxZoom: 19 }),
    L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',
      { maxZoom: 19, opacity: 0.9 })
  ]);
  street.addTo(map);
  L.control.layers({ '🗺️ Street Map': street, '🛰️ Satellite': sat }, null,
    { position: 'topright', collapsed: !!mobile }).addTo(map);
  (window.__dvMaps = window.__dvMaps || []).push(map);
  return { street, sat };
}

const EMOJI = { dhaka: '🏛️', chittagong: '⚓', rajshahi: '🌾', khulna: '🌊', barisal: '🚤', sylhet: '🍃', rangpur: '🌿', mymensingh: '🌳' };

const state = {
  map: null, markers: new Map(), labels: new Map(), polygons: new Map(),
  rows: [], token: 0, level: 'division', divisionKey: null,
  geo: { div: null, dist: null, upa: null }, upaTried: false,
  searchPin: null, searchAbort: null, searchDebounce: null, selected: null, ready: false
};

const pointCache = new Map();
const _el = id => document.getElementById(id);
const _ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const esc = t => String(t == null ? '' : t).replace(/[&<>"']/g, c => _ESC[c]);

function prop(obj, ...keys) {
  for (const k of keys) if (obj && obj[k] != null && obj[k] !== '') return obj[k];
  return '';
}

function centroid(feature) {
  const ring = c => {
    if (!Array.isArray(c) || !c.length) return null;
    let la = 0, ln = 0;
    c.forEach(([x, y]) => { la += y; ln += x; });
    return [la / c.length, ln / c.length];
  };
  const g = feature && feature.geometry;
  if (!g) return null;
  if (g.type === 'Polygon') return ring(g.coordinates[0]);
  if (g.type === 'MultiPolygon') {
    let best = g.coordinates[0][0];
    g.coordinates.forEach(p => { if (p[0].length > best.length) best = p[0]; });
    return ring(best);
  }
  if (g.type === 'Point') return [g.coordinates[1], g.coordinates[0]];
  return null;
}

function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error('timeout')), ms);
    Promise.resolve(promise).then(v => { clearTimeout(t); resolve(v); }, e => { clearTimeout(t); reject(e); });
  });
}

function snap(lat, lng) {
  return [Math.round(lat / 0.5) * 0.5, Math.round((lng + 180) / 0.625) * 0.625 - 180];
}

function pointData(rawLat, rawLng) {
  const [lat, lng] = snap(rawLat, rawLng);
  const key = lat.toFixed(3) + ',' + lng.toFixed(3);
  if (pointCache.has(key)) return pointCache.get(key);

  const p = (async () => {
    if (!window.NasaPower || !window.NasaClimate || !window.NasaFlood) return null;
    try {
      const param = await withTimeout(NasaPower.getPowerData(lat, lng, 7), 15000);
      if (!param) return null;
      const rain = NasaPower.getLatest(param, 'PRECTOTCORR');
      const temp = NasaPower.getLatest(param, 'T2M');
      const rh   = NasaPower.getLatest(param, 'RH2M');
      const gwt  = NasaPower.getLatest(param, 'GWETROOT');
      if (!rain || !temp || !rh) return null;

      const thi = NasaClimate.calculateTHI(temp.value, rh.value);
      const thiCls = thi !== null ? NasaClimate.classifyTHI(thi, 'cow') : null;
      const rainSeries = NasaPower.getSeries(param, 'PRECTOTCORR');
      const rain7d = rainSeries.reduce((s, d) => s + (d.value > 0 ? d.value : 0), 0);
      const flood = NasaFlood.calculateFloodRisk({
        rain7dayMm: rain7d, soilRoot: gwt ? gwt.value : 0, soilTop: 0, rain48hForecast: 0, rain72hForecast: 0, district: 'dhaka', daysOfRain: rainSeries.filter(d => d.value > 5).length
      });

      return {
        thi, thiLevel: thiCls ? thiCls.level : 'normal', thiColor: thiCls ? thiCls.color : '#059669',
        flood: flood.score || 0, floodLevel: flood.level || 'safe', floodColor: flood.color || '#059669',
        rain: rain.value, temp: temp.value, rh: rh.value, date: temp.date
      };
    } catch (err) { return null; }
  })();

  pointCache.set(key, p);
  p.then(r => { if (!r) pointCache.delete(key); });
  return p;
}

async function loadGeo(url) {
  try {
    const res = await fetch(url, { cache: 'force-cache' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return await res.json();
  } catch (err) { return null; }
}

async function loadAllGeo() {
  const [div, dist] = await Promise.all([loadGeo('data/bd-divisions.geojson'), loadGeo('data/bd-districts.geojson')]);
  state.geo.div  = div  || window.BD_DIVISIONS || null;
  state.geo.dist = dist || window.BD_DISTRICTS || null;
  state.geo.upa  = window.BD_UPAZILAS || null;
}

async function ensureUpazilas() {
  if (state.geo.upa || state.upaTried) return;
  state.upaTried = true;
  state.geo.upa = await loadGeo('data/bd-upazilas.geojson');
}

function ensureLeaflet() {
  if (window.L && L.map) return Promise.resolve(true);
  return new Promise(resolve => {
    if (_el('ipmLeafletScript')) { setTimeout(() => resolve(!!(window.L && L.map)), 400); return; }
    const s = document.createElement('script');
    s.id = 'ipmLeafletScript';
    s.src = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js';
    s.onload = () => resolve(!!(window.L && L.map));
    s.onerror = () => resolve(false);
    document.head.appendChild(s);
  });
}

function initMap() {
  const el = _el('ipmMap');
  if (!el || state.map) return state.map;

  const mobile = window.innerWidth <= 640;
  state.map = L.map(el, {
    center: CENTER, zoom: mobile ? 6 : ZOOM_START, zoomControl: true,
    scrollWheelZoom: false, minZoom: 5, maxZoom: 12,
    maxBounds: [[20.0, 87.0], [27.0, 93.5]]
  });

  dvAddBaseLayers(state.map, mobile);

  state.map.on('focus', () => state.map.scrollWheelZoom.enable());
  state.map.on('blur',  () => state.map.scrollWheelZoom.disable());
  setTimeout(() => { try { state.map.invalidateSize(); } catch (_) {} }, 250);
  return state.map;
}

function clearLayers() {
  if (!state.map) return;
  [state.markers, state.labels, state.polygons].forEach(coll => {
    coll.forEach(layer => { try { state.map.removeLayer(layer); } catch (_) {} });
    coll.clear();
  });
  state.token++;
  try { state.map.closePopup(); } catch (_) {}
}

/* ===== Bubble state: colors follow the active theme ===== */
function bubbleState(row) {
  const d = row.data;
  if (!d) {
    return { val: null, color: THEME.none, text: row.loading ? '…' : '—', flood: 0, thi: 0 };
  }

  const flood = Number(d.flood) || 0;
  const thi   = Number(d.thi)   || 0;

  // Level logic is identical on every page
  let level = 'safe';
  if (flood > RISK.flood.high || thi > RISK.thi.high) level = 'high';
  else if (flood > RISK.flood.med || thi > RISK.thi.med) level = 'med';

  // Bubble text shows the flood %
  const displayText = flood + '%';

  return { val: Math.max(flood, thi), level, color: THEME[level], text: displayText, flood, thi };
}

function bubbleIcon(row, boost) {
  const st = bubbleState(row);
  const frac = st.val == null ? 0 : Math.min(1, st.val / 100);
  const size = Math.round(BUBBLE_BASE + (BUBBLE_MAX - BUBBLE_BASE) * frac) + (boost || 0);
  const fs = Math.max(11, Math.min(15, size / 3.5));

  // Inline styles force the background color
  const style = [
    `width:${size}px`, `height:${size}px`, `line-height:${size}px`,
    `background:${st.color} !important`,
    `background-color:${st.color} !important`,
    `color:#fff`, `font-size:${fs}px`, `font-weight:800`,
    `border-radius:50%`, `text-align:center`,
    `border:3px solid #fff`,
    `box-shadow:0 2px 8px rgba(0,0,0,.35), 0 0 0 2px ${st.color}55`
  ].join(';');

  return L.divIcon({
    html: `<div class="ipm-bubble${row.loading ? ' ipm-loading' : ''}" style="${style}"><span>${esc(st.text)}</span></div>`,
    className: 'ipm-marker',
    iconSize: [size, size],
    iconAnchor: [size / 2, size / 2],
    popupAnchor: [0, -size / 2]
  });
}

function bubblePopup(row) {
  const st = bubbleState(row);
  const d = row.data;
  const canDrill = row.level !== 'upazila' && row.feature;
  return `
    <div class="ipm-pop">
      <div class="ipm-pop-title">${esc(row.emoji || '📍')} ${esc(row.nameBn)}</div>
      <div class="ipm-pop-metric" style="color:${st.color};">
        Flood ${d ? Math.round(d.flood) + '%' : '—'} · THI ${d ? Math.round(d.thi) : '—'}
      </div>
      ${canDrill ? `<button class="ipm-pop-btn" onclick="window.__ipmDrill(${row.idx})">See inside →</button>` : ''}
      <button class="ipm-pop-btn" style="background:#0f172a;margin-top:4px;" onclick="window.__ipmPickRow(${row.idx})">Select this area</button>
    </div>`;
}

function upsertBubble(row, boost) {
  if (!state.map) return null;
  const icon = bubbleIcon(row, boost);
  let m = state.markers.get(row.key);
  if (m) {
    m.setIcon(icon);
    m.setPopupContent(bubblePopup(row));
    return m;
  }
  m = L.marker(row.centroid, { icon, title: row.nameBn, riseOnHover: true, zIndexOffset: 1000 });
  m.bindPopup(bubblePopup(row), { autoPan: true });
  m.on('click', () => {
    const pt = row.aqiPoint || row.centroid;
    selectArea({
      districtKey: row.level === 'division' ? row.key : state.divisionKey,
      districtName: row.nameBn,
      area: row.level !== 'division' ? row.nameBn : null,
      lat: pt[0], lng: pt[1], hasArea: row.level !== 'division'
    });
  });
  m.addTo(state.map);
  state.markers.set(row.key, m);
  return m;
}

async function loadRowsConcurrent(rows, token, boost) {
  let next = 0;
  const worker = async () => {
    while (next < rows.length) {
      const i = next++; const row = rows[i];
      if (token !== state.token) return;
      const pt = row.aqiPoint || row.centroid;
      row.data = await pointData(pt[0], pt[1]);
      row.loading = false;
      if (token !== state.token) return;
      upsertBubble(row, boost);
    }
  };
  await Promise.all(Array.from({ length: CONCURRENCY }, worker));
}

function addPolygon(key, feature, style, onClick) {
  const poly = L.geoJSON(feature, {
    style,
    onEachFeature: (_f, layer) => {
      layer.on('mouseover', () => { layer.setStyle({ weight: 2.5, opacity: 1, fillOpacity: 0.2 }); layer.bringToFront(); });
      layer.on('mouseout', () => layer.setStyle(style));
      layer.on('click', onClick);
    }
  }).addTo(state.map);
  state.polygons.set(key, poly);
}

function addLabel(key, lat, lng, text) {
  const isDark = (MODE === 'claim' || MODE === 'finance');
  const colorStyle = isDark
      ? 'color: #ffffff; text-shadow: 0 1px 4px #000, 0 0 8px #000, 0 0 12px #000; font-weight: 800; font-size: 11px;'
      : 'color: #1e293b; font-weight: 700; font-size: 10.5px; text-shadow: 0 0 3px #fff, 0 0 3px #fff, 0 0 3px #fff;';

  const icon = L.divIcon({
    html: `<div class="ipm-label" style="${colorStyle}">${esc(text)}</div>`,
    className: 'ipm-label-wrap', iconSize: [100, 22], iconAnchor: [50, 11]
  });
  state.labels.set(key, L.marker([lat, lng], { icon, interactive: false, keyboard: false, zIndexOffset: -100 }).addTo(state.map));
}

function drawLevel(rows, cfg) {
  if (!state.map) return;
  const token = state.token;
  state.rows = rows;

  const isDark = (MODE === 'claim' || MODE === 'finance');
  const polyColor = isDark ? '#60a5fa' : '#7c3aed';
  const polyFill = isDark ? '#93c5fd' : '#a78bfa';

  rows.forEach((row, i) => {
    row.idx = i; row.loading = true; row.data = null;
    if (row.feature) addPolygon(row.key, row.feature, { color: polyColor, weight: 1.5, opacity: 0.8, fillColor: polyFill, fillOpacity: 0.1 }, () => cfg.onPolygonClick(row));
    addLabel(row.key + '_label', row.centroid[0] - cfg.labelOffset, row.centroid[1], row.nameBn);
  });
  rows.forEach(r => upsertBubble(r, cfg.boost));
  loadRowsConcurrent(rows, token, cfg.boost);
}

function fitPolygons() {
  const layers = Array.from(state.polygons.values());
  if (!layers.length) return;
  const b = L.featureGroup(layers).getBounds();
  if (b.isValid()) state.map.fitBounds(b, { padding: [20, 20] });
}

function renderDivisions() {
  if (!state.map) return;
  clearLayers(); state.level = 'division'; state.divisionKey = null; updateBreadcrumb('division');
  const feats = state.geo.div?.features || [];
  let rows;

  if (!feats.length) {
    rows = Object.keys(COORDS).map(k => {
      const c = COORDS[k];
      return { key: k, level: 'division', nameBn: c.name, emoji: EMOJI[k], aqiPoint: [c.lat, c.lng], centroid: [c.lat, c.lng], feature: null };
    });
  } else {
    rows = feats.map(f => {
      const nameEn = prop(f.properties, 'ADM1_EN', 'name', 'NAME_1');
      const key = divKey(nameEn); const c = COORDS[key]; const cen = centroid(f);
      return { key, level: 'division', nameBn: prop(f.properties, 'ADM1_BN', 'nameBn') || (c && c.name) || nameEn, emoji: EMOJI[key] || '📍', aqiPoint: c ? [c.lat, c.lng] : cen, centroid: cen, feature: f };
    }).filter(r => r.centroid);
  }

  drawLevel(rows, {
    style: { color: '#7c3aed', weight: 1.2, opacity: 0.55, fillColor: '#a78bfa', fillOpacity: 0.06 },
    labelOffset: LABEL_OFFSET.division, boost: 8, onPolygonClick: row => drillDistricts(row)
  });
  renderLegend();
  state.map.fitBounds([[20.6, 88.0], [26.7, 92.7]], { padding: [20, 20] });
}

function drillDistricts(divRow) {
  if (!state.map) return;
  const feats = (state.geo.dist?.features || []).filter(f => divKey(prop(f.properties, 'ADM1_EN', 'division')) === divRow.key);
  if (!feats.length) {
    const pt = divRow.aqiPoint || divRow.centroid;
    selectArea({ districtKey: divRow.key, districtName: divRow.nameBn, area: null, lat: pt[0], lng: pt[1], hasArea: false }); return;
  }

  clearLayers(); state.level = 'district'; state.divisionKey = divRow.key; updateBreadcrumb('district', divRow.nameBn);
  const rows = feats.map(f => {
    const nameEn = prop(f.properties, 'ADM2_EN', 'name', 'NAME_2');
    return { key: nameEn.toLowerCase(), level: 'district', nameBn: prop(f.properties, 'ADM2_BN', 'nameBn') || nameEn, emoji: '📍', centroid: centroid(f), feature: f };
  }).filter(r => r.centroid);

  drawLevel(rows, { style: { color: '#2563eb', weight: 1.5, opacity: 0.75, fillColor: '#60a5fa', fillOpacity: 0.10 }, labelOffset: LABEL_OFFSET.district, boost: 0, onPolygonClick: row => drillUpazilas(row) });
  fitPolygons();
}

async function drillUpazilas(distRow) {
  if (!state.map) return;
  await ensureUpazilas();
  const feats = (state.geo.upa?.features || []).filter(f => String(prop(f.properties, 'ADM2_EN', 'district')).toLowerCase() === distRow.key);
  if (!feats.length) {
    selectArea({ districtKey: state.divisionKey, districtName: distRow.nameBn, area: distRow.nameBn, lat: distRow.centroid[0], lng: distRow.centroid[1], hasArea: true }); return;
  }

  clearLayers(); state.level = 'upazila'; updateBreadcrumb('upazila', distRow.nameBn);
  const rows = feats.map(f => {
    const nameEn = prop(f.properties, 'ADM3_EN', 'name', 'NAME_3');
    return { key: nameEn.toLowerCase(), level: 'upazila', nameBn: prop(f.properties, 'ADM3_BN', 'nameBn') || nameEn, emoji: '📍', centroid: centroid(f), feature: f };
  }).filter(r => r.centroid);

  drawLevel(rows, {
    style: { color: '#0891b2', weight: 1, opacity: 0.65, fillColor: '#22d3ee', fillOpacity: 0.08 },
    labelOffset: LABEL_OFFSET.upazila, boost: 0, onPolygonClick: row => selectArea({ districtKey: state.divisionKey, districtName: distRow.nameBn, area: row.nameBn, lat: row.centroid[0], lng: row.centroid[1], hasArea: true })
  });
  fitPolygons();
}

window.__ipmDrill = function (idx) {
  const row = state.rows[idx]; if (!row || !state.map) return;
  state.map.closePopup();
  if (state.level === 'division') drillDistricts(row); else if (state.level === 'district') drillUpazilas(row);
};

window.__ipmPickRow = function (idx) {
  const row = state.rows[idx]; if (!row) return;
  const pt = row.aqiPoint || row.centroid;
  selectArea({ districtKey: row.level === 'division' ? row.key : state.divisionKey, districtName: row.nameBn, area: row.level !== 'division' ? row.nameBn : null, lat: pt[0], lng: pt[1], hasArea: row.level !== 'division' });
  if (state.map) state.map.closePopup();
};

window.__ipmBack = function () {
  renderDivisions();
  const box = _el('ipmSelectedSummary'); if (box) box.style.display = 'none';
};

window.__ipmClearSelection = function () {
  state.selected = null;
  const box = _el('ipmSelectedSummary'); if (box) box.style.display = 'none';
  const hidden = _el('policyDistrict'); if (hidden) hidden.value = '';
  if (typeof window.onPolicyLocationChange === 'function') {
    window.onPolicyLocationChange({ districtKey: 'dhaka', districtName: 'Dhaka', area: '', hasArea: false, lat: COORDS.dhaka.lat, lng: COORDS.dhaka.lng });
  }
};

function updateBreadcrumb(level, name) {
  const bc = _el('ipmBreadcrumb'); const back = _el('ipmBackBtn'); if (!bc) return;
  if (level === 'division') { bc.innerHTML = '<b>Bangladesh</b>'; if (back) back.style.display = 'none'; return; }
  if (back) back.style.display = 'inline-flex';
  bc.innerHTML = `<span class="ipm-bc-link" onclick="window.__ipmBack()">Bangladesh</span> › <b>${esc(name || '')}</b>`;
}

function renderLegend() {
  const el = _el('ipmLegend'); if (!el) return;
  const dot = (c, t) => `<span><i style="background:${c}"></i>${t}</span>`;
  const label = MODE === 'claim' ? 'Area Status' : (MODE === 'finance' ? 'Income Health' : 'Overall Risk');
  
  el.innerHTML = `<b>${label}:</b> ` + 
    dot(THEME.safe, 'Safe') + 
    dot(THEME.med, 'Medium') + 
    dot(THEME.high, 'High');
}

function selectArea(payload) {
  state.selected = payload;
  const hidden = _el('policyDistrict'); if (hidden) hidden.value = payload.districtKey;
  const box = _el('ipmSelectedSummary'); const nameEl = _el('ipmSelectedName');
  if (box && nameEl) {
    nameEl.textContent = (payload.area ? payload.area + ', ' : '') + payload.districtName;
    box.style.display = 'flex';
  }
  if (typeof window.onPolicyLocationChange === 'function') {
    window.onPolicyLocationChange({ districtKey: payload.districtKey, districtName: payload.districtName, area: payload.area || '', hasArea: !!payload.hasArea, lat: payload.lat, lng: payload.lng });
  }
}

async function searchPlaces(query) {
  if (!query || query.length < 2) return [];
  if (state.searchAbort) { try { state.searchAbort.abort(); } catch (_) {} }
  state.searchAbort = new AbortController();
  try {
    if (window.DVLocationIQ && typeof window.DVLocationIQ.search === 'function') {
      const r = await window.DVLocationIQ.search(query, { limit: 8 });
      if (Array.isArray(r)) return r;
    }
    const res = await fetch('https://geocoding-api.open-meteo.com/v1/search?name=' + encodeURIComponent(query) + '&country=BD&count=8&language=en', { signal: state.searchAbort.signal });
    if (!res.ok) return [];
    const data = await res.json();
    return (data.results || []).map(r => ({ name: r.name, sub: [r.admin2, r.admin1].filter(Boolean).join(', '), fullName: [r.name, r.admin2, r.admin1].filter(Boolean).join(', '), lat: r.latitude, lng: r.longitude, district: r.admin2 || '' }));
  } catch (err) { return []; }
}

function renderSearchResults(results) {
  const dd = _el('ipmSearchResults'); if (!dd) return;
  if (!results || !results.length) { dd.innerHTML = '<div class="ipm-search-empty">No places found</div>'; dd.style.display = 'block'; return; }
  dd.style.display = 'block';
  dd.innerHTML = results.map((r, i) => `<div class="ipm-search-item" data-i="${i}" role="option" tabindex="0"><div class="ipm-search-item-icon"><i class="fas fa-map-pin"></i></div><div style="min-width:0;"><div class="ipm-search-item-name">${esc(r.name)}</div><div class="ipm-search-item-sub">${esc(r.sub || r.fullName || '')}</div></div></div>`).join('');

  const items = dd.querySelectorAll('.ipm-search-item');
  items.forEach(item => {
    const pick = () => {
      const r = results[+item.dataset.i]; if (!r) return;
      const input = _el('ipmSearchInput'); if (input) input.value = r.name;
      if (state.map) {
        state.map.flyTo([r.lat, r.lng], 10, { duration: 1 });
        if (state.searchPin) { try { state.map.removeLayer(state.searchPin); } catch (_) {} }
        state.searchPin = L.circleMarker([r.lat, r.lng], { radius: 9, color: '#fff', weight: 3, fillColor: '#7c3aed', fillOpacity: 1 }).addTo(state.map);
      }
      const dKey = detectDistrictKey(r);
      const dName = (dKey && window.BD_DISTRICTS_LIST?.[dKey]) ? window.BD_DISTRICTS_LIST[dKey].name : (r.district || 'Unknown');
      selectArea({ districtKey: dKey || 'dhaka', districtName: dName, area: r.name, lat: r.lat, lng: r.lng, hasArea: true });
      dd.style.display = 'none';
    };
    item.addEventListener('click', pick);
    item.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); } });
  });
}

function detectDistrictKey(result) {
  if (!window.BD_DISTRICTS_LIST) return null;
  const haystack = String((result.district || '') + ' ' + (result.sub || '') + ' ' + (result.fullName || '')).toLowerCase();
  for (const [key, d] of Object.entries(window.BD_DISTRICTS_LIST)) {
    if (haystack.includes(d.name.toLowerCase()) || haystack.includes(key)) return key;
  }
  return null;
}

function initSearch() {
  const input = _el('ipmSearchInput'); if (!input) return;
  input.addEventListener('input', e => {
    const q = e.target.value.trim(); clearTimeout(state.searchDebounce);
    if (q.length < 2) { const dd = _el('ipmSearchResults'); if (dd) dd.style.display = 'none'; return; }
    state.searchDebounce = setTimeout(async () => {
      const results = await searchPlaces(q);
      if (results === null) return;
      renderSearchResults(results);
    }, 320);
  });
  document.addEventListener('click', e => {
    const dd = _el('ipmSearchResults');
    if (dd && !dd.contains(e.target) && e.target !== input) dd.style.display = 'none';
  });
}

/* Load the shared GPS animator on demand if the page did not include it */
function ensureGpsAnimator() {
  if (window.DVGpsAnimator) return Promise.resolve(true);
  return new Promise(resolve => {
    const s = document.createElement('script');
    s.src = 'js/dv-gps-animator.js';
    s.onload = () => resolve(!!window.DVGpsAnimator);
    s.onerror = () => resolve(false);
    document.head.appendChild(s);
  });
}

window.__ipmUseMyLocation = async function () {
  const ok = await ensureGpsAnimator();
  if (!ok) { alert('GPS helper (js/dv-gps-animator.js) could not be loaded.'); return; }

  DVGpsAnimator.locate({
    buttonId: 'ipmGpsBtn',
    map: state.map,
    zoom: 11,
    accentColor: THEME.safe,
    findClosest: (lat, lng) => {
      let best = null, min = Infinity;
      Object.keys(COORDS).forEach(k => {
        const c = COORDS[k];
        const d = Math.pow(c.lat - lat, 2) + Math.pow(c.lng - lng, 2);
        if (d < min) { min = d; best = k; }
      });
      return { key: best, nameBn: best ? COORDS[best].name : 'My Location' };
    },
    onSuccess: async (closest, pos) => {
      if (pos.outside) return; /* policies are Bangladesh-only */
      const { lat, lng } = pos;
      let place = null;
      if (window.DVLocationIQ && typeof window.DVLocationIQ.reverse === 'function') {
        try { place = await window.DVLocationIQ.reverse(lat, lng); } catch (_) {}
      }
      const dKey = detectDistrictKey({ district: place && place.district, sub: place && place.division, fullName: place && place.fullName }) || closest.key || 'dhaka';
      const dName = (window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[dKey]) ? window.BD_DISTRICTS_LIST[dKey].name : ((place && place.district) || 'Dhaka');
      selectArea({ districtKey: dKey, districtName: dName, area: (place && (place.area || place.name)) || 'My location', lat, lng, hasArea: true });
    }
  });
};

async function start() {
  const phone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
  if (!phone) { window.location.href = 'login.html'; return; }
  if (!_el('ipmMap')) return;

  initSearch();
  const ok = await ensureLeaflet();
  if (!ok) {
    const m = _el('ipmMap');
    if (m) m.innerHTML = '<div style="padding:30px;text-align:center;color:#dc2626;font-weight:600;">Could not load map library.</div>';
    return;
  }
  await loadAllGeo();
  initMap();
  state.ready = true;
  renderDivisions();
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
else start();

})();