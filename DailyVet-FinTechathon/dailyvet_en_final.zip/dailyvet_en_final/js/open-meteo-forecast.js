/* DailyVet — Open-Meteo Forecast Client v2.2 (Full Fix)
   Air quality, UV, weekly weather, rainfall cumulative, past days, tomorrow.
   Source: https://open-meteo.com (key-free, CORS-enabled)
*/
(function () {
'use strict';

const AQI_URL = 'https://air-quality-api.open-meteo.com/v1/air-quality';
const FORECAST_URL = 'https://api.open-meteo.com/v1/forecast';
const CACHE_TTL_MS = 30 * 60 * 1000;
const API_TIMEOUT_MS = 12000;
const _cache = new Map();

function _cacheGet(key) {
    const e = _cache.get(key);
    if (!e) return null;
    if (Date.now() - e.at > CACHE_TTL_MS) { _cache.delete(key); return null; }
    return e.data;
}
function _cacheSet(key, data) {
    _cache.set(key, { at: Date.now(), data });
}

async function _fetchJson(url) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS);
    try {
        const res = await fetch(url, { signal: controller.signal });
        clearTimeout(timer);
        if (!res.ok) return null;
        return await res.json();
    } catch (err) {
        clearTimeout(timer);
        console.warn('[OpenMeteo] fetch failed:', err.message);
        return null;
    }
}

/* ===== AQI ===== */
async function getAQI(lat, lng) {
    const key = `aqi_${Number(lat).toFixed(2)}_${Number(lng).toFixed(2)}`;
    const cached = _cacheGet(key);
    if (cached) return cached;

    const url = `${AQI_URL}?latitude=${lat}&longitude=${lng}` +
        `&current=us_aqi,pm2_5,pm10,ozone,nitrogen_dioxide,sulphur_dioxide,carbon_monoxide,dust` +
        `&timezone=Asia%2FDhaka`;
    const data = await _fetchJson(url);
    if (!data || !data.current) return null;

    const c = data.current;
    const result = {
        usAqi: Number.isFinite(c.us_aqi) ? c.us_aqi : null,
        pm25: Number.isFinite(c.pm2_5) ? c.pm2_5 : null,
        pm10: Number.isFinite(c.pm10) ? c.pm10 : null,
        o3: Number.isFinite(c.ozone) ? c.ozone : null,
        no2: Number.isFinite(c.nitrogen_dioxide) ? c.nitrogen_dioxide : null,
        so2: Number.isFinite(c.sulphur_dioxide) ? c.sulphur_dioxide : null,
        co: Number.isFinite(c.carbon_monoxide) ? c.carbon_monoxide : null,
        dust: Number.isFinite(c.dust) ? c.dust : null,
        time: c.time || null,
        source: 'Open-Meteo Air Quality (CAMS)'
    };
    _cacheSet(key, result);
    return result;
}

/* ===== WEEKLY FORECAST ===== */
async function getWeek(lat, lng) {
    const key = `week_${Number(lat).toFixed(2)}_${Number(lng).toFixed(2)}`;
    const cached = _cacheGet(key);
    if (cached) return cached;

    const url = `${FORECAST_URL}?latitude=${lat}&longitude=${lng}` +
        `&daily=temperature_2m_max,temperature_2m_min,temperature_2m_mean,relative_humidity_2m_mean,uv_index_max,precipitation_sum,wind_speed_10m_max,shortwave_radiation_sum` +
        `&timezone=Asia%2FDhaka&forecast_days=7`;
    const data = await _fetchJson(url);
    if (!data || !data.daily || !Array.isArray(data.daily.time)) return null;

    const d = data.daily;
    const days = d.time.map((date, i) => ({
        date,
        tempMax: Number.isFinite(d.temperature_2m_max?.[i]) ? d.temperature_2m_max[i] : null,
        tempMin: Number.isFinite(d.temperature_2m_min?.[i]) ? d.temperature_2m_min[i] : null,
        tempMean: Number.isFinite(d.temperature_2m_mean?.[i]) ? d.temperature_2m_mean[i] : null,
        humidity: Number.isFinite(d.relative_humidity_2m_mean?.[i]) ? d.relative_humidity_2m_mean[i] : null,
        uvIndexMax: Number.isFinite(d.uv_index_max?.[i]) ? d.uv_index_max[i] : null,
        precipitation: Number.isFinite(d.precipitation_sum?.[i]) ? d.precipitation_sum[i] : null,
        windMax: Number.isFinite(d.wind_speed_10m_max?.[i]) ? d.wind_speed_10m_max[i] : null,
        solarRadiation: Number.isFinite(d.shortwave_radiation_sum?.[i]) ? d.shortwave_radiation_sum[i] : null
    }));
    _cacheSet(key, days);
    return days;
}

/* ===== TOMORROW FORECAST ===== */
async function getTomorrow(lat, lng) {
    const key = `tomorrow_${Number(lat).toFixed(2)}_${Number(lng).toFixed(2)}`;
    const cached = _cacheGet(key);
    if (cached) return cached;

    const url = `${FORECAST_URL}?latitude=${lat}&longitude=${lng}` +
        `&daily=temperature_2m_mean,relative_humidity_2m_mean,precipitation_sum,temperature_2m_max,temperature_2m_min` +
        `&timezone=Asia%2FDhaka&forecast_days=2`;
    const data = await _fetchJson(url);
    if (!data || !data.daily || !Array.isArray(data.daily.time) || data.daily.time.length < 2) {
        return null;
    }

    // Index 1 is tomorrow
    const d = data.daily;
    const result = {
        date: d.time[1],
        tempMean: Number.isFinite(d.temperature_2m_mean?.[1]) ? d.temperature_2m_mean[1] : null,
        humidity: Number.isFinite(d.relative_humidity_2m_mean?.[1]) ? d.relative_humidity_2m_mean[1] : null,
        precipitation: Number.isFinite(d.precipitation_sum?.[1]) ? d.precipitation_sum[1] : null,
        tempMax: Number.isFinite(d.temperature_2m_max?.[1]) ? d.temperature_2m_max[1] : null,
        tempMin: Number.isFinite(d.temperature_2m_min?.[1]) ? d.temperature_2m_min[1] : null
    };
    
    if (result.tempMean === null || result.humidity === null) {
        return null;
    }

    _cacheSet(key, result);
    return result;
}

/* ===== PAST DAYS (for Yesterday) ===== */
async function getPastDays(lat, lng, daysBack) {
    daysBack = daysBack || 3;
    const key = `past_${Number(lat).toFixed(2)}_${Number(lng).toFixed(2)}_${daysBack}`;
    const cached = _cacheGet(key);
    if (cached) return cached;

    const url = `${FORECAST_URL}?latitude=${lat}&longitude=${lng}` +
        `&daily=temperature_2m_max,temperature_2m_min,temperature_2m_mean,relative_humidity_2m_mean,precipitation_sum` +
        `&timezone=Asia%2FDhaka&past_days=${daysBack}&forecast_days=1`;
    const data = await _fetchJson(url);
    if (!data || !data.daily || !Array.isArray(data.daily.time)) return null;

    const d = data.daily;
    const days = d.time.map((date, i) => ({
        date,
        tempMax: Number.isFinite(d.temperature_2m_max?.[i]) ? d.temperature_2m_max[i] : null,
        tempMin: Number.isFinite(d.temperature_2m_min?.[i]) ? d.temperature_2m_min[i] : null,
        tempMean: Number.isFinite(d.temperature_2m_mean?.[i]) ? d.temperature_2m_mean[i] : null,
        humidity: Number.isFinite(d.relative_humidity_2m_mean?.[i]) ? d.relative_humidity_2m_mean[i] : null,
        precipitation: Number.isFinite(d.precipitation_sum?.[i]) ? d.precipitation_sum[i] : null
    }));

    _cacheSet(key, days);
    return days;
}

/* ===== RAINFALL CUMULATIVE ===== */
async function getRainfallCumulative(lat, lng, hours) {
    hours = Math.max(24, Math.min(hours || 72, 168));
    const key = `rain_${Number(lat).toFixed(2)}_${Number(lng).toFixed(2)}_${hours}`;
    const cached = _cacheGet(key);
    if (cached) return cached;

    const forecastDays = Math.ceil(hours / 24);
    const url = `${FORECAST_URL}?latitude=${lat}&longitude=${lng}` +
        `&hourly=precipitation&forecast_days=${forecastDays}&timezone=Asia%2FDhaka`;
    const data = await _fetchJson(url);
    if (!data || !data.hourly || !Array.isArray(data.hourly.precipitation)) return null;

    const precip = data.hourly.precipitation.map(v => Number(v) || 0);
    const times = data.hourly.time || [];
    const slice = precip.slice(0, hours);
    const rain48hMm = slice.slice(0, 48).reduce((s, v) => s + v, 0);
    const rain72hMm = slice.slice(0, 72).reduce((s, v) => s + v, 0);
    const peakHourlyMm = Math.max(0, ...slice);

    const result = {
        rain48hMm: Math.round(rain48hMm * 10) / 10,
        rain72hMm: Math.round(rain72hMm * 10) / 10,
        peakHourlyMm: Math.round(peakHourlyMm * 10) / 10,
        hourly: slice.map((mm, i) => ({ mm, time: times[i] || null })),
        source: 'Open-Meteo (GFS/IFS)'
    };
    _cacheSet(key, result);
    return result;
}

/* ===== CLASSIFIERS ===== */
function classifyAQI(aqi) {
    if (!Number.isFinite(aqi)) return { label: 'Unknown', color: '#94a3b8', icon: '⚪', advice: 'Air quality data unavailable.' };
    if (aqi <= 50) return { label: 'Good', color: '#059669', icon: '🟢', advice: 'Air is healthy for livestock and poultry.' };
    if (aqi <= 100) return { label: 'Moderate', color: '#d97706', icon: '🟡', advice: 'Acceptable — control dust for sensitive animals.' };
    if (aqi <= 150) return { label: 'Unhealthy for Sensitive', color: '#ea580c', icon: '🟠', advice: 'Keep calves and broilers indoors with ventilation.' };
    if (aqi <= 200) return { label: 'Unhealthy', color: '#dc2626', icon: '🔴', advice: 'Keep all animals inside sheds. Run exhaust fans.' };
    if (aqi <= 300) return { label: 'Very Unhealthy', color: '#991b1b', icon: '🟣', advice: 'Toxic smog — close windows, run filtration if available.' };
    return { label: 'Hazardous', color: '#7f1d1d', icon: '☠️', advice: 'Emergency — activate filtration and consult a vet.' };
}

function classifyUV(uv) {
    if (!Number.isFinite(uv)) return { label: 'Unknown', color: '#94a3b8', icon: '⚪', advice: 'UV data unavailable.' };
    if (uv < 3) return { label: 'Low', color: '#059669', icon: '🟢', advice: 'No special protection needed.' };
    if (uv < 6) return { label: 'Moderate', color: '#d97706', icon: '🟡', advice: 'Provide shade during midday.' };
    if (uv < 8) return { label: 'High', color: '#ea580c', icon: '🟠', advice: 'Shade + extra water 11 AM–3 PM.' };
    if (uv < 11) return { label: 'Very High', color: '#dc2626', icon: '🔴', advice: 'Full precaution — keep animals under shade nets.' };
    return { label: 'Extreme', color: '#7f1d1d', icon: '☠️', advice: 'Emergency measures — indoor only, roof sprinklers.' };
}

window.OpenMeteo = {
    getAQI,
    getWeek,
    getTomorrow,
    getPastDays,
    getRainfallCumulative,
    classifyAQI,
    classifyUV
};

console.log('✅ OpenMeteo v2.2 loaded (AQI + UV + Past + Tomorrow + rainfall + week forecast)');
})();