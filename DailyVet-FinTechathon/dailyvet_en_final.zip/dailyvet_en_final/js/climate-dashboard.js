/* DailyVet - NASA Climate Dashboard v5.1 (Segment 4 Fix)
   - GPS uses shared DVGpsAnimator
   - Uses centralized DVSpecies
   - Farm Risk Score widget injected into dashboard
   - Predictive THI trend alert (3-day warning)
   - SEGMENT 4 FIX: window.DVClimate guarded with _fromFeature check
     so climate-feature.js (loaded on thi/forage/outbreak/impact pages)
     does not get overwritten when both scripts load in the same page.
   - All Bengali strings removed (English only).
*/
(function () {
'use strict';

const DISTRICT_COORDS = {
    dhaka:      { lat: 23.8103, lng: 90.4125, name: 'Dhaka', nameBn: 'Dhaka' },
    chittagong: { lat: 22.3569, lng: 91.7832, name: 'Chittagong', nameBn: 'Chittagong' },
    rajshahi:   { lat: 24.3745, lng: 88.6042, name: 'Rajshahi', nameBn: 'Rajshahi' },
    khulna:     { lat: 22.8456, lng: 89.5403, name: 'Khulna', nameBn: 'Khulna' },
    barisal:    { lat: 22.7010, lng: 90.3535, name: 'Barisal', nameBn: 'Barisal' },
    sylhet:     { lat: 24.8949, lng: 91.8687, name: 'Sylhet', nameBn: 'Sylhet' },
    rangpur:    { lat: 25.7439, lng: 89.2752, name: 'Rangpur', nameBn: 'Rangpur' },
    mymensingh: { lat: 24.7471, lng: 90.4203, name: 'Mymensingh', nameBn: 'Mymensingh' }
};

const SECTION_IDS = ['thiBody', 'forageBody', 'outbreakBody', 'impactBody'];
const ALERT_DELAY_MS = 2000;

const RISK_STYLE = {
    critical: { color: '#dc2626', bg: '#fef2f2', icon: '!' },
    alert:    { color: '#c2410c', bg: '#fff7ed', icon: '!' },
    watch:    { color: '#92400e', bg: '#fef9e7', icon: '~' },
    safe:     { color: '#047857', bg: '#ecfdf5', icon: 'OK' }
};

const VECTOR_ICON = { mosquito: 'M', fly: 'F', water: 'W', air: 'A', contact: 'C', environment: 'E' };

let currentDistrict = 'dhaka';
const SPECIES_IDS = ['cow', 'buffalo', 'goat', 'sheep', 'chicken', 'duck', 'dog', 'cat'];
const SPECIES_KEY = 'dvClimateSpecies';

let currentSpecies = (() => {
    if (window.DVSpecies && typeof DVSpecies.get === 'function') {
        return DVSpecies.get();
    }
    try {
        const v = localStorage.getItem(SPECIES_KEY);
        return SPECIES_IDS.includes(v) ? v : 'cow';
    } catch (_) { return 'cow'; }
})();

let lastParameter = null;
let loadToken = 0;
let alertTimer = null;

const _el = id => document.getElementById(id);
const _ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const escapeHtml = text => String(text == null ? '' : text).replace(/[&<>"']/g, c => _ESC[c]);

function formatDate(yyyymmdd) {
    if (!yyyymmdd || yyyymmdd.length !== 8) return '';
    const date = new Date(Date.UTC(Number(yyyymmdd.slice(0, 4)), Number(yyyymmdd.slice(4, 6)) - 1, Number(yyyymmdd.slice(6, 8))));
    if (isNaN(date.getTime())) return '';
    return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', timeZone: 'UTC' });
}

function fmtFull(v) {
    if (typeof v === 'number' && Number.isFinite(v)) return v.toLocaleString('en-IN');
    return v == null ? '-' : String(v);
}

function injectExtraStyles() {
    if (document.getElementById('dv-nasa-extra-css')) return;
    const st = document.createElement('style');
    st.id = 'dv-nasa-extra-css';
    st.textContent = `
        .dv-note{font-size:11.5px;opacity:.75;margin:6px 2px 0;line-height:1.45}
        .dv-src{display:flex;flex-wrap:wrap;gap:6px 10px;align-items:center;margin-top:12px;padding-top:8px;border-top:1px dashed rgba(100,116,139,.35);font-size:11px;opacity:.8}
        .dv-src.stale{color:#b45309;opacity:1}
        .dv-region{margin:10px 0;padding:9px 12px;border-radius:10px;font-size:13px;line-height:1.5;background:rgba(37,99,235,.08);border-left:3px solid #2563eb}
        .dv-region.drought{background:rgba(217,119,6,.10);border-left-color:#d97706}
        .dv-soil-extra{display:flex;flex-wrap:wrap;gap:6px 14px;margin-top:6px;font-size:12.5px}
        .dv-push{margin-top:12px;display:flex;align-items:center;gap:10px;flex-wrap:wrap;font-size:12.5px}
        .dv-push button{border:0;border-radius:999px;padding:7px 14px;font-weight:600;cursor:pointer;background:#0f766e;color:#fff;font-size:12.5px}
        .dvfr-slot{margin:1rem 0;}
    `;
    document.head.appendChild(st);
}

const _POWER_LABEL = { live: 'live', 'firestore-cache': 'cached (up to 24h)', 'stale-cache': 'saved old data' };

function appendDataBadge(elementId, parameter, text) {
    const el = _el(elementId);
    if (!el || el.querySelector('.climate-empty')) return;
    const src = NasaPower.getSource(parameter);
    const latest = NasaPower.getLatest(parameter, 'T2M');
    const date = latest ? formatDate(latest.date) : '';
    const age = latest ? NasaPower.ageDays(latest.date) : null;
    const stale = src === 'stale-cache';
    el.insertAdjacentHTML('beforeend', `<div class="dv-src${stale ? ' stale' : ''}"><span>${escapeHtml(text)}</span>${date ? `<span>Date: ${escapeHtml(date)}${age !== null ? ` (${age} days ago)` : ''}</span>` : ''}<span>${stale ? 'Warning: ' : ''}${escapeHtml(_POWER_LABEL[src] || src)}</span></div>`);
}

function renderPushControl(body) {
    if (!body || !window.DVNotifications || typeof DVNotifications.pushPermission !== 'function') return;
    const perm = DVNotifications.pushPermission();
    if (perm === 'unsupported') return;
    let host = body.querySelector('.dv-push');
    if (!host) { host = document.createElement('div'); host.className = 'dv-push'; body.appendChild(host); }
    if (perm === 'granted') host.innerHTML = '<span>Push alerts are enabled</span>';
    else if (perm === 'denied') host.innerHTML = '<span>Push is blocked - allow permission from browser settings</span>';
    else {
        host.innerHTML = '<button type="button">Enable Push Alerts</button><span>Receive English notifications on your phone when risk rises</span>';
        host.querySelector('button').addEventListener('click', async () => {
            await DVNotifications.requestPushPermission();
            renderPushControl(body);
        });
    }
}

function showLoading(elementId) {
    const el = _el(elementId);
    if (!el) return;
    el.innerHTML = `
        <div class="dvsk-module">
            <div class="dvsk-head"><div class="dvsk-icon dvsk"></div><div class="dvsk-tag dvsk"></div></div>
            <div class="dvsk-line-lg dvsk"></div>
            <div class="dvsk-line dvsk"></div>
            <div class="dvsk-line-sm dvsk"></div>
            <div class="dvsk-panel-body" style="margin-top: 1rem;">
                <div class="dvsk-tile dvsk"></div><div class="dvsk-tile dvsk"></div><div class="dvsk-tile dvsk"></div>
            </div>
        </div>`;
}

function showError(elementId, message) {
    const el = _el(elementId);
    if (!el) return;
    el.innerHTML = `<div class="climate-empty"><i class="fas fa-exclamation-triangle" style="color:#dc2626;"></i><span>${escapeHtml(message)}</span></div>`;
}

function safeRender(elementId, fn) {
    try { fn(); }
    catch (err) { console.error(`[Climate] ${elementId} render failed:`, err); showError(elementId, 'Failed to load NASA data'); }
}

/* ============================================================
   FARM RISK SCORE WIDGET
   ============================================================ */
async function renderFarmRiskWidget() {
    let slot = _el('dvFarmRiskSlot');
    if (!slot) {
        const container = document.querySelector('.climate-feature-container') || document.querySelector('.cl-wrapper');
        if (!container) return;
        slot = document.createElement('div');
        slot.id = 'dvFarmRiskSlot';
        slot.className = 'dvfr-slot';
        const firstSection = container.querySelector('.climate-section, section');
        if (firstSection && firstSection.parentNode) {
            firstSection.parentNode.insertBefore(slot, firstSection);
        } else {
            container.appendChild(slot);
        }
    }

    if (!window.DVFarmRisk || typeof DVFarmRisk.computeFarmRiskScore !== 'function') {
        slot.innerHTML = '';
        return;
    }

    slot.innerHTML = `
        <div style="padding:1rem;background:#F8FAFC;border:1.5px solid #E2E8F0;border-radius:16px;text-align:center;font-size:12.5px;color:#64748B;">
            <i class="fas fa-spinner fa-spin"></i> Computing combined farm risk...
        </div>`;

    try {
        const result = await DVFarmRisk.computeFarmRiskScore(currentDistrict);
        if (!result) {
            slot.innerHTML = '';
            return;
        }
        DVFarmRisk.renderFarmRiskCard(result, slot);
    } catch (err) {
        console.warn('[Climate] Farm risk widget failed:', err);
        slot.innerHTML = '';
    }
}

/* ============================================================
   PREDICTIVE THI TREND
   ============================================================ */
function renderThiTrendAlert(parameter) {
    if (!window.NasaClimate || typeof NasaClimate.predictTHITrend !== 'function') return;
    const container = document.querySelector('.climate-feature-container') || document.querySelector('.cl-wrapper');
    if (!container) return;

    let host = _el('dvThiTrendAlert');
    if (!host) {
        host = document.createElement('div');
        host.id = 'dvThiTrendAlert';
        host.style.margin = '1rem 0';
        const farmSlot = _el('dvFarmRiskSlot');
        if (farmSlot && farmSlot.parentNode) {
            farmSlot.parentNode.insertBefore(host, farmSlot.nextSibling);
        } else {
            container.insertBefore(host, container.firstChild);
        }
    }

    const tempSeries = NasaPower.getSeries(parameter, 'T2M');
    const rhSeries = NasaPower.getSeries(parameter, 'RH2M');
    const rhMap = {};
    rhSeries.forEach(r => { rhMap[r.date] = r.value; });

    const last7 = tempSeries.slice(-7).map(d => ({
        date: d.date,
        thi: NasaClimate.calculateTHI(d.value, rhMap[d.date] !== undefined ? rhMap[d.date] : (rhSeries.length ? rhSeries[rhSeries.length - 1].value : 70))
    })).filter(x => x.thi !== null);

    const trend = NasaClimate.predictTHITrend(last7, currentSpecies);
    if (!trend || !trend.alert) {
        host.innerHTML = '';
        return;
    }

    const color = trend.riskTomorrow === 'severe' ? '#dc2626'
                : trend.riskTomorrow === 'moderate' ? '#c2410c'
                : trend.riskTomorrow === 'mild' ? '#d97706'
                : '#059669';
    const bg = trend.riskTomorrow === 'severe' ? '#fef2f2'
             : trend.riskTomorrow === 'moderate' ? '#fff7ed'
             : trend.riskTomorrow === 'mild' ? '#fef9e7'
             : '#ecfdf5';

    host.innerHTML = `
        <div style="padding:12px 16px;border-radius:14px;background:${bg};border-left:4px solid ${color};display:flex;align-items:flex-start;gap:12px;">
            <div style="font-size:1.25rem;">${trend.riskTomorrow === 'severe' ? 'ALERT' : trend.riskTomorrow === 'moderate' ? 'WARN' : 'INFO'}</div>
            <div style="flex:1;min-width:0;">
                <div style="font-size:12.5px;font-weight:800;color:${color};text-transform:uppercase;letter-spacing:0.04em;">Predictive THI Alert</div>
                <div style="font-size:13px;color:#334155;margin-top:3px;line-height:1.55;">${escapeHtml(trend.alert)}</div>
                <div style="font-size:11px;color:#64748B;margin-top:4px;">Trend: <b>${escapeHtml(trend.trend)}</b> - Tomorrow: ${trend.tomorrowPrediction != null ? trend.tomorrowPrediction.toFixed(1) + ' THI' : '-'}</div>
            </div>
        </div>`;
}

/* ============================================================
   EXISTING RENDERERS
   ============================================================ */
function renderTHI(parameter) {
    const body = _el('thiBody');
    if (!body) return;
    const tempLatest = NasaPower.getLatest(parameter, 'T2M');
    const rhLatest = NasaPower.getLatest(parameter, 'RH2M');
    if (!tempLatest || !rhLatest) { showError('thiBody', 'THI data not available'); return; }
    const thi = NasaClimate.calculateTHI(tempLatest.value, rhLatest.value);
    if (thi === null) { showError('thiBody', 'THI data not available'); return; }

    const tempSeries = NasaPower.getSeries(parameter, 'T2M');
    const rhSeries = NasaPower.getSeries(parameter, 'RH2M');
    const rhMap = {};
    rhSeries.forEach(r => { rhMap[r.date] = r.value; });

    let yesterday = null, tomorrow = null;
    if (tempSeries.length >= 2) {
        const prev = tempSeries[tempSeries.length - 2];
        const prevRh = rhMap[prev.date] !== undefined ? rhMap[prev.date] : rhLatest.value;
        yesterday = NasaClimate.calculateTHI(prev.value, prevRh);
    }
    if (tempSeries.length >= 3) {
        const recent = tempSeries.slice(-3);
        const avgTemp = recent.reduce((s, d) => s + d.value, 0) / recent.length;
        const avgRh = recent.reduce((s, d) => s + (rhMap[d.date] !== undefined ? rhMap[d.date] : rhLatest.value), 0) / recent.length;
        tomorrow = NasaClimate.calculateTHI(avgTemp, avgRh);
    }

    const comparison = NasaClimate.generateTHIComparison(thi, yesterday, tomorrow, currentSpecies, 'en');
    const last7 = tempSeries.slice(-7);
    const bars = last7.map(d => {
        const dayRh = rhMap[d.date] !== undefined ? rhMap[d.date] : rhLatest.value;
        const dayThi = NasaClimate.calculateTHI(d.value, dayRh);
        if (dayThi === null) return '';
        const pct = Math.min(100, Math.max(10, (dayThi - 50) * 2));
        const dayCls = NasaClimate.classifyTHI(dayThi, currentSpecies);
        const label = formatDate(d.date);
        return `<div class="thi-bar-wrap" title="${escapeHtml(label)}: THI ${dayThi.toFixed(1)}"><div class="thi-bar" style="height:${pct}%;background:${dayCls.color};"></div><div class="thi-bar-label">${escapeHtml(label.split(' ')[0])}</div></div>`;
    }).join('');

    const speciesList = [
        { id: 'cow', label: 'Cow' }, { id: 'buffalo', label: 'Buffalo' },
        { id: 'goat', label: 'Goat' }, { id: 'sheep', label: 'Sheep' },
        { id: 'chicken', label: 'Chicken' }, { id: 'duck', label: 'Duck' },
        { id: 'dog', label: 'Dog' }, { id: 'cat', label: 'Cat' }
    ];
    const speciesOptions = speciesList.map(s => `<option value="${s.id}" ${s.id === currentSpecies ? 'selected' : ''}>${s.label}</option>`).join('');

    body.innerHTML = `
        <div class="thi-widget">
            <div class="thi-species-selector"><label for="thiSpecies">Select Animal:</label><select id="thiSpecies">${speciesOptions}</select></div>
            <div class="thi-comparison-headline" style="background:${comparison.bg};border-left:4px solid ${comparison.color};">
                <div class="thi-headline-text" style="color:${comparison.color};">${escapeHtml(comparison.headlineBn)}</div>
                ${comparison.deltaText ? `<div class="thi-delta-text" style="color:${comparison.color};opacity:0.85;">${escapeHtml(comparison.trend)} ${escapeHtml(comparison.deltaText)}</div>` : ''}
            </div>
            <div class="thi-comparison-grid">
                ${comparison.yesterdayText ? `<div class="thi-compare-card"><div class="thi-compare-label">Yesterday</div><div class="thi-compare-value" style="opacity:0.6;">${comparison.yesterday}</div><div class="thi-compare-level" style="opacity:0.6;">THI</div></div><div class="thi-compare-arrow">to</div>` : ''}
                <div class="thi-compare-card highlight" style="border-color:${comparison.color};"><div class="thi-compare-label">Latest</div><div class="thi-compare-value" style="color:${comparison.color};">${comparison.current}</div><div class="thi-compare-level" style="color:${comparison.color};">THI</div></div>
                ${comparison.tomorrowText ? `<div class="thi-compare-arrow">to</div><div class="thi-compare-card"><div class="thi-compare-label">Tomorrow*</div><div class="thi-compare-value" style="opacity:0.6;">${comparison.tomorrow}</div><div class="thi-compare-level" style="opacity:0.6;">THI</div></div>` : ''}
            </div>
            ${comparison.tomorrowText ? `<div class="dv-note">* Tomorrow's value is estimated from the last 3 days of NASA POWER (POWER itself does not issue forecasts).</div>` : ''}
            <div class="thi-widget-meta"><span>Temp ${tempLatest.value.toFixed(1)} C</span><span>RH ${rhLatest.value.toFixed(0)}%</span><span>Date ${escapeHtml(formatDate(tempLatest.date))}</span></div>
            <div class="thi-action-box" style="background:${comparison.bg};border-left:3px solid ${comparison.color};"><i class="fas fa-bolt" style="color:${comparison.color};"></i><span style="color:${comparison.color};">${escapeHtml(comparison.actionBn)}</span></div>
            ${last7.length > 1 ? `<div class="thi-widget-chart-title">Last 7 Days THI</div><div class="thi-mini-chart">${bars}</div>` : ''}
        </div>`;
}

function renderForage(parameter) {
    const body = _el('forageBody');
    if (!body) return;
    const soilLatest = NasaPower.getLatest(parameter, 'GWETTOP');
    if (!soilLatest) { showError('forageBody', 'Soil moisture data not available'); return; }
    const soilCls = NasaClimate.classifySoilMoisture(soilLatest.value);
    const currentMonth = new Date().getMonth() + 1;
    const recommendation = NasaClimate.recommendForageDetailed(soilCls.level, currentMonth, soilLatest.value, currentDistrict);
    const rootLatest = NasaPower.getLatest(parameter, 'GWETROOT');
    const soilTrend = NasaClimate.classifySoilTrend(NasaPower.getSeries(parameter, 'GWETTOP'));
    const region = recommendation.region;
    const allOptions = NasaClimate.compareForageOptions(soilCls.level);

    body.innerHTML = `
        <div class="forage-card">
            <div class="forage-soil-status" style="background:${soilCls.color}15;border-left:3px solid ${soilCls.color};">
                <div class="forage-soil-label"><i class="fas fa-water"></i> Soil Moisture</div>
                <div class="forage-soil-value" style="color:${soilCls.color};">${(soilLatest.value * 100).toFixed(0)}%<small>${escapeHtml(soilCls.labelBn)}</small></div>
                <div class="forage-soil-advice" style="color:${soilCls.color};">${escapeHtml(soilCls.adviceBn)}</div>
            </div>
            <div class="dv-soil-extra">
                ${rootLatest ? `<span>Root zone moisture: <strong>${(rootLatest.value * 100).toFixed(0)}%</strong></span>` : ''}
                ${soilTrend.trendBn ? `<span>${escapeHtml(soilTrend.trendBn)}</span>` : ''}
            </div>
            ${region ? `<div class="dv-region ${escapeHtml(region.type)}"><strong>${region.type === 'drought' ? 'Drought' : 'Flood'} - ${escapeHtml(region.regionBn)}</strong><br>${escapeHtml(region.noteBn)}</div>` : ''}
            <div class="forage-recommend-title">Plant Now</div>
            <div class="forage-detailed-grid">
                ${recommendation.recommended.map((g, i) => `
                    <div class="forage-detail-card">
                        <div class="forage-detail-rank">#${i + 1}</div>
                        <div class="forage-detail-emoji">${g.emoji}</div>
                        <div class="forage-detail-name">${escapeHtml(g.name)}</div>
                        <div class="forage-detail-sub">${escapeHtml(g.en)}</div>
                        <div class="forage-detail-why">${escapeHtml(g.why)}</div>
                        <div class="forage-detail-stats"><span>Water: ${escapeHtml(g.waterNeed)}</span><span>Harvest: ${g.harvestDays} days</span><span>Yield: ${escapeHtml(g.yieldPerHectare)}</span></div>
                        <div class="forage-detail-reason">${escapeHtml(g.reason)}</div>
                    </div>`).join('')}
            </div>
            ${recommendation.avoid.length > 0 ? `<div class="forage-avoid-section"><div class="forage-avoid-title">Do Not Plant Now</div>${recommendation.avoid.map(a => `<div class="forage-avoid-item"><strong>${escapeHtml(a.name)}</strong><span>${escapeHtml(a.reason)}</span></div>`).join('')}</div>` : ''}
            <div class="forage-calendar-section">
                <div class="forage-calendar-title">Next 3 Months Calendar</div>
                <div class="forage-calendar-grid">${recommendation.calendar.map(c => `<div class="forage-calendar-item"><div class="forage-calendar-month">${escapeHtml(c.month)}</div><div class="forage-calendar-grass">${escapeHtml(c.grass)}</div></div>`).join('')}</div>
            </div>
            <div class="forage-irrigation-section">
                <div class="forage-irrigation-title">Irrigation Advice</div>
                <div class="forage-irrigation-grid">
                    <div class="forage-irrigation-item"><span class="label">Frequency</span><span class="value">${escapeHtml(recommendation.irrigation.frequency)}</span></div>
                    <div class="forage-irrigation-item"><span class="label">Timing</span><span class="value">${escapeHtml(recommendation.irrigation.timing)}</span></div>
                    <div class="forage-irrigation-item"><span class="label">Amount</span><span class="value">${escapeHtml(recommendation.irrigation.amountPerHectare)}/hectare</span></div>
                    <div class="forage-irrigation-item highlight"><span class="label">With mulching</span><span class="value">${escapeHtml(recommendation.irrigation.mulchingBenefit)}</span></div>
                </div>
            </div>
            <details class="forage-all-options">
                <summary>Compare All Grasses</summary>
                <div class="forage-all-list">${allOptions.map(g => `<div class="forage-all-item ${g.isRecommended ? 'recommended' : ''}"><span class="forage-all-emoji">${g.emoji}</span><span class="forage-all-name">${escapeHtml(g.name)}</span><span class="forage-all-verdict">${escapeHtml(g.verdictBn)}</span></div>`).join('')}</div>
            </details>
        </div>`;
}

function renderOutbreak(parameter, sedac) {
    const body = _el('outbreakBody');
    if (!body) return;
    const rainLatest = NasaPower.getLatest(parameter, 'PRECTOTCORR');
    const tempLatest = NasaPower.getLatest(parameter, 'T2M');
    const rhLatest = NasaPower.getLatest(parameter, 'RH2M');
    if (!rainLatest || !tempLatest || !rhLatest) { showError('outbreakBody', 'Weather data not available'); return; }

    const rainMm = rainLatest.value, temp = tempLatest.value, humidity = rhLatest.value;
    const districtBn = DISTRICT_COORDS[currentDistrict].nameBn;
    const riskLevel = NasaOutbreak.calculateRainfallRiskDetailed(rainMm, humidity, temp);
    const diseases = NasaOutbreak.calculateDiseaseRisks({ rainMm, humidity, temp, district: currentDistrict });
    const alert = NasaOutbreak.generateAlertBanner(districtBn, riskLevel, diseases, rainMm);
    const vector = NasaOutbreak.getVectorActivity(riskLevel.level);
    const livestockCounts = NasaOutbreak.livestockFromSedac(sedac);
    const economicImpact = livestockCounts ? NasaOutbreak.estimateEconomicImpact(diseases, livestockCounts) : { total: 0, currency: 'BDT', breakdown: [] };

    window.__lastOutbreakRisk = {
        district: currentDistrict, districtBn, districtEn: (DISTRICT_COORDS[currentDistrict] || {}).name || currentDistrict,
        dataDate: rainLatest.date,
        stale: NasaPower.getSource(parameter) === 'stale-cache',
        level: riskLevel.level, score: riskLevel.score,
        diseases: diseases.map(d => ({ key: d.key, nameEn: d.nameEn, nameBn: d.nameBn, score: d.score })),
        rainMm, humidity, temp, economicImpact, timestamp: Date.now()
    };

    body.innerHTML = `
        <div class="outbreak-card">
            <div class="outbreak-weather-grid">
                <div class="outbreak-weather-item"><i class="fas fa-cloud-rain"></i><div class="outbreak-weather-value">${rainMm.toFixed(1)}</div><div class="outbreak-weather-label">mm (latest day)</div></div>
                <div class="outbreak-weather-item"><i class="fas fa-temperature-half"></i><div class="outbreak-weather-value">${temp.toFixed(1)} C</div><div class="outbreak-weather-label">Temp</div></div>
                <div class="outbreak-weather-item"><i class="fas fa-droplet"></i><div class="outbreak-weather-value">${humidity.toFixed(0)}%</div><div class="outbreak-weather-label">Humidity</div></div>
            </div>
            <div class="outbreak-vector"><div class="outbreak-vector-label"><i class="fas fa-mosquito"></i><span>Vector Activity</span></div><div class="outbreak-vector-value" style="color:${riskLevel.color};">${vector.icon} ${escapeHtml(vector.labelBn)}</div></div>
            <div class="outbreak-score"><div class="outbreak-score-label"><span>Risk Score</span><strong style="color:${riskLevel.color};">${riskLevel.score}%</strong></div><div class="outbreak-score-bar"><div class="outbreak-score-fill" style="width:${riskLevel.score}%;background:${riskLevel.color};"></div></div></div>
            <div class="outbreak-breakdown">
                <div class="outbreak-breakdown-title"><i class="fas fa-calculator"></i> Why ${riskLevel.score}%?</div>
                <div class="outbreak-breakdown-list">
                    ${riskLevel.breakdown.map(b => `
                        <div class="outbreak-breakdown-row">
                            <div class="outbreak-breakdown-icon">${b.icon}</div>
                            <div class="outbreak-breakdown-label">${escapeHtml(b.label)} <span class="outbreak-breakdown-value">${escapeHtml(b.value)}</span></div>
                            <div class="outbreak-breakdown-bar-wrap"><div class="outbreak-breakdown-bar" style="width:${(b.score / b.max) * 100}%;background:${riskLevel.color};"></div></div>
                            <div class="outbreak-breakdown-score" style="color:${riskLevel.color};">+${b.score}</div>
                        </div>
                        <div class="outbreak-breakdown-reason">${escapeHtml(b.reasonBn)}</div>`).join('')}
                </div>
                <div class="outbreak-breakdown-total"><span>Total score:</span><strong style="color:${riskLevel.color};">${riskLevel.totalRawScore}/100 ${riskLevel.capped ? ' (capped at 100)' : ''}</strong></div>
            </div>
            <div class="outbreak-banner ${escapeHtml(alert.type)}" style="background:${riskLevel.bg};border-color:${riskLevel.border};">
                <div class="outbreak-banner-icon">${alert.icon}</div>
                <div class="outbreak-banner-text"><strong style="color:${riskLevel.color};">${escapeHtml(alert.titleBn)}</strong><p style="color:${riskLevel.color};">${escapeHtml(alert.messageBn)}</p></div>
            </div>
            ${diseases.length > 0 ? `
                <div class="outbreak-diseases">
                    <div class="outbreak-diseases-title"><i class="fas fa-virus"></i> Watch out for these diseases</div>
                    ${diseases.map(d => `
                        <div class="outbreak-disease-item">
                            <div class="outbreak-disease-icon">${VECTOR_ICON[d.vector] || 'E'}</div>
                            <div class="outbreak-disease-info"><div class="outbreak-disease-name">${escapeHtml(d.nameBn)}</div><div class="outbreak-disease-vector">${escapeHtml(d.vectorBn)} - Score ${d.score}%</div></div>
                            <div class="outbreak-disease-score" style="color:${d.score >= 70 ? '#dc2626' : d.score >= 50 ? '#c2410c' : '#92400e'};">${d.score}%</div>
                        </div>`).join('')}
                </div>` : ''}
            ${economicImpact.total > 0 ? `
                <div class="outbreak-economic">
                    <div class="outbreak-economic-title"><i class="fas fa-coins"></i> Potential Economic Loss</div>
                    <div class="outbreak-economic-value">BDT ${(economicImpact.total / 10000000).toFixed(2)} Crore</div>
                    ${economicImpact.overlap ? `<div class="dv-note">The same animal may be counted in multiple diseases - so this is a maximum limit. Assumption: 10% of at-risk animals affected.</div>` : ''}
                    <div class="outbreak-economic-breakdown">${economicImpact.breakdown.map(b => `<div class="outbreak-economic-item"><span>${escapeHtml(b.disease)}</span><span>${b.affectedHeads.toLocaleString()} animals - BDT ${b.lossCrore} Crore</span></div>`).join('')}</div>
                </div>` : ''}
            <div class="outbreak-prevention">
                <div class="outbreak-prevention-title"><i class="fas fa-shield-halved"></i> Preventive Measures</div>
                <ul class="outbreak-prevention-list"><li>Keep animals under mosquito nets</li><li>Clear standing water and mud</li><li>Keep cattle sheds dry and clean</li><li>Vaccinate as advised by a vet</li></ul>
            </div>
        </div>`;
}

async function renderImpact(riskContext, token, preloaded) {
    const body = _el('impactBody');
    if (!body) return;
    try {
        const sedac = preloaded || await NasaSedac.fetchSedacData(currentDistrict);
        if (token !== loadToken) return;
        if (!sedac) {
            body.innerHTML = `<div class="climate-empty"><i class="fas fa-map-location-dot"></i><span>SEDAC data not available for ${escapeHtml(currentDistrict)}</span></div>`;
            return;
        }
        const impact = NasaSedac.calculateImpactDetailed(sedac, riskContext);
        window.__lastImpact = { populationAtRisk: impact.populationAtRisk, farmersAtRisk: impact.farmersAtRisk, livestockAtRisk: impact.livestockAtRisk, economicLoss: impact.economicLoss, breakdown: impact.breakdown };
        if (window.__lastOutbreakRisk) window.__lastOutbreakRisk.impact = window.__lastImpact;
        const summary = NasaSedac.generateImpactSummary(impact);
        const style = RISK_STYLE[impact.riskLevel] || RISK_STYLE.safe;
        const fmt = NasaSedac.formatNumber;

        body.innerHTML = `
            <div class="sedac-card">
                <div class="sedac-district">
                    <div class="sedac-district-icon"><i class="fas fa-map-marker-alt"></i></div>
                    <div class="sedac-district-info"><div class="sedac-district-name">${escapeHtml(sedac.nameBn || sedac.name)} - ${escapeHtml(sedac.name)}</div><div class="sedac-district-sub">NASA SEDAC - GPW v4 Population Data</div></div>
                </div>
                <div class="sedac-summary" style="background:${style.bg};border-color:${style.color};">
                    <div class="sedac-summary-icon" style="color:${style.color};">${style.icon}</div>
                    <div class="sedac-summary-text" style="color:${style.color};">${escapeHtml(summary)}</div>
                </div>
                <div class="sedac-calc-steps">
                    <div class="sedac-calc-title"><i class="fas fa-list-ol"></i> How the calculation was done</div>
                    ${impact.calculationSteps.map((step, i) => `
                        <div class="sedac-calc-row">
                            <div class="sedac-calc-num">${i + 1}</div>
                            <div class="sedac-calc-content"><div class="sedac-calc-label">${escapeHtml(step.step)}</div><div class="sedac-calc-value">${escapeHtml(fmtFull(step.value))}${step.formula ? `<span class="sedac-calc-formula">${escapeHtml(step.formula)}</span>` : ''}</div></div>
                        </div>`).join('')}
                </div>
                <div class="sedac-stats-grid">
                    <div class="sedac-stat"><div class="sedac-stat-icon">People</div><div class="sedac-stat-value">${fmt(impact.populationAtRisk)}</div><div class="sedac-stat-label">People at risk</div></div>
                    <div class="sedac-stat"><div class="sedac-stat-icon">Farmers</div><div class="sedac-stat-value">${fmt(impact.farmersAtRisk)}</div><div class="sedac-stat-label">Marginal farmers</div></div>
                    <div class="sedac-stat"><div class="sedac-stat-icon">Cattle</div><div class="sedac-stat-value">${fmt(impact.breakdown.cattle)}</div><div class="sedac-stat-label">Cattle</div></div>
                    <div class="sedac-stat"><div class="sedac-stat-icon">Goats</div><div class="sedac-stat-value">${fmt(impact.breakdown.goat)}</div><div class="sedac-stat-label">Goats</div></div>
                </div>
                <div class="sedac-total"><div class="sedac-total-label">Total livestock at risk</div><div class="sedac-total-value" style="color:${style.color};">${fmt(impact.livestockAtRisk)}</div></div>
                <div class="sedac-economic">
                    <div class="sedac-economic-title"><i class="fas fa-coins"></i> Potential Economic Loss</div>
                    <div class="sedac-economic-range">BDT ${impact.economicLoss.minCrore} - ${impact.economicLoss.maxCrore} Crore</div>
                    <div class="dv-note">Assumption: ${(impact.lossRate * 100).toFixed(1)}% of at-risk animals may be affected (per average market value).</div>
                    <div class="sedac-economic-breakdown">
                        <div class="sedac-economic-item"><span>Cattle</span><span>BDT ${(impact.economicLoss.breakdown.cattle / 10000000).toFixed(2)} Crore</span></div>
                        <div class="sedac-economic-item"><span>Goats</span><span>BDT ${(impact.economicLoss.breakdown.goat / 10000000).toFixed(2)} Crore</span></div>
                        <div class="sedac-economic-item"><span>Sheep</span><span>BDT ${(impact.economicLoss.breakdown.sheep / 10000000).toFixed(2)} Crore</span></div>
                        <div class="sedac-economic-item"><span>Poultry</span><span>BDT ${(impact.economicLoss.breakdown.poultry / 10000000).toFixed(2)} Crore</span></div>
                    </div>
                </div>
                <div class="sedac-vulnerability">
                    <div class="sedac-vulnerability-header"><span>Vulnerability Index</span><strong style="color:${style.color};">${impact.vulnerability}%</strong></div>
                    <div class="sedac-vulnerability-bar"><div class="sedac-vulnerability-fill" style="width:${impact.vulnerability}%;background:${style.color};"></div></div>
                </div>
                <div class="sedac-source"><i class="fas fa-database"></i><span>Data: <strong>NASA SEDAC GPW v4</strong> + Bangladesh DLS</span></div>
            </div>`;
    } catch (err) {
        if (token !== loadToken) return;
        console.error('[Climate] SEDAC load failed:', err);
        body.innerHTML = `<div class="climate-empty"><i class="fas fa-exclamation-triangle" style="color:#dc2626;"></i><span>Could not load impact data</span></div>`;
    }
}

/* ============================================================
   LOAD ALL SECTIONS
   ============================================================ */
async function loadAllSections() {
    const coords = DISTRICT_COORDS[currentDistrict];
    if (!coords) return;
    const token = ++loadToken;
    clearTimeout(alertTimer);
    window.__lastOutbreakRisk = null;
    window.__lastImpact = null;
    SECTION_IDS.forEach(showLoading);

    const sedacPromise = Promise.resolve()
        .then(() => NasaSedac.fetchSedacData(currentDistrict))
        .catch(err => { console.warn('[Climate] SEDAC unavailable:', err && err.message); return null; });

    let parameter;
    try { parameter = await NasaPower.getPowerData(coords.lat, coords.lng, 7); }
    catch (err) {
        if (token !== loadToken) return;
        console.error('[Climate] Load failed:', err);
        SECTION_IDS.forEach(id => showError(id, 'Failed to load NASA data'));
        return;
    }
    if (token !== loadToken) return;
    lastParameter = parameter;

    safeRender('thiBody', () => renderTHI(parameter));
    safeRender('forageBody', () => renderForage(parameter));
    appendDataBadge('thiBody', parameter, 'NASA POWER - T2M, RH2M');
    appendDataBadge('forageBody', parameter, 'NASA POWER - GWETTOP, GWETROOT');

    const sedac = await sedacPromise;
    if (token !== loadToken) return;

    safeRender('outbreakBody', () => renderOutbreak(parameter, sedac));
    appendDataBadge('outbreakBody', parameter, 'NASA POWER - PRECTOTCORR, RH2M, T2M');
    renderPushControl(_el('outbreakBody'));

    renderFarmRiskWidget().catch(err => console.warn('[Climate] Farm risk widget:', err));
    renderThiTrendAlert(parameter);

    const riskCtx = window.__lastOutbreakRisk || { level: 'safe', score: 0 };
    await renderImpact(riskCtx, token, sedac);
    if (token !== loadToken) return;

    if (window.__lastOutbreakRisk && typeof window.triggerNasaOutbreakAlert === 'function') {
        alertTimer = setTimeout(() => { if (token === loadToken) window.triggerNasaOutbreakAlert(); }, ALERT_DELAY_MS);
    }
}

/* ============================================================
   SPECIES CHANGE
   ============================================================ */
function onSpeciesChange(id) {
    if (!window.DVSpecies) {
        if (SPECIES_IDS.includes(id)) {
            currentSpecies = id;
            try { localStorage.setItem(SPECIES_KEY, id); } catch (_) {}
        }
    } else {
        currentSpecies = DVSpecies.get();
    }

    if (lastParameter) {
        safeRender('thiBody', () => renderTHI(lastParameter));
        renderThiTrendAlert(lastParameter);
    }
    renderFarmRiskWidget().catch(() => {});
}

document.addEventListener('dv:species-changed', e => {
    const next = e.detail && e.detail.species;
    if (next && next !== currentSpecies) {
        currentSpecies = next;
        onSpeciesChange(next);
    }
});

window.__changeSpecies = function (id) {
    if (window.DVSpecies) return DVSpecies.set(id);
    onSpeciesChange(id);
};

/* ============================================================
   GPS
   ============================================================ */
window.__dvmUseMyLocation = function () {
    if (!window.DVGpsAnimator) {
        alert('GPS animator not loaded. Add js/dv-gps-animator.js before climate-dashboard.js');
        return;
    }
    DVGpsAnimator.locate({
        buttonId: 'dvmGpsBtn',
        accentColor: '#0f766e',
        districtName: 'Division',
        findClosest: (lat, lng) => {
            let closestKey = 'dhaka';
            let minDist = Infinity;
            Object.keys(DISTRICT_COORDS).forEach(k => {
                const c = DISTRICT_COORDS[k];
                const d = Math.hypot(c.lat - lat, c.lng - lng);
                if (d < minDist) { minDist = d; closestKey = k; }
            });
            return { key: closestKey, nameBn: DISTRICT_COORDS[closestKey].nameBn };
        },
        onSuccess: (closest) => {
            currentDistrict = closest.key;
            const sel = _el('climateDistrict');
            if (sel) sel.value = closest.key;
            loadAllSections();
            setTimeout(() => {
                const el = _el('thiBody');
                if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }, 500);
        }
    });
};

function getUserPhone() {
    try { return sessionStorage.getItem('userPhone') || localStorage.getItem('userPhone'); }
    catch (_) { return null; }
}

function init() {
    if (!getUserPhone()) { window.location.replace('login.html'); return; }
    injectExtraStyles();
    document.addEventListener('change', e => {
        if (e.target && e.target.id === 'thiSpecies') {
            if (window.DVSpecies) DVSpecies.set(e.target.value);
            else onSpeciesChange(e.target.value);
        }
    });
    const select = _el('climateDistrict');
    if (select) {
        if (DISTRICT_COORDS[select.value]) currentDistrict = select.value;
        select.addEventListener('change', e => {
            if (!DISTRICT_COORDS[e.target.value]) return;
            currentDistrict = e.target.value;
            loadAllSections();
        });
    }
    loadAllSections();
}

/* ============================================================
   SEGMENT 4 FIX: DVClimate guard
   climate-feature.js also defines window.DVClimate on
   thi/forage/outbreak/impact pages. This dashboard script is
   only loaded on climate-dashboard.html, so the two never
   actually collide in practice. The guard is defensive:
   if climate-feature.js has already claimed DVClimate with
   its _fromFeature flag, we skip the override.
   ============================================================ */
if (!window.DVClimate || !window.DVClimate._fromFeature) {
    window.DVClimate = {
        reload: () => loadAllSections(),
        setDistrict(key) {
            if (!DISTRICT_COORDS[key]) return false;
            currentDistrict = key;
            const select = _el('climateDistrict');
            if (select) select.value = key;
            loadAllSections();
            return true;
        },
        getDistrict: () => currentDistrict,
        DISTRICT_COORDS
    };
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
else init();

})();