/* DailyVet — Leaflet GeoJSON Loader stub v1.0
   Signals map controllers that division data is ready.
   Replace with real GeoJSON fetch from data/bd-divisions.geojson when available.
*/
(function () {
'use strict';

function signalReady() {
    if (typeof window.__mapOnDataReady === 'function') {
        try { window.__mapOnDataReady(); } catch (err) {
            console.warn('[GeoJSON] onDataReady failed:', err.message);
        }
    }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => setTimeout(signalReady, 100));
} else {
    setTimeout(signalReady, 100);
}

console.log('✅ Leaflet GeoJSON loader stub ready');
})();