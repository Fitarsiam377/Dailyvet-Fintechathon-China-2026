/* ============================================================
   DAILYVET NAVBAR INJECTOR
   - Add one line on every page:
     <script src="js/dailyvet-nav.js" defer></script>
   - Navbar builds its own HTML
   - Language toggle removed (English Only)
   - FarmFin AI Hub link and Marketplace included
   - Mobile drawer shows PR Scanner (was Rx Scanner)
   - Skips injection on index.html to prevent double navbar
   - On mobile, tapping the hamburger hides the FarmFin sidebar
     while the menu is open, and brings it back when closed
   - SEGMENT 5 FIX: added ai-agent-dashboard, insurance-dashboard,
     unified-dashboard to the FinTech drawer group.
   - All Bengali strings removed.
   ============================================================ */
(function () {
'use strict';

const NAV_CONFIG = {
    brandLogo: 'assets/dailyvetlogo.png',
    brandHref: 'home.html',

    links: [
        { href: 'home.html', en: 'Home' },
        { href: 'ai.html', en: 'AI Vet' },
        { href: 'marketplace.html', en: 'Marketplace' },
        { href: 'advisor.html', en: 'Feed Advisor' },
        { href: 'pharma.html', en: 'Pharma' },
        { href: 'scanner.html', en: 'PR Scanner' },
        { href: 'farmfin-ai.html', en: 'FarmFin AI' },
        { href: 'climate-dashboard.html', en: 'Climate' },
        { href: 'community.html', en: 'Community' },
        { href: 'vet-home.html', en: 'Vets' }
    ],

    drawerGroups: [
        {
            labelEn: 'Core Services',
            items: [
                { href: 'ai.html', icon: 'fa-robot', en: 'AI Veterinary', subEn: 'Symptom-based triage' },
                { href: 'advisor.html', icon: 'fa-wheat-awn', en: 'Feed Advisor', subEn: 'Balance animal ration' },
                { href: 'pharma.html', icon: 'fa-pills', en: 'Medicine Finder', subEn: 'Dose and brands' },
                { href: 'scanner.html', icon: 'fa-file-medical', en: 'PR Scanner', subEn: 'Read handwriting' },
                { href: 'breed-detection.html', icon: 'fa-cow', en: 'Breed ID', subEn: 'Breed from photo' },
                { href: 'excreta-scan.html', icon: 'fa-microscope', en: 'Excreta Scan', subEn: 'Gut health check' }
            ]
        },
        {
            labelEn: 'FinTech and Ecosystem',
            items: [
                { href: 'farmfin-ai.html',          icon: 'fa-chart-pie',    en: 'FarmFin AI Hub',         subEn: 'All Financial Agents' },
                { href: 'ai-agent-dashboard.html',  icon: 'fa-robot',        en: 'AI Agent Dashboard',     subEn: 'Live AI decisions' },
                { href: 'finance-copilot.html',     icon: 'fa-wallet',       en: 'Finance Agent',          subEn: 'Voice ledger and credit score' },
                { href: 'insurance-hub.html',       icon: 'fa-shield-alt',   en: 'Insurance Agent',        subEn: 'Muzzle biometric and claims' },
                { href: 'insurance-dashboard.html', icon: 'fa-chart-line',   en: 'Insurance Dashboard',    subEn: 'Policy tracking' },
                { href: 'wealth-agent.html',        icon: 'fa-chart-line',   en: 'Wealth Agent',           subEn: 'Asset ROI and Net Worth' },
                { href: 'unified-dashboard.html',   icon: 'fa-layer-group',  en: 'Unified Dashboard',      subEn: 'Weather, Insurance, Finance' }
            ]
        },
        {
            labelEn: 'Climate and Farm',
            items: [
                { href: 'climate-dashboard.html', en: 'Climate Hub', icon: 'fa-satellite-dish', subEn: 'NASA satellite data' },
                { href: 'climate-thi.html', en: 'Heat Stress', icon: 'fa-temperature-high', subEn: 'Thermal index' },
                { href: 'climate-outbreak.html', en: 'Disease Risk', icon: 'fa-virus', subEn: 'Outbreak alert' },
                { href: 'climate-flood.html', en: 'Flood Warning', icon: 'fa-water', subEn: 'Water level alerts' }
            ]
        },
        {
            labelEn: 'Others',
            items: [
                { href: 'marketplace.html', en: 'Marketplace', icon: 'fa-store', subEn: 'Buy and sell livestock' },
                { href: 'community.html', en: 'Community', icon: 'fa-users', subEn: 'Talk to farmers' },
                { href: 'emergency.html', en: 'Emergency', icon: 'fa-truck-medical', subEn: 'Hotline 16358' },
                { href: 'profile.html', en: 'My Profile', icon: 'fa-user', subEn: 'Edit info' },
                { href: 'support.html', en: 'Support', icon: 'fa-headset', subEn: 'Contact us' }
            ]
        }
    ],

    sidebarSelectors: [
        '.farmfin-sidebar',
        '#farmfinSidebar',
        '#farmfin-sidebar',
        '.ff-sidebar',
        '#ffSidebar',
        '[class*="farmfin-sidebar"]',
        '[id*="farmfin-sidebar"]',
        '[id*="farmfinSidebar"]'
    ],
    sidebarMobileMax: 767
};

function buildNavbar() {
    const currentPage = location.pathname.split('/').pop() || 'home.html';

    const linksHtml = NAV_CONFIG.links.map(l => {
        let isActive = l.href === currentPage;

        if (l.href === 'farmfin-ai.html' &&
           ['finance-copilot.html', 'insurance-hub.html', 'wealth-agent.html', 'insurance-dashboard.html', 'insurance-policy.html', 'insurance-claim.html', 'insurance-risk-map.html', 'cashflow-forecast.html', 'unified-dashboard.html', 'ai-agent-dashboard.html'].includes(currentPage)) {
            isActive = true;
        }

        const active = isActive ? ' class="dv-active"' : '';
        return `<a href="${l.href}"${active}>${l.en}</a>`;
    }).join('');

    const drawerHtml = NAV_CONFIG.drawerGroups.map(g => `
        <div class="dv-drawer-group">
            <div class="dv-drawer-label">${g.labelEn}</div>
            ${g.items.map(it => `
                <a class="dv-drawer-link" href="${it.href}">
                    <span class="dv-dl-icon"><i class="fas ${it.icon}"></i></span>
                    <span class="dv-dl-body">
                        <span>${it.en}</span>
                        ${it.subEn ? `<span class="dv-dl-sub">${it.subEn}</span>` : ''}
                    </span>
                </a>
            `).join('')}
        </div>
    `).join('');

    return `
    <header class="dv-navbar">
        <div class="dv-container dv-navbar-inner">
            <a class="dv-brand" href="${NAV_CONFIG.brandHref}">
                <img src="${NAV_CONFIG.brandLogo}" alt="DailyVet">
                <div class="dv-brand-text">
                    <span class="dv-brand-name">Daily<span>Vet</span></span>
                    <span class="dv-brand-tag">Animal Care</span>
                </div>
            </a>

            <nav class="dv-nav-links">${linksHtml}</nav>

            <div class="dv-nav-actions">
                <div class="bell-wrapper" style="position:relative;">
                    <button class="dv-icon-btn" type="button" title="Notifications"
                        onclick="typeof window.toggleNotificationDropdown==='function'&&window.toggleNotificationDropdown()"
                        id="navNotifBell">
                        <i class="fas fa-bell"></i>
                        <span id="notificationBadge" class="notif-badge" style="display:none;position:absolute;top:-4px;right:-4px;min-width:18px;height:18px;border-radius:9999px;background:#e74c3c;color:#fff;font-size:10px;font-weight:700;align-items:center;justify-content:center;padding:0 4px;border:2px solid #fff;line-height:1;">0</span>
                    </button>
                    <div id="notificationDropdown" style="display:none;position:absolute;right:0;top:calc(100% + 10px);width:min(360px,92vw);max-height:420px;background:#fff;border:1px solid #e0f0f2;border-radius:16px;box-shadow:0 12px 40px rgba(3,93,105,0.18);z-index:2000;overflow:hidden;">
                        <div style="display:flex;align-items:center;justify-content:space-between;padding:12px 14px;border-bottom:1px solid #e0f0f2;background:#f8fcfc;">
                            <span style="font-weight:700;font-size:13px;color:#035D69;">Notifications</span>
                            <div style="display:flex;gap:6px;">
                                <button id="markAllReadBtn" type="button" onclick="typeof window.markAllNotificationsRead==='function'&&window.markAllNotificationsRead()" style="font-size:11px;font-weight:600;color:#088F8F;background:transparent;border:none;cursor:pointer;padding:4px 6px;">Mark all read</button>
                                <button id="clearAllNotifBtn" type="button" onclick="typeof window.clearAllNotifications==='function'&&window.clearAllNotifications()" style="font-size:11px;font-weight:600;color:#e74c3c;background:transparent;border:none;cursor:pointer;padding:4px 6px;">Clear all</button>
                            </div>
                        </div>
                        <div id="notificationList" style="max-height:340px;overflow-y:auto;">
                            <div style="padding:28px 16px;text-align:center;color:#8ab8be;font-size:13px;">No notifications</div>
                        </div>
                    </div>
                </div>

                <button class="dv-hamburger" type="button" aria-label="Menu">
                    <i class="fas fa-bars"></i>
                </button>
            </div>
        </div>
    </header>

    <div class="dv-drawer" id="dvDrawer">${drawerHtml}</div>
    `;
}

function injectSidebarHideCss() {
    if (document.getElementById('dvSidebarHideCss')) return;

    const sel = NAV_CONFIG.sidebarSelectors
        .map(s => 'body.dv-sidebar-hidden ' + s)
        .join(',\n');

    const style = document.createElement('style');
    style.id = 'dvSidebarHideCss';
    style.textContent = `
@media (max-width: ${NAV_CONFIG.sidebarMobileMax}px) {
${sel} {
    display: none !important;
}
body.dv-sidebar-hidden {
    padding-left: 0 !important;
    margin-left: 0 !important;
}
}`;
    document.head.appendChild(style);
}

function isMobileView() {
    return window.matchMedia('(max-width: ' + NAV_CONFIG.sidebarMobileMax + 'px)').matches;
}

function setSidebarHidden(hidden) {
    document.body.classList.toggle('dv-sidebar-hidden', hidden);
}

function init() {
    if (document.getElementById('dvNavbarRoot')) return;

    const currentPage = location.pathname.split('/').pop() || 'index.html';

    if (currentPage === 'index.html' || currentPage === '') {
        document.documentElement.style.setProperty('padding-top', '0', 'important');
        document.body.style.setProperty('padding-top', '0', 'important');
        document.body.style.setProperty('margin-top', '0', 'important');
        return;
    }

    const root = document.createElement('div');
    root.id = 'dvNavbarRoot';
    root.innerHTML = buildNavbar();
    document.body.insertBefore(root, document.body.firstChild);

    injectSidebarHideCss();

    const ham = root.querySelector('.dv-hamburger');
    const drawer = root.querySelector('#dvDrawer');
    if (ham && drawer) {
        ham.addEventListener('click', () => {
            const open = drawer.classList.toggle('dv-open');
            ham.innerHTML = open ? '<i class="fas fa-times"></i>' : '<i class="fas fa-bars"></i>';
            setSidebarHidden(open && isMobileView());
        });

        window.addEventListener('resize', () => {
            if (!isMobileView()) setSidebarHidden(false);
        });
    }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

window.DVNav = {
    getLang: () => 'en',
    setLang: () => {},
    toggle: () => {}
};
})();