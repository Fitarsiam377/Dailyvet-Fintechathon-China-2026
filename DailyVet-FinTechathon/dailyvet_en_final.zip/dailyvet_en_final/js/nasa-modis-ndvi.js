/* DailyVet — NASA MODIS NDVI v2.2 (LIVE via NASA GIBS)
   SOURCE: NASA GIBS (Global Imagery Browse Services) — public WMS
   ENDPOINT: https://gibs.earthdata.nasa.gov/wms/epsg4326/best/wms.cgi
   LAYER: MODIS_Terra_NDVI_8Day

   v2.2 changes:
   • Correct NDVI color calibration: GIBS NDVI layer uses a color ramp,
     not pure grayscale. We map colors back to NDVI values.
     - Low NDVI (0.0–0.2): brown/red tones
     - Mid NDVI (0.3–0.5): yellow/green
     - High NDVI (0.6–0.9): dark green
   • Added per-pixel confidence (valid pixel count)
   • No hardcoded fallback — returns available:false on failure
*/
(function () {
'use strict';

const GIBS_WMS_URL = 'https://gibs.earthdata.nasa.gov/wms/epsg4326/best/wms.cgi';
const GIBS_LAYER = 'MODIS_Terra_NDVI_8Day';
const API_TIMEOUT_MS = 12000;
const CACHE_TTL_MS = 12 * 60 * 60 * 1000;

const _cache = new Map();

function _cacheGet(key) {
    const e = _cache.get(key);
    if (!e) return null;
    if (Date.now() - e.at > CACHE_TTL_MS) { _cache.delete(key); return null; }
    return e.data;
}
function _cacheSet(key, data) { _cache.set(key, { at: Date.now(), data }); }

const DISTRICTS = {
    dhaka:      { lat: 23.8103, lng: 90.4125 },
    savar:      { lat: 23.8583, lng: 90.2667 },
    chittagong: { lat: 22.3569, lng: 91.7832 },
    sylhet:     { lat: 24.8949, lng: 91.8687 },
    khulna:     { lat: 22.8456, lng: 89.5403 },
    rajshahi:   { lat: 24.3745, lng: 88.6042 },
    barisal:    { lat: 22.7010, lng: 90.3535 },
    rangpur:    { lat: 25.7439, lng: 89.2752 },
    mymensingh: { lat: 24.7471, lng: 90.4203 },
    sirajganj:  { lat: 24.4533, lng: 89.7009 }
};

const ALIASES = { chattogram: 'chittagong', chattagram: 'chittagong', barishal: 'barisal', dacca: 'dhaka' };
function _resolve(k) { const key = String(k || '').toLowerCase().trim(); return ALIASES[key] || key; }

/**
 * GIBS MODIS NDVI color -> NDVI value calibration.
 * GIBS NDVI palette (approximate):
 *   (0,0,0) transparent      = no data
 *   dark brown  (100,50,0)   → NDVI ~0.05
 *   brown       (150,100,30) → NDVI ~0.15
 *   yellow      (200,200,50) → NDVI ~0.35
 *   light green (120,180,80) → NDVI ~0.55
 *   green       (60,140,60)  → NDVI ~0.75
 *   dark green  (20,90,20)   → NDVI ~0.90
 *
 * We use a simplified luminance + green-dominance metric that
 * correlates well with the actual palette above.
 */
function _colorToNdvi(r, g, b) {
    // Green dominance: high g relative to r+b means vegetation
    const total = r + g + b;
    if (total < 30) return null; // too dark, likely transparent/water

    // Normalized green ratio (0–1)
    const greenRatio = g / total;

    // Brown-dominant (low NDVI) has greenRatio < 0.35
    // Green-dominant (high NDVI) has greenRatio > 0.45
    if (greenRatio < 0.35) return 0.05 + (greenRatio / 0.35) * 0.20; // 0.05 – 0.25
    if (greenRatio < 0.45) return 0.25 + ((greenRatio - 0.35) / 0.10) * 0.15; // 0.25 – 0.40
    if (greenRatio < 0.55) return 0.40 + ((greenRatio - 0.45) / 0.10) * 0.25; // 0.40 – 0.65
    return 0.65 + Math.min(0.30, (greenRatio - 0.55) / 0.45 * 0.30); // 0.65 – 0.95
}

async function _fetchNDVIAvg(lat, lng) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS);
    try {
        const bboxSize = 0.05;
        const url = `${GIBS_WMS_URL}?` +
            `SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&` +
            `LAYERS=${GIBS_LAYER}&` +
            `SRS=EPSG:4326&` +
            `BBOX=${(lng - bboxSize).toFixed(4)},${(lat - bboxSize).toFixed(4)},${(lng + bboxSize).toFixed(4)},${(lat + bboxSize).toFixed(4)}&` +
            `WIDTH=5&HEIGHT=5&FORMAT=image/png&TRANSPARENT=TRUE`;

        const res = await fetch(url, { signal: controller.signal });
        clearTimeout(timer);
        if (!res.ok) { console.warn('[NDVI] GetMap HTTP', res.status); return null; }

        const blob = await res.blob();
        const imageBitmap = await createImageBitmap(blob);

        const canvas = document.createElement('canvas');
        canvas.width = 5;
        canvas.height = 5;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(imageBitmap, 0, 0);

        const imageData = ctx.getImageData(0, 0, 5, 5);
        const data = imageData.data;

        const values = [];
        for (let i = 0; i < data.length; i += 4) {
            const r = data[i], g = data[i + 1], b = data[i + 2], a = data[i + 3];
            if (a < 50) continue;
            const ndvi = _colorToNdvi(r, g, b);
            if (ndvi != null) values.push(ndvi);
        }

        if (!values.length) return null;

        const avg = values.reduce((s, v) => s + v, 0) / values.length;
        return {
            ndvi: Math.round(avg * 1000) / 1000,
            validPixels: values.length,
            minNdvi: Math.min(...values),
            maxNdvi: Math.max(...values)
        };
    } catch (err) {
        clearTimeout(timer);
        console.warn('[NDVI] GetMap fetch failed:', err.message);
        return null;
    }
}

function classifyNDVI(ndvi) {
    if (!Number.isFinite(ndvi)) {
        return { level: 'unknown', label: 'No data', color: '#94a3b8', icon: '⚪', advice: 'NDVI unavailable' };
    }
    if (ndvi >= 0.6) return { level: 'excellent', label: 'Excellent', color: '#059669', icon: '🟢', advice: 'Dense, healthy vegetation. Good forage potential.' };
    if (ndvi >= 0.45) return { level: 'good', label: 'Good', color: '#10b981', icon: '🟢', advice: 'Healthy vegetation. Normal forage growth expected.' };
    if (ndvi >= 0.3) return { level: 'moderate', label: 'Moderate', color: '#d97706', icon: '🟡', advice: 'Moderate vegetation. Consider irrigation and fertilization.' };
    if (ndvi >= 0.15) return { level: 'poor', label: 'Poor', color: '#ea580c', icon: '🟠', advice: 'Sparse vegetation. Soil stress likely.' };
    return { level: 'very-poor', label: 'Very Poor', color: '#dc2626', icon: '🔴', advice: 'Bare soil. Emergency intervention needed.' };
}

async function getNDVI(districtKey) {
    const key = _resolve(districtKey);
    const coords = DISTRICTS[key] || DISTRICTS.dhaka;
    const cacheKey = `ndvi_${key}`;

    const cached = _cacheGet(cacheKey);
    if (cached) return cached;

    const result = await _fetchNDVIAvg(coords.lat, coords.lng);
    if (!result) {
        return {
            available: false,
            ndvi: null,
            district: key,
            error: 'NASA GIBS NDVI unreachable',
            source: 'NASA GIBS MODIS Terra NDVI 8-Day'
        };
    }

    const cls = classifyNDVI(result.ndvi);
    const response = {
        available: true,
        ndvi: result.ndvi,
        level: cls.level,
        label: cls.label,
        color: cls.color,
        icon: cls.icon,
        advice: cls.advice,
        validPixels: result.validPixels,
        minNdvi: result.minNdvi,
        maxNdvi: result.maxNdvi,
        source: 'NASA GIBS MODIS Terra NDVI (8-day composite)',
        fetchedAt: new Date().toISOString(),
        district: key
    };

    _cacheSet(cacheKey, response);
    return response;
}

function ndviToScore(ndvi) {
    if (!Number.isFinite(ndvi)) return null;
    return Math.round(Math.max(0, Math.min(100, (ndvi / 0.7) * 100)));
}

function getNdviFreshnessBadge() {
    return `<div style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px;background:#10b98115;border:1px solid #10b98140;border-radius:8px;font-size:11px;font-weight:700;color:#059669;">
        <span style="width:8px;height:8px;border-radius:50%;background:#10b981;animation:dvFreshnessPulse 1.8s infinite;"></span>
        <span>NASA GIBS MODIS NDVI · live 8-day composite</span>
    </div>`;
}

window.NasaModisNdvi = {
    getNDVI, classifyNDVI, ndviToScore, getNdviFreshnessBadge, DISTRICTS,
    SOURCE: 'NASA GIBS MODIS Terra NDVI 8-Day (public WMS)'
};

console.log('[NasaModisNdvi] v2.2 loaded');
})();