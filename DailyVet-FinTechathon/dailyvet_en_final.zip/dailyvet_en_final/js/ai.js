// ═══════════════════════════════════════════════════════════
// DAILYVET AI VET ASSISTANT  v12.8  (Gemini → Groq → OpenRouter) — ENGLISH ONLY
// slots: Gemini (primary) → Groq → OpenRouter  | hedged cascade
// HARD RULE: user gets a reply inside 5–6s no matter what
// Dead key = 1 fail → 6h block | Rate-limit → exponential cooldown
// Gemini Google-Search grounding | "collabed" badge
// Strict English language lock | Toxic-med guard
// Situation-wise doctor-style triage | Voice | History | Vet finder
// Goat vs Cow vision distinction strengthened
//
// ✅ v12.8 CHANGELOG (Gemini primary):
//   • _buildSlots/arrange(): order is now Gemini → Gemini → Groq → Gemini → OpenRouter
//   • TIMING: text total 5500ms, vision 8000ms; hedge 1500/2000ms
//   • REPLY_TARGET_MS 7000 → 5500
//   • _cascade(): hedge timer now actually used (backup slot starts if
//     the first slot has not replied within cfg.hedge ms)
//   • Stale API blocks (saved in localStorage) are cleared once on upgrade
//     (BLOCK_VERSION) so a new Gemini key works immediately
//
// ✅ v12.7 CHANGELOG (generic replies OFF):
//   • ALLOW_GENERIC_REPLIES = false  → no canned / one-size-fits-all replies
//   • AI prompt: "NO GENERIC ANSWERS" rule (specific to animal + symptom)
//   • Generic fallbacks (LOCAL_TOPICS, general KB text, FRIENDLY_FALLBACK,
//     "Preliminary advice" note) disabled; short retry message instead
//   • Specific Disease-DB match + emergency fallback + quick greetings kept
//
// ✅ v12.6 CHANGELOG (bugless + fast voice):
//   • ELEVEN: firstChunkChars 60→40, nextChunkChars 260→180
//   • ELEVEN: firstFetchTimeoutMs (new) = 2500, fetchTimeoutMs 12000→8000
//   • _speakEleven: 4 upfront prefetches, pipeline depth 3
//   • _elFetch: isFirst parameter → first chunk uses short timeout
//   • _ttsChunks: splits first sentence if it exceeds firstChunkChars
//   • COLLAB_LOADER_HOLD_MS 250→100 (render reply faster)
//   • DOMContentLoaded: _unlockAudio() early attempt (100ms)
//   • Voice ON state: skip browser TTS if ElevenLabs was disabled
//     by auth/quota (avoids the slow fallback)
// ═══════════════════════════════════════════════════════════

// ── GENERIC-REPLY SWITCH ──
// false = never show canned/generic replies (AI must answer specifically,
//         otherwise a short "please resend" message is shown)
// true  = old behaviour (pattern-match + general KB + friendly fallback)
const ALLOW_GENERIC_REPLIES = false;
const AI_RETRY_MESSAGE = '⚠️ I could not get a proper answer right now. Please send your message again in a moment.';
const _noAiReply = () => ALLOW_GENERIC_REPLIES ? FRIENDLY_FALLBACK : AI_RETRY_MESSAGE;

// ── STATE ──
let userName = 'User';
let userPetType = null;
let cachedUserPhone = null;
let cachedUserPhoto = null;
let unsubscribeUserPhoto = null;
let isProcessing = false;
let lastMessageTime = 0;
let selectedImageData = null;
let conversationHistory = [];
let nameGreeted = false;
const MIN_MESSAGE_INTERVAL = 2000;
const MAX_HISTORY_TURNS = 8;

// ── KEYWORD TABLES ──
const SPECIES_KEYWORDS = {
    dog: ['dog', 'puppy', 'doggy'],
    cat: ['cat', 'kitten', 'meow'],
    cow: ['cow', 'cattle'],
    goat: ['goat'],
    sheep: ['sheep'],
    chicken: ['chicken', 'hen'],
    duck: ['duck'],
    pigeon: ['pigeon'],
    buffalo: ['buffalo'],
    horse: ['horse'],
    rabbit: ['rabbit'],
    bird: ['bird', 'parrot'],
    fish: ['fish'],
    turtle: ['turtle'],
    snake: ['snake']
};
const SYMPTOM_KEYWORDS = {
    fever: ['fever', 'high temperature'],
    skin: ['skin', 'itching', 'rash', 'mange', 'scab', 'hair loss', 'bald patch', 'ringworm', 'dandruff'],
    wound: ['wound', 'cut', 'injury', 'abscess', 'pus'],
    vomiting: ['vomit'],
    diarrhea: ['diarrhea', 'loose motion', 'scour'],
    cough: ['cough'],
    breathing: ['breathing', 'choking', 'wheeze', 'gasping', 'respiratory'],
    appetite: ['not eating', 'anorexia', 'appetite loss'],
    eye: ['eye', 'discharge from eye', 'cloudy eye', 'blindness'],
    ear: ['ear', 'ear infection', 'head shaking'],
    lameness: ['lame', 'limping', 'foot rot', 'hoof'],
    weak: ['weak', 'lethargic', 'lethargy', 'inactive'],
    bleeding: ['bleeding', 'blood', 'blood in stool', 'blood in urine'],
    swelling: ['swell', 'bloat', 'lump', 'tumor', 'distended abdomen'],
    milk: ['milk', 'mastitis', 'reduced milk yield'],
    pregnancy: ['pregnant', 'calving', 'labor', 'labour', 'birthing', 'stillbirth', 'abortion'],
    parasites: ['tick', 'flea', 'lice', 'mite', 'worm'],
    dehydration: ['dehydrat', 'sunken eyes', 'dry mouth'],
    dental: ['teeth', 'tooth', 'gum'],
    urinary: ['urine', 'urinating', 'kidney', 'bladder'],
    respiratory_infection: ['pneumonia', 'cold', 'sneeze'],
    poultry_specific: ['egg drop', 'not laying', 'ruffled feathers', 'feather loss'],
    fish_specific: ['fin rot', 'fungus on fish', 'gill'],
    neuro: ['seizure', 'convulsion', 'tremor', 'paralysis', 'circling', 'head tilt'],
    poisoning: ['poison', 'toxic', 'ate something bad'],
    heatstroke: ['heat stroke', 'heatstroke', 'overheating'],
    emergency: ['emergency', 'critical', 'accident', 'unconscious']
};

// ── TRIAGE ──
const MIN_TRIAGE_ROUNDS = 0;
const IMAGE_TRIAGE_ROUNDS = 1;
const DEFAULT_TRIAGE_ROUNDS = 3;
let triageRounds = 0;
let triageLimit = DEFAULT_TRIAGE_ROUNDS;

const _countSymptomSignals = text => {
    if (!text) return 0;
    const lower = text.toLowerCase();
    return Object.values(SYMPTOM_KEYWORDS).filter(kws =>
        kws.some(kw => findKeywordIndex(lower, String(kw).toLowerCase()) !== -1)
    ).length;
};
const _DURATION_HINT_RE = /\d+\s*(day|days|week|weeks|hour|hours|month|months|night|nights)|long\s*time|few\s*days|for\s*days/i;
const _SEVERITY_HINT_RE = /very|severe|bad|critical|urgent|very\s+sick|a\s+lot/i;
const _APPETITE_HINT_RE = /eating|appetite|water|drink/i;

function computeTriageLimit({ text, mood, isEmergency, hasImage }) {
    if (isEmergency) return MIN_TRIAGE_ROUNDS;
    if (hasImage) return IMAGE_TRIAGE_ROUNDS;
    if (mood === 'urgent') return 1;
    const words = (text || '').trim().split(/\s+/).filter(Boolean).length;
    let signals = _countSymptomSignals(text);
    if (_DURATION_HINT_RE.test(text || '')) signals += 1;
    if (_SEVERITY_HINT_RE.test(text || '')) signals += 1;
    if (_APPETITE_HINT_RE.test(text || '')) signals += 1;
    if (signals >= 4 || words >= 30) return 2;
    if (signals >= 2 || words >= 15) return 3;
    if (signals <= 1 && words <= 6) return 4;
    return DEFAULT_TRIAGE_ROUNDS;
}

const _newMemory = () => ({ currentPet: null, currentDisease: null, symptoms: [], mentionedPets: [], userMood: 'neutral' });
let topicMemory = _newMemory();
let awaitingVetSpecies = false;

// ── Small helpers ──
const _el = id => document.getElementById(id);
const _scrollChatToBottom = () => {
    const shell = _el('chatMessages') || document.querySelector('.ai-container');
    if (shell) shell.scrollTop = shell.scrollHeight;
};
const _sleep = ms => new Promise(r => setTimeout(r, ms));
const _withTimeout = (p, ms, fallback) => Promise.race([
    Promise.resolve(p).catch(() => fallback),
    new Promise(r => setTimeout(() => r(fallback), ms))
]);
const _reEsc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const _has = (text, list) => { const l = (text || '').toLowerCase(); return list.some(k => l.includes(k.toLowerCase())); };
const _nl = t => t.replace(/\\n/g, '\n').replace(/\r\n/g, '\n').replace(/\r/g, '\n');
const _fs = () => firebase.firestore();
const VET_HOTLINE = '\n\n📞 24/7 Helpline: 16358';
const GOOGLE_OPTION_TOKEN = '[[SHOW_GOOGLE_OPTION]]';

const _lsGet = k => { try { return localStorage.getItem(k); } catch (_) { return null; } };
const _lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (_) {} };

const _ESC_MAP = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
function escapeHtml(text) {
    return String(text ?? '').replace(/[&<>"']/g, c => _ESC_MAP[c]);
}

// ═══════════════════════════════════════════════════════════
// 👤 USER PHOTO
// ═══════════════════════════════════════════════════════════
const _userAvatarHTML = () => cachedUserPhoto
    ? `<img src="${escapeHtml(cachedUserPhoto)}" alt="${escapeHtml(userName)}" />`
    : escapeHtml(userName.charAt(0).toUpperCase());

const _refreshUserAvatars = () => document.querySelectorAll('.message.user-message .user-avatar').forEach(el => {
    el.innerHTML = _userAvatarHTML();
});

const _getPhone = () => (sessionStorage.getItem('userPhone') || localStorage.getItem('userPhone') || '').trim();

async function getUserPhoto() {
    const phone = cachedUserPhone || _getPhone();
    if (!phone) return '';
    if (cachedUserPhoto !== null) return cachedUserPhoto;
    try {
        const doc = await _fs().collection('users').doc(phone).get();
        cachedUserPhoto = doc.exists ? (doc.data().photoURL || '') : '';
    } catch (err) {
        console.warn('User photo fetch failed:', err.message);
        cachedUserPhoto = '';
    }
    return cachedUserPhoto;
}

function listenToUserPhoto() {
    const phone = _getPhone();
    if (!phone) return;
    if (unsubscribeUserPhoto) unsubscribeUserPhoto();
    try {
        unsubscribeUserPhoto = _fs().collection('users').doc(phone).onSnapshot(doc => {
            if (!doc.exists) return;
            cachedUserPhone = phone;
            const d = doc.data();
            cachedUserPhoto = d.photoURL && d.photoURL.indexOf('dailyvetlogo') === -1 ? d.photoURL : '';
            if (d.name) userName = d.name;
            _refreshUserAvatars();
        });
    } catch (err) {
        console.warn('Photo listener failed:', err.message);
    }
}

// ═══════════════════════════════════════════════════════════
// 🔑 API CONFIG — keys obfuscated; production uses server proxy (no keys in client traffic)
// ═══════════════════════════════════════════════════════════
const _dvDec = (s) => { try { return atob(s); } catch(e) { return ''; } };
const GEMINI_KEYS = [
    _dvDec('QVEuQWI4Uk42SXdNVERXbjh3VjRYM2g0SEJkYXN0SEUxNjlKWHhlNUlLUTFnTTNQaldFR1E='),
    _dvDec('QVEuQWI4Uk42S3V2VzgzQTNPYWphcU03R292b3lCdU5EUTh0ajlLNVNpd3NGTlVzeS1pV0E='),
    _dvDec('QVEuQWI4Uk42SVJhRmVva2s5eUtKb3lnbVQ1T3VlNWhyM2JldVUxbloxVEV2MnJMYkdUMWc='),
    _dvDec('QVEuQWI4Uk42Sm9hN25VNFY1R0dPZHY2Y0UyZEgzS0V6N29qNzF1dDNOdHBqc1pTem9jLUE='),
    _dvDec('QVEuQWI4Uk42Sm5nSUJoQTFIeVVtdG9NSHpQTVZnc0NKZlhWS0dEakhZTWNvUk5YZ3JWcGc=')
];
const GROQ_KEYS = [
    _dvDec('Z3NrX21WVXRJQThxTHdXUGNIZkFvNHNkV0dkeWIzRllkUk1rTlppMUxYT2gxb1RITVlIM0w3WXI='),
    _dvDec('Z3NrX3o4QkRyYldCbXlhS2l6M3BiVnZRV0dkeWIzRlk1R25haDNrQVptQm1xRUF2a2ZLMTZmd1M='),
    _dvDec('Z3NrX0ExSHo5VDQ3aTA5UndrM1h4UGlaV0dkeWIzRllxT0YxOHdDc0JRV0lUaVlOQjRaM3RheDQ=')
];
const OPENROUTER_KEYS = [
    _dvDec('c2stb3ItdjEtODg4MDE5MDk4Njc2MjllYWQ5ZGQyMjQ2MTc5YWVlZjE0Y2VkZTFiMGZkOGI2YmQxM2VkNDA2NTU3NWVhZWY3OQ=='),
    _dvDec('c2stb3ItdjEtNGQwZmE1MzM5YWI1YTA3NDlkM2I4ZTEyZTU1NGM3ZWI2MjFjYzNjMmI1YjgwYzk0MjA5YjM0YjhmMzZjZTFlNg==')
];
const PROVIDER_KEYS = { gemini: GEMINI_KEYS, groq: GROQ_KEYS, openrouter: OPENROUTER_KEYS };

const MODELS = {
    gemini: {
        text: [
            'gemini-3.5-flash-lite',
            'gemini-3.1-flash-lite',
            'gemini-2.5-flash-lite',
            'gemini-3.8-flash',
            'gemini-3.6-flash',
            'gemini-2.5-flash'
        ],
        vision: [
            'gemini-3.5-flash-lite',
            'gemini-3.1-flash-lite',
            'gemini-2.5-flash-lite',
            'gemini-3.8-flash',
            'gemini-3.6-flash',
            'gemini-2.5-flash'
        ]
    },
    groq: {
        text: ['openai/gpt-oss-120b'],
        vision: ['qwen/qwen3.8-27b']
    },
    openrouter: {
        text: ['meta-llama/llama-3.3-70b-instruct:free', 'google/gemma-2-9b-it:free'],
        vision: ['qwen/qwen2.5-vl-72b-instruct:free']
    }
};
const ENDPOINTS = {
    gemini: 'https://generativelanguage.googleapis.com/v1beta/models',
    groq: 'https://api.groq.com/openai/v1/chat/completions',
    openrouter: 'https://openrouter.ai/api/v1/chat/completions'
};

/* ✅ v12.8: 5–6s hard limit; hedge = start backup slot if first is slow */
const TIMING = {
    text:   { total: 5500, perCall: 3500, hedge: 1500, parallel: 2 },
    vision: { total: 8000, perCall: 5500, hedge: 2000, parallel: 2 }
};
const REPLY_TARGET_MS = 5500;
const LANG_RETRY_MIN_LEFT_MS = 1800;
const DB_LOOKUP_TIMEOUT_MS = 500;
const VET_LOOKUP_TIMEOUT_MS = 1500;
const COOLDOWN = {
    rateLimit: 20e3,
    rateLimitMax: 12 * 60e3,
    server: 15e3, timeout: 12e3, badRequest: 8 * 60e3,
    authKey: 6 * 3600e3, modelGone: 24 * 3600e3, quotaZero: 6 * 3600e3, perDay: 3 * 3600e3
};
const GEMINI_SAFETY = ['HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH', 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'HARM_CATEGORY_DANGEROUS_CONTENT']
    .map(category => ({ category, threshold: 'BLOCK_ONLY_HIGH' }));

const GEMINI_USE_GOOGLE_SEARCH = false;
const SEARCH_PAUSE_MS = 60 * 60 * 1000;
const SEARCH_STORE = 'dvSearchBlockedUntil';
let searchBlockedUntil = parseInt(_lsGet(SEARCH_STORE) || '0', 10) || 0;
const _searchAvailable = () => GEMINI_USE_GOOGLE_SEARCH && Date.now() >= searchBlockedUntil;
const GEMINI_SEARCH_NOTE = `\n\n🌐 You may use Google Search for accurate, up-to-date veterinary facts, but keep the SAME structure, language, formatting and safety rules. Do NOT add links, citations or source lists.`;

const DEBUG = false;
const _log = DEBUG ? console.log.bind(console) : () => {};

// ── Block registry ──
const BLOCK_STORE = 'dvAiBlocks';
/* ✅ v12.8: bump this string to wipe old saved blocks once (new key / new order) */
const BLOCK_VERSION = 'v12.8';
const BLOCK_VERSION_STORE = 'dvAiBlocksVer';
const _blocks = new Map();
const _strikes = new Map();
const _rot = { gemini: 0, groq: 0, openrouter: 0 };

(function _loadBlocks() {
    try {
        if (_lsGet(BLOCK_VERSION_STORE) !== BLOCK_VERSION) {
            _lsSet(BLOCK_STORE, '{}');
            _lsSet(SEARCH_STORE, '0');
            searchBlockedUntil = 0;
            _lsSet(BLOCK_VERSION_STORE, BLOCK_VERSION);
            return;
        }
        Object.entries(JSON.parse(_lsGet(BLOCK_STORE) || '{}')).forEach(([id, until]) => {
            if (until > Date.now()) _blocks.set(id, until);
        });
    } catch (_) {}
})();

const _tail = k => k.slice(-8);
const _keyId = s => `k:${s.provider}:${_tail(s.key)}`;
const _modelId = s => `m:${s.provider}:${s.model}`;
const _isBlocked = id => (_blocks.get(id) || 0) > Date.now();
const _slotBlocked = s => _isBlocked(s.id) || _isBlocked(_keyId(s)) || _isBlocked(_modelId(s));

function _block(id, ms) {
    _blocks.set(id, Date.now() + ms);
    _log(`🚫 ${id} blocked ${Math.round(ms / 1000)}s`);
    const live = {};
    _blocks.forEach((until, k) => { if (until > Date.now()) live[k] = until; });
    _lsSet(BLOCK_STORE, JSON.stringify(live));
}

function _buildSlots(hasImage) {
    const kind = hasImage ? 'vision' : 'text';
    const make = provider => {
        const keys = PROVIDER_KEYS[provider].filter(Boolean);
        const shift = keys.length ? _rot[provider] % keys.length : 0;
        const rotated = keys.slice(shift).concat(keys.slice(0, shift));
        const seen = new Set();
        const out = [];
        for (const model of MODELS[provider][kind]) {
            for (const key of rotated) {
                const id = `s:${provider}:${model}:${_tail(key)}`;
                if (seen.has(id)) continue;
                seen.add(id);
                out.push({ provider, model, key, id });
            }
        }
        return out;
    };
    /* ✅ v12.8: Gemini first, then Groq, then OpenRouter */
    const arrange = ([g, q, o]) => {
        const out = [];
        let gi = 0, qi = 0, oi = 0;
        const take = (arr, i) => (i < arr.length ? arr[i] : null);
        const steps = [
            () => take(g, gi++),   // Gemini #1
            () => take(g, gi++),   // Gemini #2 (other key / model)
            () => take(q, qi++),   // Groq
            () => take(g, gi++),   // Gemini #3
            () => take(o, oi++),   // OpenRouter
            () => take(g, gi++),   // Gemini #4
            () => take(q, qi++)    // Groq #2
        ];
        for (const step of steps) { const s = step(); if (s) out.push(s); }
        while (gi < g.length) out.push(g[gi++]);
        while (qi < q.length) out.push(q[qi++]);
        while (oi < o.length) out.push(o[oi++]);
        return out;
    };
    const all = ['gemini', 'groq', 'openrouter'].map(make);
    const live = arrange(all.map(list => list.filter(s => !_slotBlocked(s))));
    if (live.length) return live;
    return arrange(all.map(list => list.filter(s => !_isBlocked(_keyId(s)) && !_isBlocked(_modelId(s))))).slice(0, 4);
}

// ── REPLY CACHE ──
const REPLY_CACHE_TTL_MS = 60 * 60 * 1000;
const REPLY_CACHE_MAX = 200;
const replyCache = new Map();
const replyCacheKey = (text, species) => `${species || ''}|${(text || '').toLowerCase().replace(/\s+/g, ' ').trim()}`;
function getCachedReply(key) {
    const e = replyCache.get(key);
    const expired = !!e && Date.now() - e.t > REPLY_CACHE_TTL_MS;
    if (expired) replyCache.delete(key);
    return expired ? null : (e || null);
}
function setCachedReply(key, raw, provider, searchInfo) {
    replyCache.set(key, { raw, provider: provider || 'ai', searchInfo: searchInfo || null, t: Date.now() });
    if (replyCache.size > REPLY_CACHE_MAX) replyCache.delete(replyCache.keys().next().value);
}

// ── MOOD / CORRECTION / TASK ──
const MOOD_KEYWORDS = {
    worried: ['worried', 'tension', 'afraid'],
    sad: ['sad', 'crying'],
    angry: ['angry', 'frustrated'],
    urgent: ['urgent', 'hurry', 'quickly', 'emergency'],
    grateful: ['thanks', 'thank you'],
    confused: ['confused', "don't understand"],
    happy: ['happy']
};
const CORRECTION_KEYWORDS = ['wrong', 'incorrect', 'mistake', "that's not right"];
const TASK_KEYWORDS = {
    math: ['calculate'],
    summary: ['summarize', 'summary'],
    writing: ['write'],
    planning: ['plan'],
    code: ['code', 'javascript', 'python']
};
const EMOTIONAL_GUIDES = {
    worried: 'User worried. Be reassuring.',
    sad: 'User sad. Be gentle.',
    angry: 'User angry. Stay calm.',
    urgent: 'User urgent.',
    grateful: 'User grateful.',
    confused: 'User confused. Step by step.',
    happy: 'User happy.'
};
const _firstMatch = (text, map) => {
    if (!text) return null;
    const lower = text.toLowerCase();
    for (const [label, kws] of Object.entries(map)) if (kws.some(k => lower.includes(k.toLowerCase()))) return label;
    return null;
};
const detectMood = text => _firstMatch(text, MOOD_KEYWORDS) || 'neutral';
const detectTaskType = text => _firstMatch(text, TASK_KEYWORDS);
const isCorrectingUser = text => _has(text, CORRECTION_KEYWORDS);
const getEmotionalGuidance = mood => EMOTIONAL_GUIDES[mood] || '';

// ── SPECIES / SYMPTOM DETECTION ──
const NEGATION_WORDS = ['not', 'no', "isn't", 'isnt', "doesn't", 'doesnt', "didn't", 'didnt'];
const NEGATION_WINDOW_WORDS = 3;
function isNegatedAt(lower, idx, len) {
    const stop = /[,.;\n]/;
    let start = idx;
    while (start > 0 && !stop.test(lower[start - 1])) start--;
    const words = s => s.trim().split(/\s+/).filter(Boolean);
    const before = words(lower.slice(start, idx)).slice(-NEGATION_WINDOW_WORDS);
    return NEGATION_WORDS.some(w => before.includes(w));
}

const _kwRegexCache = {};
function findKeywordIndex(lower, kwLower) {
    let re = _kwRegexCache[kwLower];
    if (!re) {
        const esc = kwLower.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        re = kwLower.length <= 4
            ? new RegExp(`(^|[^a-z])${esc}(?:s|es)?(?![a-z])`)
            : new RegExp(`(^|[^a-z])${esc}`);
        _kwRegexCache[kwLower] = re;
    }
    const m = re.exec(lower);
    return m ? m.index + m[1].length : -1;
}
function detectFromKeywordMap(text, map, checkNegation) {
    if (!text) return null;
    const lower = text.toLowerCase();
    for (const [label, keywords] of Object.entries(map)) {
        for (const kw of keywords) {
            const kwLower = kw.toLowerCase();
            const idx = findKeywordIndex(lower, kwLower);
            if (idx === -1) continue;
            if (checkNegation && isNegatedAt(lower, idx, kwLower.length)) continue;
            return label;
        }
    }
    return null;
}
const detectSpecies = text => detectFromKeywordMap(text, SPECIES_KEYWORDS, true);
const detectSymptom = text => detectFromKeywordMap(text, SYMPTOM_KEYWORDS, true);

// ── CONVERSATION FLOW ──
const NEW_QUESTION_PATTERNS = [
    /what.*wrong.*this/i,
    /what.*happened.*this/i,
    /what('s| is) wrong with (this|it)/i
];
const isNewQuestion = text => !!text && NEW_QUESTION_PATTERNS.some(p => p.test(text.toLowerCase().trim()));

function updateTopicMemory(species, symptom, mood) {
    const prev = topicMemory.currentPet;
    if (species && prev && species !== prev) {
        Object.assign(topicMemory, { currentDisease: null, symptoms: [], userMood: 'neutral', mentionedPets: [species] });
    }
    if (species) {
        topicMemory.currentPet = species;
        if (!topicMemory.mentionedPets.includes(species)) topicMemory.mentionedPets.push(species);
    }
    if (symptom) {
        topicMemory.currentDisease = symptom;
        if (!topicMemory.symptoms.includes(symptom)) topicMemory.symptoms.push(symptom);
    }
    if (mood && mood !== 'neutral') topicMemory.userMood = mood;
}

function buildMemoryHint() {
    const m = topicMemory;
    if (!m.currentPet && !m.currentDisease && m.userMood === 'neutral') return '';
    let hint = '\n\n🎯 CURRENT CONTEXT:\n';
    if (m.currentPet) hint += `- Current pet: ${m.currentPet}\n`;
    if (m.currentDisease) hint += `- Previous issue: ${m.currentDisease}\n`;
    if (m.symptoms.length) hint += `- Previous symptoms: ${m.symptoms.join(', ')}\n`;
    if (m.userMood && m.userMood !== 'neutral') hint += `- Mood: ${m.userMood}\n`;
    hint += `🚫 Talk ONLY about the current pet above; never mix other animals.`;
    return hint;
}

const splitTokens = text => (text || '').toLowerCase().split(/[\s,.;:!?"()]+/).filter(Boolean);
function isReferringToPrevious(text) {
    if (!text) return false;
    const lower = text.toLowerCase().trim();
    const tokens = new Set(splitTokens(lower));
    const words = ['previous', 'earlier', 'again', 'same'];
    const phrases = ['previous problem', 'earlier problem'];
    return words.some(w => tokens.has(w)) || phrases.some(p => lower.includes(p));
}

const FOLLOWUP_TOKENS = new Set([
    'then', 'more', 'still', 'medicine', 'dose', 'treatment', 'cure'
]);
const FOLLOWUP_PHRASES = [
    'what to feed', 'what should i give', 'what do i do', 'how long', 'how much',
    'what should i', 'what about'
];
function isFollowUpMessage(text) {
    if (!text) return false;
    const lower = text.toLowerCase();
    return splitTokens(lower).some(t => FOLLOWUP_TOKENS.has(t)) || FOLLOWUP_PHRASES.some(p => lower.includes(p));
}
const DOCTOR_QUERIES = [
    'doctor', 'vet', 'veterinary',
    'where to take', 'hospital', 'clinic',
    'doctor number', 'who should i show',
    'any vet', 'any doctor', 'vet nearby'
];
const isAskingForDoctor = text => _has(text, DOCTOR_QUERIES);

// ═══════════════════════════════════════════════════════════
// 🌐 LANGUAGE SAFETY (English only)
// ═══════════════════════════════════════════════════════════
const BN_SCRIPT_GLOBAL_RE = /[\u0980-\u09FF]/g;

function banglaRatio(text) {
    if (!text) return 0;
    const letters = text.replace(/[^\u0980-\u09FFa-zA-Z]/g, '');
    if (!letters.length) return 0;
    return (letters.match(BN_SCRIPT_GLOBAL_RE) || []).length / letters.length;
}
function replyIsEnglish(reply) {
    if (!reply || typeof reply !== 'string') return false;
    return banglaRatio(reply) < 0.05;
}

// ═══════════════════════════════════════════════════════════
// 🛡️ MEDICAL SAFETY GUARD
// ═══════════════════════════════════════════════════════════
const HUMAN_ONLY_MEDS = [
    'paracetamol', 'acetaminophen', 'nimesulide', 'ibuprofen',
    'aspirin', 'diclofenac', 'ketorolac', 'naproxen',
    'tramadol', 'morphine', 'codeine', 'analgin', 'novalgin',
    'amoxicillin 500', 'azithromycin 500', 'ciprofloxacin 500',
    'cefixime', 'ceftriaxone', 'levofloxacin', 'doxycycline 100',
    'metronidazole 400', 'fluconazole 150',
    'cetirizine', 'loratadine', 'fexofenadine', 'chlorpheniramine',
    'phenylephrine', 'pseudoephedrine', 'dextromethorphan',
    'omeprazole 20', 'esomeprazole', 'pantoprazole', 'ranitidine',
    'domperidone', 'ondansetron 4', 'loperamide',
    'metformin', 'glibenclamide', 'insulin human',
    'amlodipine', 'losartan', 'atenolol', 'propranolol',
    'prednisolone 5', 'dexamethasone 4', 'hydrocortisone cream',
    'salbutamol inhaler', 'thyroxine', 'warfarin',
    'napa', 'ace', 'napa extra', 'ace plus', 'seclo', 'sergel',
    'maxpro', 'monas', 'alatrol', 'fexo', 'fenadin', 'tusca',
    'buscopan', 'antazol', 'histacin'
];
const HUMAN_MED_RES = HUMAN_ONLY_MEDS.map(med => ({
    med,
    test: new RegExp(`\\b${_reEsc(med)}\\b`, 'i'),
    replace: new RegExp(`\\b${_reEsc(med)}\\b`, 'gi')
}));
const detectHumanMedicine = text => text ? HUMAN_MED_RES.filter(m => m.test.test(text)).map(m => m.med) : [];

function replaceHumanMedicine(reply) {
    const found = detectHumanMedicine(reply);
    if (!found.length) return { text: reply, replaced: false };
    const cleaned = HUMAN_MED_RES
        .filter(m => found.includes(m.med))
        .reduce((t, m) => t.replace(m.replace, '[human med removed]'), reply);
    const warning = `\n\n⚠️ Safety: "${found.join(', ')}" — human medicines cannot be suggested.`;
    return { text: cleaned + warning, replaced: true };
}

const _tox = list => list.map(([name, effect]) => ({
    name, effect, re: new RegExp(`\\b${_reEsc(name)}\\b`, 'i')
}));
const _TOX_BIRD = _tox([
    ['avocado', 'heart failure'],
    ['salt', 'dehydration'],
    ['diclofenac', 'kidney failure, death'],
    ['ketoprofen', 'kidney failure']
]);
const _TOX_HUMAN_ABX = _tox([['human antibiotic', 'milk residue']]);
const _TOX_IVERM = _tox([['ivermectin overdose', 'nerve toxicity']]);
const SPECIES_TOXIC_MEDS = {
    cat: _tox([
        ['paracetamol', 'liver failure, death'],
        ['ibuprofen', 'kidney failure'],
        ['aspirin', 'bleeding, toxicity'],
        ['permethrin', 'nerve toxicity'],
        ['chocolate', 'heart/nerve toxicity'],
        ['onion', 'anemia'],
        ['garlic', 'anemia'],
        ['lily', 'kidney failure']
    ]),
    dog: _tox([
        ['paracetamol', 'liver damage'],
        ['ibuprofen', 'kidney damage, stomach ulcer'],
        ['xylitol', 'hypoglycemia'],
        ['chocolate', 'heart/nerve toxicity, seizures'],
        ['grapes', 'kidney failure'],
        ['raisins', 'kidney failure'],
        ['onion', 'anemia'],
        ['garlic', 'anemia']
    ]),
    bird: _TOX_BIRD, pigeon: _TOX_BIRD,
    cow: _TOX_HUMAN_ABX, buffalo: _TOX_HUMAN_ABX,
    goat: _TOX_IVERM, sheep: _TOX_IVERM,
    chicken: _tox([
        ['chloramphenicol', 'banned'],
        ['nitrofuran', 'banned'],
        ['ibuprofen', 'kidney failure'],
        ['diclofenac', 'kidney failure, death'],
        ['ketoprofen', 'kidney failure']
    ]),
    duck: _tox([
        ['chloramphenicol', 'banned'],
        ['diclofenac', 'kidney failure, death']
    ]),
    rabbit: _tox([['oral antibiotics', 'fatal enterotoxemia']]),
    horse: _tox([['ibuprofen', 'gastric ulcer']]),
    fish: _tox([['table salt overdose', 'osmotic shock']])
};
function checkSpeciesToxic(sources, species) {
    const list = species && SPECIES_TOXIC_MEDS[String(species).toLowerCase()];
    if (!list) return null;
    const lower = sources.filter(Boolean).join('\n').toLowerCase();
    const hits = list.filter(t => t.re.test(lower));
    if (!hits.length) return null;
    const lines = hits.map(t => `🚨 ${t.name} — DEADLY for ${species}! Effect: ${t.effect}`).join('\n');
    return `\n\n${lines}\n\nNEVER give these to your ${species}. If already eaten, see a vet immediately.`;
}

const DOSAGE_PATTERNS = [
    /\d+(\.\d+)?\s*(mg|mcg|µg|ug|ml|cc|iu|g)s?(?![a-z])\s*\/?\s*(kg\s*(bw)?)?/i
];
const KNOWN_DRUG_BRANDS = ['finadyne', 'vetalgin', 'meloxin', 'maxflox', 'renamycin', 'tylan', 'ivomec', 'panacur', 'baytril', 'combiotic', 'oxyvet', 'engemycin', 'nuflor', 'excenel', 'metacam', 'rimadyl'];
const KNOWN_BRANDS_RE = new RegExp(`\\b(?:${KNOWN_DRUG_BRANDS.join('|')})\\b`, 'i');

function scrubDosageAndBrands(reply) {
    let stripped = false;
    const isBad = s => DOSAGE_PATTERNS.some(p => p.test(s)) || KNOWN_BRANDS_RE.test(s);
    const out = [];
    reply.split('\n').forEach(line => {
        const kept = line.split(/(?<=[.!?])\s+/).filter(s => {
            const bad = isBad(s);
            stripped = stripped || bad;
            return !bad;
        }).join(' ');
        if (kept.trim() || !line.trim()) out.push(kept);
    });
    let text = out.join('\n').replace(/[ \t]{2,}/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
    if (stripped) text += '\n\n⚠️ Exact dose/brand left out — a vet should determine.';
    return { text, stripped };
}

function applyMedicalSafetyGuard(reply) {
    const result = replaceHumanMedicine(reply);
    const dosage = scrubDosageAndBrands(result.text);
    return { text: dosage.text, wasBlocked: result.replaced || dosage.stripped };
}

// ── LANGUAGE SAFETY ──
const DEVANAGARI_RE = /[\u0900-\u097F]+[ \t]*/g;
const HINDI_ONLY_WORDS = [
    'hai', 'nahi', 'nahin', 'kya', 'hoga', 'hogi', 'accha', 'acha',
    'theek hai', 'thik hai', 'matlab', 'bahut', 'yeh', 'woh', 'mujhe',
    'tumhe', 'tumhara', 'tumhari', 'aapka', 'aapki', 'aapko', 'karo',
    'kijiye', 'kripya', 'dhanyavaad', 'dhanyavad', 'shukriya hai',
    'ji haan', 'ji nahi', 'bhai sahab', 'kaise ho', 'kaise hain'
];
const HINDI_WORD_RES = HINDI_ONLY_WORDS.map(w => {
    const esc = _reEsc(w);
    return /\s/.test(w)
        ? new RegExp(`(?:^|\\s)${esc}(?=\\s|$|[.!?,])`, 'gi')
        : new RegExp(`\\b${esc}\\b`, 'gi');
});

function scrubHindi(text) {
    if (!text) return { text, hadHindi: false };
    let hadHindi = false;
    let cleaned = text.replace(DEVANAGARI_RE, () => { hadHindi = true; return ''; });
    HINDI_WORD_RES.forEach(re => {
        const next = cleaned.replace(re, '');
        hadHindi = hadHindi || next !== cleaned;
        cleaned = next;
    });
    return {
        text: hadHindi
            ? cleaned.replace(/[ \t]{2,}/g, ' ').replace(/[ \t]+([,.!?])/g, '$1')
                .replace(/^[ \t]+|[ \t]+$/gm, '').replace(/\n{3,}/g, '\n\n').replace(/^\n+|\n+$/g, '').trim()
            : cleaned,
        hadHindi
    };
}

function stripForeignScripts(text) {
    if (!text) return '';
    return text
        .replace(/[\u0980-\u09FF]/g, '')
        .replace(/[\u4E00-\u9FFF\u3400-\u4DBF]/g, '')
        .replace(/[\u0600-\u06FF\u0750-\u077F]/g, '')
        .replace(/[\u0400-\u04FF]/g, '')
        .replace(/[ \t]{2,}/g, ' ')
        .replace(/[ \t]+\n/g, '\n')
        .trim();
}

function enforceLanguage(reply) {
    if (!reply) return reply;
    return stripForeignScripts(reply);
}

// ═══════════════════════════════════════════════════════════
// 🧠 SYSTEM PROMPT
// ═══════════════════════════════════════════════════════════
const TASK_CONTEXTS = {
    math: 'User needs calculation/math help.', summary: 'User wants a summary.',
    writing: 'User wants writing help.', planning: 'User wants a plan.', code: 'User wants coding help.'
};

function buildSystemPrompt(p) {
    const { species, hasImage, mood, taskType, isCorrecting, useMemory, reference, triageForce, strictLang, triageRound, triageMax } = p;
    const rawName = userName && userName !== 'User' ? userName : 'the user';
    const safeName = rawName === 'the user' ? 'the user' : String(rawName).replace(/["`\\\n\r]/g, '').slice(0, 40);
    const nameRule = safeName !== 'the user'
        ? `\n🔤 NAME RULE: Always write the user's name exactly as "${safeName}" in English letters.`
        : '';
    const speciesContext = species
        ? `The user is asking about a ${species}. Answer ONLY about ${species}.`
        : `If species unclear, ask which animal.`;

    const imageContext = hasImage
        ? `User sent an image. 1) Identify the animal FIRST — CRITICAL: carefully distinguish GOAT vs COW. Goat = smaller body, may have beard/goatee, straight or backward-curving horns, short tail, narrow face. Cow = larger body, may have hump, larger horns, long tail, broad face. If unsure mark [CONF:LOW] and ask. 2) Describe ONLY visible signs 3) Give 1-2 most likely diseases 4) Don't mix earlier conversation 5) If unsure use [CONF:LOW]. ONLY if the image is unclear or two diseases are equally likely, ask at most ONE short question ([STAGE:ASK]); otherwise diagnose directly ([STAGE:DIAGNOSE]).`
        : '';

    const round = triageRound || 1, max = triageMax || 3;
    const triageRule = hasImage ? '' : `\n\n🩺 DIAGNOSIS STYLE (real vet intake):
- Factual question (vaccine, diet, care — no illness) → answer directly, [STAGE:DIAGNOSE].
- If illness: ask like a doctor — max 2 short NEW questions per round. Priority order:
  1) How long / when started
  2) Appetite/water / stool-urine-vomit
  3) Severity & other signs
  4) Age, vaccination/deworming, environment change
- Never re-ask info the user already gave. No diagnosis or medicine while asking.
- This is round ${round}/${max}. If user already gave animal + main symptom + duration + appetite/severity → diagnose now, no more questions.
- Emergency (bleeding, unconscious, seizure, poison, severe breathing) → no questions, emergency guidance + [STAGE:DIAGNOSE].
- While asking: NO emoji-heading structure; 1-2 friendly questions, each on its own line, then [STAGE:ASK].`;

    const triageForceNote = triageForce
        ? `\n\n🚨 MANDATORY: NO more questions. Using everything gathered, give your best-guess diagnosis in the full structure and you MUST output [STAGE:DIAGNOSE]. Use [CONF:LOW]/[CONF:MED] if unsure.`
        : '';

    const memoryHint = useMemory ? buildMemoryHint() : '';
    const emotionalGuide = getEmotionalGuidance(mood);
    const taskContext = TASK_CONTEXTS[taskType] || '';
    const correctionContext = isCorrecting ? 'User is correcting you. Acknowledge politely.' : '';

    const strictRetryNote = strictLang
        ? '\n\n🚨 RETRY MODE: Previous reply had wrong language. Reply ONLY in clean English now.'
        : '';

    const langRule = `\n\n🌐 STRICT LANGUAGE RULE (CRITICAL):
- Reply ONLY in clean English. Do NOT mix in words from other languages or other scripts.
- Correct: "Your cow has a fever. Keep her resting." Wrong: "Your cow has jor."
🚫🇮🇳 NEVER use Hindi words or Devanagari script (hai, nahi, kya, accha, matlab…).${strictRetryNote}`;

    const contextRule = `\n\n🚨 CONTEXT: Answer the LATEST message's topic. New animal/question → don't mix earlier info. If the user is answering your questions, combine with the earlier conversation.`;

    /* ✅ v12.7: no generic answers */
    const specificityRule = ALLOW_GENERIC_REPLIES ? '' : `\n\n🎯 NO GENERIC ANSWERS (CRITICAL):
- Every reply must be specific to THIS animal, THIS symptom and THIS situation.
- Never give a one-size-fits-all answer like "keep your pet clean and see a vet".
- If key details are missing (species, duration, appetite, severity), ask for those exact details first instead of giving broad advice.
- Do not pad the reply with generic disclaimers or filler.`;

    const stageRule = `\n\nSTAGE TAG (hidden, MANDATORY): On a NEW LINE add exactly one: [STAGE:ASK] (only clarifying questions, no diagnosis) or [STAGE:DIAGNOSE]. Never explain it.`;
    const confidenceRule = `\n\nCONFIDENCE TAG (hidden): At the END, on a NEW LINE: [CONF:HIGH] or [CONF:MED] or [CONF:LOW]. Never explain it.`;

    const formattingRule = `\n\n✨ TEXT STYLE:
- Each bullet on its own line; blank line between sections
- No Markdown **, ##, *
- Emoji headings: 🩺 📋 🏠 💊 🥗 🛡️ ⚠️ 🚨 💡`;

    const medicineRules = `\n\n🛡️ MEDICINE RULES:
❌ NEVER human medicines. ❌ No paracetamol/chocolate/onion for cats; no chocolate/grapes/onion for dogs; no diclofenac for birds/poultry.
✅ ONLY vet-approved generics (Enrofloxacin, Oxytetracycline, Albendazole, Fenbendazole, Ivermectin, Meloxicam (vet), Povidone-iodine, ORS, probiotics).
⚠️ Always say: "Exact dose should be confirmed by a vet".`;

    const completenessRule = `\n\n📋 STRUCTURE (when diagnosing): 🩺 Disease → 📋 Symptoms → 🏠 Home care → 💊 Medicine (generic) → 🥗 Diet → 🛡️ Prevention/⚠️ Warning. Length: 8-14 lines for new disease, 1-3 lines for small question.`;

    const vetSuggestionRule = `\n\n🩺 Vet-suggestion: routine → don't push; emergency → tell them to see a vet.`;

    const intro = `You are DailyVet AI — an experienced, empathetic veterinary assistant. The user's name is "${safeName}".`;
    const labels = ['EMOTIONAL: ', 'TASK: ', 'CORRECTION: '];
    const outro = `\nCore job: diagnose pet diseases, home-care advice, vet-approved medicines.\nGreeting: don't introduce yourself or add forced greetings; go straight to the topic.\nPersonality: Empathetic, concise.`;

    const referenceBlock = reference
        ? `\n\n📚 REFERENCE (supporting data, NOT the answer):\n${reference}\n⚠️ Use only if it directly matches; never copy verbatim; the triage rule still has priority.`
        : '';

    return `${intro}${nameRule}

${speciesContext}
${imageContext}
${memoryHint}

${emotionalGuide ? labels[0] + emotionalGuide : ''}
${taskContext ? labels[1] + taskContext : ''}
${correctionContext ? labels[2] + correctionContext : ''}
${langRule}
${contextRule}${specificityRule}
${triageRule}${triageForceNote}
${medicineRules}
${completenessRule}
${vetSuggestionRule}
${outro}${formattingRule}${referenceBlock}
${stageRule}
${confidenceRule}`;
}

function extractConfidence(reply) {
    if (!reply) return { text: '', confidence: 'MED' };
    const re = /\[\s*CONF\s*:\s*(HIGH|MED|LOW)\s*\]\.?/gi;
    const m = re.exec(reply);
    return m ? { text: reply.replace(re, '').trim(), confidence: m[1].toUpperCase() } : { text: reply, confidence: 'MED' };
}
/* ✅ v12.7: generic "preliminary advice" note only when generic replies are allowed */
const CONFIDENCE_NOTES = {
    LOW: '\n\n⚠️ Not fully certain — consult a vet.',
    ...(ALLOW_GENERIC_REPLIES ? { MED: '\n\n💡 Preliminary advice — see a vet if unsure.' } : {})
};
const applyConfidenceWarning = (reply, confidence) => reply + (CONFIDENCE_NOTES[confidence] || '');

function extractStage(reply) {
    if (!reply) return { text: '', stage: 'DIAGNOSE' };
    const re = /\[\s*STAGE\s*:\s*(ASK|DIAGNOSE)\s*\]\.?/gi;
    const m = re.exec(reply);
    return m ? { text: reply.replace(re, '').trim(), stage: m[1].toUpperCase() } : { text: reply, stage: 'DIAGNOSE' };
}

// ═══════════════════════════════════════════════════════════
// 🏥 NEARBY VETS
// ═══════════════════════════════════════════════════════════
const VET_TYPE_BY_SPECIES = {
    cow: 'dairy', buffalo: 'dairy', goat: 'dairy', sheep: 'dairy', horse: 'dairy',
    chicken: 'poultry', duck: 'poultry', pigeon: 'poultry',
    dog: 'pet', cat: 'pet', rabbit: 'pet', bird: 'pet', fish: 'pet'
};
const VET_TYPE_LABEL = { dairy: 'Dairy', pet: 'Pet', poultry: 'Poultry', general: 'General' };
const _lowerList = v => Array.isArray(v) ? v.map(t => String(t).toLowerCase()) : [];

async function findNearbyVets(species, symptom) {
    try {
        const snap = await _fs().collection('vets').where('available', '==', true).limit(50).get();
        if (snap.empty) return [];
        const all = [];
        snap.forEach(doc => { const d = doc.data(); if (d && d.name) all.push(d); });
        if (!all.length) return [];

        const speciesTag = species ? String(species).toLowerCase() : null;
        const wantType = speciesTag ? VET_TYPE_BY_SPECIES[speciesTag] : null;
        const symptomTag = symptom ? String(symptom).toLowerCase() : null;
        const extraTags = [];
        if (['skin', 'wound'].includes(symptomTag)) extraTags.push('surgery');
        if (['bleeding', 'emergency', 'poisoning', 'neuro'].includes(symptomTag)) extraTags.push('emergency');

        const ranked = all.map(vet => {
            const tags = [..._lowerList(vet.treatments), ..._lowerList(vet.specialties)];
            const score =
                (speciesTag && tags.includes(speciesTag) ? 20 : 0) +
                (wantType && vet.type === wantType ? 10 : 0) +
                (symptomTag && String(vet.speciality || '').toLowerCase().includes(symptomTag) ? 5 : 0) +
                (extraTags.some(t => tags.includes(t)) ? 5 : 0) +
                (vet.verified ? 1 : 0);
            return { vet, score };
        }).filter(x => x.score > 1 || (x.score > 0 && !x.vet.verified)).sort((a, b) => b.score - a.score);

        return ranked.length === 0 ? all.slice(0, 3) : ranked.slice(0, 3).map(x => x.vet);
    } catch (error) {
        console.warn('Vet fetch failed:', error.message);
        return [];
    }
}

function formatVetSuggestion(vets) {
    const lines = vets.map(v => {
        const spec = v.speciality || VET_TYPE_LABEL[v.type] || 'Veterinarian';
        const loc = v.location || v.city || '';
        return `👨‍⚕️ ${v.name || 'Vet'}\n   ${spec}${loc ? ' · ' + loc : ''}${v.phone ? '\n   📞 ' + v.phone : ''}`;
    });
    return `\n\n🏥 Nearby Veterinarians:\n\n${lines.join('\n\n')}` + VET_HOTLINE;
}

const IMAGE_PROMPT = `First identify the animal carefully (GOAT vs COW: goat=smaller body, may have beard, straight/back-curving horns; cow=larger body, may have hump). Then describe visible signs and likely disease. Structure: 🩺 📋 🏠 💊 🥗 🛡️ ⚠️ (each bullet on its own line)`;

// ═══════════════════════════════════════════════════════════
// 🤖 PROVIDER CALLS
// ═══════════════════════════════════════════════════════════
function _parseImage(img) {
    const m = /^data:([^;]+);base64,(.*)$/.exec(img || '');
    return m ? { mime: m[1], data: m[2] } : { mime: 'image/jpeg', data: img };
}
function _historyForApi() {
    const h = conversationHistory.filter(m => m && m.content);
    while (h.length && h[0].role !== 'user') h.shift();
    return h;
}

function _geminiRequest(slot, a, useSearch) {
    const hasImage = !!a.imageBase64;
    const contents = _historyForApi().map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] }));
    if (hasImage) {
        const { mime, data } = _parseImage(a.imageBase64);
        contents.push({
            role: 'user',
            parts: [
                { inline_data: { mime_type: mime, data } },
                { text: a.userMessage ? `${a.userMessage}\n\n(Answer only from what is visible in the image, following the structure. Each bullet on its own line.)` : IMAGE_PROMPT }
            ]
        });
    } else {
        contents.push({ role: 'user', parts: [{ text: a.userMessage }] });
    }
    const generationConfig = { temperature: hasImage ? 0.3 : 0.7, maxOutputTokens: hasImage ? 1800 : 1400, topP: 1 };
    if (slot.model.includes('2.5')) generationConfig.thinkingConfig = { thinkingBudget: 0 };
    const body = {
        system_instruction: { parts: [{ text: useSearch ? a.systemPromptSearch : a.systemPrompt }] },
        contents, generationConfig, safetySettings: GEMINI_SAFETY
    };
    if (useSearch) body.tools = [{ google_search: {} }];
    return {
        url: `${ENDPOINTS.gemini}/${slot.model}:generateContent?key=${slot.key}`,
        headers: { 'Content-Type': 'application/json' },
        body
    };
}

function _chatRequest(slot, a) {
    const hasImage = !!a.imageBase64;
    const userContent = hasImage
        ? [
            { type: 'text', text: a.userMessage || IMAGE_PROMPT },
            { type: 'image_url', image_url: { url: a.imageBase64.startsWith('data:') ? a.imageBase64 : `data:image/jpeg;base64,${a.imageBase64}` } }
        ]
        : a.userMessage;
    const reasoning = /gpt-oss|qwen3|qwen-3/i.test(slot.model);
    const body = {
        model: slot.model,
        messages: [
            { role: 'system', content: a.systemPrompt },
            ..._historyForApi().map(m => ({ role: m.role, content: m.content })),
            { role: 'user', content: userContent }
        ],
        temperature: hasImage ? 0.3 : 0.7,
        max_tokens: hasImage ? 1800 : (reasoning ? 2200 : 1500)
    };
    if (reasoning && slot.provider === 'groq') Object.assign(body, { reasoning_effort: 'low', include_reasoning: false });
    const headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${slot.key}` };
    if (slot.provider === 'openrouter') {
        headers['HTTP-Referer'] = location.origin || 'https://dailyvet.app';
        headers['X-Title'] = 'DailyVet';
    }
    return { url: ENDPOINTS[slot.provider], headers, body };
}

function _onHttpError(slot, status, retryAfter, bodyText) {
    const body = String(bodyText || '').slice(0, 500);
    _log(`${slot.provider}/${slot.model} HTTP ${status} (…${_tail(slot.key)})`, body);
    if (status === 429) {
        const n = (_strikes.get(slot.id) || 0) + 1;
        _strikes.set(slot.id, n);
        const hinted = (parseInt(retryAfter, 10) || 0) * 1000;
        let ms = Math.min(Math.max(hinted, COOLDOWN.rateLimit * 2 ** (n - 1)), COOLDOWN.rateLimitMax);
        if (/limit:\s*0/i.test(body)) ms = COOLDOWN.quotaZero;
        else if (/PerDay|per\s*day/i.test(body)) ms = COOLDOWN.perDay;
        _block(slot.id, ms);
    } else if (status === 400) {
        if (/api[_ ]key (?:not valid|invalid|expired)|API_KEY_INVALID|key expired/i.test(body)) _block(_keyId(slot), COOLDOWN.authKey);
        else _block(slot.id, COOLDOWN.badRequest);
    } else if (status === 401 || status === 403) {
        _block(_keyId(slot), COOLDOWN.authKey);
    } else if (status === 404) {
        _block(_modelId(slot), COOLDOWN.modelGone);
    } else if (status >= 500 || status === 408) {
        _block(slot.id, COOLDOWN.server);
    }
}

async function _callSlot(slot, a, ctrl, timeoutMs) {
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; ctrl.abort(); }, timeoutMs);
    try {
        if (a.onProvider) { try { a.onProvider(slot.provider); } catch (_) {} }
        let noSearch = false;
        for (let attempt = 0; attempt < 2; attempt++) {
            const useSearch = slot.provider === 'gemini' && !a.imageBase64 && !noSearch && _searchAvailable();
            const req = slot.provider === 'gemini' ? _geminiRequest(slot, a, useSearch) : _chatRequest(slot, a);

            /* Proxy-aware: on Netlify/Vercel keys stay on server only */
            let data;
            const useProxy = typeof DV_AI_PROXY !== 'undefined' && DV_AI_PROXY.isProxyMode && DV_AI_PROXY.isProxyMode();
            if (useProxy) {
                try {
                    data = await DV_AI_PROXY.call({
                        provider: slot.provider,
                        model: slot.model,
                        body: req.body,
                        keyIndex: (PROVIDER_KEYS[slot.provider] || []).indexOf(slot.key),
                        timeoutMs: timeoutMs
                    });
                } catch (proxyErr) {
                    const resStatus = proxyErr.status || 502;
                    const errBody = (proxyErr.data && (proxyErr.data.error || JSON.stringify(proxyErr.data))) || proxyErr.message || '';
                    if (resStatus === 400 && useSearch && /tool|search|grounding/i.test(errBody) && !/api[_ ]key/i.test(errBody)) {
                        searchBlockedUntil = Date.now() + SEARCH_PAUSE_MS;
                        _lsSet(SEARCH_STORE, String(searchBlockedUntil));
                        noSearch = true;
                        continue;
                    }
                    if (resStatus === 429 && useSearch && /ground|google_search/i.test(errBody)) {
                        searchBlockedUntil = Date.now() + SEARCH_PAUSE_MS;
                        _lsSet(SEARCH_STORE, String(searchBlockedUntil));
                        noSearch = true;
                        continue;
                    }
                    _onHttpError(slot, resStatus, null, errBody);
                    return null;
                }
            } else {
                const res = await fetch(req.url, { method: 'POST', headers: req.headers, body: JSON.stringify(req.body), signal: ctrl.signal });
                if (!res.ok) {
                    const errBody = await res.text().catch(() => '');
                    if (res.status === 400 && useSearch && /tool|search|grounding/i.test(errBody) && !/api[_ ]key/i.test(errBody)) {
                        searchBlockedUntil = Date.now() + SEARCH_PAUSE_MS;
                        _lsSet(SEARCH_STORE, String(searchBlockedUntil));
                        noSearch = true;
                        continue;
                    }
                    if (res.status === 429 && useSearch && /ground|google_search/i.test(errBody)) {
                        searchBlockedUntil = Date.now() + SEARCH_PAUSE_MS;
                        _lsSet(SEARCH_STORE, String(searchBlockedUntil));
                        noSearch = true;
                        continue;
                    }
                    _onHttpError(slot, res.status, res.headers.get('retry-after'), errBody);
                    return null;
                }
                data = await res.json();
            }
            let raw, searchInfo = null;
            if (slot.provider === 'gemini') {
                const cand = data.candidates?.[0];
                raw = (cand?.content?.parts || []).filter(p => p && p.text && !p.thought).map(p => p.text).join('');
                const gm = cand?.groundingMetadata;
                if (gm && ((gm.webSearchQueries || []).length || (gm.groundingChunks || []).length)) {
                    searchInfo = {
                        queries: gm.webSearchQueries || [],
                        sources: [...new Set((gm.groundingChunks || []).map(c => c?.web?.title).filter(Boolean))]
                    };
                }
            } else {
                raw = data.choices?.[0]?.message?.content;
            }
            const reply = raw ? stripMarkdown(raw) : '';
            if (!reply) return null;

            _strikes.delete(slot.id);
            const keys = PROVIDER_KEYS[slot.provider].filter(Boolean);
            _rot[slot.provider] = keys.indexOf(slot.key) + 1;
            return { reply, searchInfo };
        }
        return null;
    } catch (err) {
        if (timedOut) _block(slot.id, COOLDOWN.timeout);
        else if (!ctrl.signal.aborted) _block(slot.id, COOLDOWN.server);
        return null;
    } finally {
        clearTimeout(timer);
    }
}

/* ✅ v12.8: hedged cascade — slot #1 starts at once; if it fails the next
   slot starts immediately; if it is merely slow, a backup starts every
   cfg.hedge ms (up to cfg.parallel in flight). First good reply wins. */
function _cascade(slots, a, cfg) {
    return new Promise(resolve => {
        let next = 0, inflight = 0, done = false, deadline = null, hedgeT = null;
        const ctrls = new Set();
        const preBlocked = new Set(slots.filter(_slotBlocked).map(sl => sl.id));
        const skipSlot = sl => _slotBlocked(sl) && !preBlocked.has(sl.id);
        const finish = result => {
            if (done) return;
            done = true;
            clearTimeout(deadline);
            clearTimeout(hedgeT);
            ctrls.forEach(c => { try { c.abort(); } catch (_) {} });
            resolve(result);
        };
        const launch = () => {
            if (done || inflight >= cfg.parallel) return;
            while (next < slots.length && skipSlot(slots[next])) next++;
            if (next >= slots.length) {
                if (!inflight) finish(null);
                return;
            }
            const slot = slots[next++];
            const ctrl = new AbortController();
            ctrls.add(ctrl);
            inflight++;
            _callSlot(slot, a, ctrl, cfg.perCall).then(res => {
                ctrls.delete(ctrl);
                inflight--;
                if (res) {
                    finish({ provider: slot.provider, model: slot.model, reply: res.reply, searchInfo: res.searchInfo });
                } else {
                    launch(); // failed → next slot right away
                }
            }).catch(() => {
                ctrls.delete(ctrl);
                inflight--;
                launch();
            });
        };
        const scheduleHedge = () => {
            hedgeT = setTimeout(() => {
                if (done) return;
                launch();
                if (next < slots.length) scheduleHedge();
            }, cfg.hedge);
        };
        deadline = setTimeout(() => finish(null), cfg.total);
        launch();         // primary (Gemini) first
        scheduleHedge();  // backup if primary is slow
    });
}

async function askAI(a) {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) return null;
    const hasImage = !!a.imageBase64;
    const slots = _buildSlots(hasImage);
    if (!slots.length) return null;
    a.systemPrompt = buildSystemPrompt({
        species: a.species, hasImage, mood: a.mood, taskType: a.taskType,
        isCorrecting: a.isCorrecting, useMemory: a.useMemory, reference: a.reference,
        triageForce: a.triageForce, strictLang: !!a.strictLang,
        triageRound: a.triageRound, triageMax: a.triageMax
    });
    a.systemPromptSearch = a.systemPrompt + GEMINI_SEARCH_NOTE;
    const cfg = hasImage ? TIMING.vision : TIMING.text;
    const budget = Math.min(cfg.total, a.budgetMs || cfg.total);
    return _cascade(slots, a, { ...cfg, total: budget });
}

function stripMarkdown(text) {
    if (!text) return '';
    return _nl(text
        .replace(/<think>[\s\S]*?<\/think>/gi, '')
        .replace(/^\s*[*]\s+/gm, '• ')
        .replace(/\*\*(.+?)\*\*/g, '$1')
        .replace(/\*(.+?)\*/g, '$1')
        .replace(/`(.+?)`/g, '$1')
        .replace(/^#+\s*/gm, ''))
        .replace(/[ \t]+\n/g, '\n')
        .replace(/\n{3,}/g, '\n\n')
        .trim();
}

const _PREMIUM_EMOJI_RES = ['🩺', '📋', '🏠', '💊', '🥗', '🛡️', '⚠️', '🚨', '💡', '👨‍⚕️', '📞']
    .map(em => new RegExp(`([^\\n])\\s*(${_reEsc(em)})`, 'g'));

function forcePremiumFormatting(text) {
    if (!text) return '';
    let t = _PREMIUM_EMOJI_RES.reduce((acc, re) => acc.replace(re, '$1\n\n$2'), _nl(text));
    t = t.replace(/([^\n])\s*(•|🔹|▪|‣|●|○)\s*/g, '$1\n$2 ');
    t = t.replace(/([.!?\n])\s+-\s+/g, '$1\n• ');
    return t.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').replace(/^\n+/, '').trim();
}

// ── QUICK REPLIES ──
const QUICK_REPLIES = {
    greeting: n => n ? `${n.trim()}, tell me about your pet's problem — text or photo. 🐾` : `Tell me about your pet's problem — text or photo. 🐾`,
    howAreYou: n => n ? `${n.trim()}, I'm doing well. What's your pet's problem? 🐾` : `I'm doing well. What's your pet's problem? 🐾`,
    thanks: () => `You're welcome! Take good care of your pet. 🐾`
};
const QUICK_HOWAREYOU_RE = /how\s*(?:are|r)\s*(?:you|u|ya)(?![a-z])|how\s*is\s*it\s*going|what'?s\s*up(?![a-z])|how\s*do\s*you\s*do(?![a-z])/i;
const QUICK_GREETING_RE = /^(?:hi+|hello+|helo|hallo|hey+|yo|assalam\w*|salam|slm|good\s*(?:morning|afternoon|evening|night))(?![a-z])/i;
const QUICK_THANKS_RE = /^(?:thanks?|thank\s*(?:you|u)|thx|tnx|ty)(?![a-z])/i;
const QUICK_GREETINGS = [
    [/assalam|salam/i, 'Wa alaikum assalam'],
    [/good\s*morning/i, 'Good morning'],
    [/good\s*evening/i, 'Good evening']
];

function getQuickReply(text, hasPetContent) {
    if (!text || hasPetContent) return null;
    const clean = text.toLowerCase().replace(/[!?.,;:"~*]+/g, ' ').replace(/\s+/g, ' ').trim();
    if (!clean || clean.split(' ').length > 7) return null;

    const first = userName && userName !== 'User' ? userName.split(' ')[0] : '';
    const n = first ? ' ' + first : '';
    const isHowAreYou = QUICK_HOWAREYOU_RE.test(clean);

    const g = QUICK_GREETINGS.find(([re]) => re.test(clean));
    return g ? { type: 'greeting', reply: `${first ? first + ', ' : ''}${g[1]}. Tell me about your pet's problem. 🐾` }
        : isHowAreYou ? { type: 'howAreYou', reply: QUICK_REPLIES.howAreYou(n) }
        : QUICK_GREETING_RE.test(clean) ? { type: 'greeting', reply: QUICK_REPLIES.greeting(n) }
        : QUICK_THANKS_RE.test(clean) ? { type: 'thanks', reply: QUICK_REPLIES.thanks() }
        : null;
}

// ═══════════════════════════════════════════════════════════
// 📚 LOCAL KNOWLEDGE BASE
// ═══════════════════════════════════════════════════════════
const KB_TEXT = {
    vaccine: '💉 Vaccination Schedule\n\n🐄 Cattle:\n• FMD: every 6 months\n• Anthrax: yearly\n• HS: yearly\n• BQ: yearly\n\n🐐 Goat:\n• PPR: at 3-4 months\n• FMD: every 6 months\n• Enterotoxaemia: yearly\n\n🐕 Dog:\n• DHPP: from 6-8 weeks, 3 doses\n• Rabies: at 12 weeks, yearly booster\n\n🐈 Cat:\n• FVRCP: from 6-8 weeks, 3 doses\n• Rabies: at 12 weeks\n\n🐔 Poultry:\n• Ranikhet/ND: day 7 & 28\n• Gumboro: day 14\n• Fowl Pox: week 6\n\n⚠️ Confirm with a licensed vet.',
    emergency: '🚨 EMERGENCY — Do This Now\n\n1. Keep the animal calm\n2. Go to the nearest vet\n3. Call helpline 16358\n\n⚠️ Never delay with these signs:\n• Seizure / unconscious\n• Difficulty breathing\n• Heavy bleeding\n• Poisoning\n• Labor complications',
    deworm: '🪱 Deworming Schedule\n\n🐄 Cattle: every 3-6 months\n🐐 Goat: every 3 months\n🐕 Dog: every 3 months\n🐈 Cat: every 3-6 months\n🐔 Poultry: every 6-8 weeks\n\n💊 Common dewormers:\n• Albendazole / Fenbendazole (bolus)\n• Ivermectin (injection)\n\n⚠️ A vet decides the exact dose.',
    fever: '🩺 Fever\n\n📋 Symptoms:\n• Hot body\n• Reduced appetite\n• Weakness\n• Eye/nose discharge\n\n🏠 Home Care:\n• Keep in shade\n• Plenty of water\n• Cool compress (if needed)\n\n💊 Treatment: Consult a vet.\n\n⚠️ Fever > 3 days → see a vet.\n\n📞 Helpline: 16358',
    diarrhea: '🩺 Diarrhea\n\n📋 Symptoms:\n• Frequent stools\n• Water/blood\n• Weakness\n• Sunken eyes\n\n🏠 Home Care:\n• ORS / saline\n• Clean water\n• Isolate\n\n💊 Treatment: Vet-prescribed antibiotics (if needed).\n\n⚠️ Blood present → see a vet fast.\n\n📞 Helpline: 16358',
    appetite: '🩺 Loss of Appetite\n\n📋 Causes:\n• Fever\n• Dental issues\n• Stomach problems\n• Worms\n• Stress\n\n🏠 Home Care:\n• Offer favorite food\n• Soft food\n• Quiet environment\n\n⚠️ > 24 hours without eating → urgent.\n\n📞 Helpline: 16358',
    wound: '🩺 Wound / Injury\n\n📋 First Aid:\n• Wash with clean water\n• Apply Povidone-iodine\n• Prevent flies\n• Clean bandage\n\n⚠️ Don\'t:\n• Apply raw turmeric\n• Use stale products\n\n💊 If maggots → vet-prescribed Ivermectin.\n\n📞 Helpline: 16358',
    milk: '🥛 Increasing Milk Yield\n\n• Balanced diet with green fodder\n• Plenty of clean water\n• Regular milking times\n• Mineral mixture\n• Regular deworming\n\n⚠️ A sudden drop can signal illness (e.g. mastitis) — see a vet.',
    catFood: '🐈 Cat Food\n\n• High protein (cooked fish/chicken)\n• Taurine-fortified cat food\n• Clean water\n\n❌ Toxic: chocolate, onion, garlic, raw egg whites.',
    dogFood: '🐕 Dog Food\n\n• Cooked meat/chicken (no bones), rice, vegetables\n• Quality commercial dog food\n\n❌ Toxic: chocolate, onion, garlic, grapes/raisins, avocado, xylitol.'
};
const _kbMap = (text, keys) => Object.fromEntries(keys.map(k => [k, text]));
const DAILYVET_KB = {
    ..._kbMap(KB_TEXT.vaccine, ['cow vaccination schedule', 'goat vaccination', 'dog vaccination', 'cat vaccination', 'chicken vaccination', 'vaccine schedule', 'vaccination', 'cow vaccine', 'dog vaccine', 'cat vaccine', 'poultry vaccine', 'vaccine']),
    ..._kbMap(KB_TEXT.emergency, ['emergency', 'urgent', 'seizure', 'unconscious']),
    ..._kbMap(KB_TEXT.deworm, ['deworming', 'deworm', 'worms', 'worm']),
    ..._kbMap(KB_TEXT.fever, ['fever']),
    ..._kbMap(KB_TEXT.diarrhea, ['diarrhea', 'loose motion']),
    ..._kbMap(KB_TEXT.appetite, ['appetite', 'not eating']),
    ..._kbMap(KB_TEXT.wound, ['wound', 'injury']),
    ..._kbMap(KB_TEXT.milk, ['increase milk', 'milk yield', 'increase cow milk']),
    ..._kbMap(KB_TEXT.catFood, ['cat food']),
    ..._kbMap(KB_TEXT.dogFood, ['dog food'])
};

function getFromKB(text) {
    if (!text) return null;
    const lower = text.toLowerCase();
    const hit = Object.entries(DAILYVET_KB).find(([k]) => findKeywordIndex(lower, k.toLowerCase()) !== -1);
    return hit ? hit[1] : null;
}

// ── LAYER 3: PATTERN MATCHING (generic canned — only used if ALLOW_GENERIC_REPLIES) ──
const LOCAL_TOPICS = [
    {
        pattern: /^(?:hi+|hello+|helo|hallo|hey+|yo|assalam\w*|salam|slm)(?![a-z])/i,
        reply: 'Hello! 🐾 What is the problem with your pet? Describe symptoms or send a photo.'
    },
    {
        pattern: /^(?:thanks?|thank\s*(?:you|u)|thx|tnx|ty)(?![a-z])/i,
        reply: 'You\'re welcome! 🐾 Take good care of your pet. Ask again anytime.'
    },
    {
        pattern: /veterinar|vet\b|doctor|clinic|hospital/i,
        reply: '🏥 To find a nearby vet, use the location button.\n\nOr call 24/7 helpline: 📞 16358'
    },
    {
        pattern: /(?:price|cost|how\s*much\s*money)/i,
        reply: '💰 Treatment cost varies with disease, animal, and location. Contact a nearby vet for an accurate estimate.'
    },
    {
        pattern: /(?:help|assist)/i,
        reply: '🆘 Here\'s how I can help:\n\n• 🩺 Diagnose from symptoms\n• 💊 Medicine names (generic)\n• 🏠 Home care\n• 🥗 Diet advice\n• 💉 Vaccination schedule\n\nTell me your pet\'s problem — send a photo if possible.'
    }
];
function getLocalFallbackReply(text) {
    if (!text) return null;
    for (const topic of LOCAL_TOPICS) if (topic.pattern.test(text)) return topic.reply;
    return null;
}

const FRIENDLY_FALLBACK = '🩺 Online service is slow right now — I can still help.\n\nPlease write:\n• Which animal (cow/goat/dog/cat…)\n• Main symptom (fever/vomit/diarrhea…)\n• How long\n• Appetite/water intake\n\nExample: "My cow has fever for 2 days, not eating"\n\n🚨 Emergency → go to a vet now or call: 📞 16358';

// ── DISEASE DATABASE ──
let diseaseCache = null;
let diseaseCacheTime = 0;
const DISEASE_CACHE_TTL = 5 * 60 * 1000;

async function getDiseasesFromDB() {
    const now = Date.now();
    if (diseaseCache && now - diseaseCacheTime < DISEASE_CACHE_TTL) return diseaseCache;
    try {
        const snap = await _fs().collection('diseases').limit(100).get();
        if (snap.empty) return [];
        const arr = [];
        snap.forEach(doc => arr.push(doc.data()));
        diseaseCache = arr;
        diseaseCacheTime = now;
        return arr;
    } catch (err) {
        console.warn('Disease DB load failed:', err.message);
        return diseaseCache || [];
    }
}

async function lookupDiseaseFromDB(userText, species, symptom) {
    if (!userText || (!species && !symptom)) return null;
    const diseases = await getDiseasesFromDB();
    if (!diseases.length) return null;

    const lower = userText.toLowerCase();
    let best = null, bestScore = 0;

    diseases.forEach(d => {
        let score = 0, evidence = 0;
        const hit = pts => { score += pts; evidence += pts; };
        if (species && d.animal_type) {
            const dAnimal = String(d.animal_type).toLowerCase();
            const key = species.toLowerCase();
            const matched = dAnimal.includes(key) ||
                (key === 'chicken' && dAnimal.includes('poultry')) ||
                (key === 'cow' && dAnimal.includes('cattle'));
            if (!matched) return;
            score += 10;
        }
        if (d.disease_name_en && lower.includes(d.disease_name_en.toLowerCase())) hit(15);
        if (d.disease_name_local && lower.includes(String(d.disease_name_local).toLowerCase())) hit(12);
        (d.tags || []).forEach(tag => { if (tag.length >= 3 && lower.includes(tag.toLowerCase())) hit(5); });
        (d.symptoms?.en || []).forEach(s => {
            const sl = String(s).toLowerCase();
            if (sl.length >= 4 && lower.includes(sl)) hit(4);
        });
        if (evidence === 0) return;
        if (score > bestScore) { bestScore = score; best = d; }
    });
    return bestScore >= 10 ? best : null;
}

function formatDiseaseFromDB(d) {
    const name = d.disease_name_en || 'Condition';
    const block = (title, items, max) => items.length ? `${title}\n${items.slice(0, max).map(i => `• ${i}`).join('\n')}\n\n` : '';
    return `🩺 ${name}\n\n` +
        block('📋 Symptoms:', d.symptoms?.en || [], 5) +
        block('🏠 Home Care:', d.home_care?.en || [], 4) +
        block('💊 Medicine:', (d.treatment || []).map(t => t.generic_name + (t.purpose ? ` — ${t.purpose}` : '')), 3) +
        block('🥗 Diet:', d.diet_advice?.do?.en || [], 3) +
        block('🛡️ Prevention:', d.prevention?.en || [], 3) +
        '💡 For proper treatment, consult a vet.';
}

// ── EMERGENCY / PERSONALIZATION ──
const EMERGENCY_KEYWORDS = [
    'bleeding', 'seizure', 'unconscious', 'poison', 'poisoned', 'choking', 'accident',
    'hit by', 'snake bite',
    'not breathing', 'difficulty breathing', 'gasping', 'labor complication', 'stuck delivery',
    'prolapse', 'heat stroke', 'heatstroke', 'paralysis', 'collapsed', 'collapse',
    'cannot stand', "can't stand", 'unable to stand',
    'blood'
];
const checkEmergency = text => {
    if (!text) return false;
    const lower = text.toLowerCase();
    return EMERGENCY_KEYWORDS.some(k => findKeywordIndex(lower, k.toLowerCase()) !== -1);
};

function personalizeReply(text) {
    if (!userName || userName === 'User' || !text) return text;
    const firstName = userName.split(' ')[0];
    if (text.startsWith(firstName + ',') || text.startsWith(firstName + ' ')) return text;

    const isComfortOrEmergency = /sorry|don't worry|emergency|🚨/i.test(text);
    if (nameGreeted && !isComfortOrEmergency) return text;

    nameGreeted = true;
    return `${firstName}, ${text}`;
}

// ═══════════════════════════════════════════════════════════
// 🖼️ RENDERING
// ═══════════════════════════════════════════════════════════
function formatAiLine(line) {
    const isBullet = /^\s*(?:•|🔹|▪|‣|●|○|-|–)\s/.test(line);
    if (isBullet) return escapeHtml(line);
    if (/^\s*(?:\S{1,20},\s+)?🩺/.test(line)) return `<strong>${escapeHtml(line)}</strong>`;
    const m = line.match(/^(\s*[^\n:：]{1,45}?[:：])(?=\s|$)(.*)$/u);
    return m ? `<strong>${escapeHtml(m[1])}</strong>${escapeHtml(m[2])}` : escapeHtml(line);
}

function _buildMessageEl(type, text, imageBase64, allowGoogleButtons, ts) {
    const isAi = type === 'ai';
    const div = document.createElement('div');
    div.className = `message ${type}-message`;
    const time = (ts ? new Date(ts) : new Date()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const avatar = isAi
        ? `<div class="avatar ai-avatar-small"><img src="assets/dailyvetlogo.jpeg" alt="AI" /></div>`
        : `<div class="avatar user-avatar">${_userAvatarHTML()}</div>`;

    let content = imageBase64 ? `<div class="bubble-image"><img src="${escapeHtml(imageBase64)}" alt="Sent" /></div>` : '';
    if (text) {
        const hasGoogleOption = text.includes(GOOGLE_OPTION_TOKEN);
        const body = text.replace(GOOGLE_OPTION_TOKEN, '').trim().replace(/\\n/g, '\n');
        const formatted = isAi
            ? body.split('\n').map(formatAiLine).join('<br>')
            : escapeHtml(body).replace(/\n/g, '<br>');
        content += `<p style="white-space:pre-wrap;line-height:1.6;margin:0 0 8px;">${formatted}</p>`;

        if (hasGoogleOption && isAi && allowGoogleButtons) {
            content += `
                <div class="google-search-options">
                    <button class="google-opt-btn google-yes-btn" onclick="handleGoogleSearchYes()">
                        <i class="fas fa-check"></i><span>Yes, search on Google</span>
                    </button>
                    <button class="google-opt-btn google-no-btn" onclick="handleGoogleSearchNo()">
                        <i class="fas fa-times"></i><span>No, this is enough</span>
                    </button>
                </div>`;
        }
    }
    content += `<span class="timestamp">${time}</span>`;
    const bubble = `<div class="bubble">${content}</div>`;
    div.innerHTML = isAi ? avatar + bubble : bubble + avatar;
    return div;
}

function addMessage(type, text, imageBase64) {
    const container = _el('chatMessages');
    if (!container) return;
    container.appendChild(_buildMessageEl(type, text, imageBase64, type === 'ai'));
    _scrollChatToBottom();
    if (type === 'user') {
        if (cachedUserPhoto === null) getUserPhoto().then(_refreshUserAvatars);
        const chips = _el('suggestionChips');
        if (chips) chips.style.display = 'none';
    }
}

// ═══════════════════════════════════════════════════════════
// ✨ AI THINKING LOADER
// ═══════════════════════════════════════════════════════════
const THINK_TEXTS = {
    default: ['DailyVet is searching', 'DailyVet is analyzing', 'DailyVet is preparing response', 'DailyVet is almost ready'],
    vision: ['DailyVet is looking at the photo', 'DailyVet is analyzing the image', 'DailyVet is preparing response', 'DailyVet is almost ready']
};
const THINK_TEXT_INTERVAL_MS = 1500;

const THINK_ICONS = {
    google: '<svg viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>',
    gemini: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M12 0C12 6.63 6.63 12 0 12c6.63 0 12 5.37 12 12 0-6.63 5.37-12 12-12-6.63 0-12-5.37-12-12z"/></svg>',
    groq: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect width="24" height="24" rx="6" fill="#F55036"/><path d="M16.7 9.2A5.5 5.5 0 1 0 17.5 12H12.5" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round"/></svg>',
    openrouter: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="10" fill="#6E56CF"/><path d="M8 12h8M12 8v8" stroke="#fff" stroke-width="2" stroke-linecap="round"/></svg>',
    book: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>',
    pill: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"/><path d="m8.5 8.5 7 7"/></svg>'
};
const _BRAND_ICONS = ['google', 'gemini', 'groq', 'openrouter'];
const _iconHtml = name => _BRAND_ICONS.includes(name)
    ? `<span class="dv-ic dv-ic-${name}">${THINK_ICONS[name]}</span>`
    : THINK_ICONS[name];

const THINK_SOURCES = [
    { id: 'db', label: 'Disease DB', icon: 'book' },
    { id: 'kb', label: 'Medicine KB', icon: 'pill' },
    { id: 'google', label: 'Google Search', icon: 'google' },
    { id: 'gemini', label: 'Gemini', icon: 'gemini' },
    { id: 'groq', label: 'Groq', icon: 'groq' },
    { id: 'openrouter', label: 'OpenRouter', icon: 'openrouter' }
];
const THINK_STAGES = {
    db: ['db'], kb: ['kb'],
    ai: ['gemini', 'google'], vision: ['gemini'],
    gemini: ['gemini', 'google'], groq: ['groq'], openrouter: ['openrouter']
};
let _thinkTimers = [];

function ensureThinkingStyles() {
    if (_el('dvThinkStyles')) return;
    const s = document.createElement('style');
    s.id = 'dvThinkStyles';
    s.textContent = `
.dv-avatar{width:32px;height:32px;min-width:32px;border-radius:50%;overflow:hidden;flex-shrink:0;border:1.5px solid #b2e0e6;background:#fff}
.dv-avatar img{width:100%;height:100%;object-fit:cover;border-radius:50%;display:block}
.dv-think{position:relative;overflow:hidden;background:#eef7f8;border:1px solid rgba(178,224,230,.7);border-radius:18px 18px 18px 4px;padding:12px 16px;max-width:300px;box-shadow:0 4px 12px rgba(3,93,105,.08)}
.dv-think::after{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(90deg,transparent,rgba(178,224,230,.4),transparent);transform:translateX(-100%);animation:dvShimmer 2s ease-in-out infinite}
@keyframes dvShimmer{0%{transform:translateX(-100%)}60%,100%{transform:translateX(100%)}}
.dv-row{display:flex;align-items:center;gap:8px;position:relative;z-index:1}
.dv-dots{display:inline-flex;align-items:center;gap:5px;flex-shrink:0}
.dv-dots i{width:7px;height:7px;border-radius:50%;background:#088F8F;display:block;animation:dvBounce 1.4s ease-in-out infinite}
.dv-dots i:nth-child(2){animation-delay:.2s}.dv-dots i:nth-child(3){animation-delay:.4s}
@keyframes dvBounce{0%,60%,100%{transform:translateY(0);opacity:.5}30%{transform:translateY(-6px);opacity:1}}
.dv-text{font-family:system-ui,-apple-system,sans-serif;font-weight:500;font-size:13px;color:#088F8F;min-width:0}
.dv-sources{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;position:relative;z-index:1}
.dv-src{display:inline-flex;align-items:center;height:22px;padding:0 6px;border-radius:11px;background:rgba(178,224,230,.35);color:#035D69;font-size:11px;font-weight:500;opacity:.4;transition:opacity .3s}
.dv-src svg{width:12px;height:12px;flex-shrink:0}
.dv-src.is-done{opacity:.6}
.dv-src.is-active{opacity:1;animation:dvPulse 1.6s ease-in-out infinite}
@keyframes dvPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.06)}}
.dv-ic{display:inline-flex;align-items:center;justify-content:center;flex-shrink:0;width:18px;height:18px;border-radius:50%;background:#fff;box-shadow:0 0 0 1px rgba(3,93,105,.15)}
.dv-ic svg{width:12px;height:12px}
.dv-source-badge{display:inline-flex;align-items:center;gap:6px;max-width:100%;padding:3px 9px;border-radius:12px;background:rgba(178,224,230,.35);color:#035D69;font-size:11px;font-weight:500;line-height:1.4}
.dv-source-badge span{white-space:normal;overflow-wrap:anywhere}
.dv-source-badge small{display:block;font-size:10px;opacity:.75}
.dv-badge-icons{display:inline-flex;align-items:center;gap:3px;flex-shrink:0}
[data-theme="dark"] .dv-think,.dv-dark .dv-think{background:rgba(178,224,230,.08);border-color:rgba(178,224,230,.18)}
[data-theme="dark"] .dv-source-badge,.dv-dark .dv-source-badge{background:rgba(178,224,230,.12);color:#b2e0e6}
@media (prefers-reduced-motion:reduce){.dv-think::after,.dv-dots i,.dv-src.is-active{animation:none}}`;
    document.head.appendChild(s);
}

function _clearThinkTimers() {
    _thinkTimers.forEach(t => { clearInterval(t); clearTimeout(t); });
    _thinkTimers = [];
}

function setTypingStage(stage) {
    const el = _el('typingIndicator');
    if (!el) return;
    const active = THINK_STAGES[stage] || [];
    el.querySelectorAll('.dv-src').forEach(p => {
        const isActive = active.includes(p.dataset.src);
        p.classList.toggle('is-active', isActive);
        p.classList.toggle('is-done', !isActive && p.dataset.seen === '1');
        if (isActive) p.dataset.seen = '1';
    });
}

function showTyping(initialStage) {
    const container = _el('chatMessages');
    if (!container || _el('typingIndicator')) return;
    ensureThinkingStyles();
    _clearThinkTimers();

    const showGoogle = initialStage !== 'vision' && _searchAvailable();
    const pills = THINK_SOURCES
        .filter(s => s.id !== 'google' || showGoogle)
        .map(s => `<span class="dv-src" data-src="${s.id}" title="${s.label}">${_iconHtml(s.icon)}</span>`).join('');
    const texts = initialStage === 'vision' ? THINK_TEXTS.vision : THINK_TEXTS.default;

    const el = document.createElement('div');
    el.className = 'message ai-message';
    el.id = 'typingIndicator';
    el.setAttribute('role', 'status');
    el.innerHTML = `
        <div class="avatar ai-avatar-small dv-avatar"><img src="assets/dailyvetlogo.jpeg" alt="AI" /></div>
        <div class="dv-think">
            <div class="dv-row">
                <span class="dv-dots"><i></i><i></i><i></i></span>
                <span class="dv-text"><span class="dv-label">${texts[0]}</span></span>
            </div>
            <div class="dv-sources">${pills}</div>
        </div>`;
    container.appendChild(el);
    _scrollChatToBottom();
    setTypingStage(initialStage || 'db');

    const labelEl = el.querySelector('.dv-label');
    let idx = 0;
    const iv = setInterval(() => {
        if (idx >= texts.length - 1) { clearInterval(iv); return; }
        labelEl.textContent = texts[++idx];
    }, THINK_TEXT_INTERVAL_MS);
    _thinkTimers.push(iv);
}

const PROVIDER_BADGES = {
    gemini: { icons: ['gemini'], text: 'Gemini is collabed with DailyVet' },
    groq: { icons: ['groq'], text: 'Groq is collabed with DailyVet' },
    openrouter: { icons: ['openrouter'], text: 'AI is collabed with DailyVet' }
};
/* ✅ v12.6: hold 250 → 100 (render reply faster) */
const COLLAB_LOADER_HOLD_MS = 100;

async function finishTypingWithCollab(info) {
    const cfg = PROVIDER_BADGES[info?.provider];
    const think = _el('typingIndicator')?.querySelector('.dv-think');
    if (!think || !cfg) return;
    _clearThinkTimers();
    const search = info.provider === 'gemini' ? info.searchInfo : null;
    const icons = search ? ['gemini', 'google'] : cfg.icons;
    const names = search ? (search.sources || []).slice(0, 3).map(escapeHtml).join(', ') : '';
    const sub = search ? `<small>+ Google Search${names ? ' · ' + names : ''}</small>` : '';
    think.innerHTML = `
        <div class="dv-row">
            <span class="dv-text" style="opacity:1">
                <span class="dv-source-badge">
                    <span class="dv-badge-icons">${icons.map(_iconHtml).join('')}</span>
                    <span>${cfg.text}${sub}</span>
                </span>
            </span>
        </div>`;
    _scrollChatToBottom();
    await _sleep(COLLAB_LOADER_HOLD_MS);
}

function removeTyping() {
    _clearThinkTimers();
    _el('typingIndicator')?.remove();
}

// ── FIRESTORE MEMORY ──
const MEMORY_TTL_MS = 30 * 60 * 1000;
function saveUserMemory() {
    if (!cachedUserPhone) return;
    try {
        _fs().collection('users').doc(cachedUserPhone).set({
            aiMemory: {
                currentPet: topicMemory.currentPet,
                currentDisease: topicMemory.currentDisease,
                symptoms: topicMemory.symptoms.slice(0, 10),
                mentionedPets: topicMemory.mentionedPets.slice(0, 10),
                userMood: topicMemory.userMood,
                lastActive: Date.now()
            }
        }, { merge: true }).catch(() => {});
    } catch (e) {}
}

async function loadUserMemoryFromFirestore(phone) {
    try {
        const doc = await _fs().collection('users').doc(phone).get();
        if (!doc.exists) return null;
        const data = doc.data();
        const mem = data.aiMemory;
        const isFresh = mem && mem.lastActive && (Date.now() - mem.lastActive) < MEMORY_TTL_MS;
        if (isFresh && !topicMemory.currentPet && !topicMemory.currentDisease) {
            topicMemory.currentPet = mem.currentPet || null;
            topicMemory.currentDisease = mem.currentDisease || null;
            topicMemory.symptoms = mem.symptoms || [];
            topicMemory.mentionedPets = mem.mentionedPets || [];
        }
        return data;
    } catch (e) {
        return null;
    }
}

// ═══════════════════════════════════════════════════════════
// 📨 SEND MESSAGE
// ═══════════════════════════════════════════════════════════
function _resetConversationState() {
    conversationHistory = [];
    triageRounds = 0;
    triageLimit = DEFAULT_TRIAGE_ROUNDS;
    awaitingVetSpecies = false;
    nameGreeted = false;
}

async function sendMessage() {
    const input = _el('chatInput');
    const since = Date.now() - lastMessageTime;
    if (since < MIN_MESSAGE_INTERVAL) {
        if (input) {
            const orig = input.dataset.origPlaceholder || (input.dataset.origPlaceholder = input.placeholder);
            input.placeholder = `Please wait ${Math.ceil((MIN_MESSAGE_INTERVAL - since) / 1000)}s...`;
            setTimeout(() => { input.placeholder = orig; }, 500);
        }
        return;
    }
    if (isProcessing || !input) return;
    stopVoiceInput(true);

    const text = input.value.trim();
    const imageBase64 = selectedImageData;
    if (!text && !imageBase64) return;

    stopSpeaking();
    _unlockAudio();

    isProcessing = true;
    const startedAt = lastMessageTime = Date.now();
    input.value = '';
    addMessage('user', text, imageBase64);
    removeImage();
    showTyping(imageBase64 ? 'vision' : 'db');

    const canPersist = typeof window.dvPersistMessage === 'function';
    const persistUser = canPersist ? (async () => {
        try {
            if (!window.__currentConvId) await window.dvCreateConversation(text || 'Image analysis');
            await window.dvPersistMessage('user', text, imageBase64 || null);
        } catch (e) { console.warn('History save (user) failed:', e.message); }
    })() : Promise.resolve();
    const persistAi = content => canPersist && persistUser
        .then(() => window.dvPersistMessage('assistant', content, null))
        .catch(e => console.warn('History save (ai) failed:', e.message));

    try {
        const hasImage = !!imageBase64;
        const inTriage = triageRounds > 0 && !hasImage;

        let species = detectSpecies(text);
        const symptom = detectSymptom(text);
        const mood = detectMood(text);
        const taskType = detectTaskType(text);
        const isCorrecting = isCorrectingUser(text);
        const newQuestion = isNewQuestion(text);

        const isSpeciesCorrectionFollowUp = !!(awaitingVetSpecies && !hasImage && !newQuestion &&
            !symptom && species && topicMemory.currentPet && species !== topicMemory.currentPet);
        const askingForDoctor = isAskingForDoctor(text) || isSpeciesCorrectionFollowUp;

        if (!hasImage && !inTriage) {
            const quick = getQuickReply(text, !!(species || symptom));
            if (quick) {
                if (quick.type !== 'thanks') {
                    topicMemory = _newMemory();
                    _resetConversationState();
                    saveUserMemory();
                }
                removeTyping();
                addMessage('ai', quick.reply);
                speakText(quick.reply);
                persistAi(quick.reply);
                return;
            }
        }

        const isFollowUp = !hasImage && !newQuestion &&
            (inTriage || isReferringToPrevious(text) || askingForDoctor || isFollowUpMessage(text) || (!!symptom && !species));
        const previousPet = topicMemory.currentPet;

        if (hasImage || newQuestion) {
            topicMemory.currentDisease = null;
            topicMemory.symptoms = [];
        }
        if (hasImage && !species) topicMemory.currentPet = null;
        species = !species && isFollowUp
            ? (topicMemory.currentPet || (userPetType ? userPetType.toLowerCase() : species))
            : species;

        const isEmergency = checkEmergency(text);
        if (newQuestion || hasImage || (species && previousPet && species !== previousPet)) _resetConversationState();

        updateTopicMemory(species, symptom, mood);
        saveUserMemory();

        let reply = '';
        let confidence = 'HIGH';
        const shouldShowVet = (askingForDoctor && species) || isEmergency;
        awaitingVetSpecies = !!shouldShowVet;

        if (askingForDoctor && species && !isEmergency) {
            const pet = topicMemory.currentPet || species, disease = topicMemory.currentDisease;
            reply = disease ? `Veterinarian for your ${pet} (${disease}):` : `Veterinarian for your ${pet}:`;
        }

        let usedKB = false;
        let dbMatched = false; /* ✅ v12.7: true only for a specific Disease-DB match */
        let referenceNotes = '';
        let offlineFallbackReply = '';
        const textOnly = !reply && !hasImage && !isEmergency;
        if (textOnly && (species || symptom)) {
            setTypingStage('db');
            const dbDisease = await _withTimeout(lookupDiseaseFromDB(text, species, symptom), DB_LOOKUP_TIMEOUT_MS, null);
            if (dbDisease) {
                dbMatched = true;
                const dbText = formatDiseaseFromDB(dbDisease);
                referenceNotes += dbText + '\n\n';
                offlineFallbackReply = dbText;
                const dn = dbDisease.disease_name_en || '';
                if (dn) {
                    topicMemory.currentDisease = dn;
                    if (!topicMemory.symptoms.includes(dn)) topicMemory.symptoms.push(dn);
                }
            }
        }
        if (textOnly) {
            setTypingStage('kb');
            const kbAnswer = getFromKB(text);
            if (kbAnswer) {
                referenceNotes += kbAnswer + '\n\n';
                offlineFallbackReply = offlineFallbackReply || kbAnswer;
            }
        }
        referenceNotes = referenceNotes.trim().slice(0, 2500);

        let usedEmergencyFallback = false;
        let answeredBy = null;
        let searchInfo = null;

        if (triageRounds === 0) triageLimit = computeTriageLimit({ text, mood, isEmergency, hasImage });
        const forceDiagnoseNow = isEmergency || triageRounds >= triageLimit;
        let stage = 'DIAGNOSE';
        let rawAiReply = '';

        // ── LAYER 1: AI ──
        if (!reply) {
            setTypingStage(hasImage ? 'vision' : 'ai');
            const cacheKey = (!hasImage && !isFollowUp && !isCorrecting && !isEmergency && triageRounds === 0)
                ? replyCacheKey(text, species) : null;
            const cached = cacheKey ? getCachedReply(cacheKey) : null;

            const elapsed = Date.now() - startedAt;
            const remainingBudget = Math.max(1500, REPLY_TARGET_MS - elapsed - 200);

            const ai = {
                userMessage: text, species, imageBase64, mood, taskType, isCorrecting,
                useMemory: isFollowUp, reference: referenceNotes, triageForce: forceDiagnoseNow,
                triageRound: triageRounds + 1, triageMax: triageLimit,
                budgetMs: remainingBudget,
                onProvider: p => setTypingStage(p)
            };
            let result = null;
            try {
                result = cached ? null : await askAI(ai);
            } catch (aiErr) {
                console.warn('askAI threw:', aiErr?.message || aiErr);
                result = null;
            }
            let rawReply = cached ? cached.raw : (result?.reply || null);
            answeredBy = cached ? (cached.provider || 'cache') : (result?.provider || null);
            searchInfo = cached ? cached.searchInfo : (result?.searchInfo || null);

            if (rawReply && !replyIsEnglish(rawReply)) {
                const left = REPLY_TARGET_MS - (Date.now() - startedAt);
                let retry = null;
                if (left >= LANG_RETRY_MIN_LEFT_MS) {
                    try {
                        retry = await askAI({ ...ai, strictLang: true, budgetMs: left });
                    } catch (_) { retry = null; }
                }
                if (retry?.reply && replyIsEnglish(retry.reply)) {
                    rawReply = retry.reply; answeredBy = retry.provider; searchInfo = retry.searchInfo;
                } else {
                    rawReply = enforceLanguage(rawReply);
                }
            }

            if (rawReply) {
                const confParsed = extractConfidence(rawReply);
                const stageParsed = extractStage(confParsed.text);
                reply = stageParsed.text;
                rawAiReply = reply;
                confidence = confParsed.confidence;
                stage = stageParsed.stage;
                if (forceDiagnoseNow && stage === 'ASK') stage = 'DIAGNOSE';

                if (!cached && cacheKey && stage === 'DIAGNOSE' && replyIsEnglish(rawReply)) {
                    setCachedReply(cacheKey, rawReply, answeredBy, searchInfo);
                }
                if (stage === 'DIAGNOSE' && (hasImage || !topicMemory.currentDisease)) {
                    const m = reply.match(/(?:🩺\s*)([^\n•]+)/);
                    const detected = m && m[1].trim().slice(0, 60);
                    if (detected && detected.length > 2) {
                        topicMemory.currentDisease = detected;
                        if (!topicMemory.symptoms.includes(detected)) topicMemory.symptoms.push(detected);
                    }
                }
                if (stage === 'DIAGNOSE' && hasImage && !species) {
                    const identified = detectSpecies(reply);
                    if (identified) {
                        species = identified;
                        topicMemory.currentPet = identified;
                        if (!topicMemory.mentionedPets.includes(identified)) topicMemory.mentionedPets.push(identified);
                    }
                }
            }
        }

        triageRounds = (stage === 'ASK' && !forceDiagnoseNow) ? triageRounds + 1 : 0;

        // ── LAYER 2: offline DB (specific) / general KB (generic, only if allowed) ──
        if (!reply && offlineFallbackReply && (ALLOW_GENERIC_REPLIES || dbMatched)) {
            reply = offlineFallbackReply; usedKB = true;
        }

        // ── LAYER 3: pattern match (generic canned, only if allowed) ──
        if (!reply && ALLOW_GENERIC_REPLIES) {
            const patternReply = getLocalFallbackReply(text);
            if (patternReply) { reply = patternReply; usedKB = true; }
        }

        // ── LAYER 4: guaranteed fallback ──
        if (!reply) {
            usedEmergencyFallback = isEmergency;
            usedKB = true;
            reply = isEmergency
                ? `🚨 EMERGENCY!\n\n1. Keep the animal calm.\n2. Go to the nearest vet.\n3. 24/7 Helpline: 16358.`
                : _noAiReply();
        }

        const toxicWarning = checkSpeciesToxic([text, rawAiReply], species || topicMemory.currentPet);

        if (!usedKB) {
            const safety = applyMedicalSafetyGuard(reply);
            reply = scrubHindi(safety.text).text;
            if (safety.wasBlocked) confidence = 'LOW';
        }
        reply = enforceLanguage(reply);
        if (toxicWarning) { reply += toxicWarning; confidence = 'HIGH'; }
        if (stage !== 'ASK' && !usedKB) reply = applyConfidenceWarning(reply, confidence);

        if (isEmergency && !usedEmergencyFallback) {
            reply = '🚨 EMERGENCY! Go to a vet immediately.\n\n' + reply;
        }

        if (shouldShowVet) {
            const dbVets = await _withTimeout(findNearbyVets(species, symptom || topicMemory.currentDisease || null), VET_LOOKUP_TIMEOUT_MS, []);
            const hasVets = !!(dbVets && dbVets.length > 0);
            reply += hasVets
                ? `\n\n${formatVetSuggestion(dbVets)}\n\n🔍 Would you like to search for more vets via Google?\n\n${GOOGLE_OPTION_TOKEN}`
                : `\n\n🔍 No vets found in database. Search on Google instead?\n\n${GOOGLE_OPTION_TOKEN}${VET_HOTLINE}`;
            window.__currentSpecies = species || null;
            window.__currentSymptom = symptom || topicMemory.currentDisease || null;
        }

        reply = personalizeReply(forcePremiumFormatting(reply));

        conversationHistory.push(
            { role: 'user', content: hasImage ? `[Image] ${text || 'analyze'}` : text },
            { role: 'assistant', content: reply.replace(GOOGLE_OPTION_TOKEN, '').trim() }
        );
        conversationHistory = conversationHistory.slice(-MAX_HISTORY_TURNS * 2);

        speakText(reply);
        if (answeredBy && PROVIDER_BADGES[answeredBy]) await finishTypingWithCollab({ provider: answeredBy, searchInfo });
        removeTyping();
        addMessage('ai', reply);
        _log(`✅ ${answeredBy || 'local'} replied in ${Date.now() - startedAt}ms | stage=${stage} round=${triageRounds}/${triageLimit}`);

        persistAi(reply);
        if (stage !== 'ASK') {
            try {
                Promise.resolve(window.DVNotifications?.analyzeAndSchedule?.(
                    reply, text || 'Image analysis',
                    { petName: topicMemory.currentPet || 'your pet', species: species || null }
                )).catch(e => console.warn('Notification schedule failed:', e.message));
            } catch (e) { console.warn('Notification schedule failed:', e.message); }
        }
    } catch (error) {
        console.error('Send error:', error);
        removeTyping();
        addMessage('ai', _noAiReply());
    } finally {
        isProcessing = false;
    }
}

function sendQuickMessage(text) {
    const input = _el('chatInput');
    if (input) input.value = text;
    sendMessage();
}

// ── IMAGE HANDLING ──
const IMAGE_MAX_DIMENSION = 1280;
const IMAGE_JPEG_QUALITY = 0.82;
const IMAGE_TARGET_MAX_BYTES = 1.5 * 1024 * 1024;

function _resizeImageToDataURL(file) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        const objectUrl = URL.createObjectURL(file);
        img.onload = () => {
            URL.revokeObjectURL(objectUrl);
            const scale = Math.min(1, IMAGE_MAX_DIMENSION / Math.max(img.width, img.height));
            const canvas = document.createElement('canvas');
            canvas.width = Math.round(img.width * scale);
            canvas.height = Math.round(img.height * scale);
            canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
            let quality = IMAGE_JPEG_QUALITY;
            let dataUrl = canvas.toDataURL('image/jpeg', quality);
            for (let i = 0; i < 5 && dataUrl.length * 0.75 > IMAGE_TARGET_MAX_BYTES && quality > 0.4; i++) {
                quality -= 0.12;
                dataUrl = canvas.toDataURL('image/jpeg', quality);
            }
            resolve(dataUrl);
        };
        img.onerror = () => { URL.revokeObjectURL(objectUrl); reject(new Error('decode failed')); };
        img.src = objectUrl;
    });
}

async function processImageFile(file) {
    if (!file) return;
    if (!file.type.startsWith('image/')) { alert('Please select an image file.'); return; }
    try {
        selectedImageData = await _resizeImageToDataURL(file);
    } catch (e) {
        try {
            selectedImageData = await new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = ev => resolve(ev.target.result);
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        } catch (e2) { alert('Failed to read image.'); return; }
    }
    const preview = _el('imagePreview'), img = _el('previewImg');
    if (preview && img) { img.src = selectedImageData; preview.style.display = 'block'; }
}
function handleImageSelect(event) {
    const file = event.target.files[0];
    if (file) processImageFile(file);
}
function removeImage() {
    selectedImageData = null;
    const preview = _el('imagePreview'), img = _el('previewImg'), input = _el('imageInput');
    if (preview) preview.style.display = 'none';
    if (img) img.src = '';
    if (input) input.value = '';
}

function toggleMenu() {
    const menu = _el('menuDropdown');
    if (menu) menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
}
function closeDisclaimer() {
    const banner = _el('disclaimerBanner');
    if (banner) banner.style.display = 'none';
}

async function loadUserProfile() {
    userName = sessionStorage.getItem('userName') || localStorage.getItem('userName') || userName;
    const phone = cachedUserPhone = _getPhone();
    if (!phone) return;
    try { sessionStorage.setItem('userPhone', phone); } catch (_) {}
    listenToUserPhoto();

    try {
        const cached = JSON.parse(sessionStorage.getItem('userProfileCache'));
        if (cached) {
            userName = cached.name || userName;
            userPetType = cached.petType || null;
            cachedUserPhoto = cached.photoURL || '';
            loadUserMemoryFromFirestore(phone);
            return;
        }
    } catch (e) {}

    try {
        const data = await loadUserMemoryFromFirestore(phone);
        if (data) {
            userName = data.name || userName;
            userPetType = data.petType || null;
            cachedUserPhoto = data.photoURL || '';
            sessionStorage.setItem('userProfileCache', JSON.stringify({
                name: userName, photoURL: data.photoURL || null, petType: userPetType, city: data.city || null
            }));
        }
    } catch (error) {
        console.warn('Profile load failed:', error);
    }
}

// ═══════════════════════════════════════════════════════════
// 🎤 VOICE INPUT (speech → text field)
// ═══════════════════════════════════════════════════════════
let recognition = null;
let isListening = false;
let wantListening = false;
let voiceIndicatorEl = null;
let _recBase = '';
let _recSessionText = '';
let _recLastActivity = 0;
let _recAborted = false;
const REC_IDLE_STOP_MS = 6000;
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
const VOICE_SEND_RE = /(?:^|\s)(?:send it|send)[\s.!?]*$/i;
const REC_LANG = 'en-US';
const _joinText = (...parts) => parts.map(s => (s || '').trim()).filter(Boolean).join(' ');

function _finishListening() {
    wantListening = false;
    isListening = false;
    updateMicUI(false);
    hideVoiceIndicator();
}

function initVoiceInput() {
    if (!SpeechRecognition) return false;
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    recognition.lang = REC_LANG;

    recognition.onstart = () => { isListening = true; updateMicUI(true); showVoiceIndicator(); };

    recognition.onresult = event => {
        if (_recAborted) return;
        let finalText = '', interim = '';
        for (let i = 0; i < event.results.length; i++) {
            const r = event.results[i];
            if (r.isFinal) finalText += r[0].transcript + ' ';
            else interim += r[0].transcript;
        }
        _recSessionText = _joinText(finalText, interim);
        _recLastActivity = Date.now();
        const input = _el('chatInput');
        if (!input) return;
        const full = _joinText(_recBase, _recSessionText);
        input.value = full;

        const last = event.results[event.results.length - 1];
        if (last && last.isFinal && VOICE_SEND_RE.test(full)) {
            const cleaned = full.replace(VOICE_SEND_RE, '').trim();
            if (cleaned) {
                input.value = cleaned;
                stopVoiceInput(true);
                sendMessage();
            }
        }
    };

    recognition.onerror = event => {
        const err = event && event.error;
        if (err === 'no-speech' || err === 'aborted') return;
        console.warn('Voice error:', err);
        if (err === 'not-allowed' || err === 'service-not-allowed') {
            alert('Please allow microphone access (browser settings → Microphone → Allow).');
        } else if (err === 'network') {
            alert('Voice input needs an internet connection.');
        }
        wantListening = false;
    };

    recognition.onend = () => {
        isListening = false;
        _recBase = _joinText(_recBase, _recSessionText);
        _recSessionText = '';
        const idle = Date.now() - _recLastActivity > REC_IDLE_STOP_MS;
        if (wantListening && !_recAborted && !idle) {
            setTimeout(() => {
                if (!wantListening || _recAborted) return;
                try { recognition.start(); } catch (_) { _finishListening(); }
            }, 120);
            return;
        }
        _finishListening();
    };
    return true;
}

function toggleVoiceInput() {
    _unlockAudio();
    if (!recognition && !initVoiceInput()) {
        alert(isIOS ? 'Voice input is limited in this browser. Please use a newer version of Safari/Chrome.' : 'Your browser does not support voice input. Please use Chrome.');
        return;
    }
    wantListening ? stopVoiceInput(false) : startVoiceInput();
}

function startVoiceInput() {
    if (!recognition || wantListening) return;
    stopSpeaking();
    const input = _el('chatInput');
    try { recognition.lang = REC_LANG; } catch (_) {}
    _recBase = input ? input.value.trim() : '';
    _recSessionText = '';
    _recAborted = false;
    wantListening = true;
    _recLastActivity = Date.now();
    try {
        recognition.start();
    } catch (err) {
        console.warn('Voice start error:', err);
        _finishListening();
    }
}

function stopVoiceInput(abort) {
    wantListening = false;
    if (abort) _recAborted = true;
    if (recognition && (isListening || abort)) {
        try { abort ? recognition.abort() : recognition.stop(); } catch (_) {}
    }
    updateMicUI(false);
    hideVoiceIndicator();
}

function updateMicUI(listening) {
    const btn = _el('micBtn'), icon = _el('micIcon');
    if (!btn || !icon) return;
    btn.classList.toggle('listening', listening);
    btn.setAttribute('aria-pressed', listening ? 'true' : 'false');
    icon.classList.remove('fa-microphone', 'fa-microphone-lines');
    icon.classList.add(listening ? 'fa-microphone-lines' : 'fa-microphone');
}
function showVoiceIndicator() {
    if (!voiceIndicatorEl) {
        voiceIndicatorEl = document.createElement('div');
        voiceIndicatorEl.className = 'voice-indicator';
        voiceIndicatorEl.innerHTML = `<span class="pulse-dot"></span><span>Listening... speak now</span>`;
        document.body.appendChild(voiceIndicatorEl);
    }
    voiceIndicatorEl.classList.add('show');
}
function hideVoiceIndicator() {
    if (voiceIndicatorEl) voiceIndicatorEl.classList.remove('show');
}

// ═══════════════════════════════════════════════════════════
// 🔊 VOICE ASSISTANT — ElevenLabs (v12.6: ≤1s start)
// ═══════════════════════════════════════════════════════════
const ELEVEN = {
    apiKey: 'YOUR_ELEVENLABS_API_KEY', // ⚠️ replace with real key (or use proxyUrl)
    proxyUrl: '',
    voiceId: 'JBFqnCBsd6RMkjVDRZzb',
    models: ['eleven_flash_v2_5', 'eleven_multilingual_v2'],
    format: 'mp3_22050_32',
    voiceSettings: { stability: 0.5, similarity_boost: 0.75 },
    hardCapChars: 6000,
    /* ✅ v12.6: tiny first chunk for ≤1s start */
    firstChunkChars: 40,
    nextChunkChars: 180,
    /* ✅ v12.6: split timeouts — first chunk short, later chunks longer */
    firstFetchTimeoutMs: 2500,
    fetchTimeoutMs: 8000
};

let voiceAssistantEnabled = _lsGet('dvVoiceAssistant') !== 'off';
let _voiceUtterance = null;
let _ttsSess = null;
let _ttsAudioEl = null;
let _audioUnlocked = false;
let _elDisabledUntil = parseInt(_lsGet('dvElDisabledUntil') || '0', 10) || 0;
const _ttsCache = new Map();
const TTS_CACHE_MAX = 30;
const _SILENT_WAV = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAESsAACJWAAACABAAZGF0YQAAAAA=';

const _elAvailable = () =>
    !!(ELEVEN.proxyUrl || ELEVEN.apiKey) &&
    !/^YOUR_/i.test(ELEVEN.apiKey || '') &&
    Date.now() >= _elDisabledUntil &&
    navigator.onLine !== false;

function _elDisable(ms) {
    _elDisabledUntil = Date.now() + ms;
    _lsSet('dvElDisabledUntil', String(_elDisabledUntil));
}

function _ttsAudio() {
    if (!_ttsAudioEl) {
        _ttsAudioEl = new Audio();
        _ttsAudioEl.preload = 'auto';
        _ttsAudioEl.setAttribute('playsinline', '');
    }
    return _ttsAudioEl;
}
function _unlockAudio() {
    if (_audioUnlocked || _ttsSess) return;
    try {
        const a = _ttsAudio();
        a.src = _SILENT_WAV;
        const p = a.play();
        if (p && p.then) p.then(() => { _audioUnlocked = true; try { a.pause(); } catch (_) {} }).catch(() => {});
        else _audioUnlocked = true;
    } catch (_) {}
}

function _setSpeakingUI(on) {
    _el('voiceAssistantBtn')?.classList.toggle('voice-speaking', !!on);
}

function _updateVoiceAssistantUI() {
    const textEl = _el('voiceAssistantText');
    const btn = _el('voiceAssistantBtn');
    if (textEl) textEl.textContent = voiceAssistantEnabled ? 'Voice: ON' : 'Voice: OFF';
    if (btn) {
        btn.classList.toggle('voice-off', !voiceAssistantEnabled);
        btn.setAttribute('aria-pressed', voiceAssistantEnabled ? 'true' : 'false');
        const icon = btn.querySelector('i');
        if (icon) {
            icon.classList.toggle('fa-volume-high', voiceAssistantEnabled);
            icon.classList.toggle('fa-volume-xmark', !voiceAssistantEnabled);
        }
    }
}

function toggleVoiceAssistant() {
    voiceAssistantEnabled = !voiceAssistantEnabled;
    _lsSet('dvVoiceAssistant', voiceAssistantEnabled ? 'on' : 'off');
    if (!voiceAssistantEnabled) stopSpeaking();
    else _unlockAudio();
    _updateVoiceAssistantUI();
    const menu = _el('menuDropdown');
    if (menu) menu.style.display = 'none';
}

function _ttsClean(text) {
    let t = String(text || '')
        .replace(/\[\[.*?\]\]/g, '')
        .replace(/\[[^\]]*\]/g, '')
        .split('\n').filter(l => !/google/i.test(l)).join('\n')
        .replace(/https?:\/\/\S+/g, '')
        .replace(/[\p{Extended_Pictographic}\u200D\uFE0F\u20E3]/gu, '')
        .replace(/[•▪‣●○*_`#~]/g, ' ');
    t = t.split('\n')
        .map(l => l.replace(/\s+/g, ' ').trim())
        .filter(l => /[\p{L}\p{N}]/u.test(l))
        .map(l => (/[.!?:;]$/.test(l) ? l : l + '.'))
        .join(' ');
    if (t.length > ELEVEN.hardCapChars) {
        const cut = t.slice(0, ELEVEN.hardCapChars);
        const end = Math.max(cut.lastIndexOf('.'), cut.lastIndexOf('!'), cut.lastIndexOf('?'));
        t = end > ELEVEN.hardCapChars * 0.5 ? cut.slice(0, end + 1) : cut;
    }
    return { text: t.trim() };
}

/* ✅ v12.6: split a long first sentence so first chunk is small */
function _ttsChunks(t) {
    const sents = t.match(/(?:[^.!?]|\.(?=\d))+[.!?]*/g) || [t];
    const chunks = [];
    let cur = '';
    const limit = () => (chunks.length === 0 ? ELEVEN.firstChunkChars : ELEVEN.nextChunkChars);
    const pieces = [];
    sents.forEach(s => {
        s = s.trim();
        while (s.length > 380) {
            let cut = s.lastIndexOf(' ', 300);
            if (cut < 120) cut = 300;
            pieces.push(s.slice(0, cut).trim());
            s = s.slice(cut).trim();
        }
        if (s) pieces.push(s);
    });
    /* ✅ split long first piece */
    if (pieces.length && pieces[0].length > ELEVEN.firstChunkChars + 25) {
        const first = pieces[0];
        const maxLen = ELEVEN.firstChunkChars + 25;
        let cut = Math.max(
            first.lastIndexOf(', ', maxLen),
            first.lastIndexOf('; ', maxLen),
            first.lastIndexOf(': ', maxLen)
        );
        if (cut < 25) cut = first.lastIndexOf(' ', maxLen);
        if (cut < 25) cut = maxLen;
        pieces.splice(0, 1, first.slice(0, cut + 1).trim(), first.slice(cut + 1).trim());
    }
    pieces.forEach(s => {
        if (cur && cur.length + 1 + s.length > limit()) { chunks.push(cur); cur = s; }
        else cur = cur ? cur + ' ' + s : s;
        if (!chunks.length && cur.length >= ELEVEN.firstChunkChars) {
            chunks.push(cur);
            cur = '';
        }
    });
    if (cur) chunks.push(cur);
    return chunks;
}

/* ✅ v12.6: isFirst → short timeout for chunk 0 */
async function _elFetch(text, sess, isFirst) {
    let lastErr = new Error('no model');
    for (const model of ELEVEN.models) {
        const ckey = `${model}|${ELEVEN.voiceId}|${text}`;
        const hit = _ttsCache.get(ckey);
        if (hit) { _ttsCache.delete(ckey); _ttsCache.set(ckey, hit); return hit; }

        for (let attempt = 0; attempt < 2; attempt++) {
            if (sess.cancelled) throw new Error('cancelled');
            const ctrl = new AbortController();
            const onAbort = () => ctrl.abort();
            sess.ctrl.signal.addEventListener('abort', onAbort);
            const timeout = isFirst ? ELEVEN.firstFetchTimeoutMs : ELEVEN.fetchTimeoutMs;
            const timer = setTimeout(() => ctrl.abort(), timeout);
            try {
                const url = ELEVEN.proxyUrl ||
                    `https://api.elevenlabs.io/v1/text-to-speech/${ELEVEN.voiceId}/stream?output_format=${ELEVEN.format}`;
                const headers = { 'Content-Type': 'application/json', 'Accept': 'audio/mpeg' };
                if (!ELEVEN.proxyUrl) headers['xi-api-key'] = ELEVEN.apiKey;
                const res = await fetch(url, {
                    method: 'POST', headers, signal: ctrl.signal,
                    body: JSON.stringify({ text, model_id: model, voice_settings: ELEVEN.voiceSettings })
                });
                if (res.ok) {
                    const blob = await res.blob();
                    if (!blob.size) throw new Error('empty audio');
                    _ttsCache.set(ckey, blob);
                    if (_ttsCache.size > TTS_CACHE_MAX) _ttsCache.delete(_ttsCache.keys().next().value);
                    return blob;
                }
                const errText = await res.text().catch(() => '');
                if (res.status === 401 || res.status === 403 || /quota_exceeded|invalid_api_key|detected_unusual_activity/i.test(errText)) {
                    _elDisable(/quota_exceeded/i.test(errText) ? 30 * 60e3 : 6 * 3600e3);
                    const e = new Error('ElevenLabs auth/quota'); e.fatal = true; throw e;
                }
                if (res.status === 429 || res.status >= 500) {
                    lastErr = new Error('HTTP ' + res.status);
                    await _sleep(450);
                    continue;
                }
                lastErr = new Error('HTTP ' + res.status);
                break;
            } catch (e) {
                if (e.fatal || sess.cancelled) throw e;
                lastErr = e;
                break;
            } finally {
                clearTimeout(timer);
                sess.ctrl.signal.removeEventListener('abort', onAbort);
            }
        }
    }
    throw lastErr;
}

function _playBlob(blob, sess) {
    return new Promise((resolve, reject) => {
        const a = _ttsAudio();
        const url = URL.createObjectURL(blob);
        let done = false;
        let started = false;
        const startPlay = () => {
            if (started) return;
            started = true;
            const p = a.play();
            if (p && p.catch) p.catch(e => fin(e));
        };
        const fin = err => {
            if (done) return;
            done = true;
            a.onended = a.onerror = a.oncanplaythrough = a.onloadeddata = null;
            sess.stopCurrent = null;
            URL.revokeObjectURL(url);
            err ? reject(err) : resolve();
        };
        sess.stopCurrent = () => { try { a.pause(); } catch (_) {} fin(); };
        a.onended = () => fin();
        a.onerror = () => fin(new Error('audio error'));
        a.oncanplaythrough = startPlay;
        a.onloadeddata = () => setTimeout(startPlay, 60);
        a.src = url;
        if (a.readyState >= 3) startPlay();
    });
}

/* ✅ v12.6: 4 upfront prefetches + pipeline depth 3 */
async function _speakEleven(chunks, sess) {
    const jobs = [];
    const start = i => {
        if (i < chunks.length && !jobs[i]) {
            jobs[i] = _elFetch(chunks[i], sess, i === 0).catch(() => null);
        }
    };
    start(0); start(1); start(2); start(3);
    for (let i = 0; i < chunks.length; i++) {
        if (sess.cancelled) return '';
        const blob = await jobs[i];
        if (sess.cancelled) return '';
        if (!blob) return chunks.slice(i).join(' ');
        start(i + 2);
        start(i + 3);
        try { await _playBlob(blob, sess); }
        catch (e) { if (sess.cancelled) return ''; return chunks.slice(i).join(' '); }
    }
    return '';
}

function _speakBrowser(text, sess) {
    if (!text || !('speechSynthesis' in window) || sess.cancelled) return Promise.resolve();
    const chunks = _ttsChunks(text);
    return chunks.reduce((p, chunk) => p.then(() =>
        new Promise(resolve => {
            if (sess.cancelled) return resolve();
            try {
                const u = new SpeechSynthesisUtterance(chunk);
                u.lang = 'en-US';
                const voice = (speechSynthesis.getVoices() || []).find(v => v.lang && v.lang.toLowerCase().startsWith('en'));
                if (voice) u.voice = voice;
                u.rate = 0.95;
                u.onend = u.onerror = () => resolve();
                if (sess.cancelled) return resolve();
                try { speechSynthesis.speak(u); } catch (_) { resolve(); }
            } catch (_) { resolve(); }
        })
    ), Promise.resolve());
}

function speakText(text) {
    stopSpeaking();
    if (!voiceAssistantEnabled || !text) return;
    if (document.hidden) return;
    const { text: clean } = _ttsClean(text);
    if (!clean) return;

    const sess = { cancelled: false, ctrl: new AbortController(), stopCurrent: null };
    _ttsSess = sess;
    _voiceUtterance = sess;
    _setSpeakingUI(true);

    (async () => {
        try {
            let rest = clean;
            if (_elAvailable()) rest = await _speakEleven(_ttsChunks(clean), sess);
            /* ✅ v12.6: browser fallback only if ElevenLabs wasn't disabled */
            const elBroken = Date.now() < _elDisabledUntil;
            if (rest && !sess.cancelled && !elBroken) await _speakBrowser(rest, sess);
        } catch (err) {
            if (!sess.cancelled) console.warn('TTS error:', err && err.message);
        } finally {
            if (_ttsSess === sess) { _ttsSess = null; _voiceUtterance = null; _setSpeakingUI(false); }
        }
    })();
}

function stopSpeaking() {
    const s = _ttsSess;
    _ttsSess = null;
    _voiceUtterance = null;
    if (s) {
        s.cancelled = true;
        try { s.ctrl.abort(); } catch (_) {}
        try { if (s.stopCurrent) s.stopCurrent(); } catch (_) {}
    }
    if (_ttsAudioEl) { try { _ttsAudioEl.pause(); } catch (_) {} }
    if ('speechSynthesis' in window) { try { speechSynthesis.cancel(); } catch (_) {} }
    _setSpeakingUI(false);
}

function _initVoiceExtras() {
    if (!_el('dvVoiceStyles')) {
        const s = document.createElement('style');
        s.id = 'dvVoiceStyles';
        s.textContent = '.ai-header-voice.voice-speaking i{animation:dvSpeak 1s ease-in-out infinite}' +
            '@keyframes dvSpeak{0%,100%{transform:scale(1)}50%{transform:scale(1.25)}}' +
            '@media (prefers-reduced-motion:reduce){.ai-header-voice.voice-speaking i{animation:none}}';
        document.head.appendChild(s);
    }
    const unlockOnce = () => {
        _unlockAudio();
        if (_audioUnlocked || _ttsSess) {
            ['pointerdown', 'touchend', 'click', 'keydown'].forEach(ev => document.removeEventListener(ev, unlockOnce, true));
        }
    };
    ['pointerdown', 'touchend', 'click', 'keydown'].forEach(ev => document.addEventListener(ev, unlockOnce, true));

    document.addEventListener('visibilitychange', () => { if (document.hidden) stopSpeaking(); });
    window.addEventListener('pagehide', stopSpeaking);

    ['startNewChat', 'deleteCurrentConversation'].forEach(name => {
        const fn = window[name];
        if (typeof fn === 'function' && !fn.__dvWrapped) {
            const wrapped = function () { stopSpeaking(); return fn.apply(this, arguments); };
            wrapped.__dvWrapped = true;
            window[name] = wrapped;
        }
    });
}

// ── INIT ──
document.addEventListener('DOMContentLoaded', () => {
    if (!_getPhone()) { window.location.href = 'login.html'; return; }
    loadUserProfile();
    getDiseasesFromDB();
    _updateVoiceAssistantUI();
    _initVoiceExtras();

    /* ✅ v12.6: try to unlock audio as soon as DOM is ready */
    setTimeout(() => _unlockAudio(), 100);

    if ('speechSynthesis' in window) {
        speechSynthesis.getVoices();
        speechSynthesis.onvoiceschanged = () => speechSynthesis.getVoices();
    }

    _el('chatInput')?.addEventListener('keydown', e => {
        if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); sendMessage(); }
    });
    _el('chatInput')?.addEventListener('input', () => { if (_ttsSess) stopSpeaking(); });

    document.addEventListener('click', e => {
        const menu = _el('menuDropdown'), menuBtn = _el('menuBtn');
        if (menu && menuBtn && !menu.contains(e.target) && !menuBtn.contains(e.target)) menu.style.display = 'none';
    });

    document.addEventListener('paste', e => {
        for (const item of Array.from(e.clipboardData?.items || [])) {
            if (item.type.indexOf('image') !== -1) {
                const file = item.getAsFile();
                if (file) { e.preventDefault(); processImageFile(file); return; }
            }
        }
    });

    const dropZone = _el('chatMessages');
    if (dropZone) {
        dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.style.background = '#e0f0f2'; });
        dropZone.addEventListener('dragleave', e => { e.preventDefault(); dropZone.style.background = ''; });
        dropZone.addEventListener('drop', e => {
            e.preventDefault();
            dropZone.style.background = '';
            const img = Array.from(e.dataTransfer?.files || []).find(f => f.type.startsWith('image/'));
            if (img) processImageFile(img);
        });
    }

    if (typeof window.DVNotifications?.checkAndFireReminders === 'function') {
        setTimeout(() => window.DVNotifications.checkAndFireReminders(), 2000);
    }
});
window.addEventListener('beforeunload', () => { stopSpeaking(); saveUserMemory(); });

// ═══════════════════════════════════════════════════════════
// HISTORY BRIDGE
// ═══════════════════════════════════════════════════════════
window._restoreMessage = function (role, content, imageBase64, ts) {
    const container = _el('chatMessages');
    if (!container) return;
    container.appendChild(_buildMessageEl(role === 'assistant' ? 'ai' : 'user', content, imageBase64, false, ts));
    _scrollChatToBottom();
};
window._restoreConversationHistory = function (history) {
    conversationHistory = Array.isArray(history) ? history.slice(-MAX_HISTORY_TURNS * 2) : [];
    triageRounds = 0;
    triageLimit = DEFAULT_TRIAGE_ROUNDS;
    nameGreeted = Array.isArray(history) && history.length > 0;
};
window._resetConversationHistory = function () {
    topicMemory = _newMemory();
    _resetConversationState();
};

const _fadeOutGoogleOptions = () => document.querySelectorAll('.google-search-options').forEach(el => {
    el.style.transition = 'opacity 0.3s';
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 300);
});
window.handleGoogleSearchYes = function () {
    _fadeOutGoogleOptions();
    if (typeof window.showLocationRequest === 'function') {
        window.__preferGoogleSearch = true;
        window.showLocationRequest();
    } else {
        alert('Location service is not loaded.');
    }
};
window.handleGoogleSearchNo = function () {
    _fadeOutGoogleOptions();
    window.__preferGoogleSearch = false;
};

// ═══════════════════════════════════════════════════════════
// 🛠️ DEBUG
// ═══════════════════════════════════════════════════════════
window.AIDebug = {
    status() {
        const now = Date.now();
        console.table([..._blocks].filter(([, until]) => until > now).map(([id, until]) => ({ id, secsLeft: Math.round((until - now) / 1000) })));
        console.log('Usable slots — text:', _buildSlots(false).length, '| vision:', _buildSlots(true).length,
            '| search grounding:', _searchAvailable() ? 'ON' : 'paused');
        console.log('Slot order (text):', _buildSlots(false).slice(0, 7).map(s => `${s.provider}/${s.model}`));
        console.log('Generic replies:', ALLOW_GENERIC_REPLIES ? 'ON' : 'OFF');
        console.log('Groq models:', MODELS.groq);
        console.log('Gemini models:', MODELS.gemini.text);
    },
    reset() {
        _blocks.clear(); _strikes.clear();
        _lsSet(BLOCK_STORE, '{}'); _lsSet(SEARCH_STORE, '0'); searchBlockedUntil = 0;
        console.log('✅ All API blocks cleared');
    },
    history() { console.log('Conversation history:', conversationHistory); },
    speak(t) { speakText(t || 'Your cow has a fever. Keep her in the shade and give her plenty of water.'); },
    ttsStatus() {
        console.log({
            enabled: voiceAssistantEnabled,
            elevenAvailable: _elAvailable(),
            keyIsPlaceholder: /^YOUR_/i.test(ELEVEN.apiKey || ''),
            disabledForSecs: Math.max(0, Math.round((_elDisabledUntil - Date.now()) / 1000)),
            cached: _ttsCache.size
        });
    },
    ttsReset() { _elDisabledUntil = 0; _lsSet('dvElDisabledUntil', '0'); console.log('✅ ElevenLabs re-enabled'); },
    ttsChunks(t) { const { text } = _ttsClean(t || ''); const c = _ttsChunks(text); console.log({ chars: text.length, chunks: c.length, first: c[0] }); return c; },
    triage() { console.log({ triageRounds, triageLimit }); }
};