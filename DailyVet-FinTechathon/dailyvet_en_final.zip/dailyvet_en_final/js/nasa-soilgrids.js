/* DailyVet — ISRIC SoilGrids v2.1 (LIVE — CORS-enabled REST API)
   Endpoint: https://rest.isric.org/soilgrids/v2.0/properties/query
   v2.1: Removed unused code, English-only logs
*/
(function () {
'use strict';

const SOILGRIDS_URL = 'https://rest.isric.org/soilgrids/v2.0/properties/query';
const API_TIMEOUT_MS = 12000;
const CACHE_TTL_MS = 24 * 60 * 60 * 1000;

const _cache = new Map();
function _cacheGet(key) {
    const e = _cache.get(key);
    if (!e) return null;
    if (Date.now() - e.at > CACHE_TTL_MS) { _cache.delete(key); return null; }
    return e.data;
}
function _cacheSet(key, data) { _cache.set(key, { at: Date.now(), data }); }

const DISTRICTS = {
    dhaka:      { lat: 23.8103, lng: 90.4125 },
    savar:      { lat: 23.8583, lng: 90.2667 },
    chittagong: { lat: 22.3569, lng: 91.7832 },
    sylhet:     { lat: 24.8949, lng: 91.8687 },
    khulna:     { lat: 22.8456, lng: 89.5403 },
    rajshahi:   { lat: 24.3745, lng: 88.6042 },
    barisal:    { lat: 22.7010, lng: 90.3535 },
    rangpur:    { lat: 25.7439, lng: 89.2752 },
    mymensingh: { lat: 24.7471, lng: 90.4203 },
    sirajganj:  { lat: 24.4533, lng: 89.7009 }
};
const ALIASES = { chattogram: 'chittagong', chattagram: 'chittagong', barishal: 'barisal', dacca: 'dhaka' };
function _resolve(k) { const key = String(k || '').toLowerCase().trim(); return ALIASES[key] || key; }

async function _fetchFromSoilGrids(lat, lng) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS);
    try {
        const url = `${SOILGRIDS_URL}?lon=${lng}&lat=${lat}` +
                    `&property=nitrogen&property=phh2o&property=soc&property=clay` +
                    `&depth=0-5cm&value=mean`;
        const res = await fetch(url, { signal: controller.signal });
        clearTimeout(timer);
        if (!res.ok) { console.warn('[SoilGrids] HTTP', res.status); return null; }

        const data = await res.json();
        if (!data || !data.properties || !Array.isArray(data.properties.layers)) {
            console.warn('[SoilGrids] Invalid response structure');
            return null;
        }

        const layers = data.properties.layers;
        const getLayerMean = name => {
            const layer = layers.find(l => l.name === name);
            if (!layer || !layer.depths || !layer.depths[0]) return null;
            const v = layer.depths[0].values && layer.depths[0].values.mean;
            return v != null && Number.isFinite(Number(v)) ? Number(v) : null;
        };

        const rawN = getLayerMean('nitrogen');
        const rawPh = getLayerMean('phh2o');
        const rawSoc = getLayerMean('soc');
        const rawClay = getLayerMean('clay');

        return {
            nitrogen_gkg: rawN != null ? Math.round(rawN / 100 * 10) / 10 : null,
            ph: rawPh != null ? Math.round(rawPh / 10 * 10) / 10 : null,
            soc_gkg: rawSoc != null ? Math.round(rawSoc / 10 * 10) / 10 : null,
            clay_pct: rawClay != null ? Math.round(rawClay / 10 * 10) / 10 : null
        };
    } catch (err) {
        clearTimeout(timer);
        console.warn('[SoilGrids] Fetch failed:', err.message);
        return null;
    }
}

function classifyNitrogen(gkg) {
    if (!Number.isFinite(gkg)) return { level: 'unknown', label: 'Unknown', color: '#94a3b8' };
    if (gkg >= 2.0) return { level: 'high', label: 'High', color: '#059669' };
    if (gkg >= 1.0) return { level: 'moderate', label: 'Moderate', color: '#d97706' };
    return { level: 'low', label: 'Low', color: '#dc2626' };
}
function classifyPH(ph) {
    if (!Number.isFinite(ph)) return { level: 'unknown', label: 'Unknown', color: '#94a3b8' };
    if (ph < 5.5) return { level: 'acidic', label: 'Too Acidic', color: '#dc2626' };
    if (ph < 6.0) return { level: 'slightly-acidic', label: 'Slightly Acidic', color: '#d97706' };
    if (ph <= 7.5) return { level: 'optimal', label: 'Optimal', color: '#059669' };
    if (ph <= 8.5) return { level: 'slightly-alkaline', label: 'Slightly Alkaline', color: '#d97706' };
    return { level: 'alkaline', label: 'Too Alkaline', color: '#dc2626' };
}
function classifySOC(gkg) {
    if (!Number.isFinite(gkg)) return { level: 'unknown', label: 'Unknown', color: '#94a3b8' };
    if (gkg >= 20) return { level: 'high', label: 'High Carbon', color: '#059669' };
    if (gkg >= 10) return { level: 'moderate', label: 'Moderate', color: '#d97706' };
    return { level: 'low', label: 'Low Carbon', color: '#dc2626' };
}

function getSoilHealthScore(nitrogen, ph, soc) {
    let score = 0, weight = 0;
    if (Number.isFinite(nitrogen)) {
        score += nitrogen >= 2.0 ? 33 : nitrogen >= 1.0 ? 22 : 11;
        weight += 33;
    }
    if (Number.isFinite(ph)) {
        score += (ph >= 6.0 && ph <= 7.5) ? 34 : (ph >= 5.5 && ph <= 8.0) ? 22 : 10;
        weight += 34;
    }
    if (Number.isFinite(soc)) {
        score += soc >= 20 ? 33 : soc >= 10 ? 22 : 11;
        weight += 33;
    }
    if (weight === 0) return null;
    return Math.round((score / weight) * 100);
}

async function getSoilData(districtKey) {
    const key = _resolve(districtKey);
    const coords = DISTRICTS[key] || DISTRICTS.dhaka;
    const cacheKey = `soil_${key}`;

    const cached = _cacheGet(cacheKey);
    if (cached) return cached;

    const live = await _fetchFromSoilGrids(coords.lat, coords.lng);
    if (!live) {
        return {
            available: false,
            district: key,
            error: 'ISRIC SoilGrids API unreachable',
            source: 'ISRIC SoilGrids 2.0'
        };
    }

    const healthScore = getSoilHealthScore(live.nitrogen_gkg, live.ph, live.soc_gkg);
    const response = {
        available: true,
        nitrogen_gkg: live.nitrogen_gkg,
        ph: live.ph,
        soc_gkg: live.soc_gkg,
        clay_pct: live.clay_pct,
        nitrogenClass: classifyNitrogen(live.nitrogen_gkg),
        phClass: classifyPH(live.ph),
        socClass: classifySOC(live.soc_gkg),
        healthScore,
        source: 'ISRIC SoilGrids 2.0 (live REST API)',
        fetchedAt: new Date().toISOString(),
        district: key
    };
    _cacheSet(cacheKey, response);
    return response;
}

function getSoilFreshnessBadge() {
    return `<div style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px;background:#05966915;border:1px solid #05966940;border-radius:8px;font-size:11px;font-weight:700;color:#059669;">
        <span style="width:8px;height:8px;border-radius:50%;background:#059669;animation:dvFreshnessPulse 1.8s infinite;"></span>
        <span>ISRIC SoilGrids · live REST API</span>
    </div>`;
}

window.NasaSoilGrids = {
    getSoilData, classifyNitrogen, classifyPH, classifySOC, getSoilHealthScore,
    getSoilFreshnessBadge, DISTRICTS,
    SOURCE: 'ISRIC SoilGrids 2.0 (live CORS-enabled REST API)'
};

console.log('[NasaSoilGrids] v2.1 loaded');
})();