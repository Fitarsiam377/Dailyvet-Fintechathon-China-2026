/* ============================================================
   DailyVet — District + Area (Upazila) Two-Segment Picker v1.0
   ✅ Segment 1: 64 districts from bd-districts.js
   ✅ Segment 2: Area/upazila search via LocationIQ
   ✅ GPS auto-detect (district + nearest upazila)
   ✅ Emits onSelect(districtKey, area, coords)
   ============================================================ */
(function () {
'use strict';

/* ============================================================
   BUILD the picker HTML inside a container
   container: HTMLElement that will hold the picker
   options: { theme, onChange, initialDistrict }
   ============================================================ */
function buildPicker(container, options) {
    if (!container) return null;
    const opts = options || {};
    const theme = opts.theme || 'default';   // 'default' | 'blue' | 'green'

    container.innerHTML = `
        <div class="dv-picker dv-picker-${theme}">
            <!-- Segment 1: District -->
            <div class="dv-picker-seg">
                <label class="dv-picker-label">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>District</span>
                </label>
                <div class="dv-picker-select-wrap">
                    <select class="dv-picker-district"></select>
                    <i class="fas fa-chevron-down dv-picker-chev"></i>
                </div>
            </div>

            <!-- Segment 2: Area / Upazila -->
            <div class="dv-picker-seg">
                <label class="dv-picker-label">
                    <i class="fas fa-city"></i>
                    <span>Area / Upazila</span>
                </label>
                <div class="dv-picker-area-wrap">
                    <div class="dv-picker-area-input-wrap">
                        <i class="fas fa-search dv-picker-area-icon"></i>
                        <input type="text" class="dv-picker-area-input"
                               placeholder="Search upazila, village, area..."
                               autocomplete="off" />
                        <button type="button" class="dv-picker-area-clear" style="display:none;" title="Clear">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="dv-picker-area-dropdown" style="display:none;"></div>
                </div>
            </div>

            <!-- GPS -->
            <button type="button" class="dv-picker-gps">
                <i class="fas fa-location-crosshairs"></i>
                <span>GPS</span>
            </button>
        </div>
    `;

    const root = container.querySelector('.dv-picker');
    const districtSel = root.querySelector('.dv-picker-district');
    const areaInput = root.querySelector('.dv-picker-area-input');
    const areaClear = root.querySelector('.dv-picker-area-clear');
    const areaDrop = root.querySelector('.dv-picker-area-dropdown');
    const gpsBtn = root.querySelector('.dv-picker-gps');

    /* State */
    const state = {
        districtKey: opts.initialDistrict || 'dhaka',
        districtName: '',
        area: null   // { name, lat, lng, fullName, district, area }
    };

    /* Fill district dropdown */
    if (window.populateDistrictSelect) {
        window.populateDistrictSelect(districtSel, {
            placeholder: '-- Select District --',
            grouped: true,
            selected: state.districtKey
        });
    }

    /* District change */
    districtSel.addEventListener('change', () => {
        state.districtKey = districtSel.value;
        state.area = null;
        areaInput.value = '';
        areaClear.style.display = 'none';
        hideDropdown();
        emitChange();
    });

    /* Area search (debounced) */
    let searchTimer = null;
    areaInput.addEventListener('input', (e) => {
        const q = e.target.value.trim();
        areaClear.style.display = q ? 'inline-flex' : 'none';
        clearTimeout(searchTimer);
        if (q.length < 2) { hideDropdown(); return; }
        searchTimer = setTimeout(() => doAreaSearch(q), 300);
    });

    /* Clear */
    areaClear.addEventListener('click', () => {
        areaInput.value = '';
        areaClear.style.display = 'none';
        state.area = null;
        hideDropdown();
        emitChange();
    });

    /* Click outside */
    document.addEventListener('click', (e) => {
        if (!root.querySelector('.dv-picker-area-wrap').contains(e.target)) hideDropdown();
    });

    /* GPS */
    gpsBtn.addEventListener('click', async () => {
        if (!navigator.geolocation) return alert('GPS not supported.');
        gpsBtn.disabled = true;
        gpsBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>Locating...</span>';

        navigator.geolocation.getCurrentPosition(
            async (pos) => {
                const lat = pos.coords.latitude;
                const lng = pos.coords.longitude;

                if (!window.isInBangladesh || !window.isInBangladesh(lat, lng)) {
                    gpsBtn.disabled = false;
                    gpsBtn.innerHTML = '<i class="fas fa-location-crosshairs"></i> <span>GPS</span>';
                    alert('Your location is outside Bangladesh.');
                    return;
                }

                /* Nearest district */
                const nearest = window.findNearestDistrict ? window.findNearestDistrict(lat, lng) : null;
                if (nearest) {
                    districtSel.value = nearest;
                    state.districtKey = nearest;
                }

                /* Reverse geocode for area */
                let place = null;
                if (window.DVLocationIQ) place = await window.DVLocationIQ.reverse(lat, lng);
                if (place) {
                    state.area = place;
                    areaInput.value = place.area || place.name || '';
                    areaClear.style.display = areaInput.value ? 'inline-flex' : 'none';
                } else {
                    state.area = { name: '', lat, lng };
                }

                gpsBtn.disabled = false;
                gpsBtn.innerHTML = '<i class="fas fa-check-circle"></i> <span>' + (nearest ? window.BD_DISTRICTS_LIST[nearest].name : 'OK') + '</span>';
                emitChange();
            },
            (err) => {
                gpsBtn.disabled = false;
                gpsBtn.innerHTML = '<i class="fas fa-location-crosshairs"></i> <span>GPS</span>';
                alert('Location failed: ' + err.message);
            },
            { enableHighAccuracy: true, timeout: 12000, maximumAge: 5 * 60 * 1000 }
        );
    });

    /* ============================================================
       Area search
       ============================================================ */
    let searchToken = 0;
    async function doAreaSearch(q) {
        if (!window.DVLocationIQ) return;
        const token = ++searchToken;

        const districtName = window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[state.districtKey]
            ? window.BD_DISTRICTS_LIST[state.districtKey].name
            : '';

        areaDrop.innerHTML = '<div class="dv-picker-loading"><i class="fas fa-spinner fa-spin"></i> Searching...</div>';
        areaDrop.style.display = 'block';

        const results = await window.DVLocationIQ.search(q, {
            limit: 10,
            state: districtName || undefined
        });

        if (token !== searchToken) return;

        if (!results || !results.length) {
            areaDrop.innerHTML = '<div class="dv-picker-empty"><i class="fas fa-search"></i> No places found</div>';
            return;
        }

        /* Prefer results inside the chosen district */
        const inDistrict = results.filter(r =>
            (r.district || '').toLowerCase().includes((districtName || '').toLowerCase()) ||
            (r.division || '').toLowerCase().includes((districtName || '').toLowerCase())
        );
        const finalResults = inDistrict.length > 0 ? inDistrict : results.slice(0, 8);

        areaDrop.innerHTML = finalResults.map((r, i) => {
            const sub = [r.area, r.district, r.division].filter(Boolean).join(', ');
            return `
                <div class="dv-picker-option" data-idx="${i}">
                    <div class="dv-picker-option-icon">
                        <i class="fas fa-map-pin"></i>
                    </div>
                    <div class="dv-picker-option-body">
                        <div class="dv-picker-option-name">${escapeHtml(r.name)}</div>
                        ${sub ? `<div class="dv-picker-option-sub">${escapeHtml(sub)}</div>` : ''}
                    </div>
                </div>
            `;
        }).join('');

        areaDrop.querySelectorAll('.dv-picker-option').forEach(el => {
            el.addEventListener('click', () => {
                const idx = parseInt(el.dataset.idx, 10);
                const picked = finalResults[idx];
                if (!picked) return;
                state.area = picked;
                areaInput.value = picked.name;
                areaClear.style.display = 'inline-flex';
                hideDropdown();
                emitChange();
            });
        });
    }

    function hideDropdown() {
        areaDrop.style.display = 'none';
        areaDrop.innerHTML = '';
    }

    function escapeHtml(s) {
        const d = document.createElement('div');
        d.textContent = String(s || '');
        return d.innerHTML;
    }

    /* ============================================================
       Emit change
       ============================================================ */
    function emitChange() {
        const districtName = window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[state.districtKey]
            ? window.BD_DISTRICTS_LIST[state.districtKey].name
            : state.districtKey;

        const coords = state.area && Number.isFinite(state.area.lat)
            ? { lat: state.area.lat, lng: state.area.lng }
            : (window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[state.districtKey])
                ? { lat: window.BD_DISTRICTS_LIST[state.districtKey].lat, lng: window.BD_DISTRICTS_LIST[state.districtKey].lng }
                : { lat: 23.8103, lng: 90.4125 };

        const payload = {
            districtKey: state.districtKey,
            districtName: districtName,
            area: state.area ? state.area.name : '',
            areaFull: state.area ? state.area.fullName : '',
            lat: coords.lat,
            lng: coords.lng,
            hasArea: !!state.area
        };

        if (typeof opts.onChange === 'function') opts.onChange(payload);
        root.dispatchEvent(new CustomEvent('dv-picker-change', { detail: payload, bubbles: true }));
    }

    /* Expose setter for external use */
    root.setDistrict = (key) => {
        if (key && window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[key]) {
            districtSel.value = key;
            state.districtKey = key;
            state.area = null;
            areaInput.value = '';
            areaClear.style.display = 'none';
            emitChange();
        }
    };

    /* Initial emit */
    emitChange();

    return root;
}

/* ============================================================
   AUTO-BIND any <div data-dv-picker> in the page
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('[data-dv-picker]').forEach(el => {
        const onChangeName = el.dataset.onChange;
        const theme = el.dataset.theme || 'default';
        const initial = el.dataset.initialDistrict || 'dhaka';

        buildPicker(el, {
            theme,
            initialDistrict: initial,
            onChange: onChangeName && typeof window[onChangeName] === 'function'
                ? window[onChangeName]
                : null
        });
    });
});

window.DVPicker = { build: buildPicker };

console.log('✅ District+Area picker loaded');

})();
