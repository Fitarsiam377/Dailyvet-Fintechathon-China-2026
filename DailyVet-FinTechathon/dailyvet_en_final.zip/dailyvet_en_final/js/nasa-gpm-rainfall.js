/* DailyVet — Live Satellite Rainfall v2.1
   SOURCE: Open-Meteo (NOAA GFS + ECMWF IFS — same physical family as NASA GPM IMERG)
   ENDPOINT: https://api.open-meteo.com/v1/forecast

   Why Open-Meteo instead of direct GPM IMERG:
   - GPM IMERG requires NASA Earthdata login (CORS blocked from browser)
   - Open-Meteo aggregates NOAA GFS + ECMWF IFS satellite data (same physics)
   - CORS-enabled, no auth, hourly updates

   v2.1 changes:
   • Uses both `hourly=precipitation` and `daily=precipitation_sum`
   • Daily totals more accurate than summing hourly (rounds once)
   • No Bangla strings
*/
(function () {
'use strict';

const CACHE_TTL_MS = 60 * 60 * 1000;
const API_TIMEOUT_MS = 12000;

const _cache = new Map();

function _cacheGet(key) {
    const e = _cache.get(key);
    if (!e) return null;
    if (Date.now() - e.at > CACHE_TTL_MS) { _cache.delete(key); return null; }
    return e.data;
}
function _cacheSet(key, data) {
    _cache.set(key, { at: Date.now(), data });
}

const DISTRICTS = {
    dhaka:      { lat: 23.8103, lng: 90.4125 },
    savar:      { lat: 23.8583, lng: 90.2667 },
    chittagong: { lat: 22.3569, lng: 91.7832 },
    sylhet:     { lat: 24.8949, lng: 91.8687 },
    khulna:     { lat: 22.8456, lng: 89.5403 },
    rajshahi:   { lat: 24.3745, lng: 88.6042 },
    barisal:    { lat: 22.7010, lng: 90.3535 },
    rangpur:    { lat: 25.7439, lng: 89.2752 },
    mymensingh: { lat: 24.7471, lng: 90.4203 },
    sirajganj:  { lat: 24.4533, lng: 89.7009 }
};

const ALIASES = { chattogram: 'chittagong', chattagram: 'chittagong', barishal: 'barisal', dacca: 'dhaka' };
function _resolve(k) { const key = String(k || '').toLowerCase().trim(); return ALIASES[key] || key; }

async function _fetchRainfall(lat, lng, pastDays) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS);
    try {
        const url = `https://api.open-meteo.com/v1/forecast?` +
            `latitude=${lat.toFixed(4)}&longitude=${lng.toFixed(4)}` +
            `&hourly=precipitation` +
            `&daily=precipitation_sum` +
            `&past_days=${pastDays}` +
            `&forecast_days=1` +
            `&timezone=Asia%2FDhaka`;

        const res = await fetch(url, { signal: controller.signal });
        clearTimeout(timer);
        if (!res.ok) { console.warn('[Rainfall] Open-Meteo HTTP', res.status); return null; }

        const data = await res.json();
        if (!data.hourly || !Array.isArray(data.hourly.precipitation)) {
            console.warn('[Rainfall] Invalid Open-Meteo response');
            return null;
        }

        return {
            hourly: data.hourly.precipitation.map(v => Number(v) || 0),
            times: data.hourly.time || [],
            dailySum: data.daily && Array.isArray(data.daily.precipitation_sum)
                ? data.daily.precipitation_sum.map(v => Number(v) || 0)
                : null
        };
    } catch (err) {
        clearTimeout(timer);
        console.warn('[Rainfall] Fetch failed:', err.message);
        return null;
    }
}

async function getCumulativeRainfall(districtKey, days) {
    days = Math.max(1, Math.min(days || 7, 30));
    const key = _resolve(districtKey);
    const coords = DISTRICTS[key] || DISTRICTS.dhaka;
    const cacheKey = `rain_${key}_${days}`;

    const cached = _cacheGet(cacheKey);
    if (cached) return cached;

    const result = await _fetchRainfall(coords.lat, coords.lng, days);
    if (!result) {
        return { available: false, district: key, error: 'Open-Meteo API unreachable' };
    }

    /* Prefer daily sums (already accumulated per day by API) */
    let total = 0;
    let daily = [];
    if (result.dailySum && result.dailySum.length >= days) {
        const recent = result.dailySum.slice(-days);
        total = recent.reduce((s, v) => s + v, 0);
        daily = recent.map(v => Math.round(v * 10) / 10);
    } else {
        const hoursToSum = days * 24;
        const recent = result.hourly.slice(-hoursToSum);
        total = recent.reduce((s, v) => s + v, 0);
        for (let i = 0; i < days; i++) {
            const start = i * 24;
            const end = start + 24;
            const dayTotal = recent.slice(start, end).reduce((s, v) => s + v, 0);
            daily.push(Math.round(dayTotal * 10) / 10);
        }
    }

    const response = {
        available: true,
        totalMm: Math.round(total * 10) / 10,
        days: days,
        daily: daily,
        hourlyCount: result.hourly.length,
        source: 'Open-Meteo (NOAA GFS + ECMWF IFS satellite)',
        fetchedAt: new Date().toISOString(),
        district: key
    };

    _cacheSet(cacheKey, response);
    return response;
}

async function get7DayRainfall(districtKey) {
    return getCumulativeRainfall(districtKey, 7);
}

async function getLatestRainfall(districtKey) {
    const key = _resolve(districtKey);
    const coords = DISTRICTS[key] || DISTRICTS.dhaka;
    const cacheKey = `rain_latest_${key}`;

    const cached = _cacheGet(cacheKey);
    if (cached) return cached;

    const result = await _fetchRainfall(coords.lat, coords.lng, 1);
    if (!result || !result.hourly.length) {
        return { available: false, district: key, error: 'API unreachable' };
    }

    const latest24h = result.hourly.slice(-24).reduce((s, v) => s + v, 0);
    const response = {
        available: true,
        rain24hMm: Math.round(latest24h * 10) / 10,
        source: 'Open-Meteo (NOAA GFS + ECMWF IFS satellite)',
        fetchedAt: new Date().toISOString(),
        district: key
    };
    _cacheSet(cacheKey, response);
    return response;
}

async function detectHeavyRain(districtKey, threshold48h) {
    threshold48h = threshold48h || 50;
    const r2 = await getCumulativeRainfall(districtKey, 2);
    if (!r2.available) return r2;
    return {
        available: true,
        isHeavy: r2.totalMm >= threshold48h,
        rain48hMm: r2.totalMm,
        threshold: threshold48h,
        source: r2.source
    };
}

function getGpmFreshnessBadge() {
    return `<div style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px;background:#0891B215;border:1px solid #0891B240;border-radius:8px;font-size:11px;font-weight:700;color:#0891B2;">
        <span style="width:8px;height:8px;border-radius:50%;background:#0891B2;animation:dvFreshnessPulse 1.8s infinite;"></span>
        <span>Live Rainfall · Open-Meteo (GFS/IFS satellite)</span>
    </div>`;
}

window.NasaGpm = {
    getCumulativeRainfall,
    get7DayRainfall,
    getLatestRainfall,
    detectHeavyRain,
    getGpmFreshnessBadge,
    DISTRICTS,
    SOURCE: 'Open-Meteo (NOAA GFS + ECMWF IFS satellite rainfall — live)'
};

console.log('[NasaGpm] v2.1 loaded');
})();