/* DailyVet — NASA Global Flood Product v2.2 */
(function () {
'use strict';

const GIBS_WMS_URL = 'https://gibs.earthdata.nasa.gov/wms/epsg4326/best/wms.cgi';
const FLOOD_LAYER = 'MODIS_Combined_Flood_2-Day';
const API_TIMEOUT_MS = 12000;

const _cache = new Map();
const DISTRICTS = {
    dhaka: { lat: 23.8103, lng: 90.4125 }, savar: { lat: 23.8583, lng: 90.2667 },
    chittagong: { lat: 22.3569, lng: 91.7832 }, sylhet: { lat: 24.8949, lng: 91.8687 },
    khulna: { lat: 22.8456, lng: 89.5403 }, rajshahi: { lat: 24.3745, lng: 88.6042 },
    barisal: { lat: 22.7010, lng: 90.3535 }, rangpur: { lat: 25.7439, lng: 89.2752 },
    mymensingh: { lat: 24.7471, lng: 90.4203 }, sirajganj: { lat: 24.4533, lng: 89.7009 },
    kurigram: { lat: 25.8072, lng: 89.6295 }, gaibandha: { lat: 25.3288, lng: 89.5286 },
    sunamganj: { lat: 25.0658, lng: 91.3950 }
};

function _resolve(k) {
    const key = String(k || '').toLowerCase().trim();
    return { chattogram: 'chittagong', chattagram: 'chittagong', barishal: 'barisal', dacca: 'dhaka' }[key] || key;
}

async function _drawToCanvas(blob) {
    const canvas = document.createElement('canvas');
    canvas.width = 5; canvas.height = 5;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    if (typeof createImageBitmap === 'function') {
        try {
            const bitmap = await createImageBitmap(blob);
            ctx.drawImage(bitmap, 0, 0);
            return ctx.getImageData(0, 0, 5, 5);
        } catch (_) { /* fall through */ }
    }

    return new Promise(resolve => {
        const img = new Image();
        const url = URL.createObjectURL(blob);
        img.onload = () => {
            try {
                ctx.drawImage(img, 0, 0);
                URL.revokeObjectURL(url);
                resolve(ctx.getImageData(0, 0, 5, 5));
            } catch (err) {
                URL.revokeObjectURL(url); resolve(null);
            }
        };
        img.onerror = () => { URL.revokeObjectURL(url); resolve(null); };
        img.src = url;
    });
}

async function _fetchFloodViaGetMap(lat, lng) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS);

    try {
        const bboxSize = 0.05;
        const url = `${GIBS_WMS_URL}?SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&` +
            `LAYERS=${FLOOD_LAYER}&SRS=EPSG:4326&` +
            `BBOX=${(lng - bboxSize).toFixed(4)},${(lat - bboxSize).toFixed(4)},${(lng + bboxSize).toFixed(4)},${(lat + bboxSize).toFixed(4)}&` +
            `WIDTH=5&HEIGHT=5&FORMAT=image/png&TRANSPARENT=TRUE&EXCEPTIONS=BLANK`;

        const res = await fetch(url, { signal: controller.signal });
        clearTimeout(timer);

        if (!res.ok) return null;

        const blob = await res.blob();
        if (!blob || blob.size < 50) return { flooded: false, redRatio: 0, redPixels: 0, totalPixels: 0, empty: true };

        const imageData = await _drawToCanvas(blob);
        if (!imageData) return null;

        const data = imageData.data;
        let redPixels = 0, totalNonTransparent = 0;

        for (let i = 0; i < data.length; i += 4) {
            const r = data[i], g = data[i + 1], b = data[i + 2], a = data[i + 3];
            if (a < 50) continue;
            totalNonTransparent++;
            if (r > 150 && g < 100 && b < 100) redPixels++;
        }

        const redRatio = totalNonTransparent > 0 ? redPixels / totalNonTransparent : 0;
        return { flooded: redRatio > 0.15, redRatio, redPixels, totalPixels: totalNonTransparent, empty: totalNonTransparent === 0 };
    } catch (err) {
        clearTimeout(timer);
        return null;
    }
}

async function getFloodInfo(districtKey) {
    const key = _resolve(districtKey);
    const coords = DISTRICTS[key] || DISTRICTS.dhaka;
    const cacheKey = `flood_${key}`;

    if (_cache.has(cacheKey)) return _cache.get(cacheKey);

    const result = await _fetchFloodViaGetMap(coords.lat, coords.lng);

    const response = {
        available: !!result,
        district: key,
        flooded: result ? result.flooded : false,
        floodValue: result ? result.redRatio : 0,
        confidence: result ? (result.empty ? 'no data for this period' : result.flooded ? 'detected' : 'not detected') : 'unavailable',
        redPixels: result ? result.redPixels : 0,
        totalPixels: result ? result.totalPixels : 0,
        source: 'NASA GIBS MODIS Combined Flood 2-Day',
        fetchedAt: new Date().toISOString()
    };

    _cache.set(cacheKey, response);
    return response;
}

function getFloodBadgeHtml(floodInfo) {
    if (!floodInfo || !floodInfo.available) {
        return `<div style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px;background:#94A3B815;border:1px solid #94A3B840;border-radius:8px;font-size:11px;font-weight:700;color:#64748B;"><span style="width:8px;height:8px;border-radius:50%;background:#94A3B8;"></span><span>Flood product · unavailable</span></div>`;
    }
    const color = floodInfo.flooded ? '#DC2626' : '#059669';
    const icon = floodInfo.flooded ? '🌊' : '✅';
    const label = floodInfo.flooded ? 'Flood detected' : 'No flood';
    return `<div style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px;background:${color}15;border:1px solid ${color}40;border-radius:8px;font-size:11px;font-weight:700;color:${color};"><span style="width:8px;height:8px;border-radius:50%;background:${color};"></span><span>${icon} NASA Flood: ${label}</span></div>`;
}

window.NasaFloodProduct = { getFloodInfo, getFloodBadgeHtml, DISTRICTS };
})();