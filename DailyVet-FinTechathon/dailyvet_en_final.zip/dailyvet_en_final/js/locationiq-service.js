/* ============================================================
   DailyVet — LocationIQ Service v1.0
   ✅ Search cities/upazilas/areas inside Bangladesh
   ✅ Reverse geocode (lat/lng → place name)
   ✅ In-memory cache (30 min)
   ✅ Fallback to Open-Meteo geocoding if LocationIQ fails
   ============================================================ */
(function () {
'use strict';

/* ⚠️ REPLACE with your own LocationIQ key before production */
const LOCATIONIQ_KEY = 'pk.6233e1f050e2472d37bc17cb18a3b519';
const LOCATIONIQ_URL = 'https://us1.locationiq.com/v1';

/* Cache */
const CACHE_TTL_MS = 30 * 60 * 1000;
const _searchCache = new Map();
const _reverseCache = new Map();

const cacheKey = (q, opts) => `${(q || '').toLowerCase().trim()}|${JSON.stringify(opts || {})}`;

function _readCache(cache, key) {
    const e = cache.get(key);
    if (!e) return null;
    if (Date.now() - e.at > CACHE_TTL_MS) { cache.delete(key); return null; }
    return e.data;
}
function _writeCache(cache, key, data) {
    cache.set(key, { at: Date.now(), data });
    if (cache.size > 100) cache.delete(cache.keys().next().value);
}

/* ============================================================
   1. SEARCH places (district / upazila / area / village)
   ============================================================ */
async function search(query, options) {
    if (!query || String(query).trim().length < 2) return [];

    const opts = options || {};
    const key = cacheKey(query, opts);
    const hit = _readCache(_searchCache, key);
    if (hit) return hit;

    try {
        const params = new URLSearchParams({
            key: LOCATIONIQ_KEY,
            q: query,
            countrycodes: 'bd',
            format: 'json',
            limit: String(opts.limit || 10),
            addressdetails: '1',
            'accept-language': 'en',
            dedupe: '1',
            normalizecity: '1'
        });
        if (opts.state) params.set('state', opts.state);
        if (opts.viewbox) params.set('viewbox', opts.viewbox);

        const res = await fetch(`${LOCATIONIQ_URL}/search?${params}`);
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const data = await res.json();
        if (!Array.isArray(data)) return [];

        const results = data.map(r => ({
            name: r.display_place || (r.address && r.address.name) || String(r.display_name || '').split(',')[0],
            fullName: r.display_name || '',
            district: (r.address && (r.address.county || r.address.state_district || r.address.city_district)) || '',
            division: (r.address && r.address.state) || '',
            area: (r.address && (r.address.suburb || r.address.village || r.address.town || r.address.neighbourhood || r.address.hamlet)) || '',
            type: r.type || r.class || 'place',
            lat: parseFloat(r.lat),
            lng: parseFloat(r.lon),
            placeId: r.place_id
        })).filter(r => Number.isFinite(r.lat) && Number.isFinite(r.lng));

        _writeCache(_searchCache, key, results);
        return results;
    } catch (err) {
        console.warn('[LocationIQ] Search failed, using fallback:', err.message);
        return openMeteoFallback(query);
    }
}

/* ============================================================
   2. REVERSE geocode (coordinates → place name)
   ============================================================ */
async function reverse(lat, lng) {
    if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;

    const key = `${lat.toFixed(4)},${lng.toFixed(4)}`;
    const hit = _readCache(_reverseCache, key);
    if (hit) return hit;

    try {
        const params = new URLSearchParams({
            key: LOCATIONIQ_KEY,
            lat: String(lat),
            lon: String(lng),
            format: 'json',
            addressdetails: '1',
            'accept-language': 'en',
            zoom: '14'
        });

        const res = await fetch(`${LOCATIONIQ_URL}/reverse?${params}`);
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const r = await res.json();

        const result = {
            name: r.display_place || String(r.display_name || '').split(',')[0],
            fullName: r.display_name || '',
            district: (r.address && (r.address.county || r.address.state_district || r.address.city_district)) || '',
            division: (r.address && r.address.state) || '',
            area: (r.address && (r.address.suburb || r.address.village || r.address.town || r.address.neighbourhood || r.address.hamlet)) || '',
            lat, lng
        };

        _writeCache(_reverseCache, key, result);
        return result;
    } catch (err) {
        console.warn('[LocationIQ] Reverse failed:', err.message);
        return null;
    }
}

/* ============================================================
   3. FALLBACK — Open-Meteo geocoding (no key needed)
   ============================================================ */
async function openMeteoFallback(query) {
    try {
        const res = await fetch(
            `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&country=BD&count=10&language=en`
        );
        if (!res.ok) return [];
        const data = await res.json();
        return (data.results || []).map(r => ({
            name: r.name,
            fullName: [r.name, r.admin2, r.admin1].filter(Boolean).join(', '),
            district: r.admin2 || '',
            division: r.admin1 || '',
            area: '',
            type: 'place',
            lat: r.latitude,
            lng: r.longitude,
            placeId: r.id
        }));
    } catch (_) {
        return [];
    }
}

/* ============================================================
   PUBLIC API
   ============================================================ */
window.DVLocationIQ = {
    search,
    reverse,
    clearCache() { _searchCache.clear(); _reverseCache.clear(); }
};

console.log('✅ LocationIQ service loaded');

})();
