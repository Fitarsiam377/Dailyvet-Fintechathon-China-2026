/* ============================================================
   DailyVet — Insurance Policy Wizard v4.5 (Manual Payment & Custom Upload)
   ============================================================ */
(function () {
'use strict';

const CONFIG = {
  DRAFT_KEY: 'dvPolicyDraft_v4',
  DRAFT_TTL_MS: 30 * 60 * 1000,
  QUOTE_TIMEOUT_MS: 12000,
  RETRY_ATTEMPTS: 2,
  RETRY_DELAY_MS: 900,
  DEFAULT_COORDS: { lat: 23.8103, lng: 90.4125 }
};

const state = {
  step: 1,
  animal: 'cow',
  districtKey: 'dhaka',
  districtName: 'Dhaka',
  area: null,
  lat: CONFIG.DEFAULT_COORDS.lat,
  lng: CONFIG.DEFAULT_COORDS.lng,
  hasArea: false,
  premium: 0,
  riskLevel: 'Low',
  riskScore: 0,
  floodScore: 0,
  thi: 0,
  quoteLoaded: false,
  quoteLoading: false,
  quoteAbort: null,
  activating: false
};

const _el = id => document.getElementById(id);

const LOG = {
  _on: false,
  set on(v) { this._on = !!v; },
  info(...a) { if (this._on) console.info('[Policy]', ...a); },
  warn(...a) { if (this._on) console.warn('[Policy]', ...a); },
  error(...a) { console.error('[Policy]', ...a); }
};

/* ============================================================
   SCREENSHOT FILE UPLOAD HANDLER
   ============================================================ */
window.updateScreenshotName = function(input) {
  const display = _el('screenshotFileName');
  if (!display) return;

  if (input.files && input.files.length > 0) {
    display.textContent = input.files[0].name;
    display.style.color = '#10B981';
    display.style.fontWeight = '700';
  } else {
    display.textContent = 'No file chosen';
    display.style.color = '#64748B';
    display.style.fontWeight = '600';
  }
};

/* ============================================================
   PAYMENT STATUS HELPERS
   ============================================================ */
function setPayStatus(type, msg) {
  const el = _el('paymentStatus');
  if (!el) return;
  el.style.display = 'block';
  el.className = '';
  
  if (type === 'loading') el.classList.add('pay-status-loading');
  else if (type === 'success') el.classList.add('pay-status-success');
  else el.classList.add('pay-status-error');

  const icons = {
    loading: '<i class="fas fa-spinner fa-spin"></i>',
    success: '<i class="fas fa-check-circle"></i>',
    error: '<i class="fas fa-times-circle"></i>'
  };
  el.innerHTML = `${icons[type] || ''} ${msg}`;
}

/* ============================================================
   MAP / PICKER CALLBACK
   ============================================================ */
window.onPolicyLocationChange = function (payload) {
  if (!payload) return;

  state.districtKey  = payload.districtKey || 'dhaka';
  state.districtName = payload.districtName || 'Dhaka';
  state.hasArea      = !!payload.hasArea;
  state.area         = state.hasArea ? (payload.area || null) : null;
  state.lat = Number.isFinite(payload.lat) ? payload.lat : CONFIG.DEFAULT_COORDS.lat;
  state.lng = Number.isFinite(payload.lng) ? payload.lng : CONFIG.DEFAULT_COORDS.lng;

  const hidden = _el('policyDistrict');
  if (hidden) hidden.value = state.districtKey;

  if (state.step === 2 && state.quoteLoaded) {
    state.quoteLoaded = false;
    const btn = _el('btnProceedToConfirm');
    if (btn) btn.disabled = true;
  }
  saveDraft();
};

/* ============================================================
   INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  const phone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
  if (!phone) { window.location.href = 'login.html'; return; }

  restoreDraft();

  const animalSel = _el('policyAnimal');
  if (animalSel) {
    animalSel.value = state.animal;
    animalSel.addEventListener('change', () => {
      state.animal = animalSel.value;
      saveDraft();
    });
  }

  if (state.step > 1) {
    applyStep(state.step);
    if (state.step === 3) populateSummary();
  }
});

/* ============================================================
   DRAFT PERSISTENCE
   ============================================================ */
function saveDraft() {
  try {
    sessionStorage.setItem(CONFIG.DRAFT_KEY, JSON.stringify({
      ...state,
      quoteAbort: null,
      quoteLoading: false,
      activating: false,
      savedAt: Date.now()
    }));
  } catch (_) {}
}

function restoreDraft() {
  try {
    const raw = sessionStorage.getItem(CONFIG.DRAFT_KEY);
    if (!raw) return;
    const d = JSON.parse(raw);
    if (!d || Date.now() - (d.savedAt || 0) > CONFIG.DRAFT_TTL_MS) {
      sessionStorage.removeItem(CONFIG.DRAFT_KEY);
      return;
    }
    Object.assign(state, {
      animal:       d.animal || 'cow',
      districtKey:  d.districtKey || 'dhaka',
      districtName: d.districtName || 'Dhaka',
      area:         d.area || null,
      lat:          Number.isFinite(d.lat) ? d.lat : CONFIG.DEFAULT_COORDS.lat,
      lng:          Number.isFinite(d.lng) ? d.lng : CONFIG.DEFAULT_COORDS.lng,
      hasArea:      !!d.hasArea,
      premium:      d.premium || 0,
      riskLevel:    d.riskLevel || 'Low',
      riskScore:    d.riskScore || 0,
      floodScore:   d.floodScore || 0,
      thi:          d.thi || 0,
      step:         Math.min(3, Math.max(1, d.step || 1))
    });
  } catch (_) {}
}

function clearDraft() {
  try { sessionStorage.removeItem(CONFIG.DRAFT_KEY); } catch (_) {}
}

/* ============================================================
   NAVIGATION
   ============================================================ */
async function goToStep(step) {
  step = Math.max(1, Math.min(3, step));

  if (step === 2) {
    const animalSel = _el('policyAnimal');
    const animal = animalSel ? animalSel.value : state.animal;

    if (!state.districtKey) { alert('Please select a district first.'); return; }
    if (!animal)            { alert('Please select an animal first.'); return; }

    state.animal = animal;

    applyStep(2);
    await fetchLiveQuote(state.animal, state.districtKey);
  } else if (step === 3) {
    if (!state.quoteLoaded) { alert('Please wait for the quote to finish.'); return; }
    applyStep(3);
    populateSummary();
  } else {
    applyStep(1);
  }

  state.step = step;
  saveDraft();
}
window.goToStep = goToStep;

function applyStep(step) {
  [1, 2, 3].forEach(i => {
    const ind = _el(`step${i}Indicator`);
    if (ind) {
      ind.classList.remove('active', 'completed');
      ind.setAttribute('aria-selected', i === step ? 'true' : 'false');
      if (i < step) ind.classList.add('completed');
      if (i === step) ind.classList.add('active');
    }
    const panel = _el(`panel${i}`);
    if (panel) panel.classList.toggle('active', i === step);
  });
}

/* ============================================================
   LIVE QUOTE
   ============================================================ */
async function fetchLiveQuote(animal, district) {
  if (state.quoteAbort) { try { state.quoteAbort.abort(); } catch (_) {} }
  state.quoteAbort = new AbortController();
  state.quoteLoading = true;
  state.quoteLoaded = false;

  const loadingEl = _el('nasaLoadingTxt');
  const floodEl   = _el('nasaFloodVal');
  const heatEl    = _el('nasaHeatVal');
  const premiumEl = _el('quotePremiumVal');
  const riskEl    = _el('quoteRiskLevelTxt');
  const label     = _el('riskDistrictLabel');
  const btn       = _el('btnProceedToConfirm');

  if (loadingEl) loadingEl.style.display = 'block';
  if (floodEl)   { floodEl.textContent = '--%'; floodEl.style.color = ''; }
  if (heatEl)    { heatEl.textContent  = '--';  heatEl.style.color  = ''; }
  if (premiumEl) premiumEl.textContent = '৳ ---';
  if (riskEl)    { riskEl.textContent = 'Calculating...'; riskEl.style.color = ''; }
  if (btn) btn.disabled = true;

  if (label) {
    const display = state.area
      ? `${state.area}, ${state.districtName}`
      : state.districtName;
    label.textContent = display.toUpperCase();
  }

  const useArea = state.hasArea && Number.isFinite(state.lat) && Number.isFinite(state.lng);
  const lat = useArea ? state.lat : null;
  const lng = useArea ? state.lng : null;

  let lastErr = null;

  for (let attempt = 1; attempt <= CONFIG.RETRY_ATTEMPTS; attempt++) {
    if (state.quoteAbort.signal.aborted) return;

    try {
      if (typeof window.fetchLiveRiskData !== 'function') {
        throw new Error('Insurance engine not loaded');
      }

      const riskData = await withTimeout(
        window.fetchLiveRiskData(district, lat, lng),
        CONFIG.QUOTE_TIMEOUT_MS
      );

      if (state.quoteAbort.signal.aborted) return;
      if (!riskData) throw new Error('Empty NASA response');

      if (typeof window.calculatePremiumFromRisk !== 'function') {
        throw new Error('Premium calculator not loaded');
      }
      const calc = window.calculatePremiumFromRisk(riskData, animal);

      state.premium    = calc.premium;
      state.riskLevel  = calc.level;
      state.riskScore  = calc.riskScore;
      state.floodScore = riskData.flood?.score || 0;
      state.thi        = riskData.heat?.thi || 0;
      state.quoteLoaded = true;
      state.quoteLoading = false;

      renderQuote(riskData, calc);
      saveDraft();
      return;

    } catch (err) {
      if (state.quoteAbort.signal.aborted) return;
      lastErr = err;
      LOG.warn(`Quote attempt ${attempt} failed:`, err.message);
      if (attempt < CONFIG.RETRY_ATTEMPTS) {
        await sleep(CONFIG.RETRY_DELAY_MS * attempt);
      }
    }
  }

  state.quoteLoading = false;
  state.quoteLoaded = false;
  if (loadingEl) {
    loadingEl.innerHTML = '<span style="color:#dc2626;">⚠️ Could not load NASA data. Check your internet and try again.</span>';
  }
  if (btn) btn.disabled = true;
  LOG.error('Quote failed after retries:', lastErr?.message);
}

function renderQuote(riskData, calc) {
  const loadingEl = _el('nasaLoadingTxt');
  const floodEl   = _el('nasaFloodVal');
  const heatEl    = _el('nasaHeatVal');
  const premiumEl = _el('quotePremiumVal');
  const riskEl    = _el('quoteRiskLevelTxt');
  const btn       = _el('btnProceedToConfirm');

  if (loadingEl) loadingEl.style.display = 'none';

  const flood = riskData.flood?.score || 0;
  if (floodEl) {
    floodEl.textContent = `${flood}%`;
    floodEl.style.color = flood > 70 ? '#DC2626' : flood > 40 ? '#D97706' : '#059669';
  }

  const thi = riskData.heat?.thi || 0;
  const heatLvl = riskData.heat?.level || 'normal';
  if (heatEl) {
    heatEl.textContent = `THI ${thi}`;
    heatEl.style.color = heatLvl === 'severe' ? '#DC2626'
                       : heatLvl === 'moderate' ? '#D97706'
                       : '#059669';
  }

  if (premiumEl) premiumEl.textContent = `৳ ${calc.premium}`;
  if (riskEl) {
    riskEl.textContent = `${calc.level} Risk Area`;
    riskEl.style.color = calc.color;
  }
  if (btn) btn.disabled = false;
}

/* ============================================================
   SUMMARY
   ============================================================ */
function populateSummary() {
  setText('sumAnimal',   state.animal.toUpperCase());
  setText('sumDistrict', state.districtName.toUpperCase());

  const areaRow = _el('sumAreaRow');
  const areaEl  = _el('sumArea');
  if (state.area && areaRow && areaEl) {
    areaEl.textContent = state.area;
    areaRow.style.display = 'flex';
  } else if (areaRow) {
    areaRow.style.display = 'none';
  }

  const riskEl = _el('sumRisk');
  if (riskEl) {
    riskEl.textContent = state.riskLevel;
    riskEl.style.color =
      (state.riskLevel === 'High' || state.riskLevel === 'Very High') ? '#DC2626' :
      state.riskLevel === 'Moderate' ? '#D97706' : '#059669';
  }

  setText('sumPremium', `৳ ${state.premium}`);
  
  const manualAmt = _el('manualPremiumAmount');
  if (manualAmt) manualAmt.textContent = state.premium;
}

/* ============================================================
   ACTIVATE POLICY (MANUAL PAYMENT)
   ============================================================ */
async function activatePolicy() {
  if (state.activating) return;
  if (!state.quoteLoaded) { alert('Please load a quote first.'); return; }

  const trxId = (_el('manualTrxId')?.value || '').trim().toUpperCase();
  const senderNumber = (_el('manualSenderNumber')?.value || '').trim();
  const screenshotInput = _el('manualScreenshot');
  const file = screenshotInput?.files?.[0];

  if (!trxId || trxId.length < 6) {
    setPayStatus('error', 'Enter a valid Transaction ID (TrxID).');
    _el('manualTrxId')?.focus();
    return;
  }
  if (!/^01\d{9}$/.test(senderNumber)) {
    setPayStatus('error', 'Enter the valid 11-digit mobile number you sent money from.');
    _el('manualSenderNumber')?.focus();
    return;
  }
  if (!file) {
    setPayStatus('error', 'Please upload the payment screenshot.');
    return;
  }

  const userPhone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
  if (!userPhone) {
    setPayStatus('error', 'Session expired. Please login again.');
    return;
  }

  // Check payout account exists
  try {
    const userDoc = await firebase.firestore().collection('users').doc(userPhone).get();
    const u = userDoc.data() || {};
    if (!u.payoutMethod || !u.payoutNumber) {
      setPayStatus('error',
        'Please add a payout account in your <a href="profile.html" style="color:#B91C1C;text-decoration:underline;font-weight:800;">Profile</a> first — claim money will be sent there.');
      return;
    }
  } catch (e) {
    console.warn('Payout check failed:', e.message);
  }

  const btn = _el('btnActivatePolicy');
  const originalHTML = btn ? btn.innerHTML : '';
  state.activating = true;
  if (btn) {
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading Proof...';
  }

  try {
    setPayStatus('loading', 'Uploading payment proof...');

    // Convert screenshot to base64
    const base64Screenshot = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = e => resolve(e.target.result);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });

    if (typeof window.savePolicy !== 'function') {
      setPayStatus('error', 'Policy engine not loaded. Please refresh.');
      state.activating = false;
      if (btn) { btn.disabled = false; btn.innerHTML = originalHTML; }
      return;
    }

    const policyId = await window.savePolicy({
      animalType: state.animal,
      district: state.districtKey,
      districtName: state.districtName,
      area: state.area || null,
      lat: state.lat,
      lng: state.lng,
      premium: state.premium,
      riskLevel: state.riskLevel,
      riskScore: state.riskScore,
      policyNumber: 'DV-' + Date.now().toString(36).toUpperCase(),
      
      // Manual payment details
      paymentMethod: 'manual',
      paymentTxnId: trxId,
      paymentSender: senderNumber,
      paymentScreenshot: base64Screenshot,
      paymentStatus: 'pending', 
      status: 'pending', // Admin must change to 'active'
      createdAt: new Date().toISOString()
    });

    if (!policyId) throw new Error('Could not save policy request.');

    clearDraft();
    setPayStatus('success', '✅ Proof submitted! We will verify the TrxID and activate your policy within 1-2 hours.');
    
    setTimeout(() => {
      window.location.href = 'insurance-dashboard.html';
    }, 2500);

  } catch (err) {
    LOG.error('Activation failed:', err);
    setPayStatus('error', '❌ ' + (err.message || 'Submission failed. Please contact support.'));
    state.activating = false;
    if (btn) { btn.disabled = false; btn.innerHTML = originalHTML; }
  }
}
window.activatePolicy = activatePolicy;

/* ============================================================
   UTILITIES
   ============================================================ */
function setText(id, value) {
  const el = _el(id);
  if (el) el.textContent = value;
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('Timeout')), ms);
    Promise.resolve(promise).then(
      v => { clearTimeout(timer); resolve(v); },
      e => { clearTimeout(timer); reject(e); }
    );
  });
}

})();
