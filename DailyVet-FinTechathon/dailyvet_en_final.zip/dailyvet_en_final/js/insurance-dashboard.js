/* ============================================================
   DailyVet - Insurance Dashboard v2.0 (Segment 4 Fix)
   - Users can view own policy and claim status
   - Pending, Paid, Rejected with full details
   - Real-time listener (admin updates instantly)
   - SEGMENT 4 FIX:
     * DASH_COVERED_HAZARDS now consistent with insurance.js
       (flood + heat + air) - previously hardcoded but
       documents the source of truth
     * DVRisk guard added for insurance-risk-map.js integration
     * All Bengali strings removed
   ============================================================ */

const _elDash = id => document.getElementById(id);

/* SEGMENT 4 FIX: must match DEFAULT_COVERED_HAZARDS in insurance.js */
const DASH_COVERED_HAZARDS = ['flood', 'heat', 'air'];

const DASH_HAZARD_META = {
    flood:   { name: 'Flood',       icon: 'W', unit: '%' },
    heat:    { name: 'Heat stress', icon: 'T', unit: 'THI' },
    drought: { name: 'Drought',     icon: 'D', unit: '' },
    air:     { name: 'Air quality', icon: 'A', unit: 'AQI' }
};

document.addEventListener('DOMContentLoaded', async () => {
    const phone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
    if (!phone) {
        window.location.href = 'login.html';
        return;
    }

    let policies = [];
    try { policies = await loadActivePolicies(); } catch (_) {}

    await loadAllPoliciesUI(policies);
    await loadLiveRiskUI(policies);

    if (window.DVInsuranceAdvisor && _elDash('insuranceAdvisorCard')) {
        try {
            await window.DVInsuranceAdvisor.render('insuranceAdvisorCard');
        } catch (err) {
            console.warn('[Dashboard] advisor render failed:', err.message);
        }
    }

    setupRealtimeListener(phone);
});

async function loadAllPoliciesUI(preloaded) {
    const container = _elDash('activePolicyContainer');
    if (!container) return;

    try {
        const phone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
        const snap = await firebase.firestore().collection('users').doc(phone)
            .collection('insurance_policies')
            .orderBy('createdAtMs', 'desc')
            .limit(10).get();

        const allDocs = snap.docs;
        const cancelledCount = allDocs.filter(d => d.data().status === 'cancelled').length;
        const validPolicies = allDocs.filter(doc => doc.data().status !== 'cancelled');

        if (validPolicies.length === 0) {
            const hintText = cancelledCount > 0
                ? `You have ${cancelledCount} cancelled polic${cancelledCount > 1 ? 'ies' : 'y'}. Buy a new one to get coverage.`
                : 'Protect your livestock from weather risks.';

            container.innerHTML = `
                <div class="empty-policy">
                    <div style="font-size: 2rem; margin-bottom: 0.5rem;">Shield</div>
                    <h4 style="font-size: 1rem; font-weight: 800; color: #1E293B; margin: 0 0 0.5rem;">No Active Policy</h4>
                    <p style="font-size: 0.8125rem; color: #64748B; margin: 0 0 1rem;">${hintText}</p>
                    <a href="insurance-policy.html" class="btn-ins btn-primary" style="display: inline-flex; width: auto; padding: 0.5rem 1.5rem;">
                        Buy Policy
                    </a>
                </div>
            `;
            return;
        }

        let html = '';
        let hasPending = false;

        validPolicies.forEach(doc => {
            const p = doc.data();
            const docId = doc.id;
            if (p.status === 'pending') hasPending = true;

            const claims = Array.isArray(p.claims) ? p.claims : [];
            const totalPaid = p.totalPaidOut || 0;

            let statusBadge = '';
            let borderColor = '#BFDBFE';
            if (p.status === 'active') {
                statusBadge = '<div class="pf-policy-badge" style="background:#10B981; font-size:0.6rem;">ACTIVE</div>';
            } else if (p.status === 'pending') {
                statusBadge = '<div class="pf-policy-badge" style="background:#F59E0B; font-size:0.6rem;">PENDING</div>';
                borderColor = '#FCD34D';
            } else if (p.status === 'rejected') {
                statusBadge = '<div class="pf-policy-badge" style="background:#DC2626; font-size:0.6rem;">REJECTED</div>';
                borderColor = '#FCA5A5';
            }

            let claimsHtml = '<div style="font-size:0.75rem; color:#94A3B8; font-style:italic;">No claims filed yet.</div>';
            if (claims.length > 0) {
                claimsHtml = claims.slice(-3).reverse().map(c => {
                    let claimStatusColor = '#64748B';
                    let claimStatusText = c.status || 'UNKNOWN';

                    if (c.status === 'pending_manual_verification') {
                        claimStatusColor = '#D97706';
                        claimStatusText = 'PENDING VERIFICATION';
                    }
                    else if (c.status === 'paid') {
                        claimStatusColor = '#047857';
                        claimStatusText = 'PAID';
                    }
                    else if (c.status === 'rejected') {
                        claimStatusColor = '#DC2626';
                        claimStatusText = 'REJECTED';
                    }

                    return `
                        <div style="display:flex; justify-content:space-between; align-items:center; font-size:0.75rem; padding:6px 0; border-bottom:1px solid #E2E8F0;">
                            <div>
                                <span style="font-weight:700; color:#0F172A;">${c.icon || 'Cash'} ${c.label}</span><br>
                                <span style="font-size:0.6875rem; color:#64748B;">${new Date(c.filedAt).toLocaleDateString('en-GB')}</span>
                            </div>
                            <div style="text-align:right;">
                                <span style="font-weight:800; color:#047857;">BDT ${c.payout.toLocaleString('en-IN')}</span><br>
                                <span style="font-size:0.625rem; font-weight:800; color:${claimStatusColor};">${claimStatusText}</span>
                            </div>
                        </div>
                    `;
                }).join('');
            }

            html += `
                <div style="padding: 1rem; background: #F8FAFC; border: 1.5px solid ${borderColor}; border-radius: 14px; margin-bottom: 0.75rem; position:relative;">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem;">
                        <div>
                            ${statusBadge}
                            <div style="font-size: 1.125rem; font-weight: 900; color: #0F172A; margin-top: 4px;">
                                ${(p.animalType || 'cow').toUpperCase()} - ${(p.districtName || p.district || 'dhaka').toUpperCase()}
                            </div>
                            <div style="font-size: 0.75rem; color: #64748B;">Policy No: <b>${p.policyNumber || '-'}</b></div>
                        </div>
                        <div style="text-align: right;">
                            <div style="font-size: 0.75rem; font-weight: 700; color: #64748B;">Premium</div>
                            <div style="font-size: 1.125rem; font-weight: 900; color: #1E40AF;">BDT ${p.premium}/mo</div>
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; padding-top: 0.75rem; border-top: 1px dashed #CBD5E1; margin-bottom: 0.75rem;">
                        <div>
                            <div style="font-size: 0.75rem; font-weight: 700; color: #64748B;">Total Payouts</div>
                            <div style="font-size: 1rem; font-weight: 900; color: #047857;">BDT ${totalPaid.toLocaleString('en-IN')}</div>
                        </div>
                        <div>
                            <div style="font-size: 0.75rem; font-weight: 700; color: #64748B;">Claims Filed</div>
                            <div style="font-size: 1rem; font-weight: 900; color: #0F172A;">${claims.length}</div>
                        </div>
                    </div>

                    <div style="background:#fff; border:1px solid #E2E8F0; border-radius:10px; padding:0.75rem; margin-bottom:0.75rem;">
                        <div style="font-size:0.6875rem; font-weight:800; color:#64748B; text-transform:uppercase; margin-bottom:0.5rem;">Recent Claims</div>
                        ${claimsHtml}
                    </div>

                    <div style="text-align: right;">
                        <button onclick="cancelPolicy('${docId}', '${p.policyNumber || 'N/A'}')"
                                style="background: #FEF2F2; color: #DC2626; border: 1px solid #FECACA; padding: 6px 12px; border-radius: 8px; font-size: 0.75rem; font-weight: 700; cursor: pointer;">
                            <i class="fas fa-times-circle"></i> Cancel Policy
                        </button>
                    </div>

                    ${p.status === 'pending' ? `<div style="font-size: 0.75rem; color: #92400E; margin-top: 8px;"><i class="fas fa-info-circle"></i> Awaiting admin verification of your payment proof.</div>` : ''}
                </div>
            `;
        });

        container.innerHTML = html;

        const notice = _elDash('pendingNotice');
        if (notice) {
            notice.style.display = hasPending ? 'flex' : 'none';
        }

    } catch (err) {
        console.error('Load policy UI failed:', err);
        container.innerHTML = `<div style="color: #DC2626; font-size: 0.875rem;">Failed to load policies. Please refresh.</div>`;
    }
}

window.cancelPolicy = async function(policyId, policyNumber) {
    if (!confirm(`Are you sure you want to cancel policy ${policyNumber}?\n\nThis action cannot be undone.`)) return;
    if (!confirm('Are you absolutely sure? You will lose your coverage.')) return;

    const phone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
    if (!phone) return;

    try {
        const ref = firebase.firestore().collection('users').doc(phone)
            .collection('insurance_policies').doc(policyId);

        await ref.update({
            status: 'cancelled',
            paymentStatus: 'cancelled',
            cancelledAt: Date.now(),
            cancelledAtServer: firebase.firestore.FieldValue.serverTimestamp()
        });

        alert('Policy cancelled successfully.');
        window.location.reload();

    } catch (err) {
        console.error('Cancel failed:', err);
        alert('Failed to cancel: ' + err.message);
    }
};

async function loadLiveRiskUI(preloaded) {
    const gauge = _elDash('riskGauge');
    const scoreVal = _elDash('riskScoreVal');
    const statusTxt = _elDash('riskStatusText');
    const reasonTxt = _elDash('riskReasonText');
    const triggerContainer = _elDash('triggerListContainer');
    const districtLabel = _elDash('liveDistrictLabel');

    let district = 'dhaka', animal = 'cow', lat, lng, areaName = '';
    const policies = preloaded || [];
    const activePolicy = policies.find(p => p.status === 'active');

    if (activePolicy) {
        district = activePolicy.district || 'dhaka';
        animal = activePolicy.animalType || 'cow';
        lat = activePolicy.lat; lng = activePolicy.lng;
        areaName = activePolicy.area ? activePolicy.area + ', ' : '';
    }

    if (districtLabel) {
        districtLabel.textContent = (areaName + ((window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[district]) ? window.BD_DISTRICTS_LIST[district].name : district)).toUpperCase();
    }

    try {
        if (triggerContainer) {
            triggerContainer.innerHTML = `<div style="text-align: center; color: #64748B; padding: 1rem;"><i class="fas fa-spinner fa-spin"></i> Checking NASA triggers...</div>`;
        }

        const result = await detectTriggers(district, animal, lat, lng);
        const triggers = result.triggers || [];
        const coverageGaps = result.coverageGaps || [];

        let riskScore = 0;
        if (triggers && triggers.length > 0) {
            const totalPayout = triggers.reduce((sum, t) => sum + (t.payout || 0), 0);
            riskScore = Math.min(95, Math.round((totalPayout / 3000) * 100));
            if (riskScore < 30) riskScore = 40;
        } else {
            riskScore = 15;
        }

        let color = '#10B981';
        let status = 'Low Risk';
        if (riskScore > 70) { color = '#DC2626'; status = 'High Risk'; }
        else if (riskScore > 40) { color = '#F59E0B'; status = 'Moderate Risk'; }

        if (gauge) gauge.style.background = `conic-gradient(${color} ${riskScore}%, #E2E8F0 ${riskScore}%)`;
        if (scoreVal) { scoreVal.textContent = `${riskScore}%`; scoreVal.style.color = color; }
        if (statusTxt) { statusTxt.textContent = status; statusTxt.style.color = color; }
        if (reasonTxt) {
            reasonTxt.textContent = triggers.length > 0
                ? `${triggers.length} trigger(s) detected`
                : 'All indices normal';
        }

        if (triggerContainer) {
            if (triggers.length === 0) {
                triggerContainer.innerHTML = `
                    <div class="trigger-row" style="background: #ECFDF5; border-color: #86EFAC;">
                        <div class="trigger-label" style="color: #047857;">
                            <i class="fas fa-check-circle"></i> No active triggers
                        </div>
                        <div class="trigger-status" style="background: #DCFCE7; color: #047857;">Safe</div>
                    </div>
                `;
            } else {
                triggerContainer.innerHTML = triggers.map(t => `
                    <div class="trigger-row">
                        <div class="trigger-label">
                            ${t.icon} ${t.label}
                        </div>
                        <div class="trigger-status" style="background: ${t.severity === 'critical' ? '#FEE2E2' : '#FEF3C7'}; color: ${t.severity === 'critical' ? '#DC2626' : '#B45309'};">
                            Triggered
                        </div>
                    </div>
                `).join('');
            }
        }

        await renderRiskCoverageTable(coverageGaps, policies);

        if (window.DVInsuranceAdvisor && _elDash('insuranceAdvisorCard')) {
            try {
                await window.DVInsuranceAdvisor.render('insuranceAdvisorCard');
            } catch (err) {
                console.warn('[Dashboard] advisor refresh failed:', err.message);
            }
        }

    } catch (err) {
        console.error('Risk fetch failed:', err);
        if (triggerContainer) {
            triggerContainer.innerHTML = `<div style="color: #DC2626; font-size: 0.8125rem;">Failed to fetch NASA data. Check internet.</div>`;
        }
        if (reasonTxt) reasonTxt.textContent = 'Data unavailable';
    }
}

async function renderRiskCoverageTable(coverageGaps, policies) {
    let host = _elDash('riskCoverageTable');
    if (!host) return;

    let risk = null;
    let district = 'dhaka', lat, lng;
    const activePolicy = (policies || []).find(p => p.status === 'active');
    if (activePolicy) {
        district = activePolicy.district || 'dhaka';
        lat = activePolicy.lat; lng = activePolicy.lng;
    }
    try {
        if (typeof window.fetchLiveRiskData === 'function') {
            risk = await window.fetchLiveRiskData(district, lat, lng);
        }
    } catch (err) {
        console.warn('[Dashboard] risk coverage fetch failed:', err.message);
    }
    if (!risk) { host.innerHTML = ''; return; }

    const floodScore = risk.flood?.score || 0;
    const heatLevel = risk.heat?.level || 'normal';
    const heatThi = risk.heat?.thi || 0;
    const aqi = risk.air?.aqi;
    const droughtTriggered = Array.isArray(coverageGaps) && coverageGaps.some(g => g.hazard === 'drought');

    const hazards = [
        { key: 'flood',   value: floodScore + '%',                        level: floodScore > 70 ? 'high' : floodScore > 40 ? 'medium' : 'low',   score: floodScore },
        { key: 'heat',    value: heatThi ? 'THI ' + Math.round(heatThi) : 'n/a',
                          level: heatLevel === 'severe' ? 'high' : heatLevel === 'moderate' ? 'medium' : 'low', score: heatLevel === 'severe' ? 80 : heatLevel === 'moderate' ? 50 : 10 },
        { key: 'drought', value: droughtTriggered ? 'Active' : 'None',    level: droughtTriggered ? 'high' : 'low',                              score: droughtTriggered ? 75 : 5 },
        { key: 'air',     value: Number.isFinite(aqi) ? 'AQI ' + Math.round(aqi) : 'n/a',
                          level: Number.isFinite(aqi) ? (aqi > 200 ? 'high' : aqi > 100 ? 'medium' : 'low') : 'low', score: Number.isFinite(aqi) ? Math.min(100, aqi / 3) : 5 }
    ];

    const LEVEL_META = {
        high:   { color: '#DC2626', bg: '#FEF2F2', border: '#FECACA', text: 'High' },
        medium: { color: '#D97706', bg: '#FFFBEB', border: '#FDE68A', text: 'Medium' },
        low:    { color: '#059669', bg: '#ECFDF5', border: '#86EFAC', text: 'Low' }
    };

    const rows = hazards.map(h => {
        const meta = DASH_HAZARD_META[h.key] || { name: h.key, icon: '*' };
        const levelMeta = LEVEL_META[h.level] || LEVEL_META.low;
        const covered = DASH_COVERED_HAZARDS.includes(h.key);
        const isGap = !covered && h.level !== 'low';

        const rowBg = isGap ? '#FEF2F2' : '#FFFFFF';
        const rowBorder = isGap ? '#FECACA' : '#E2E8F0';

        const covPill = covered
            ? `<span style="padding: 2px 8px; border-radius: 999px; font-size: 10px; font-weight: 800; background: #ECFDF5; color: #047857; border: 1px solid #86EFAC;">Covered</span>`
            : isGap
                ? `<span style="padding: 2px 8px; border-radius: 999px; font-size: 10px; font-weight: 800; background: #FEE2E2; color: #B91C1C; border: 1px solid #FCA5A5;">Not covered</span>`
                : `<span style="padding: 2px 8px; border-radius: 999px; font-size: 10px; font-weight: 800; background: #F1F5F9; color: #64748B; border: 1px solid #E2E8F0;">Not covered</span>`;

        return `
            <div style="display: grid; grid-template-columns: 1.2fr 1fr 1fr; gap: 8px; align-items: center; padding: 10px 12px; background: ${rowBg}; border-bottom: 1px solid ${rowBorder}; font-size: 12.5px;">
                <div style="display: flex; align-items: center; gap: 8px; font-weight: 700; color: ${isGap ? '#B91C1C' : '#0F172A'};">
                    <span style="font-size: 14px;">${meta.icon}</span>
                    <span>${meta.name}</span>
                </div>
                <div style="display: flex; align-items: center; gap: 6px; color: ${levelMeta.color}; font-weight: 800;">
                    ${h.value}
                    <span style="padding: 1px 6px; border-radius: 6px; font-size: 10px; background: ${levelMeta.bg}; border: 1px solid ${levelMeta.border}; color: ${levelMeta.color};">
                        ${levelMeta.text}
                    </span>
                </div>
                <div style="text-align: right;">${covPill}</div>
            </div>
        `;
    }).join('');

    const gapCount = hazards.filter(h => !DASH_COVERED_HAZARDS.includes(h.key) && h.level !== 'low').length;

    host.innerHTML = `
        <div style="background: #fff; border: 1.5px solid #E2E8F0; border-radius: 14px; overflow: hidden;">
            <div style="display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 10px 14px; background: ${gapCount > 0 ? '#FEF2F2' : '#F0FDF4'}; border-bottom: 1.5px solid ${gapCount > 0 ? '#FECACA' : '#BBF7D0'};">
                <div style="display: flex; align-items: center; gap: 8px;">
                    <i class="fas ${gapCount > 0 ? 'fa-triangle-exclamation' : 'fa-shield-halved'}" style="color: ${gapCount > 0 ? '#DC2626' : '#059669'}; font-size: 13px;"></i>
                    <span style="font-size: 12.5px; font-weight: 900; color: ${gapCount > 0 ? '#991B1B' : '#065F46'};">Risk vs Coverage</span>
                </div>
                <span style="font-size: 11px; font-weight: 800; color: ${gapCount > 0 ? '#B91C1C' : '#047857'};">
                    ${gapCount > 0 ? `${gapCount} gap${gapCount > 1 ? 's' : ''} detected` : 'All covered'}
                </span>
            </div>
            <div style="display: grid; grid-template-columns: 1.2fr 1fr 1fr; gap: 8px; padding: 8px 12px; background: #F8FAFC; border-bottom: 1px solid #E2E8F0; font-size: 10.5px; font-weight: 800; color: #64748B; text-transform: uppercase; letter-spacing: 0.04em;">
                <span>Hazard</span>
                <span>Current risk</span>
                <span style="text-align: right;">Coverage</span>
            </div>
            ${rows}
            ${gapCount > 0 ? `
                <div style="padding: 10px 14px; background: #FFFBEB; border-top: 1px solid #FDE68A;">
                    <div style="display: flex; align-items: flex-start; gap: 8px;">
                        <i class="fas fa-lightbulb" style="color: #D97706; font-size: 12px; margin-top: 2px;"></i>
                        <div style="font-size: 11.5px; color: #92400E; line-height: 1.5;">
                            You are exposed to uncovered risks. <b>Consider upgrading your policy</b> before the next season.
                            <div style="margin-top: 6px;">
                                <a href="insurance-policy.html" style="font-weight: 800; color: #B45309; text-decoration: underline;">Add coverage</a>
                            </div>
                        </div>
                    </div>
                </div>
            ` : ''}
        </div>
    `;
}

function setupRealtimeListener(phone) {
    if (!phone) return;

    firebase.firestore()
        .collection('users').doc(phone)
        .collection('insurance_policies')
        .onSnapshot(snapshot => {
            snapshot.docChanges().forEach(change => {
                if (change.type === 'modified') {
                    const newData = change.doc.data();

                    if (newData.status === 'active' && newData.paymentStatus === 'verified') {
                        showToast('Payment Verified! Your policy is now ACTIVE.');
                        setTimeout(() => window.location.reload(), 2500);
                    }
                    if (newData.status === 'rejected') {
                        showToast('Your payment proof was rejected. Please check your profile.', 'error');
                        setTimeout(() => window.location.reload(), 2500);
                    }
                }
            });
        });
}

function showToast(msg, type = 'success') {
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed; top: 20px; left: 50%; transform: translateX(-50%);
        background: ${type === 'error' ? '#FEF2F2' : '#ECFDF5'};
        color: ${type === 'error' ? '#DC2626' : '#065F46'};
        padding: 14px 24px; border-radius: 10px; font-weight: 700; font-size: 14px;
        box-shadow: 0 8px 25px rgba(0,0,0,0.2); z-index: 9999;
        border: 1px solid ${type === 'error' ? '#FECACA' : '#86EFAC'};
        animation: fadeInDown 0.3s ease; text-align: center; max-width: 90vw;
    `;
    toast.textContent = msg;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}