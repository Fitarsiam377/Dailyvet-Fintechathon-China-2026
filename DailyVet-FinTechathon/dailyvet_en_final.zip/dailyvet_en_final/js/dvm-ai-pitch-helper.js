/* DailyVet — AI Pitch Helper v1.1

   Judges-facing utilities:
   • Predefined demo scenarios (Savar + Sirajganj)
   • One-click switch to a scenario
   • Export full feature report as PDF (via browser print) or JSON
   • Live demo overlay showing what's happening

   Zero hardcoded data: every scenario triggers LIVE API calls.

   v1.1 changes:
   • captureLiveSnapshots() handles missing modules gracefully
   • Diagnostic panel shows per-module availability with color
   • Toast messages English-only
   • Removed unused scenario.focus field
*/
(function () {
'use strict';

const _el = id => document.getElementById(id);
const _ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const escapeHtml = t => String(t == null ? '' : t).replace(/[&<>"']/g, c => _ESC[c]);

/* ============================================================
   SCENARIOS — predefined demo setups
   ============================================================ */
const SCENARIOS = {
    savar: {
        id: 'savar',
        name: 'Savar (Central)',
        subtitle: 'Moderate climate, mixed farming',
        district: 'savar',
        accent: '#0891B2',
        hint: 'Good baseline demo — moderate THI, mixed NDVI'
    },
    sirajganj: {
        id: 'sirajganj',
        name: 'Sirajganj (Jamuna basin)',
        subtitle: 'High flood risk, char area',
        district: 'sirajganj',
        accent: '#2563EB',
        hint: 'Best for flood demo — upstream basin effect visible'
    }
};

/* ============================================================
   OVERLAY UI
   ============================================================ */
function injectStyles() {
    if (_el('dvPitchStyles')) return;
    const st = document.createElement('style');
    st.id = 'dvPitchStyles';
    st.textContent = `
    .dv-pitch-bar{position:fixed;bottom:20px;right:20px;z-index:9998;display:flex;flex-direction:column;gap:8px;align-items:flex-end;font-family:inherit;}
    .dv-pitch-bar-btn{padding:10px 16px;background:#0F5132;color:#fff;border:none;border-radius:12px;font-size:12.5px;font-weight:800;cursor:pointer;box-shadow:0 6px 18px rgba(15,81,50,0.3);display:inline-flex;align-items:center;gap:8px;transition:transform 0.15s,box-shadow 0.15s;}
    .dv-pitch-bar-btn:hover{transform:translateY(-2px);box-shadow:0 10px 24px rgba(15,81,50,0.4);}
    .dv-pitch-bar-btn:active{transform:translateY(0);}
    .dv-pitch-panel{position:fixed;bottom:80px;right:20px;width:340px;max-height:60vh;overflow:auto;background:#fff;border:1.5px solid #D1E7DD;border-radius:16px;box-shadow:0 12px 36px rgba(15,81,50,0.2);padding:14px;z-index:9999;font-family:inherit;}
    .dv-pitch-panel-head{display:flex;justify-content:space-between;align-items:center;padding-bottom:10px;border-bottom:1px solid #E8F5F0;margin-bottom:10px;}
    .dv-pitch-panel-title{font-size:13px;font-weight:900;color:#0F5132;margin:0;display:inline-flex;align-items:center;gap:6px;}
    .dv-pitch-close{background:none;border:none;color:#94A3B8;font-size:15px;cursor:pointer;padding:2px 6px;border-radius:6px;}
    .dv-pitch-close:hover{background:#FEE2E2;color:#DC2626;}
    .dv-pitch-scenario{padding:10px 12px;background:#F8FAFC;border:1.5px solid #E2E8F0;border-radius:12px;cursor:pointer;margin-bottom:8px;transition:border-color 0.15s,background 0.15s;}
    .dv-pitch-scenario:hover{border-color:#0E7C7B;background:#fff;}
    .dv-pitch-scenario.active{border-color:#0E7C7B;background:#ECFDF5;}
    .dv-pitch-scenario-name{font-size:12.5px;font-weight:900;color:#0F5132;}
    .dv-pitch-scenario-sub{font-size:11px;color:#64748B;margin-top:2px;}
    .dv-pitch-scenario-hint{font-size:10.5px;color:#0891B2;margin-top:4px;font-weight:700;}
    .dv-pitch-actions{margin-top:12px;padding-top:10px;border-top:1px dashed #E2E8F0;display:flex;flex-direction:column;gap:6px;}
    .dv-pitch-action-btn{padding:9px 12px;background:#fff;border:1.5px solid #D1E7DD;border-radius:10px;font-size:11.5px;font-weight:800;color:#0F5132;cursor:pointer;display:inline-flex;align-items:center;gap:8px;font-family:inherit;transition:border-color 0.15s,background 0.15s;}
    .dv-pitch-action-btn:hover{border-color:#0E7C7B;background:#ECFDF5;}
    .dv-pitch-toast{position:fixed;bottom:80px;right:380px;padding:10px 16px;background:#0F5132;color:#fff;border-radius:12px;font-size:12px;font-weight:800;box-shadow:0 8px 24px rgba(15,81,50,0.3);z-index:9999;opacity:0;transition:opacity 0.3s,transform 0.3s;transform:translateY(6px);}
    .dv-pitch-toast.show{opacity:1;transform:translateY(0);}
    `;
    document.head.appendChild(st);
}

function showToast(msg) {
    let toast = _el('dvPitchToast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'dvPitchToast';
        toast.className = 'dv-pitch-toast';
        document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.classList.add('show');
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toast.classList.remove('show'), 2400);
}

/* ============================================================
   SCENARIO APPLY
   ============================================================ */
function applyScenario(scenario) {
    if (!scenario) return;
    const districtKey = scenario.district;

    /* 1. Set district select if present */
    const sel = _el('climateDistrict');
    if (sel && sel.querySelector(`option[value="${districtKey}"]`)) {
        sel.value = districtKey;
        sel.dispatchEvent(new Event('change', { bubbles: true }));
    }

    /* 2. Update URL query (survives page reload) */
    try {
        const url = new URL(window.location.href);
        url.searchParams.set('district', districtKey);
        window.history.replaceState({}, '', url.toString());
    } catch (_) {}

    /* 3. If DVClimate is present, use its API */
    if (window.DVClimate && typeof DVClimate.setDistrict === 'function') {
        try { DVClimate.setDistrict(districtKey); } catch (_) {}
    }

    showToast(`Loaded scenario: ${scenario.name}`);
    localStorage.setItem('dvPitchActiveScenario', scenario.id);

    /* Mark active in panel */
    document.querySelectorAll('.dv-pitch-scenario').forEach(el => {
        el.classList.toggle('active', el.dataset.id === scenario.id);
    });
}

/* ============================================================
   EXPORT UTILITIES
   ============================================================ */
async function exportPageReport() {
    const district = (function () {
        try {
            const sel = _el('climateDistrict');
            return sel ? sel.value : 'dhaka';
        } catch (_) { return 'dhaka'; }
    })();

    const report = {
        generatedAt: new Date().toISOString(),
        district,
        feature: detectFeature(),
        sources: collectSourcesFromDOM(),
        snapshots: await captureLiveSnapshots(district)
    };

    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dailyvet-${report.feature}-${district}-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast('JSON report downloaded');
}

function detectFeature() {
    if (_el('thiAppRoot')) return 'heat-stress';
    if (_el('forageAppRoot')) return 'forage';
    if (_el('outbreakAppRoot')) return 'outbreak';
    if (_el('impactAppRoot')) return 'impact';
    if (_el('floodAppRoot')) return 'flood';
    if (_el('airBody')) return 'air-quality';
    if (_el('divisionMap')) return 'map';
    return 'dashboard';
}

function collectSourcesFromDOM() {
    const sources = new Set();
    document.querySelectorAll('[data-source]').forEach(el => {
        sources.add(el.getAttribute('data-source'));
    });
    if (window.NasaPower) sources.add('nasa-power');
    if (window.NasaGpm) sources.add('open-meteo');
    if (window.NasaModisNdvi) sources.add('nasa-gibs');
    if (window.NasaSoilGrids) sources.add('isric-soilgrids');
    if (window.NasaSedac) sources.add('nasa-sedac');
    return Array.from(sources);
}

async function captureLiveSnapshots(district) {
    const snapshots = {};

    if (window.NasaPower) {
        const coords = getDistrictCoords(district);
        if (coords) {
            try {
                const p = await NasaPower.getPowerData(coords.lat, coords.lng, 7);
                snapshots.nasaPower = {
                    temp: NasaPower.getLatest(p, 'T2M'),
                    humidity: NasaPower.getLatest(p, 'RH2M'),
                    soilMoisture: NasaPower.getLatest(p, 'GWETTOP'),
                    rainfall: NasaPower.getLatest(p, 'PRECTOTCORR'),
                    freshness: NasaPower.getDataFreshness(p)
                };
            } catch (err) { snapshots.nasaPower = { error: err.message }; }
        }
    }

    if (window.NasaGpm) {
        try { snapshots.nasaGpm = await NasaGpm.get7DayRainfall(district); }
        catch (err) { snapshots.nasaGpm = { error: err.message }; }
    }

    if (window.NasaModisNdvi) {
        try { snapshots.nasaNdvi = await NasaModisNdvi.getNDVI(district); }
        catch (err) { snapshots.nasaNdvi = { error: err.message }; }
    }

    if (window.NasaSoilGrids) {
        try { snapshots.soilGrids = await NasaSoilGrids.getSoilData(district); }
        catch (err) { snapshots.soilGrids = { error: err.message }; }
    }

    if (window.GrassHealthScore) {
        try { snapshots.grassHealth = await GrassHealthScore.computeGrassHealthScore(district); }
        catch (err) { snapshots.grassHealth = { error: err.message }; }
    }

    if (window.NasaSedac) {
        try {
            const sedac = await NasaSedac.fetchSedacData(district);
            if (sedac) snapshots.sedac = { name: sedac.name, ruralPop: sedac.ruralPopulation, livestock: sedac.livestock };
        } catch (err) { snapshots.sedac = { error: err.message }; }
    }

    return snapshots;
}

function getDistrictCoords(district) {
    const map = {
        dhaka: { lat: 23.8103, lng: 90.4125 },
        savar: { lat: 23.8583, lng: 90.2667 },
        chittagong: { lat: 22.3569, lng: 91.7832 },
        sylhet: { lat: 24.8949, lng: 91.8687 },
        khulna: { lat: 22.8456, lng: 89.5403 },
        rajshahi: { lat: 24.3745, lng: 88.6042 },
        barisal: { lat: 22.7010, lng: 90.3535 },
        rangpur: { lat: 25.7439, lng: 89.2752 },
        mymensingh: { lat: 24.7471, lng: 90.4203 },
        sirajganj: { lat: 24.4533, lng: 89.7009 }
    };
    return map[district] || map.dhaka;
}

function exportPagePdf() {
    showToast('Preparing PDF (browser print)...');
    setTimeout(() => window.print(), 400);
}

/* ============================================================
   PANEL RENDER
   ============================================================ */
function buildPanel() {
    const panel = document.createElement('div');
    panel.className = 'dv-pitch-panel';
    panel.id = 'dvPitchPanel';
    panel.style.display = 'none';

    const activeScenarioId = localStorage.getItem('dvPitchActiveScenario') || '';

    const scenariosHtml = Object.values(SCENARIOS).map(s => `
        <div class="dv-pitch-scenario ${s.id === activeScenarioId ? 'active' : ''}" data-id="${escapeHtml(s.id)}">
            <div class="dv-pitch-scenario-name">${escapeHtml(s.name)}</div>
            <div class="dv-pitch-scenario-sub">${escapeHtml(s.subtitle)}</div>
            <div class="dv-pitch-scenario-hint">💡 ${escapeHtml(s.hint)}</div>
        </div>
    `).join('');

    panel.innerHTML = `
        <div class="dv-pitch-panel-head">
            <h4 class="dv-pitch-panel-title"><i class="fas fa-bullhorn"></i> Pitch Helper</h4>
            <button class="dv-pitch-close" id="dvPitchClose">✕</button>
        </div>
        <div style="font-size:11px;font-weight:800;color:#64748B;text-transform:uppercase;margin-bottom:8px;">Demo Scenarios</div>
        ${scenariosHtml}
        <div class="dv-pitch-actions">
            <button class="dv-pitch-action-btn" id="dvPitchExportJson">
                <i class="fas fa-file-code" style="color:#0891B2;"></i>
                Export JSON (all live data)
            </button>
            <button class="dv-pitch-action-btn" id="dvPitchExportPdf">
                <i class="fas fa-file-pdf" style="color:#DC2626;"></i>
                Export PDF (print dialog)
            </button>
            <button class="dv-pitch-action-btn" id="dvPitchRunDiagnostic">
                <i class="fas fa-stethoscope" style="color:#7C3AED;"></i>
                Run live data diagnostic
            </button>
        </div>
    `;

    document.body.appendChild(panel);
    return panel;
}

function attachPanelEvents(panel) {
    const closeBtn = _el('dvPitchClose');
    if (closeBtn) closeBtn.addEventListener('click', () => { panel.style.display = 'none'; });

    panel.querySelectorAll('.dv-pitch-scenario').forEach(el => {
        el.addEventListener('click', () => {
            const id = el.dataset.id;
            applyScenario(SCENARIOS[id]);
        });
    });

    const exportJson = _el('dvPitchExportJson');
    if (exportJson) exportJson.addEventListener('click', exportPageReport);

    const exportPdf = _el('dvPitchExportPdf');
    if (exportPdf) exportPdf.addEventListener('click', exportPagePdf);

    const diag = _el('dvPitchRunDiagnostic');
    if (diag) diag.addEventListener('click', runDiagnostic);
}

/* ============================================================
   DIAGNOSTIC
   ============================================================ */
async function runDiagnostic() {
    showToast('Running diagnostic...');
    const district = (function () {
        try { const sel = _el('climateDistrict'); return sel ? sel.value : 'dhaka'; }
        catch (_) { return 'dhaka'; }
    })();

    const results = [];
    const check = (name, ok, detail) => results.push({ name, ok, detail });

    /* 1. Loaded modules */
    check('NasaPower', !!window.NasaPower, 'NASA POWER weather client');
    check('NasaGpm', !!window.NasaGpm, 'Open-Meteo satellite rainfall');
    check('NasaModisNdvi', !!window.NasaModisNdvi, 'NASA GIBS MODIS NDVI');
    check('NasaSoilGrids', !!window.NasaSoilGrids, 'ISRIC SoilGrids');
    check('NasaSedac', !!window.NasaSedac, 'SEDAC GPW v4.11');
    check('NasaClimate', !!window.NasaClimate, 'THI engine');
    check('NasaOutbreak', !!window.NasaOutbreak, 'Disease risk engine');
    check('GrassHealthScore', !!window.GrassHealthScore, 'Grass health scoring');
    check('NasaFlood', !!window.NasaFlood, 'Flood risk engine');
    check('DVTrace', !!window.DVTrace, 'AI trace');
    check('DVNotifications', !!window.DVNotifications, 'Notification engine');

    /* 2. Live API tests */
    if (window.NasaGpm) {
        try {
            const r = await NasaGpm.get7DayRainfall(district);
            check('Live rainfall', r && r.available, r && r.available ? `${r.totalMm} mm from ${r.source}` : (r && r.error) || 'failed');
        } catch (err) { check('Live rainfall', false, err.message); }
    }

    if (window.NasaModisNdvi) {
        try {
            const r = await NasaModisNdvi.getNDVI(district);
            check('Live NDVI', r && r.available, r && r.available ? `NDVI ${r.ndvi} (${r.label})` : (r && r.error) || 'failed');
        } catch (err) { check('Live NDVI', false, err.message); }
    }

    if (window.NasaSoilGrids) {
        try {
            const r = await NasaSoilGrids.getSoilData(district);
            check('Live soil', r && r.available, r && r.available ? `pH ${r.ph}, N ${r.nitrogen_gkg}` : (r && r.error) || 'failed');
        } catch (err) { check('Live soil', false, err.message); }
    }

    /* 3. Render diagnostic panel */
    const modal = document.createElement('div');
    modal.style.cssText = 'position:fixed;inset:0;background:rgba(15,81,50,0.5);backdrop-filter:blur(3px);z-index:10000;display:flex;align-items:center;justify-content:center;padding:20px;';

    const passCount = results.filter(r => r.ok).length;
    const total = results.length;

    modal.innerHTML = `
        <div style="background:#fff;border-radius:20px;max-width:560px;width:100%;max-height:80vh;overflow:auto;padding:20px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;padding-bottom:12px;border-bottom:1px solid #E2E8F0;">
                <div>
                    <h3 style="margin:0;font-size:16px;font-weight:900;color:#0F5132;">Live Diagnostic — ${escapeHtml(district)}</h3>
                    <p style="margin:2px 0 0;font-size:11.5px;color:#64748B;font-weight:600;">${passCount}/${total} checks passed</p>
                </div>
                <button style="background:none;border:none;font-size:20px;color:#94A3B8;cursor:pointer;" id="dvDiagClose">✕</button>
            </div>
            <div style="display:flex;flex-direction:column;gap:6px;">
                ${results.map(r => `
                    <div style="padding:10px 12px;background:${r.ok ? '#ECFDF5' : '#FEF2F2'};border:1px solid ${r.ok ? '#A7F3D0' : '#FCA5A5'};border-radius:10px;display:flex;align-items:center;gap:10px;">
                        <span style="font-size:14px;flex-shrink:0;">${r.ok ? '✅' : '❌'}</span>
                        <div style="flex:1;min-width:0;">
                            <div style="font-size:12px;font-weight:800;color:${r.ok ? '#047857' : '#991B1B'};">${escapeHtml(r.name)}</div>
                            <div style="font-size:10.5px;color:#64748B;margin-top:1px;word-break:break-word;">${escapeHtml(r.detail)}</div>
                        </div>
                    </div>
                `).join('')}
            </div>
        </div>
    `;

    document.body.appendChild(modal);
    const close = () => document.body.removeChild(modal);
    modal.querySelector('#dvDiagClose').addEventListener('click', close);
    modal.addEventListener('click', e => { if (e.target === modal) close(); });
}

/* ============================================================
   MOUNT
   ============================================================ */
function mount() {
    injectStyles();

    const bar = document.createElement('div');
    bar.className = 'dv-pitch-bar';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'dv-pitch-bar-btn';
    btn.innerHTML = '<i class="fas fa-bullhorn"></i> Pitch Helper';

    bar.appendChild(btn);
    document.body.appendChild(bar);

    const panel = buildPanel();
    attachPanelEvents(panel);

    btn.addEventListener('click', () => {
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    });
}

window.DVPitchHelper = {
    SCENARIOS,
    applyScenario,
    exportPageReport,
    exportPagePdf,
    runDiagnostic
};

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mount);
} else {
    mount();
}

console.log('[DVPitchHelper] v1.1 loaded');
})();