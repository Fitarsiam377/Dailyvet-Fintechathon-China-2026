/* DailyVet — Fast Fetch Layer v1.0
   ------------------------------------------------------------
   Drop-in speed layer for all climate pages. NO changes needed in
   your API files — it wraps them:

     • Same request already running?  -> shares the one in-flight request
     • Same request done recently?    -> answers instantly from memory
     • Open-Meteo answers             -> also kept in sessionStorage, so
                                         reopening / switching pages is instant
     • Failed / empty answers         -> never cached

   LOAD ORDER on each climate page:
     open-meteo.js, nasa-power-api.js, nasa-sedac-mapper.js, ...
     dv-fast-fetch.js        <-- right here
     climate-*.js
*/
(function () {
'use strict';
if (window.DVFast) return;

const MEM = new Map();        // key -> { t, v }
const INFLIGHT = new Map();   // key -> Promise
const SS = 'dvf1:';

function ssGet(key, ttl) {
    try {
        const raw = sessionStorage.getItem(SS + key);
        if (!raw) return null;
        const o = JSON.parse(raw);
        if (!o || Date.now() - o.t > ttl) { sessionStorage.removeItem(SS + key); return null; }
        return o;
    } catch (_) { return null; }
}
function ssSet(key, entry) {
    try { sessionStorage.setItem(SS + key, JSON.stringify(entry)); }
    catch (_) {
        /* quota full — drop our own old entries and move on */
        try {
            Object.keys(sessionStorage).filter(k => k.indexOf(SS) === 0).forEach(k => sessionStorage.removeItem(k));
        } catch (__) {}
    }
}
function isEmpty(v) {
    return v === null || v === undefined || (Array.isArray(v) && v.length === 0);
}

function memo(obj, name, opts) {
    if (!obj || typeof obj[name] !== 'function') return false;
    if (obj[name].__dvFast) return true;
    const orig = obj[name].bind(obj);
    const ttl = opts.ttl;

    const wrapped = function () {
        const args = Array.prototype.slice.call(arguments);
        const key = opts.id + JSON.stringify(args);

        const hit = MEM.get(key);
        if (hit && Date.now() - hit.t < ttl) return Promise.resolve(hit.v);

        if (opts.persist) {
            const s = ssGet(key, ttl);
            if (s && !isEmpty(s.v)) {
                MEM.set(key, s);
                return Promise.resolve(s.v);
            }
        }

        if (INFLIGHT.has(key)) return INFLIGHT.get(key);

        const p = new Promise(function (res) { res(orig.apply(null, args)); })
            .then(function (v) {
                if (!isEmpty(v)) {
                    const entry = { t: Date.now(), v: v };
                    MEM.set(key, entry);
                    if (opts.persist) ssSet(key, entry);
                }
                return v;
            })
            .finally(function () { INFLIGHT.delete(key); });

        INFLIGHT.set(key, p);
        return p;
    };
    wrapped.__dvFast = true;
    try { obj[name] = wrapped; return true; } catch (_) { return false; }
}

const MIN = 60 * 1000;
const PLAN = [
    // [global name, method, { id, ttl, persist }]
    ['OpenMeteo', 'getAQI',              { id: 'om:aqi:',  ttl: 10 * MIN, persist: true }],
    ['OpenMeteo', 'getWeek',             { id: 'om:week:', ttl: 15 * MIN, persist: true }],
    ['OpenMeteo', 'getPastDays',         { id: 'om:past:', ttl: 30 * MIN, persist: true }],
    ['OpenMeteo', 'getTomorrow',         { id: 'om:tmrw:', ttl: 15 * MIN, persist: true }],
    ['OpenMeteo', 'getRainfallCumulative', { id: 'om:rain:', ttl: 10 * MIN, persist: true }],
    /* NASA POWER returns objects that the library tracks by reference
       (getSource/getSeries) — so memory + in-flight sharing only, no JSON copy. */
    ['NasaPower', 'getPowerData',        { id: 'np:pd:',   ttl: 15 * MIN, persist: false }],
    ['NasaSedac', 'fetchSedacData',      { id: 'ns:fd:',   ttl: 60 * MIN, persist: false }]
];

const wrappedList = [];
function applyAll() {
    PLAN.forEach(function (p) {
        const target = window[p[0]];
        const label = p[0] + '.' + p[1];
        if (wrappedList.indexOf(label) === -1 && memo(target, p[1], p[2])) wrappedList.push(label);
    });
}

applyAll();
/* If a library script loads late, try again */
document.addEventListener('DOMContentLoaded', applyAll);
window.addEventListener('load', applyAll);

/* Resolve to null instead of hanging forever when an API is slow */
function timeout(p, ms) {
    return Promise.race([
        Promise.resolve(p),
        new Promise(function (res) { setTimeout(function () { res(null); }, ms); })
    ]);
}

window.DVFast = {
    timeout: timeout,
    wrapped: function () { return wrappedList.slice(); },
    clear: function () {
        MEM.clear();
        try {
            Object.keys(sessionStorage).filter(function (k) { return k.indexOf(SS) === 0; })
                .forEach(function (k) { sessionStorage.removeItem(k); });
        } catch (_) {}
    }
};

console.log('[DVFast] speed layer on:', wrappedList.join(', ') || '(libraries not found yet)');
})();