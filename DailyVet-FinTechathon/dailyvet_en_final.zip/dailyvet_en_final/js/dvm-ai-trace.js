/* DailyVet — AI Trace & Reasoning Transparency v1.1

   Provides a complete "why" trail for any AI recommendation:
     1. INPUTS   — user parameters (district, species, date)
     2. SOURCES  — which NASA/satellite feed supplied each value
     3. FORMULA  — the exact calculation applied
     4. OUTPUT   — the resulting recommendation / risk score

   Design goals:
   • Zero hardcoded demo data
   • Every value carries its source + timestamp
   • Ready for judges: click "Why?" on any card, this module renders the trace

   v1.1 changes:
   • Added buildGrassHealthTrace, buildAirQualityTrace, buildSEDACImpactTrace
   • attachWhyButton accepts optional label + position
   • render() safer when rows missing
   • English-only comments
*/
(function () {
'use strict';

const _ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const escapeHtml = t => String(t == null ? '' : t).replace(/[&<>"']/g, c => _ESC[c]);

/* ============================================================
   SOURCE REGISTRY — canonical labels for every feed we use
   ============================================================ */
const SOURCE_LABELS = {
    'nasa-power':       { name: 'NASA POWER',               url: 'https://power.larc.nasa.gov/',                color: '#0E7C7B', provider: 'NASA LaRC' },
    'nasa-gibs':        { name: 'NASA GIBS',                url: 'https://gibs.earthdata.nasa.gov/',            color: '#059669', provider: 'NASA EOSDIS' },
    'nasa-sedac':       { name: 'NASA SEDAC GPW v4.11',     url: 'https://sedac.ciesin.columbia.edu/',          color: '#7C3AED', provider: 'CIESIN' },
    'open-meteo':       { name: 'Open-Meteo (GFS/IFS)',     url: 'https://open-meteo.com/',                     color: '#0891B2', provider: 'NOAA + ECMWF' },
    'isric-soilgrids':  { name: 'ISRIC SoilGrids 2.0',      url: 'https://soilgrids.org/',                      color: '#B45309', provider: 'ISRIC' },
    'dls-bangladesh':   { name: 'DLS Bangladesh 2022-23',   url: 'https://dls.gov.bd/',                         color: '#047857', provider: 'Gov. of Bangladesh' }
};

/* ============================================================
   HTML HELPERS
   ============================================================ */
function fmtDate(iso) {
    if (!iso) return '—';
    try {
        const d = new Date(iso);
        if (isNaN(d.getTime())) return iso;
        return d.toLocaleString('en-GB', {
            day: '2-digit', month: 'short', year: 'numeric',
            hour: '2-digit', minute: '2-digit'
        });
    } catch (_) { return iso; }
}

function fmtValue(v, unit) {
    if (v == null) return '—';
    if (typeof v === 'number') {
        const n = Math.abs(v) >= 100 ? Math.round(v) : Math.round(v * 100) / 100;
        return `${n}${unit ? ' ' + unit : ''}`;
    }
    return String(v) + (unit ? ' ' + unit : '');
}

function renderSourceBadge(sourceId) {
    const info = SOURCE_LABELS[sourceId] || { name: sourceId, color: '#64748B', url: '#' };
    return `<a href="${escapeHtml(info.url)}" target="_blank" rel="noopener"
        style="display:inline-flex;align-items:center;gap:4px;padding:2px 8px;background:${info.color}15;border:1px solid ${info.color}40;border-radius:8px;font-size:10.5px;font-weight:800;color:${info.color};text-decoration:none;">
        <i class="fas fa-satellite" style="font-size:9px;"></i>
        ${escapeHtml(info.name)}
    </a>`;
}

/* ============================================================
   TRACE BUILDERS
   ============================================================ */

function buildTHITrace(p) {
    const steps = [];

    steps.push({
        kind: 'input',
        title: 'User input',
        rows: [
            { label: 'District', value: p.district },
            { label: 'Species', value: p.species || 'cow' }
        ]
    });

    steps.push({
        kind: 'source',
        title: 'Live data fetched',
        rows: [
            { label: 'Temperature (T2M)', value: fmtValue(p.tempC, '°C'), source: 'open-meteo', fetchedAt: p.source && p.source.fetchedAt },
            { label: 'Relative humidity (RH2M)', value: fmtValue(p.rh, '%'), source: 'open-meteo', fetchedAt: p.source && p.source.fetchedAt }
        ]
    });

    steps.push({
        kind: 'formula',
        title: 'THI formula (NRC 1971)',
        formula: 'THI = (1.8 × T + 32) − (0.55 − 0.0055 × RH) × (1.8 × T − 26)',
        substitution: p.tempC != null && p.rh != null
            ? `THI = (1.8 × ${p.tempC.toFixed(1)} + 32) − (0.55 − 0.0055 × ${p.rh.toFixed(0)}) × (1.8 × ${p.tempC.toFixed(1)} − 26)`
            : '—'
    });

    steps.push({
        kind: 'output',
        title: 'Result',
        rows: [
            { label: 'THI value', value: fmtValue(p.thi) },
            { label: 'Heat-stress level', value: (p.level || 'unknown').toUpperCase() },
            { label: 'Species thresholds applied', value: 'NRC 1971 + Bangladesh-specific adaptation' }
        ]
    });

    return {
        feature: 'Heat Stress (THI)',
        timestamp: new Date().toISOString(),
        steps
    };
}

function buildForageTrace(p) {
    const steps = [];

    steps.push({
        kind: 'input',
        title: 'User input',
        rows: [
            { label: 'District', value: p.district },
            { label: 'Month', value: p.month || (new Date().getMonth() + 1) }
        ]
    });

    const sourceRows = [];
    if (p.gwettop != null) sourceRows.push({ label: 'Soil moisture (GWETTOP)', value: fmtValue(p.gwettop * 100, '%'), source: 'nasa-power' });
    if (p.ndvi != null) sourceRows.push({ label: 'NDVI (vegetation)', value: fmtValue(p.ndvi), source: 'nasa-gibs' });
    if (p.ph != null) sourceRows.push({ label: 'Soil pH', value: fmtValue(p.ph), source: 'isric-soilgrids' });
    if (p.nitrogen != null) sourceRows.push({ label: 'Soil nitrogen', value: fmtValue(p.nitrogen, 'g/kg'), source: 'isric-soilgrids' });
    if (p.soc != null) sourceRows.push({ label: 'Soil organic carbon', value: fmtValue(p.soc, 'g/kg'), source: 'isric-soilgrids' });

    steps.push({
        kind: 'source',
        title: 'Live data fetched',
        rows: sourceRows
    });

    steps.push({
        kind: 'formula',
        title: 'Grass selection algorithm',
        formula: 'Score = 0.30 × MoistureScore + 0.30 × VegetationScore + 0.20 × NutrientScore + 0.10 × PHScore + 0.10 × TemperatureScore',
        substitution: p.grassHealth != null ? `Composite Grass Health Score = ${p.grassHealth}/100` : 'Grass health requires all 5 factors'
    });

    steps.push({
        kind: 'output',
        title: 'Recommended grasses',
        rows: (p.recommended || []).slice(0, 3).map((g, i) => ({
            label: `#${i + 1} choice`,
            value: g.name || g
        }))
    });

    return {
        feature: 'Forage Rotation',
        timestamp: new Date().toISOString(),
        steps
    };
}

function buildOutbreakTrace(p) {
    const steps = [];

    steps.push({
        kind: 'input',
        title: 'User input',
        rows: [
            { label: 'District', value: p.district }
        ]
    });

    steps.push({
        kind: 'source',
        title: 'Live data fetched',
        rows: [
            { label: '7-day rainfall', value: fmtValue(p.rain7dayMm, 'mm'), source: 'open-meteo' },
            { label: 'Today rainfall', value: fmtValue(p.dailyRain, 'mm'), source: 'open-meteo' },
            { label: 'Temperature', value: fmtValue(p.temp, '°C'), source: 'nasa-power' },
            { label: 'Humidity', value: fmtValue(p.humidity, '%'), source: 'nasa-power' },
            { label: 'Soil moisture', value: p.soilMoisture != null ? fmtValue(p.soilMoisture * 100, '%') : '—', source: 'nasa-power' }
        ]
    });

    steps.push({
        kind: 'formula',
        title: 'Disease risk scoring',
        formula: 'Risk = RainScore + HumidityScore + TempScore + VectorBaseline + DiseaseBonuses + DistrictPrior',
        substitution: `Rain=${p.dailyRain}mm → humidity=${p.humidity}% → temp=${p.temp}°C`
    });

    steps.push({
        kind: 'output',
        title: 'Overall risk',
        rows: [
            { label: 'Risk score', value: fmtValue(p.riskScore, '%') },
            { label: 'Risk level', value: (p.riskLevel || 'unknown').toUpperCase() },
            { label: 'Top diseases', value: (p.diseases || []).slice(0, 3).map(d => `${d.nameEn || d.nameBn || 'Disease'} (${d.score}%)`).join(', ') || 'None above 30%' }
        ]
    });

    return {
        feature: 'Disease Risk Radar',
        timestamp: new Date().toISOString(),
        steps
    };
}

function buildFloodTrace(p) {
    const steps = [];

    steps.push({
        kind: 'input',
        title: 'User input',
        rows: [{ label: 'District', value: p.district }]
    });

    steps.push({
        kind: 'source',
        title: 'Live data fetched',
        rows: [
            { label: 'Local 7-day rainfall', value: fmtValue(p.rain7dayMm, 'mm'), source: 'nasa-power' },
            { label: '48h forecast rain', value: fmtValue(p.rain48hForecast, 'mm'), source: 'open-meteo' },
            { label: '72h forecast rain', value: fmtValue(p.rain72hForecast, 'mm'), source: 'open-meteo' },
            { label: 'Soil moisture (root)', value: p.soilRoot != null ? fmtValue(p.soilRoot * 100, '%') : '—', source: 'nasa-power' },
            { label: 'Upstream basin rain', value: fmtValue(p.upstreamRainMm, 'mm'), source: 'nasa-power' },
            { label: 'Basin', value: p.basin || '—' }
        ]
    });

    steps.push({
        kind: 'formula',
        title: 'Flood risk calculation',
        formula: 'FloodScore = Rain7d + SoilSat + ForecastRain + Upstream + RegionalVulnerability',
        substitution: `Rain7d=${p.rain7dayMm || 0}mm + Soil=${((p.soilRoot || 0) * 100).toFixed(0)}% + Fcst72h=${p.rain72hForecast || 0}mm + Upstream=${p.upstreamRainMm || 0}mm`
    });

    steps.push({
        kind: 'output',
        title: 'Flood risk',
        rows: [
            { label: 'Flood risk score', value: fmtValue(p.riskScore, '%') },
            { label: 'Risk level', value: (p.riskLevel || 'unknown').toUpperCase() },
            { label: 'Action', value: p.action || '—' }
        ]
    });

    return {
        feature: 'Flood Early Warning',
        timestamp: new Date().toISOString(),
        steps
    };
}

/* ============================================================
   v1.1 NEW: GRASS HEALTH TRACE
   ============================================================ */
function buildGrassHealthTrace(p) {
    const steps = [];

    steps.push({
        kind: 'input',
        title: 'User input',
        rows: [{ label: 'District', value: p.district }]
    });

    steps.push({
        kind: 'source',
        title: 'Live data fetched',
        rows: [
            { label: 'NDVI (vegetation index)', value: fmtValue(p.ndvi), source: 'nasa-gibs' },
            { label: 'Surface soil moisture', value: p.soilMoisture != null ? fmtValue(p.soilMoisture * 100, '%') : '—', source: 'nasa-power' },
            { label: 'Soil nitrogen', value: fmtValue(p.nitrogen, 'g/kg'), source: 'isric-soilgrids' },
            { label: 'Soil pH', value: fmtValue(p.ph), source: 'isric-soilgrids' },
            { label: 'Soil organic carbon', value: fmtValue(p.soc, 'g/kg'), source: 'isric-soilgrids' }
        ]
    });

    steps.push({
        kind: 'formula',
        title: 'Composite grass health score',
        formula: 'Score = 0.35 × NDVI + 0.30 × SoilMoisture + 0.15 × Nitrogen + 0.10 × pH + 0.10 × SOC',
        substitution: p.score != null ? `Composite = ${p.score}/100` : 'Score requires at least one factor'
    });

    steps.push({
        kind: 'output',
        title: 'Grass health',
        rows: [
            { label: 'Health score', value: p.score != null ? p.score + '/100' : '—' },
            { label: 'Level', value: (p.level || 'unknown').toUpperCase() },
            { label: 'Advice', value: p.advice || 'Maintain current practices' }
        ]
    });

    return {
        feature: 'Grass Health Score',
        timestamp: new Date().toISOString(),
        steps
    };
}

/* ============================================================
   v1.1 NEW: AIR QUALITY TRACE
   ============================================================ */
function buildAirQualityTrace(p) {
    const steps = [];

    steps.push({
        kind: 'input',
        title: 'User input',
        rows: [{ label: 'District', value: p.district }]
    });

    steps.push({
        kind: 'source',
        title: 'Live data fetched',
        rows: [
            { label: 'PM2.5', value: fmtValue(p.pm25, 'µg/m³'), source: 'open-meteo' },
            { label: 'PM10', value: fmtValue(p.pm10, 'µg/m³'), source: 'open-meteo' },
            { label: 'Ozone (O3)', value: fmtValue(p.o3, 'µg/m³'), source: 'open-meteo' },
            { label: 'NO2', value: fmtValue(p.no2, 'µg/m³'), source: 'open-meteo' },
            { label: 'SO2', value: fmtValue(p.so2, 'µg/m³'), source: 'open-meteo' },
            { label: 'CO', value: fmtValue(p.co, 'µg/m³'), source: 'open-meteo' },
            { label: 'UV Index', value: fmtValue(p.uv), source: 'open-meteo' }
        ]
    });

    steps.push({
        kind: 'formula',
        title: 'US EPA AQI calculation',
        formula: 'AQI = max(PM2.5_breakpoint, PM10_breakpoint, O3_breakpoint, NO2_breakpoint, SO2_breakpoint, CO_breakpoint)',
        substitution: `US AQI = ${p.usAqi != null ? Math.round(p.usAqi) : '—'} → ${p.aqiLabel || 'Unknown'}`
    });

    steps.push({
        kind: 'output',
        title: 'Air quality + UV',
        rows: [
            { label: 'US AQI', value: p.usAqi != null ? Math.round(p.usAqi) : '—' },
            { label: 'AQI category', value: p.aqiLabel || 'Unknown' },
            { label: 'UV Index', value: fmtValue(p.uv) },
            { label: 'UV category', value: p.uvLabel || 'Unknown' }
        ]
    });

    return {
        feature: 'Air Quality & UV',
        timestamp: new Date().toISOString(),
        steps
    };
}

/* ============================================================
   v1.1 NEW: SEDAC IMPACT TRACE
   ============================================================ */
function buildSEDACImpactTrace(p) {
    const steps = [];

    steps.push({
        kind: 'input',
        title: 'User input',
        rows: [
            { label: 'District', value: p.district },
            { label: 'Risk level', value: (p.riskLevel || 'unknown').toUpperCase() }
        ]
    });

    steps.push({
        kind: 'source',
        title: 'Live data fetched',
        rows: [
            { label: 'Rural population', value: fmtValue(p.ruralPopulation), source: 'nasa-sedac' },
            { label: 'Marginal farmers', value: fmtValue(p.marginalFarmers), source: 'dls-bangladesh' },
            { label: 'Cattle count', value: fmtValue(p.cattle), source: 'dls-bangladesh' },
            { label: 'Poultry count', value: fmtValue(p.poultry), source: 'dls-bangladesh' }
        ]
    });

    steps.push({
        kind: 'formula',
        title: 'Impact calculation',
        formula: 'AtRisk = Population × ExposureMultiplier | Loss = Heads × LossRate × MarketValue',
        substitution: `Exposure=${p.exposureMultiplier || 0.5} · LossRate=${p.lossRate || 0.02}`
    });

    steps.push({
        kind: 'output',
        title: 'Impact',
        rows: [
            { label: 'People at risk', value: fmtValue(p.populationAtRisk) },
            { label: 'Livestock at risk', value: fmtValue(p.livestockAtRisk) },
            { label: 'Economic loss (Crore)', value: p.economicLoss ? `৳${p.economicLoss}` : '—' }
        ]
    });

    return {
        feature: 'SEDAC Impact & Loss',
        timestamp: new Date().toISOString(),
        steps
    };
}

/* ============================================================
   RENDER
   ============================================================ */
function renderStep(step) {
    const kindColor = {
        input: '#64748B',
        source: '#0891B2',
        formula: '#7C3AED',
        output: '#059669'
    }[step.kind] || '#0F5132';

    const kindIcon = {
        input: 'fa-keyboard',
        source: 'fa-satellite-dish',
        formula: 'fa-calculator',
        output: 'fa-check-circle'
    }[step.kind] || 'fa-circle';

    let inner = '';

    if (step.rows && step.rows.length) {
        inner += `<div style="display:flex;flex-direction:column;gap:6px;margin-top:8px;">`;
        step.rows.forEach(r => {
            inner += `
                <div style="display:flex;align-items:flex-start;gap:10px;padding:8px 10px;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:10px;">
                    <span style="font-size:11px;font-weight:800;color:#475569;min-width:140px;flex-shrink:0;">${escapeHtml(r.label)}</span>
                    <span style="font-size:12px;font-weight:700;color:#0F5132;flex:1;min-width:0;word-break:break-word;">${escapeHtml(String(r.value))}</span>
                    ${r.source ? renderSourceBadge(r.source) : ''}
                </div>`;
            if (r.fetchedAt) {
                inner += `<div style="font-size:10px;color:#94A3B8;padding-left:152px;margin-top:-2px;">Fetched: ${escapeHtml(fmtDate(r.fetchedAt))}</div>`;
            }
        });
        inner += `</div>`;
    }

    if (step.formula) {
        inner += `
            <div style="margin-top:8px;padding:10px 12px;background:#F5F3FF;border:1px solid #DDD6FE;border-radius:10px;">
                <div style="font-size:10.5px;font-weight:800;color:#7C3AED;text-transform:uppercase;margin-bottom:4px;">Formula</div>
                <code style="font-family:'Inter',monospace;font-size:12px;color:#5B21B6;display:block;line-height:1.5;">${escapeHtml(step.formula)}</code>
                ${step.substitution ? `<div style="margin-top:6px;font-size:11px;color:#6D28D9;padding-top:6px;border-top:1px dashed #C4B5FD;">${escapeHtml(step.substitution)}</div>` : ''}
            </div>`;
    }

    return `
        <div style="padding:12px 14px;background:#fff;border:1.5px solid #D1E7DD;border-radius:14px;margin-bottom:10px;">
            <div style="display:flex;align-items:center;gap:8px;">
                <span style="width:26px;height:26px;border-radius:8px;background:${kindColor}20;color:${kindColor};display:inline-flex;align-items:center;justify-content:center;font-size:11px;flex-shrink:0;">
                    <i class="fas ${kindIcon}"></i>
                </span>
                <span style="font-size:12.5px;font-weight:900;color:${kindColor};text-transform:uppercase;letter-spacing:0.03em;">${escapeHtml(step.title)}</span>
            </div>
            ${inner}
        </div>`;
}

function render(container, trace) {
    if (!container) return;
    if (!trace || !trace.steps) {
        container.innerHTML = `<div style="padding:20px;text-align:center;color:#94A3B8;font-size:12px;">No trace data available.</div>`;
        return;
    }

    const stepsHtml = trace.steps.map(renderStep).join('');

    container.innerHTML = `
        <div style="padding:16px;background:#fff;border:1.5px solid #D1E7DD;border-radius:18px;">
            <div style="display:flex;align-items:flex-start;gap:12px;padding-bottom:12px;border-bottom:1px solid #E8F5F0;margin-bottom:14px;flex-wrap:wrap;">
                <div style="width:40px;height:40px;border-radius:12px;background:linear-gradient(135deg,#7C3AED,#5B21B6);color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:15px;flex-shrink:0;">
                    <i class="fas fa-brain"></i>
                </div>
                <div style="flex:1;min-width:0;">
                    <h3 style="margin:0;font-size:15px;font-weight:900;color:#0F5132;">AI Reasoning Trace</h3>
                    <p style="margin:2px 0 0;font-size:11.5px;color:#64748B;font-weight:600;">${escapeHtml(trace.feature)} · Generated ${escapeHtml(fmtDate(trace.timestamp))}</p>
                </div>
            </div>
            ${stepsHtml}
            <div style="padding:10px 12px;background:#ECFDF5;border:1px dashed #A7F3D0;border-radius:10px;font-size:11px;color:#047857;line-height:1.5;">
                <b>Verify:</b> Every value above carries its source feed. Click any source badge to verify on the original NASA / partner site.
            </div>
        </div>`;
}

/* ============================================================
   WHY BUTTON INJECTOR
   ============================================================ */
function attachWhyButton(container, traceProvider, options) {
    if (!container || typeof traceProvider !== 'function') return;
    const opts = options || {};
    const label = opts.label || 'Why this recommendation?';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.style.cssText = 'margin-top:10px;padding:8px 14px;background:#7C3AED;color:#fff;border:none;border-radius:10px;font-size:12px;font-weight:800;cursor:pointer;display:inline-flex;align-items:center;gap:6px;font-family:inherit;';
    btn.innerHTML = `<i class="fas fa-question-circle"></i> ${escapeHtml(label)}`;

    let panel = null;

    btn.addEventListener('click', () => {
        if (panel && panel.style.display !== 'none') {
            panel.style.display = 'none';
            return;
        }
        if (!panel) {
            panel = document.createElement('div');
            panel.style.marginTop = '12px';
            container.appendChild(panel);
        }
        const trace = traceProvider();
        render(panel, trace);
        panel.style.display = 'block';
        panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });

    container.appendChild(btn);
}

/* ============================================================
   EXPORT
   ============================================================ */
function exportTrace(trace) {
    if (!trace) return;
    const blob = new Blob([JSON.stringify(trace, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dailyvet-trace-${trace.feature.replace(/\s+/g, '-').toLowerCase()}-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

/* ============================================================
   PUBLIC API
   ============================================================ */
window.DVTrace = {
    buildTHITrace,
    buildForageTrace,
    buildOutbreakTrace,
    buildFloodTrace,
    buildGrassHealthTrace,
    buildAirQualityTrace,
    buildSEDACImpactTrace,
    render,
    attachWhyButton,
    exportTrace,
    SOURCE_LABELS
};

console.log('[DVTrace] v1.1 loaded (AI reasoning transparency)');
})();