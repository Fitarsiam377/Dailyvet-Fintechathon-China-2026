/* DailyVet — Air Quality & UV Interactive Map v2.2 (Added Satellite Mode) */
(function () {
'use strict';
console.log('[AirMap] climate-air-map.js v2.2 loaded');

const DIVISIONS = {
    dhaka:      { lat: 23.8103, lng: 90.4125, name: 'Dhaka',      nameBn: 'Dhaka',      emoji: '🏛️' },
    chittagong: { lat: 22.3569, lng: 91.7832, name: 'Chittagong', nameBn: 'Chittagong', emoji: '⚓' },
    rajshahi:   { lat: 24.3745, lng: 88.6042, name: 'Rajshahi',   nameBn: 'Rajshahi',   emoji: '🌾' },
    khulna:     { lat: 22.8456, lng: 89.5403, name: 'Khulna',     nameBn: 'Khulna',     emoji: '🌊' },
    barisal:    { lat: 22.7010, lng: 90.3535, name: 'Barisal',    nameBn: 'Barisal',    emoji: '🚤' },
    sylhet:     { lat: 24.8949, lng: 91.8687, name: 'Sylhet',     nameBn: 'Sylhet',     emoji: '🍃' },
    rangpur:    { lat: 25.7439, lng: 89.2752, name: 'Rangpur',    nameBn: 'Rangpur',    emoji: '🌿' },
    mymensingh: { lat: 24.7471, lng: 90.4203, name: 'Mymensingh', nameBn: 'Mymensingh', emoji: '🌳' }
};

const MAP_CENTER = [23.7, 90.35];
const MAP_ZOOM = 6.4;
const MAP_ZOOM_MOBILE = 6;
const CONCURRENCY = 8;   // all 8 divisions at once

const DIV_ALIAS = { chattogram: 'chittagong', chattagram: 'chittagong', barishal: 'barisal', dacca: 'dhaka' };
const divKey = s => { const k = String(s || '').trim().toLowerCase(); return DIV_ALIAS[k] || k; };

const BUBBLE_BASE = 22;
const BUBBLE_MAX  = 40;
const LABEL_OFFSET_LAT = 0.28;

const AQI_GRID_CACHE = new Map();
const AQI_GRID_INFLIGHT = new Map();

function aqiGridKey(lat, lng) {
    const gridLat = Math.round(lat / 0.5) * 0.5;
    const gridLng = Math.round((lng + 180) / 0.625) * 0.625 - 180;
    return `${gridLat.toFixed(3)},${gridLng.toFixed(3)}`;
}

function safeGetAQICached(lat, lng) {
    if (!window.OpenMeteo || typeof OpenMeteo.getAQI !== 'function') {
        return Promise.resolve(null);
    }
    const key = aqiGridKey(lat, lng);
    if (AQI_GRID_CACHE.has(key)) return Promise.resolve(AQI_GRID_CACHE.get(key));
    if (AQI_GRID_INFLIGHT.has(key)) return AQI_GRID_INFLIGHT.get(key);

    const [gridLat, gridLng] = key.split(',').map(Number);
    const p = withTimeout(OpenMeteo.getAQI(gridLat, gridLng), 7000)
        .then(aqi => {
            if (aqi && Number.isFinite(aqi.usAqi)) {
                AQI_GRID_CACHE.set(key, aqi);
                return aqi;
            }
            return null;
        })
        .catch(() => null)
        .finally(() => { AQI_GRID_INFLIGHT.delete(key); });

    AQI_GRID_INFLIGHT.set(key, p);
    return p;
}

async function safeGetAQI(lat, lng) {
    const aqi = await safeGetAQICached(lat, lng);
    return aqi && Number.isFinite(aqi.usAqi) ? aqi.usAqi : null;
}

/* ✅ Updated Tiles: Added OpenStreetMap and Satellite */
const TILES = {
    light: {
        url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        options: { attribution: '&copy; OpenStreetMap contributors', maxZoom: 19, crossOrigin: true }
    },
    satellite: {
        url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        options: { attribution: 'Tiles &copy; Esri', maxZoom: 19, crossOrigin: true }
    }
};

let map = null;
let markers = new Map();
let labelMarkers = new Map();
let polygons = new Map();
let rowsCache = [];
let runToken = 0;
let selectedKey = null;

let currentLevel = 'division';
let selectedDivision = null;

const _el = id => document.getElementById(id);
const _ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const esc = t => String(t == null ? '' : t).replace(/[&<>"']/g, c => _ESC[c]);

function withTimeout(p, ms) {
    return Promise.race([p, new Promise(res => setTimeout(() => res(null), ms))]);
}

function levelOfAqi(aqi) {
    if (!Number.isFinite(aqi)) return { label: 'Unknown', color: '#94a3b8', icon: '⚪' };
    if (aqi <= 50)  return { label: 'Good', color: '#059669', icon: '🟢' };
    if (aqi <= 100) return { label: 'Moderate', color: '#d97706', icon: '🟡' };
    if (aqi <= 150) return { label: 'Unhealthy for Sensitive Groups', color: '#ea580c', icon: '🟠' };
    if (aqi <= 200) return { label: 'Unhealthy', color: '#dc2626', icon: '🔴' };
    if (aqi <= 300) return { label: 'Very Unhealthy', color: '#991b1b', icon: '🟣' };
    return { label: 'Hazardous', color: '#7f1d1d', icon: '☠️' };
}

/* Shared base layers: Street (OSM) + Satellite (Esri imagery + place labels); registers map for GPS */
function dvAddBaseLayers(map, mobile) {
    const street = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        { attribution: '&copy; OpenStreetMap contributors', maxZoom: 19 });
    const sat = L.layerGroup([
        L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
            { attribution: 'Tiles &copy; Esri', maxZoom: 19 }),
        L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',
            { maxZoom: 19, opacity: 0.9 })
    ]);
    street.addTo(map);
    L.control.layers({ '🗺️ Street Map': street, '🛰️ Satellite': sat }, null,
        { position: 'topright', collapsed: !!mobile }).addTo(map);
    (window.__dvMaps = window.__dvMaps || []).push(map);
    return { street, sat };
}

function initMap() {
    const container = _el('divisionMap');
    if (!container) return null;
    if (map) return map;

    const isMobile = window.innerWidth <= 520;

    map = L.map(container, {
        center: MAP_CENTER, zoom: isMobile ? MAP_ZOOM_MOBILE : MAP_ZOOM,
        zoomControl: true, attributionControl: true, scrollWheelZoom: false,
        minZoom: 5, maxZoom: 12, maxBounds: [[20.0, 87.0], [27.0, 93.5]]
    });

    dvAddBaseLayers(map, isMobile);

    map.on('focus', () => map.scrollWheelZoom.enable());
    map.on('blur',  () => map.scrollWheelZoom.disable());

    setTimeout(() => { try { map.invalidateSize(); } catch (_) {} }, 300);
    return map;
}

function hideLoading() {
    const loading = _el('mapLoading');
    if (loading) loading.style.display = 'none';
}

function showError(msg) {
    const loading = _el('mapLoading');
    if (loading) {
        loading.innerHTML = `<div style="text-align:center;padding:20px;"><i class="fas fa-exclamation-triangle" style="color:#dc2626;font-size:32px;"></i><p style="margin-top:10px;color:#64748b;font-size:14px;">${esc(msg)}</p></div>`;
    }
}

function injectBubbleStyles() {
    if (document.getElementById('airb-styles')) return;
    const s = document.createElement('style');
    s.id = 'airb-styles';
    s.textContent =
        '.airb-marker{background:transparent!important;border:none!important;}' +
        '.airb-bubble{display:flex;align-items:center;justify-content:center;box-sizing:border-box;' +
            'border:2.5px solid #fff;border-radius:50%;color:#fff;font-weight:800;line-height:1;' +
            'text-shadow:0 1px 2px rgba(0,0,0,.45);box-shadow:0 2px 8px rgba(0,0,0,.35);' +
            'cursor:pointer;transition:transform .15s ease,box-shadow .15s ease;}' +
        '.airb-marker:hover .airb-bubble{transform:scale(1.2);box-shadow:0 4px 14px rgba(0,0,0,.45);}' +
        '.airb-bubble.airb-loading{opacity:.6;animation:airbPulse 1.2s infinite ease-in-out;}' +
        '@keyframes airbPulse{50%{opacity:.3;}}';
    document.head.appendChild(s);
}

function bubbleSize(value, maxValue) {
    if (!value || !maxValue) return BUBBLE_BASE;
    const ratio = Math.sqrt(value / Math.max(1, maxValue));
    return Math.round(BUBBLE_BASE + (BUBBLE_MAX - BUBBLE_BASE) * ratio);
}

function bubbleState(row) {
    const aqi = Number.isFinite(row.aqi) ? row.aqi : null;
    const info = aqi != null ? levelOfAqi(aqi) : { label: row.loading ? 'Loading' : 'No data', color: '#94a3b8', icon: '⚪' };
    return { aqi, info };
}

function makeBubbleIcon(row, ctx) {
    const { aqi, info } = bubbleState(row);
    const size = bubbleSize(aqi || 0, ctx.maxAqi) + ctx.boost;
    const score = aqi != null ? Math.round(aqi) : (row.loading ? '…' : '—');
    const fontSize = Math.max(9, Math.min(14, size / 3));
    const html =
        '<div class="airb-bubble' + (row.loading ? ' airb-loading' : '') + '" style="' +
            'width:' + size + 'px;height:' + size + 'px;' +
            'background:' + info.color + ';font-size:' + fontSize + 'px;">' +
            '<span>' + esc(score) + '</span>' +
        '</div>';
    return L.divIcon({
        html, className: 'airb-marker', iconSize: [size, size], iconAnchor: [size / 2, size / 2], popupAnchor: [0, -size / 2]
    });
}

function popupHTML(row) {
    const { aqi, info } = bubbleState(row);
    return '<div style="min-width:150px;font-family:inherit;line-height:1.5;">' +
        '<div style="font-weight:700;font-size:14px;margin-bottom:2px;">' + esc(row.emoji || '📍') + ' ' + esc(row.nameBn) + '</div>' +
        '<div style="font-weight:800;font-size:15px;color:' + info.color + ';">AQI ' +
            (aqi != null ? Math.round(aqi) : '—') + ' · ' + esc(info.label) + '</div>' +
    '</div>';
}

function getCtx(rows, boost) {
    return { boost: boost || 0, maxAqi: Math.max(1, ...rows.map(r => (Number.isFinite(r.aqi) ? r.aqi : 0))) };
}

function upsertBubble(row, ctx) {
    const icon = makeBubbleIcon(row, ctx);
    let m = markers.get(row.key);
    if (m) {
        m.setIcon(icon);
        m.setPopupContent(popupHTML(row));
        return m;
    }
    m = L.marker(row.centroid, { icon, title: row.nameBn, riseOnHover: true, zIndexOffset: 1000 });
    m.bindPopup(popupHTML(row), { autoPan: true });
    m.on('click', () => {
        const lat = row.centroid[0];
        const lng = row.centroid[1];
        showAirResult(row.nameBn + ' Division', lat, lng);
    });
    m.addTo(map);
    markers.set(row.key, m);
    return m;
}

async function loadAqi(rows, token, boost) {
    let anyOk = false;
    const groups = new Map();
    
    rows.forEach(row => {
        const pt = row.centroid;
        if (!pt) return;
        const key = aqiGridKey(pt[0], pt[1]);
        if (!groups.has(key)) {
            const [glat, glng] = key.split(',').map(Number);
            groups.set(key, { lat: glat, lng: glng, rows: [] });
        }
        groups.get(key).rows.push(row);
    });

    const groupList = Array.from(groups.values());
    let next = 0;

    const worker = async () => {
        while (next < groupList.length) {
            const group = groupList[next++];
            if (token !== runToken) return;
            const aqi = await safeGetAQI(group.lat, group.lng);
            if (token !== runToken) return;

            group.rows.forEach(row => {
                row.aqi = aqi;
                row.loading = false;
                if (aqi != null) anyOk = true;
                if (token !== runToken) return;
                const ctx = getCtx(rows, boost);
                upsertBubble(row, ctx);
            });
        }
    };

    const concurrency = Math.min(CONCURRENCY, groupList.length || 1);
    await Promise.all(Array.from({ length: concurrency }, worker));
    if (token === runToken && !anyOk) console.warn('[AirMap] No AQI data returned.');
}

function addLabelMarker(key, lat, lng, text, cssClass) {
    const labelIcon = L.divIcon({
        html: '<div class="' + cssClass + '">' + esc(text) + '</div>',
        className: 'dv-label-wrap', iconSize: [100, 22], iconAnchor: [50, 11]
    });
    const m = L.marker([lat, lng], { icon: labelIcon, interactive: false, keyboard: false, zIndexOffset: -100 }).addTo(map);
    labelMarkers.set(key, m);
    return m;
}

function drawLevel(rows, cfg) {
    const token = runToken;
    rowsCache = rows;
    
    // Clear old markers/labels
    markers.forEach(m => map.removeLayer(m));
    markers.clear();
    labelMarkers.forEach(m => map.removeLayer(m));
    labelMarkers.clear();

    rows.forEach((row, i) => {
        row.idx = i;
        row.loading = true;
        row.aqi = null;
        
        addLabelMarker(row.key + '_label', row.centroid[0] - cfg.labelOffset, row.centroid[1], row.nameBn, cfg.labelClass);
    });
    const ctx = getCtx(rows, cfg.boost);
    rows.forEach(r => upsertBubble(r, ctx));
    loadAqi(rows, token, cfg.boost);
}

function renderDivisions() {
    if (!map) return;
    currentLevel = 'division';
    updateBreadcrumb('division');

    const rows = Object.keys(DIVISIONS).map(key => {
        const d = DIVISIONS[key];
        return {
            key, level: 'division',
            nameEn: d.name, nameBn: d.nameBn, emoji: d.emoji,
            centroid: [d.lat, d.lng]
        };
    });

    drawLevel(rows, {
        labelClass: 'dv-division-label',
        labelOffset: LABEL_OFFSET_LAT,
        boost: 8
    });

    renderScoreReference();
    
    // Auto fit bounds and hide loading
    map.fitBounds(Object.values(DIVISIONS).map(d => [d.lat, d.lng]), { padding: [20, 20], animate: false });
    hideLoading();
}

function renderScoreReference() {
    const ref = _el('mapScoreReference');
    if (!ref) return;
    ref.style.display = 'block';
    ref.innerHTML =
        '<div class="map-ref-card">' +
            '<div class="map-ref-title"><i class="fas fa-clipboard-list"></i><span>Score Ranges (Which score is healthy)</span></div>' +
            '<div class="map-ref-group">' +
                '<div class="map-ref-label">🌬️ AQI (US EPA)</div>' +
                '<div class="map-ref-grid">' +
                    '<div class="map-ref-item"><span class="map-ref-dot" style="background:#059669;"></span><span class="map-ref-range">0–50</span><span class="map-ref-text" style="color:#059669;">Good</span></div>' +
                    '<div class="map-ref-item"><span class="map-ref-dot" style="background:#d97706;"></span><span class="map-ref-range">51–100</span><span class="map-ref-text" style="color:#d97706;">Moderate</span></div>' +
                    '<div class="map-ref-item"><span class="map-ref-dot" style="background:#ea580c;"></span><span class="map-ref-range">101–150</span><span class="map-ref-text" style="color:#ea580c;">Sensitive</span></div>' +
                    '<div class="map-ref-item"><span class="map-ref-dot" style="background:#dc2626;"></span><span class="map-ref-range">151–200</span><span class="map-ref-text" style="color:#dc2626;">Unhealthy</span></div>' +
                '</div>' +
            '</div>' +
        '</div>';
}

function updateBreadcrumb(level, name) {
    const bc = _el('mapBreadcrumb');
    const backBtn = _el('mapBackBtn');
    if (!bc) return;

    if (level === 'division') {
        bc.innerHTML = '<span class="map-bc-active">Bangladesh (8 Divisions)</span>';
        if (backBtn) backBtn.style.display = 'none';
        return;
    }
}

async function showAirResult(placeName, lat, lng) {
    const result = _el('airResult');
    if (!result) return;

    result.style.display = 'block';
    result.innerHTML = '<div class="map-result-loading"><i class="fas fa-spinner fa-spin"></i><span>Loading air quality for ' + esc(placeName) + '...</span></div>';

    try {
        /* ⚡ Same grid cache the bubbles use -> instant, and always matches the bubble.
           (The 7-day weather call was never displayed, so it is gone.) */
        const aqi = await safeGetAQICached(lat, lng);

        const aqiInfo = levelOfAqi(aqi ? aqi.usAqi : null);
        const aqiValue = aqi ? Math.round(aqi.usAqi) : '—';
        
        result.innerHTML =
            '<div class="air-result-card">' +
                '<div class="air-result-header">' +
                    '<div class="air-result-icon" style="background:' + aqiInfo.color + ';">' + (aqiInfo.icon || '🟠') + '</div>' +
                    '<div class="air-result-title"><h3>' + esc(placeName) + '</h3><p>Air Quality · Real-time</p></div>' +
                    '<button class="air-result-close" onclick="window.__closeAirResult()"><i class="fas fa-times"></i></button>' +
                '</div>' +
                '<div class="air-result-aqi" style="border-color:' + aqiInfo.color + ';background:' + aqiInfo.color + '15;">' +
                    '<div class="air-result-aqi-value" style="color:' + aqiInfo.color + ';">' + aqiValue + '</div>' +
                    '<div class="air-result-aqi-label" style="color:' + aqiInfo.color + ';">US AQI · ' + esc(aqiInfo.label || '') + '</div>' +
                '</div>' +
            '</div>';
    } catch (err) {
        result.innerHTML = '<div class="map-result-loading"><i class="fas fa-exclamation-triangle" style="color:#dc2626;"></i><span>Could not load data.</span></div>';
    }
}

window.__closeAirResult = function () {
    const r = _el('airResult');
    if (r) r.style.display = 'none';
};

function getUserPhone() {
    try { return sessionStorage.getItem('userPhone') || localStorage.getItem('userPhone'); }
    catch (_) { return null; }
}

function start() {
    if (!getUserPhone()) { window.location.replace('login.html'); return; }
    
    injectBubbleStyles();

    if (typeof L === 'undefined') {
        showError('Map library failed to load. Check your connection and refresh.');
        return;
    }

    /* Watchdog: never leave the spinner up forever */
    setTimeout(() => {
        const l = _el('mapLoading');
        if (l && l.style.display !== 'none' && !l.querySelector('.fa-exclamation-triangle')) hideLoading();
    }, 12000);

    try { initMap(); } catch (err) {
        console.error('[AirMap] initMap failed:', err);
        showError('Could not start the map.');
        return;
    }
    
    if (map) {
        renderDivisions();
    } else {
        showError('Map container not found.');
    }
}

window.__mapBackToDivisions = function () {
    renderDivisions();
    const r = _el('airResult');
    if (r) r.style.display = 'none';
};

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
} else {
    start();
}

})();