/* DailyVet — Centralized Species State v1.0
   Single source of truth for selected livestock species across all climate pages.
   Zero dependencies. ~1.5 KB.
   Listens to nothing; emits `dv:species-changed` on every set(). */
(function () {
'use strict';

const KEY = 'dvClimateSpecies';
const VALID = ['cow', 'buffalo', 'goat', 'sheep', 'chicken', 'duck', 'dog', 'cat'];

let current = 'cow';
try {
    const v = localStorage.getItem(KEY);
    if (VALID.includes(v)) current = v;
} catch (_) {}

function set(id) {
    if (!VALID.includes(id)) return false;
    if (id === current) return true;
    current = id;
    try { localStorage.setItem(KEY, id); } catch (_) {}
    try {
        document.dispatchEvent(new CustomEvent('dv:species-changed', { detail: { species: id } }));
    } catch (_) {}
    return true;
}

window.DVSpecies = {
    get: () => current,
    set,
    all: () => VALID.slice(),
    isValid: id => VALID.includes(id),
    KEY
};
})();