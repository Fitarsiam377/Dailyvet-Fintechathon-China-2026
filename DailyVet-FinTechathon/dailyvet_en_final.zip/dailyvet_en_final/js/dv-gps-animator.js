/* DailyVet — GPS Animator v2.0
   Shared "My Location" handler for ALL climate pages.

   What it does on every page that has a Leaflet map:
     1. Button spinner while locating (+ brief "Located" confirmation)
     2. Scrolls the map into view
     3. Smooth fly-to zoom animation onto the user
     4. Drops ONE pulsing marker + accuracy ring (replaces any previous one)
     5. Calls opts.onSuccess(closest, { lat, lng, accuracy }) after the flight

   Map discovery (no page wiring needed):
     opts.map  ->  window.__dvMaps (every map pushes itself here)  ->  none
   Pages without a map still get the spinner + callback.

   Self-contained: injects its own CSS. No external deps. */
(function () {
'use strict';

var BD_BOUNDS = { minLat: 20.4, maxLat: 26.7, minLng: 87.9, maxLng: 92.8 };

function inBD(lat, lng) {
    return lat >= BD_BOUNDS.minLat && lat <= BD_BOUNDS.maxLat &&
           lng >= BD_BOUNDS.minLng && lng <= BD_BOUNDS.maxLng;
}

function injectCss() {
    if (document.getElementById('dvgps-css')) return;
    var s = document.createElement('style');
    s.id = 'dvgps-css';
    s.textContent =
        '.dvgps-wrap{background:transparent!important;border:none!important;}' +
        '.dvgps{position:relative;width:26px;height:26px;}' +
        '.dvgps-dot{position:absolute;left:6px;top:6px;width:14px;height:14px;border-radius:50%;' +
            'border:3px solid #fff;box-shadow:0 1px 6px rgba(0,0,0,.45);z-index:2;}' +
        '.dvgps-ring{position:absolute;left:0;top:0;width:26px;height:26px;border-radius:50%;opacity:0;' +
            'animation:dvgpsPulse 2s ease-out infinite;}' +
        '.dvgps-ring.r2{animation-delay:1s;}' +
        '@keyframes dvgpsPulse{0%{transform:scale(.4);opacity:.65;}100%{transform:scale(2.6);opacity:0;}}' +
        '.dvgps-popup{line-height:1.4;min-width:120px;}' +
        '.dvgps-popup b{font-size:14px;color:#111827;}' +
        '.dvgps-popup span{display:block;font-size:13px;color:#4b5563;margin-top:2px;}' +
        '.dvgps-toast{position:fixed;left:50%;bottom:28px;transform:translateX(-50%) translateY(20px);' +
            'background:#0f172a;color:#fff;padding:10px 16px;border-radius:12px;font-size:13px;font-weight:600;' +
            'box-shadow:0 8px 24px rgba(0,0,0,.3);opacity:0;transition:all .3s ease;z-index:99999;max-width:90vw;text-align:center;}' +
        '.dvgps-toast.show{opacity:1;transform:translateX(-50%) translateY(0);}' +
        '.dvgps-btn-ok{background:#059669!important;color:#fff!important;border-color:#059669!important;}';
    document.head.appendChild(s);
}

function toast(msg) {
    injectCss();
    var t = document.createElement('div');
    t.className = 'dvgps-toast';
    t.textContent = msg;
    document.body.appendChild(t);
    requestAnimationFrame(function () { t.classList.add('show'); });
    setTimeout(function () {
        t.classList.remove('show');
        setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, 350);
    }, 3800);
}

function getButton(ref) {
    if (!ref) return null;
    if (typeof ref === 'string') return document.getElementById(ref);
    return ref;
}

function setLoading(btn, on) {
    if (!btn) return;
    if (on) {
        if (btn.dataset.dvOrig === undefined) btn.dataset.dvOrig = btn.innerHTML;
        btn.disabled = true;
        btn.classList.add('loading');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Locating…</span>';
    } else {
        btn.disabled = false;
        btn.classList.remove('loading');
        if (btn.dataset.dvOrig !== undefined) {
            btn.innerHTML = btn.dataset.dvOrig;
            delete btn.dataset.dvOrig;
        }
    }
}

function flashOk(btn) {
    if (!btn) return;
    var orig = btn.innerHTML;
    btn.classList.add('dvgps-btn-ok');
    btn.innerHTML = '<i class="fas fa-check"></i><span>Located</span>';
    setTimeout(function () {
        btn.classList.remove('dvgps-btn-ok');
        btn.innerHTML = orig;
    }, 1600);
}

/* ---------- map discovery ---------- */
function isUsable(m) {
    try { return m && m.getContainer && document.body.contains(m.getContainer()); }
    catch (_) { return false; }
}
function findMap(explicit) {
    if (isUsable(explicit)) return explicit;
    var list = window.__dvMaps || [];
    for (var i = list.length - 1; i >= 0; i--) if (isUsable(list[i])) return list[i];
    return null;
}

/* ---------- marker + flight ---------- */
function drop(map, lat, lng, accuracy, accent, label, zoom) {
    if (!map || !window.L) return Promise.resolve();
    injectCss();
    accent = accent || '#2563eb';

    try { map.invalidateSize(); } catch (_) {}

    if (map.__dvGpsLayer) {
        try { map.removeLayer(map.__dvGpsLayer); } catch (_) {}
        map.__dvGpsLayer = null;
    }

    var group = L.layerGroup();
    var r = Math.max(60, Math.min(accuracy || 150, 3000));
    L.circle([lat, lng], {
        radius: r, color: accent, weight: 1, opacity: 0.6,
        fillColor: accent, fillOpacity: 0.12, interactive: false
    }).addTo(group);

    var icon = L.divIcon({
        className: 'dvgps-wrap',
        iconSize: [26, 26], iconAnchor: [13, 13],
        html: '<div class="dvgps">' +
              '<div class="dvgps-ring" style="background:' + accent + ';"></div>' +
              '<div class="dvgps-ring r2" style="background:' + accent + ';"></div>' +
              '<div class="dvgps-dot" style="background:' + accent + ';"></div></div>'
    });
    var marker = L.marker([lat, lng], { icon: icon, zIndexOffset: 5000, keyboard: false });
    var safeLabel = String(label || 'My Location').replace(/[<>&"]/g, '');
    marker.bindPopup('<div class="dvgps-popup"><b>📍 My Location</b><span>' + safeLabel + '</span></div>');
    marker.addTo(group);
    group.addTo(map);
    map.__dvGpsLayer = group;

    try {
        var c = map.getContainer();
        if (c && c.scrollIntoView) c.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } catch (_) {}

    return new Promise(function (resolve) {
        var done = false;
        function finish() {
            if (done) return; done = true;
            try { marker.openPopup(); } catch (_) {}
            resolve();
        }
        try {
            map.once('moveend', function () { setTimeout(finish, 120); });
            map.flyTo([lat, lng], Math.min(zoom || 11, map.getMaxZoom ? (map.getMaxZoom() || 18) : 18), { duration: 1.8 });
        } catch (_) { finish(); }
        setTimeout(finish, 2600); /* never hang */
    });
}

/* ---------- public API ---------- */
function locate(opts) {
    opts = opts || {};
    injectCss();
    var btn = getButton(opts.button || opts.buttonId);

    if (!navigator.geolocation) {
        toast('Geolocation is not supported by this browser.');
        return;
    }

    setLoading(btn, true);

    function onPos(pos) {
        var lat = pos.coords.latitude;
        var lng = pos.coords.longitude;
        var acc = pos.coords.accuracy;
        setLoading(btn, false);

        var closest = { key: null, nameBn: 'My Location', name: 'My Location' };
        if (typeof opts.findClosest === 'function') {
            try {
                var res = opts.findClosest(lat, lng);
                if (res) closest = res;
            } catch (err) { console.warn('[GPS] findClosest failed:', err.message); }
        }

        var outside = !inBD(lat, lng);
        if (outside) toast('Your location is outside Bangladesh — showing the nearest area.');

        var map = findMap(opts.map);
        var label = closest.nameBn || closest.name || 'My Location';

        var flight = Promise.resolve();
        if (map && !outside) {
            flight = drop(map, lat, lng, acc, opts.accentColor, label, opts.zoom);
        } else if (map && outside && closest.row && closest.row.centroid) {
            try { map.flyTo(closest.row.centroid, 8, { duration: 1.4 }); } catch (_) {}
        }

        flashOk(btn);

        flight.then(function () {
            if (typeof opts.onSuccess === 'function') {
                try {
                    var r = opts.onSuccess(closest, { lat: lat, lng: lng, accuracy: acc, outside: outside });
                    if (r && typeof r.catch === 'function') r.catch(function (e) { console.error('[GPS] onSuccess failed:', e); });
                } catch (err) { console.error('[GPS] onSuccess failed:', err); }
            }
        });
    }

    function onErr(err) {
        setLoading(btn, false);
        var msgs = {
            1: 'Location permission denied. Enable location in your browser settings.',
            2: 'Location unavailable. Check GPS / network.',
            3: 'Location request timed out. Try again.'
        };
        toast(msgs[err.code] || ('Location failed: ' + err.message));
    }

    /* High accuracy first; on timeout/unavailable retry once with low accuracy (desktop/Wi-Fi) */
    navigator.geolocation.getCurrentPosition(onPos, function (err) {
        if (err && (err.code === 2 || err.code === 3)) {
            navigator.geolocation.getCurrentPosition(onPos, onErr,
                { enableHighAccuracy: false, timeout: 12000, maximumAge: 300000 });
        } else onErr(err);
    }, { enableHighAccuracy: true, timeout: 8000, maximumAge: 60000 });
}

window.DVGpsAnimator = { locate: locate, drop: drop, toast: toast };
})();