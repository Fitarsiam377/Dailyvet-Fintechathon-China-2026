/* DailyVet — NASA POWER API Client v2.1
   Source: https://power.larc.nasa.gov/docs/services/api/
   Flow: memory cache -> Firestore cache (24h) -> live NASA POWER call

   v2.1 changes:
   • Added WS2M (wind speed at 2m) — used by THI heat index pages
   • Added T2MDEW (dew point) — helps compute RH fallback
   • Freshness indicator now returns per-parameter status
   • Cleaner logging; no Bangla strings
*/
(function () {
'use strict';

const POWER_BASE_URL   = 'https://power.larc.nasa.gov/api/temporal/daily/point';
const POWER_PARAMS     = [
    'T2M', 'T2M_MAX', 'T2M_MIN', 'RH2M', 'T2MDEW', 'WS2M',
    'GWETTOP', 'GWETROOT', 'TSOIL1',
    'PRECTOTCORR', 'ALLSKY_SFC_SW_DWN'
].join(',');

const CACHE_TTL_MS     = 24 * 60 * 60 * 1000;
const MEM_TTL_MS       = 30 * 60 * 1000;
const CACHE_COLLECTION = 'nasa_cache';
const API_TIMEOUT_MS   = 15000;
const RETRY_DELAY_MS   = 800;
const MISSING_VALUE    = -999;

const PARAM_TTL_MS = {
    T2M:                12 * 60 * 60 * 1000,
    T2M_MAX:            12 * 60 * 60 * 1000,
    T2M_MIN:            12 * 60 * 60 * 1000,
    RH2M:               12 * 60 * 60 * 1000,
    T2MDEW:             12 * 60 * 60 * 1000,
    WS2M:               12 * 60 * 60 * 1000,
    PRECTOTCORR:        6  * 60 * 60 * 1000,
    GWETTOP:            24 * 60 * 60 * 1000,
    GWETROOT:           24 * 60 * 60 * 1000,
    TSOIL:              24 * 60 * 60 * 1000,
    ALLSKY_SFC_SW_DWN:  24 * 60 * 60 * 1000
};

function _effectiveTTL() {
    let min = Infinity;
    for (const k of Object.keys(PARAM_TTL_MS)) {
        if (PARAM_TTL_MS[k] < min) min = PARAM_TTL_MS[k];
    }
    return min;
}

const _fs  = () => firebase.firestore();
const _mem = new Map();
const _meta = new WeakMap();
const _tag = (obj, source) => { if (obj && typeof obj === 'object') _meta.set(obj, source); return obj; };

const _sleep = ms => new Promise(r => setTimeout(r, ms));

function _dateStr(d) {
    return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
}

function _cacheKey(lat, lng, start, end) {
    return `${Number(lat).toFixed(2)}_${Number(lng).toFixed(2)}_${start}_${end}`;
}

function _isValidValue(v) {
    return typeof v === 'number' && Number.isFinite(v) && v !== MISSING_VALUE;
}

function _latestKey(lat, lng) {
    return `latest_${Number(lat).toFixed(2)}_${Number(lng).toFixed(2)}`;
}

function ageDays(yyyymmdd) {
    if (!yyyymmdd || String(yyyymmdd).length !== 8) return null;
    const s = String(yyyymmdd);
    const t = Date.UTC(+s.slice(0, 4), +s.slice(4, 6) - 1, +s.slice(6, 8));
    if (!Number.isFinite(t)) return null;
    return Math.max(0, Math.floor((Date.now() - t) / 86400000));
}

function _isRetryable(err) {
    return err.name === 'TypeError' || err.retryable === true ||
           err.status === 429 || err.status >= 500;
}

async function _fetchOnce(url) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS);
    try {
        const res = await fetch(url, { signal: controller.signal });
        if (!res.ok) {
            let detail = '';
            try { const j = await res.json(); detail = (j.messages || j.errors || j.message || '').toString(); } catch (_) {}
            const e = new Error(`NASA POWER HTTP ${res.status}` + (detail ? ' - ' + detail : ''));
            e.status = res.status;
            throw e;
        }
        const json = await res.json();
        if (!json || !json.properties || !json.properties.parameter) {
            throw new Error('NASA POWER: unexpected response format');
        }
        const param = json.properties.parameter;
        if (param.TSOIL1 && !param.TSOIL) param.TSOIL = param.TSOIL1;
        return param;
    } catch (err) {
        if (err.name === 'AbortError') {
            const e = new Error('NASA POWER request timed out');
            e.retryable = true;
            throw e;
        }
        throw err;
    } finally {
        clearTimeout(timer);
    }
}

async function fetchFromPowerAPI(lat, lng, startDate, endDate) {
    const la = Number(lat);
    const lo = Number(lng);
    if (!Number.isFinite(la) || !Number.isFinite(lo)) {
        throw new Error('NASA POWER: invalid coordinates');
    }
    const url = `${POWER_BASE_URL}?parameters=${POWER_PARAMS}&community=AG` +
                `&longitude=${lo}&latitude=${la}&start=${startDate}&end=${endDate}&format=JSON`;
    try {
        return await _fetchOnce(url);
    } catch (err) {
        if (err.status === 422) {
            const toD = v => { const t = String(v); return new Date(+t.slice(0,4), +t.slice(4,6) - 1, +t.slice(6,8)); };
            const e2 = toD(endDate); e2.setDate(e2.getDate() - 5);
            const s2 = toD(startDate); s2.setDate(s2.getDate() - 5);
            const url2 = `${POWER_BASE_URL}?parameters=${POWER_PARAMS}&community=AG` +
                         `&longitude=${lo}&latitude=${la}&start=${_dateStr(s2)}&end=${_dateStr(e2)}&format=JSON`;
            return _fetchOnce(url2);
        }
        if (!_isRetryable(err)) throw err;
        await _sleep(RETRY_DELAY_MS);
        return _fetchOnce(url);
    }
}

async function readCache(cacheKey, allowStale) {
    try {
        const doc = await _fs().collection(CACHE_COLLECTION).doc(cacheKey).get();
        if (!doc.exists) return null;
        const data = doc.data();
        if (!data || !data.cachedAtMs) return null;
        if (!allowStale) {
            const age = Date.now() - data.cachedAtMs;
            if (age > _effectiveTTL()) return null;
        }
        return data.parameter || null;
    } catch (err) {
        console.warn('[NASA] Cache read failed:', err.message);
        return null;
    }
}

async function writeCache(cacheKey, parameter) {
    try {
        await _fs().collection(CACHE_COLLECTION).doc(cacheKey).set({
            parameter,
            cachedAtMs: Date.now(),
            cachedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (err) {
        console.warn('[NASA] Cache write failed:', err.message);
    }
}

async function _load(lat, lng, startStr, endStr, cacheKey) {
    const cached = await readCache(cacheKey);
    if (cached) return _tag(cached, 'firestore-cache');

    try {
        const parameter = await fetchFromPowerAPI(lat, lng, startStr, endStr);
        if (getLatest(parameter, 'T2M')) {
            writeCache(cacheKey, parameter);
            writeCache(_latestKey(lat, lng), parameter);
        }
        return _tag(parameter, 'live');
    } catch (err) {
        const stale = await readCache(_latestKey(lat, lng), true);
        if (stale && getLatest(stale, 'T2M')) {
            console.warn('[NASA] Live call failed, using last saved snapshot:', err.message);
            return _tag(stale, 'stale-cache');
        }
        throw err;
    }
}

function getPowerData(lat, lng, daysBack) {
    daysBack = daysBack || 7;
    const end = new Date();
    const start = new Date();
    start.setDate(end.getDate() - daysBack);

    const startStr = _dateStr(start);
    const endStr = _dateStr(end);
    const key = _cacheKey(lat, lng, startStr, endStr);

    const hit = _mem.get(key);
    if (hit && Date.now() - hit.at < MEM_TTL_MS) return hit.promise;

    const promise = _load(lat, lng, startStr, endStr, key);
    _mem.set(key, { at: Date.now(), promise });
    promise.catch(() => {
        const cur = _mem.get(key);
        if (cur && cur.promise === promise) _mem.delete(key);
    });
    return promise;
}

function getLatest(parameter, key) {
    if (!parameter || !parameter[key]) return null;
    const series = parameter[key];
    const dates = Object.keys(series).sort();
    for (let i = dates.length - 1; i >= 0; i--) {
        if (_isValidValue(series[dates[i]])) {
            return { value: series[dates[i]], date: dates[i] };
        }
    }
    return null;
}

function getSeries(parameter, key) {
    if (!parameter || !parameter[key]) return [];
    const series = parameter[key];
    return Object.keys(series)
        .sort()
        .map(d => ({ date: d, value: series[d] }))
        .filter(item => _isValidValue(item.value));
}

const _FRESHNESS_THRESHOLDS = { fresh: 2, acceptable: 7 };

function getDataFreshness(parameter) {
    if (!parameter) {
        return { status: 'no-data', ageDays: null, dataDate: null, warning: 'No NASA data available', perParam: {} };
    }

    const paramKeys = Object.keys(PARAM_TTL_MS);
    const perParam = {};
    let oldestAge = 0;

    paramKeys.forEach(k => {
        const latest = getLatest(parameter, k);
        if (!latest) {
            perParam[k] = { date: null, ageDays: null, status: 'no-data' };
            return;
        }
        const age = ageDays(latest.date);
        const ageNum = age == null ? 0 : age;
        let status;
        if (ageNum <= _FRESHNESS_THRESHOLDS.fresh) status = 'fresh';
        else if (ageNum <= _FRESHNESS_THRESHOLDS.acceptable) status = 'acceptable';
        else status = 'stale';
        perParam[k] = { date: latest.date, ageDays: age, status };
        if (ageNum > oldestAge) oldestAge = ageNum;
    });

    const ref = perParam.T2M;
    let status = 'no-data';
    let warning = null;
    let refDate = null;
    if (ref && ref.date) {
        refDate = ref.date;
        if (ref.ageDays <= _FRESHNESS_THRESHOLDS.fresh) status = 'fresh';
        else if (ref.ageDays <= _FRESHNESS_THRESHOLDS.acceptable) {
            status = 'acceptable';
            warning = `NASA data is ${ref.ageDays} day${ref.ageDays === 1 ? '' : 's'} old (satellite processing delay)`;
        } else {
            status = 'stale';
            warning = `NASA data is ${ref.ageDays} days old — treat as reference only`;
        }
    } else {
        warning = 'No valid temperature data';
    }

    return { status, ageDays: ref ? ref.ageDays : null, dataDate: refDate, warning, oldestAge, perParam };
}

function freshnessLabel(status) {
    switch (status) {
        case 'fresh':      return 'Live';
        case 'acceptable': return 'Recent';
        case 'stale':      return 'Old';
        case 'no-data':    return 'No data';
        default:           return 'Unknown';
    }
}

function freshnessColor(status) {
    switch (status) {
        case 'fresh':      return '#059669';
        case 'acceptable': return '#d97706';
        case 'stale':      return '#dc2626';
        default:           return '#94a3b8';
    }
}

window.NasaPower = {
    getPowerData,
    getLatest,
    getSeries,
    fetchFromPowerAPI,
    getSource: parameter => (parameter && _meta.get(parameter)) || 'unknown',
    ageDays,
    getDataFreshness,
    freshnessLabel,
    freshnessColor,
    PARAM_TTL_MS,
    _effectiveTTL,
    PARAMETERS: POWER_PARAMS.split(',')
};

})();