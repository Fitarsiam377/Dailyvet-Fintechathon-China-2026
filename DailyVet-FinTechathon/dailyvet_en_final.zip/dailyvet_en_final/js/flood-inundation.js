/* DailyVet — Flood Inundation Section Controller
   
   Loads NASA GIBS satellite flood data for the selected district
   and renders it into #floodInundationCard.
   
   Depends on: nasa-flood-product.js
*/
(function () {
'use strict';

const _el = id => document.getElementById(id);

async function loadFloodInundation() {
    const card = _el('floodInundationCard');
    if (!card || !window.NasaFloodProduct) return;
    const body = card.querySelector('.climate-section-body');
    if (!body) return;

    const sel = _el('climateDistrict');
    const district = sel ? sel.value : 'dhaka';

    body.innerHTML = `
        <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:30px 20px;text-align:center;gap:12px;">
            <i class="fas fa-satellite fa-bounce" style="font-size:32px;color:#2563EB;"></i>
            <span style="font-size:14px;font-weight:700;color:#1e293b;">Fetching NASA GIBS flood layer...</span>
        </div>`;

    try {
        const floodInfo = await NasaFloodProduct.getFloodInfo(district);

        if (!floodInfo || !floodInfo.available) {
            body.innerHTML = `
                <div style="padding:24px;text-align:center;">
                    <div class="cl-empty-title">Satellite Flood Inundation</div>
                    <div class="cl-empty-sub" style="margin-top:8px;">Data temporarily unavailable</div>
                    <div style="font-size:11px;color:#94A3B8;margin-top:6px;">${floodInfo && floodInfo.error ? floodInfo.error : 'NASA GIBS unreachable'}</div>
                    <button id="floodInundationRetryBtn" style="margin-top:12px;padding:8px 16px;background:#0F5132;color:#fff;border:none;border-radius:10px;font-size:12px;font-weight:800;cursor:pointer;">Retry</button>
                </div>`;
            const retry = _el('floodInundationRetryBtn');
            if (retry) retry.addEventListener('click', loadFloodInundation);
            return;
        }

        const flooded = floodInfo.flooded;
        const color = flooded ? '#DC2626' : '#059669';
        const bg = flooded ? '#FEF2F2' : '#ECFDF5';
        const icon = flooded ? '🌊' : '✅';
        const label = flooded ? 'Flood Detected' : 'No Flood Detected';

        body.innerHTML = `
            <div class="cl-info-card" style="border-color:${color}40;background:${bg};">
                <div class="cl-info-head">
                    <div class="cl-info-head-icon" style="background:${color}20;color:${color};">
                        <i class="fas fa-satellite"></i>
                    </div>
                    <div>
                        <h3 class="cl-info-head-title">Satellite Flood Inundation</h3>
                        <p class="cl-info-head-sub">NASA GIBS • MODIS Combined 2-Day Composite</p>
                    </div>
                </div>
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;padding:12px 0;">
                    <div style="padding:14px;background:#fff;border:1px solid ${color}30;border-radius:12px;text-align:center;">
                        <div style="font-size:11px;font-weight:800;color:#64748B;text-transform:uppercase;">Status</div>
                        <div style="font-size:18px;font-weight:900;color:${color};margin-top:4px;">${icon} ${label}</div>
                    </div>
                    <div style="padding:14px;background:#fff;border:1px solid ${color}30;border-radius:12px;text-align:center;">
                        <div style="font-size:11px;font-weight:800;color:#64748B;text-transform:uppercase;">Detected</div>
                        <div style="font-size:22px;font-weight:900;color:${color};margin-top:4px;">${floodInfo.floodValue > 0 ? 'Yes' : 'No'}</div>
                    </div>
                    <div style="padding:14px;background:#fff;border:1px solid ${color}30;border-radius:12px;text-align:center;">
                        <div style="font-size:11px;font-weight:800;color:#64748B;text-transform:uppercase;">Source</div>
                        <div style="font-size:12px;font-weight:800;color:#0F5132;margin-top:6px;">NASA GIBS</div>
                    </div>
                </div>
                <div style="padding:10px 12px;background:#fff;border:1px dashed ${color}40;border-radius:10px;font-size:11.5px;color:#475569;">
                    <b>Data:</b> ${floodInfo.source} · Fetched: ${new Date(floodInfo.fetchedAt).toLocaleString()}
                </div>
            </div>`;
    } catch (err) {
        console.error('[FloodInundation] failed:', err);
        body.innerHTML = `<div class="cl-empty"><i class="fas fa-exclamation-triangle" style="color:#dc2626;"></i><span>Could not load flood data</span></div>`;
    }
}

function init() {
    const waitForFloodProduct = setInterval(function () {
        if (window.NasaFloodProduct && window.NasaFloodProduct.getFloodInfo) {
            clearInterval(waitForFloodProduct);
            loadFloodInundation();
        }
    }, 200);
    setTimeout(function () { clearInterval(waitForFloodProduct); }, 15000);

    document.addEventListener('change', function (e) {
        if (e.target && e.target.id === 'climateDistrict') {
            setTimeout(loadFloodInundation, 100);
        }
    });
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

window.loadFloodInundation = loadFloodInundation;

console.log('✅ FloodInundation controller loaded');
})();