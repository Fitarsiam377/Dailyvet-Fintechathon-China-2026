const _fs = () => firebase.firestore();
let currentUserPhone = null;
let allMarketItems = [];
let currentCategory = 'All';
let uploadedImages = [];
let currentViewItemId = null;

/* ---------- Pagination / cache state ---------- */
const PAGE_SIZE = 12;
const CACHE_KEY = 'dv_market_cache_v2';
let lastDoc = null;
let hasMore = false;
let isLoadingMore = false;
let _loadMoreObserver = null;

document.addEventListener('DOMContentLoaded', () => {
    currentUserPhone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
    if (!currentUserPhone) {
        window.location.href = 'login.html';
        return;
    }
    loadMarketItems();
    refreshBankBalance();
});

/* ---------- Helpers ---------- */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = String(text ?? '');
    return div.innerHTML;
}

function getThumb(item) {
    return item.thumb || (item.images && item.images[0]) || '';
}

function getImageCount(item) {
    return item.imageCount || (item.images ? item.images.length : 0);
}

function loadImage(src) {
    return new Promise((resolve, reject) => {
        const img = new Image();
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = src;
    });
}

function compressImage(file, maxWidth = 600, quality = 0.7) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > maxWidth) {
                    height = (maxWidth / width) * height;
                    width = maxWidth;
                }

                canvas.width = width;
                canvas.height = height;
                canvas.getContext('2d').drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/jpeg', quality));
            };
            img.onerror = reject;
            img.src = e.target.result;
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

async function makeThumb(dataUrl, maxWidth = 320, quality = 0.6) {
    const img = await loadImage(dataUrl);
    let width = img.width;
    let height = img.height;
    if (width > maxWidth) {
        height = (maxWidth / width) * height;
        width = maxWidth;
    }
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    canvas.getContext('2d').drawImage(img, 0, 0, width, height);
    return canvas.toDataURL('image/jpeg', quality);
}

async function handleMarketImages(event) {
    const files = Array.from(event.target.files);
    const remainingSlots = 5 - uploadedImages.length;

    if (files.length > remainingSlots) {
        alert(`You can only upload up to 5 images. Adding the first ${remainingSlots}.`);
    }

    const filesToProcess = files.slice(0, remainingSlots);

    const results = await Promise.all(filesToProcess.map(file =>
        compressImage(file).catch(e => {
            console.warn('Image compression failed', e);
            return null;
        })
    ));
    results.forEach(r => { if (r) uploadedImages.push(r); });

    renderImagePreviews();
    event.target.value = '';
}

function renderImagePreviews() {
    const grid = document.getElementById('mktImagePreviews');
    if (!grid) return;

    grid.innerHTML = uploadedImages.map((img, index) => `
        <div class="mkt-preview-item">
            <img src="${img}" alt="Preview">
            <button class="mkt-preview-remove" onclick="removeMarketImage(${index})" type="button"><i class="fas fa-times"></i></button>
        </div>
    `).join('');
}

function removeMarketImage(index) {
    uploadedImages.splice(index, 1);
    renderImagePreviews();
}

function openPostModal() {
    document.getElementById('mktEditId').value = '';
    document.getElementById('mktTitle').value = '';
    document.getElementById('mktPrice').value = '';
    document.getElementById('mktUnit').value = '';
    const _stk = document.getElementById('mktQuantity'); if (_stk) _stk.value = '';
    document.getElementById('mktLocation').value = '';
    document.getElementById('mktContact').value = '';
    uploadedImages = [];
    renderImagePreviews();

    document.getElementById('postModalTitle').textContent = 'List an Item for Sale';
    document.getElementById('saveItemBtn').textContent = 'Publish Listing';
    document.getElementById('postModal').style.display = 'flex';
}

function closePostModal() {
    document.getElementById('postModal').style.display = 'none';
}

async function saveMarketItem() {
    const editId = document.getElementById('mktEditId').value;
    const title = document.getElementById('mktTitle').value.trim();
    const category = document.getElementById('mktCategory').value;
    const price = Number(document.getElementById('mktPrice').value);
    const unit = document.getElementById('mktUnit').value.trim() || 'Piece';
    const location = document.getElementById('mktLocation').value.trim();
    const contact = document.getElementById('mktContact').value.trim();
    const stockVal = Math.floor(Number(document.getElementById('mktQuantity').value));

    if (!title || !price || !location || !contact) return alert('Please fill in all required fields.');
    if (!stockVal || stockVal < 1) return alert('Please enter the quantity (at least 1).');
    if (uploadedImages.length === 0) return alert('Please upload at least 1 photo.');

    const saveBtn = document.getElementById('saveItemBtn');
    const originalLabel = saveBtn ? saveBtn.textContent : '';
    if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'Saving...'; }

    const db = _fs();
    const FV = firebase.firestore.FieldValue;

    try {
        const thumb = await makeThumb(uploadedImages[0]);
        const base = { title, category, price, unit, location, contact, thumb, imageCount: uploadedImages.length };
        base.stock = stockVal; // quantity entered = units available; drops by 1 on every sale
        if (editId) base.status = ''; // saving with a quantity re-opens a sold-out listing

        const itemRef = editId ? db.collection('marketplace').doc(editId) : db.collection('marketplace').doc();
        const photosRef = db.collection('marketplace_photos').doc(itemRef.id);

        try {
            const batch = db.batch();
            if (editId) {
                batch.update(itemRef, { ...base, images: FV.delete() });
            } else {
                batch.set(itemRef, {
                    ...base,
                    sellerPhone: currentUserPhone,
                    createdAt: FV.serverTimestamp(),
                    createdAtMs: Date.now()
                });
            }
            batch.set(photosRef, { images: uploadedImages, sellerPhone: currentUserPhone });
            await batch.commit();
        } catch (err) {
            if (err && err.code === 'permission-denied') {
                console.warn('marketplace_photos blocked by rules — saving in legacy layout');
                if (editId) {
                    await itemRef.update({ ...base, images: uploadedImages });
                } else {
                    await itemRef.set({
                        ...base,
                        images: uploadedImages,
                        sellerPhone: currentUserPhone,
                        createdAt: FV.serverTimestamp(),
                        createdAtMs: Date.now()
                    });
                }
            } else {
                throw err;
            }
        }

        alert(editId ? '✅ Item updated successfully.' : '✅ Item published successfully.');
        closePostModal();
        loadMarketItems();
    } catch (err) {
        console.error('Save failed:', err);
        alert('❌ Failed to save item. Check Firestore rules.');
    } finally {
        if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = originalLabel; }
    }
}

async function ensureFullImages(item) {
    if (item.images && item.images.length) return item.images;

    try {
        const photoDoc = await _fs().collection('marketplace_photos').doc(item.id).get();
        if (photoDoc.exists && photoDoc.data().images) {
            item.images = photoDoc.data().images;
            return item.images;
        }
    } catch (e) {
        console.warn('Photos fetch failed, trying main doc:', e.message);
    }

    try {
        const mainDoc = await _fs().collection('marketplace').doc(item.id).get();
        if (mainDoc.exists && mainDoc.data().images) {
            item.images = mainDoc.data().images;
            return item.images;
        }
    } catch (e) {
        console.warn('Main doc fetch failed:', e.message);
    }

    const t = getThumb(item);
    return t ? [t] : [];
}

async function editMarketItemFromDetails() {
    const item = allMarketItems.find(i => i.id === currentViewItemId);
    if (!item) return;

    const images = await ensureFullImages(item);

    document.getElementById('detailsModal').style.display = 'none';

    document.getElementById('mktEditId').value = item.id;
    document.getElementById('mktTitle').value = item.title;
    document.getElementById('mktCategory').value = item.category;
    document.getElementById('mktPrice').value = item.price;
    document.getElementById('mktUnit').value = item.unit;
    document.getElementById('mktLocation').value = item.location;
    document.getElementById('mktContact').value = item.contact;
    document.getElementById('mktQuantity').value = (item.stock != null) ? item.stock : '';

    uploadedImages = [...images];
    renderImagePreviews();

    document.getElementById('postModalTitle').textContent = 'Edit Item';
    document.getElementById('saveItemBtn').textContent = 'Update Listing';
    document.getElementById('postModal').style.display = 'flex';
}

function toCacheItem(d) {
    return {
        id: d.id,
        title: d.title,
        category: d.category,
        price: d.price,
        unit: d.unit,
        location: d.location,
        contact: d.contact,
        sellerPhone: d.sellerPhone,
        status: d.status || '',
        stock: (d.stock != null) ? d.stock : null,
        soldCount: d.soldCount || 0,
        thumb: getThumb(d),
        imageCount: getImageCount(d)
    };
}

function saveCache(items) {
    try {
        sessionStorage.setItem(CACHE_KEY, JSON.stringify(items.slice(0, PAGE_SIZE).map(toCacheItem)));
    } catch (_) { }
}

function readCache() {
    try {
        const raw = sessionStorage.getItem(CACHE_KEY);
        return raw ? JSON.parse(raw) : null;
    } catch (_) {
        return null;
    }
}

function skeletonHTML() {
    return Array(6).fill(0).map(() => `
        <div class="skeleton-card">
            <div class="skeleton-img"></div>
            <div class="skeleton-body">
                <div class="skeleton-text price"></div>
                <div class="skeleton-text title"></div>
                <div class="skeleton-text location"></div>
            </div>
        </div>
    `).join('');
}

async function loadMarketItems() {
    const grid = document.getElementById('marketGrid');
    if (!grid) return;

    const cached = readCache();
    let paintedFromCache = false;
    if (cached && cached.length) {
        allMarketItems = cached;
        hasMore = false;
        applyFilters();
        paintedFromCache = true;
    } else {
        grid.innerHTML = skeletonHTML();
    }

    try {
        const snap = await _fs().collection('marketplace')
            .orderBy('createdAtMs', 'desc')
            .limit(PAGE_SIZE)
            .get();

        if (snap.empty) {
            allMarketItems = [];
            hasMore = false;
            lastDoc = null;
            try { sessionStorage.removeItem(CACHE_KEY); } catch (_) {}
            grid.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding:3rem; color:#64748b;"><i class="fas fa-store-slash" style="font-size:2rem; margin-bottom:1rem; color:#cbd5e1;"></i><div>No items listed yet. Be the first to sell!</div></div>';
            return;
        }

        allMarketItems = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        lastDoc = snap.docs[snap.docs.length - 1];
        hasMore = snap.size === PAGE_SIZE;

        saveCache(allMarketItems);
        applyFilters();
    } catch (err) {
        console.error('Load failed:', err);
        if (!paintedFromCache) {
            grid.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding:2rem; color:#dc2626;">Failed to load marketplace.</div>';
        }
    }
}

async function loadMoreItems() {
    if (isLoadingMore || !hasMore || !lastDoc) return;
    isLoadingMore = true;

    const btn = document.getElementById('mktLoadMoreBtn');
    if (btn) { btn.disabled = true; btn.textContent = 'Loading...'; }

    try {
        const snap = await _fs().collection('marketplace')
            .orderBy('createdAtMs', 'desc')
            .startAfter(lastDoc)
            .limit(PAGE_SIZE)
            .get();

        snap.forEach(doc => {
            if (!allMarketItems.some(i => i.id === doc.id)) {
                allMarketItems.push({ id: doc.id, ...doc.data() });
            }
        });

        if (!snap.empty) lastDoc = snap.docs[snap.docs.length - 1];
        hasMore = snap.size === PAGE_SIZE;
    } catch (err) {
        console.error('Load more failed:', err);
        hasMore = false;
    } finally {
        isLoadingMore = false;
        applyFilters();
    }
}

function setCategoryFilter(category, btnEl) {
    currentCategory = category;
    document.querySelectorAll('.mkt-chip').forEach(c => c.classList.remove('active'));
    if (btnEl) btnEl.classList.add('active');
    applyFilters();
}

let _filterTimer;
function filterMarketItems() {
    clearTimeout(_filterTimer);
    _filterTimer = setTimeout(applyFilters, 150);
}

function applyFilters() {
    const input = document.getElementById('mktSearchInput');
    const query = (input ? input.value : '').toLowerCase();

    const filtered = allMarketItems.filter(item => {
        const matchesSearch = !query ||
            String(item.title || '').toLowerCase().includes(query) ||
            String(item.location || '').toLowerCase().includes(query);
        const matchesCategory = currentCategory === 'All' || item.category === currentCategory;
        return matchesSearch && matchesCategory;
    });

    renderMarketItems(filtered);

    if ((query || currentCategory !== 'All') && hasMore && !isLoadingMore) {
        loadMoreItems();
    }
}

function renderMarketItems(items) {
    const grid = document.getElementById('marketGrid');

    if (!items.length) {
        grid.innerHTML = hasMore
            ? '<div style="grid-column: 1/-1; text-align:center; padding:2rem; color:#64748b;">Searching more items...</div>'
            : '<div style="grid-column: 1/-1; text-align:center; padding:2rem; color:#64748b;">No items found matching your criteria.</div>';
        return;
    }

    const html = items.map((d, i) => {
        let imgHtml = `<i class="fas fa-box placeholder-icon"></i>`;
        const thumb = getThumb(d);
        if (thumb) {
            const loading = i < 4 ? 'eager' : 'lazy';
            imgHtml = `<img src="${thumb}" alt="${escapeHtml(d.title)}" loading="${loading}" decoding="async">`;
            const count = getImageCount(d);
            if (count > 1) {
                imgHtml += `<span style="position:absolute; bottom:10px; right:10px; background:rgba(15,23,42,0.85); color:#fff; font-size:0.75rem; font-weight:800; padding:4px 10px; border-radius:99px; backdrop-filter:blur(4px); display:flex; align-items:center; gap:4px;"><i class="fas fa-images"></i> +${count - 1}</span>`;
            }
        }

        return `
        <div class="mkt-card" onclick="openDetailsModal('${escapeHtml(d.id)}')" style="cursor:pointer;">
            <div class="mkt-img-wrap">
                ${imgHtml}
                <span class="mkt-category-badge">${escapeHtml(d.category)}</span>
                ${d.status === 'sold' ? '<span style="position:absolute;top:10px;left:10px;background:#DC2626;color:#fff;font-size:0.7rem;font-weight:900;padding:4px 10px;border-radius:99px;">SOLD OUT</span>' : ''}
            </div>
            <div class="mkt-card-body">
                <div class="mkt-price">৳ ${Number(d.price).toLocaleString('en-IN')} <span style="font-size:0.75rem; font-weight:600; color:#64748b;">/ ${escapeHtml(d.unit)}</span></div>
                <div class="mkt-item-name">${escapeHtml(d.title)}</div>
                <div class="mkt-loc"><i class="fas fa-map-marker-alt"></i> ${escapeHtml(d.location)}</div>
                ${d.status === 'sold'
                    ? `<div style="font-size:0.7rem; font-weight:800; color:#DC2626; margin-top:3px;"><i class="fas fa-ban"></i> Sold out</div>`
                    : (d.soldCount > 0 ? `<div style="font-size:0.7rem; font-weight:800; color:#059669; margin-top:3px;"><i class="fas fa-check-circle"></i> Sold ${Number(d.soldCount)}${d.stock != null ? ' · ' + Number(d.stock) + ' left' : ''}</div>` : (d.stock != null ? `<div style="font-size:0.7rem; font-weight:700; color:#64748B; margin-top:3px;">${Number(d.stock)} available</div>` : ''))}
            </div>
        </div>
        `;
    }).join('');

    const moreHtml = hasMore ? `
        <div id="mktLoadMoreWrap" style="grid-column: 1/-1; text-align:center; padding:1rem;">
            <button id="mktLoadMoreBtn" type="button" onclick="loadMoreItems()"
                style="padding:0.625rem 1.5rem; border-radius:99px; border:1px solid #CBD5E1; background:#fff; color:#0F172A; font-weight:700; cursor:pointer;">
                Load more
            </button>
        </div>` : '';

    grid.innerHTML = html + moreHtml;
    observeLoadMore();
}

function observeLoadMore() {
    if (_loadMoreObserver) { _loadMoreObserver.disconnect(); _loadMoreObserver = null; }
    const wrap = document.getElementById('mktLoadMoreWrap');
    if (!wrap || !('IntersectionObserver' in window)) return;

    _loadMoreObserver = new IntersectionObserver(entries => {
        if (entries.some(e => e.isIntersecting)) loadMoreItems();
    }, { rootMargin: '400px' });
    _loadMoreObserver.observe(wrap);
}

async function openDetailsModal(id) {
    const item = allMarketItems.find(i => i.id === id);
    if (!item) return;

    currentViewItemId = id;
    const isOwner = item.sellerPhone === currentUserPhone;

    document.getElementById('detailsTitle').textContent = item.title;
    document.getElementById('detailsCategory').textContent = item.category;
    document.getElementById('detailsPrice').textContent = `৳ ${Number(item.price).toLocaleString('en-IN')}`;
    document.getElementById('detailsUnit').textContent = `/ ${item.unit}`;
    document.getElementById('detailsLocation').innerHTML = `<i class="fas fa-map-marker-alt text-emerald"></i> ${escapeHtml(item.location)}`;

    if (isOwner) {
        document.getElementById('detailsSeller').textContent = `You (${item.contact})`;
    } else {
        document.getElementById('detailsSeller').textContent = item.contact;
    }

    let cleanPhone = String(item.contact).replace(/[\s\-+]/g, '');
    if (cleanPhone.startsWith('880')) cleanPhone = '+' + cleanPhone;
    else if (cleanPhone.startsWith('0')) cleanPhone = '+880' + cleanPhone.slice(1);
    else cleanPhone = '+880' + cleanPhone;

    document.getElementById('detailsCallBtn').href = 'tel:' + cleanPhone;
    const msg = encodeURIComponent(`Hello, I am interested in your "${item.title}" listed on DailyVet Marketplace.`);
    document.getElementById('detailsWaBtn').href = 'https://wa.me/' + cleanPhone.replace('+', '') + '?text=' + msg;

    const callBtn = document.getElementById('detailsCallBtn');
    const waBtn = document.getElementById('detailsWaBtn');
    const ownerActions = document.getElementById('detailsOwnerActions');

    if (isOwner) {
        callBtn.style.display = 'none';
        waBtn.style.display = 'none';
        ownerActions.style.display = 'flex';
    } else {
        callBtn.style.display = 'block';
        waBtn.style.display = 'block';
        ownerActions.style.display = 'none';
    }

    const imgContainer = document.getElementById('detailsImages');
    const thumb = getThumb(item);
    imgContainer.innerHTML = thumb
        ? `<img src="${thumb}" style="width:100%; height:150px; object-fit:cover; opacity:0.6;">`
        : `<div style="grid-column: 1/-1; height:100px; background:#f1f5f9; display:flex; align-items:center; justify-content:center; color:#94a3b8;"><i class="fas fa-image fa-2x"></i></div>`;

    imgContainer.onclick = (e) => {
        if (e.target && e.target.tagName === 'IMG' && e.target.dataset.full === '1') openLightbox(e.target.src);
    };

    setBuyButtonState(item);
    renderSalesInfo(item);
    document.getElementById('detailsModal').style.display = 'flex';

    const images = await ensureFullImages(item);
    if (currentViewItemId !== id) return;

    if (images.length) {
        imgContainer.innerHTML = images.map(img =>
            `<img src="${img}" data-full="1" decoding="async" style="width:100%; height:150px; object-fit:cover; cursor:pointer; transition:opacity 0.2s;" onmouseover="this.style.opacity=0.8" onmouseout="this.style.opacity=1">`
        ).join('');
    }
}

function openLightbox(imageUrl) {
    const lightboxImg = document.getElementById('lightboxImage');
    const lightboxModal = document.getElementById('lightboxModal');

    if (lightboxImg && lightboxModal) {
        lightboxImg.src = imageUrl;
        lightboxModal.style.display = 'flex';
    }
}

async function deleteMarketItemFromDetails() {
    const item = allMarketItems.find(i => i.id === currentViewItemId);
    if (!item) return;

    if (!confirm(`Are you sure you want to delete "${item.title}"?\n\nThis cannot be undone.`)) return;

    try {
        await _fs().collection('marketplace').doc(currentViewItemId).delete();
        _fs().collection('marketplace_photos').doc(currentViewItemId).delete().catch(() => {});

        document.getElementById('detailsModal').style.display = 'none';
        allMarketItems = allMarketItems.filter(i => i.id !== currentViewItemId);
        saveCache(allMarketItems);
        applyFilters();

        alert('✅ Item deleted successfully.');
    } catch (err) {
        console.error('Delete failed:', err);
        alert('❌ Failed to delete item. Check Firestore rules.');
    }
}

/* =============================================
   BUY WITH POINTS (PERSONAL BANK)
   ============================================= */
window.buyWithPoints = async function() {
    if (!currentUserPhone || !currentViewItemId) return;

    const local = allMarketItems.find(i => i.id === currentViewItemId);
    if (!local) return;
    if (local.sellerPhone === currentUserPhone) { alert('❌ You cannot buy your own item.'); return; }
    if (local.status === 'sold') { alert('❌ This item has already been sold.'); return; }

    const db = _fs();
    const itemRef = db.collection('marketplace').doc(currentViewItemId);
    const buyerRef = db.collection('users').doc(currentUserPhone);
    const confirmedPrice = Math.round(Number(local.price) || 0);
    if (confirmedPrice <= 0) { alert('❌ Invalid price.'); return; }

    let bankBalance = 0;
    try {
        const snap = await buyerRef.get();
        bankBalance = Math.floor((snap.data() || {}).personalBank || 0);
    } catch (e) {
        alert('❌ Could not read your Personal Bank. Please try again.');
        return;
    }

    if (bankBalance < confirmedPrice) {
        alert(`❌ Insufficient balance in your Personal Bank!\n\nYour balance: ৳${bankBalance.toLocaleString('en-IN')}\nRequired: ৳${confirmedPrice.toLocaleString('en-IN')}\n\nComplete daily farm tasks and convert your points to money on the AI Agent dashboard.`);
        return;
    }

    if (!confirm(`Do you want to buy "${local.title}" for ৳${confirmedPrice.toLocaleString('en-IN')}?\nBalance after: ৳${(bankBalance - confirmedPrice).toLocaleString('en-IN')}`)) return;

    const btn = document.getElementById('detailsBuyBtn');
    if (btn) btn.disabled = true;
    const orderRef = db.collection('orders').doc();

    try {
        await db.runTransaction(async tx => {
            // ---- all reads first ----
            const itemSnap = await tx.get(itemRef);
            if (!itemSnap.exists) throw new Error('GONE');
            const it = itemSnap.data();
            if (it.status === 'sold' || (it.stock != null && it.stock <= 0)) throw new Error('SOLD');

            const sellerPhone = it.sellerPhone;
            if (!sellerPhone) throw new Error('NO_SELLER');
            if (sellerPhone === currentUserPhone) throw new Error('OWN');

            const price = Math.round(Number(it.price) || 0);
            if (price !== confirmedPrice) throw new Error('PRICE_CHANGED');

            const buyerSnap = await tx.get(buyerRef);
            const bal = (buyerSnap.data() || {}).personalBank || 0;
            if (bal < price) throw new Error('INSUFFICIENT');
            const buyerName = (buyerSnap.data() || {}).name || 'Farmer';

            // ---- then writes ----
            const sellerRef = db.collection('users').doc(sellerPhone);
            const FV = firebase.firestore.FieldValue;
            tx.set(buyerRef, { personalBank: FV.increment(-price) }, { merge: true });
            tx.set(sellerRef, { personalBank: FV.increment(price), totalSold: FV.increment(1) }, { merge: true });
            const upd = { soldCount: FV.increment(1), lastSoldAtMs: Date.now() };
            if (it.stock != null) {
                const left = Math.max(0, it.stock - 1);
                upd.stock = left;
                if (left <= 0) upd.status = 'sold';
            }
            tx.update(itemRef, upd);
            tx.set(orderRef, {
                itemId: currentViewItemId,
                title: it.title || '',
                category: it.category || '',
                price: price,
                unit: it.unit || '',
                buyerPhone: currentUserPhone,
                buyerName: buyerName,
                sellerPhone: sellerPhone,
                createdAtMs: Date.now(),
                createdAt: FV.serverTimestamp()
            });
        });

        local.soldCount = (local.soldCount || 0) + 1;
        if (local.stock != null) {
            local.stock = Math.max(0, local.stock - 1);
            if (local.stock <= 0) local.status = 'sold';
        }
        renderSalesInfo(local);
        saveCache(allMarketItems);
        applyFilters();
        setBuyButtonState(local);
        refreshBankBalance();
        alert('✅ Purchase successful! The amount was deducted from your Personal Bank and sent to the seller.\nContact the seller to arrange delivery.');
    } catch (err) {
        const msgs = {
            GONE: '❌ This item no longer exists.',
            SOLD: '❌ Sorry, this item was just sold to someone else.',
            OWN: '❌ You cannot buy your own item.',
            NO_SELLER: '❌ Seller information is missing for this item.',
            PRICE_CHANGED: '❌ The price changed. Please reopen the item and try again.',
            INSUFFICIENT: '❌ Insufficient balance in your Personal Bank.'
        };
        console.error('Purchase failed:', err);
        alert(msgs[err.message] || ('❌ Purchase failed. Please try again.\n\nReason: ' + (err.code || err.message || 'unknown')));
        if (err.message === 'SOLD') { local.status = 'sold'; applyFilters(); setBuyButtonState(local); }
    } finally {
        if (btn && local.status !== 'sold') btn.disabled = false;
    }
};

async function renderSalesInfo(item) {
    const id = item.id;
    const setTxt = (el, t) => { const e = document.getElementById(el); if (e) e.textContent = t; };
    const soldOut = item.status === 'sold' || (item.stock != null && item.stock <= 0);
    const soldEl = document.getElementById('detailsSoldCount');
    const showSold = n => {
        if (!soldEl) return;
        soldEl.textContent = soldOut ? 'Sold out' : Number(n);
        soldEl.style.color = soldOut ? '#DC2626' : '#065F46';
    };
    showSold(item.soldCount || 0);
    setTxt('detailsStock', item.stock != null ? item.stock : '∞');
    setTxt('detailsSellerTotal', '…');
    const box = document.getElementById('detailsBuyers');
    if (box) box.textContent = 'Loading...';

    // seller total sales (auto counted on every purchase)
    try {
        const sSnap = await _fs().collection('users').doc(item.sellerPhone).get();
        if (currentViewItemId === id) setTxt('detailsSellerTotal', Number((sSnap.data() || {}).totalSold || 0));
    } catch (_) { if (currentViewItemId === id) setTxt('detailsSellerTotal', '0'); }

    // who bought this item
    try {
        const snap = await _fs().collection('orders').where('itemId', '==', id).limit(100).get();
        if (currentViewItemId !== id || !box) return;
        if (snap.empty) { box.textContent = 'No purchases yet'; return; }

        const byBuyer = {};
        snap.forEach(doc => {
            const o = doc.data();
            const k = o.buyerPhone || doc.id;
            if (!byBuyer[k]) byBuyer[k] = { name: o.buyerName || 'Farmer', count: 0, last: 0 };
            byBuyer[k].count++;
            byBuyer[k].last = Math.max(byBuyer[k].last, o.createdAtMs || 0);
        });
        const rows = Object.values(byBuyer).sort((a, b) => b.last - a.last);
        box.innerHTML = rows.map(r =>
            `<div style="display:flex; justify-content:space-between; padding:3px 0;"><span><i class="fas fa-user" style="color:#059669; margin-right:6px;"></i>${escapeHtml(r.name)}</span>` +
            (r.count > 1 ? `<span style="color:#64748B;">×${r.count}</span>` : '') + `</div>`
        ).join('');
        showSold(Math.max(Number(item.soldCount || 0), snap.size));
    } catch (e) {
        console.warn('Buyers load failed:', e.message);
        if (box) box.textContent = 'Could not load buyers';
    }
}

function setBuyButtonState(item) {
    const btn = document.getElementById('detailsBuyBtn');
    const manualBtn = document.getElementById('detailsManualPayBtn'); // NEW
    if (!btn) return;
    const isOwner = item.sellerPhone === currentUserPhone;
    
    if (isOwner) {
        btn.style.display = 'none';
        if (manualBtn) manualBtn.style.display = 'none';
    } else if (item.status === 'sold') {
        btn.style.display = 'flex';
        btn.disabled = true;
        btn.style.background = '#94A3B8';
        btn.style.cursor = 'not-allowed';
        btn.innerHTML = '<i class="fas fa-ban"></i> Sold out';
        if (manualBtn) manualBtn.style.display = 'none'; // NEW
    } else {
        btn.style.display = 'flex';
        btn.disabled = false;
        btn.style.background = '#F59E0B';
        btn.style.cursor = 'pointer';
        btn.innerHTML = '<i class="fas fa-wallet"></i> Buy with Personal Bank';
        if (manualBtn) manualBtn.style.display = 'flex'; // NEW
    }
}

async function refreshBankBalance() {
    const el = document.getElementById('mktBankBalance');
    if (!el || !currentUserPhone) return;
    try {
        const snap = await _fs().collection('users').doc(currentUserPhone).get();
        const bal = Math.floor((snap.data() || {}).personalBank || 0);
        el.textContent = '৳' + bal.toLocaleString('en-IN');
    } catch (_) {}
}

/* ============================================================
   MANUAL PAYMENT (bKash / Nagad / Rocket / Cash) - NEW
   ============================================================ */

// Dropdown toggle
window.toggleManualPayDropdown = function(e) {
    if (e) e.stopPropagation();
    const menu = document.getElementById('mktPayoutDropdownMenu');
    if (menu) menu.classList.toggle('open');
};

// Close dropdown on outside click
document.addEventListener('click', (e) => {
    const dd = document.getElementById('mktPayoutDropdown');
    if (dd && !dd.contains(e.target)) {
        const menu = document.getElementById('mktPayoutDropdownMenu');
        if (menu) menu.classList.remove('open');
    }
});

// Select payment method
window.selectManualPay = function(value, label, imgSrc) {
    const hidden = document.getElementById('mktManualPayMethod');
    const display = document.getElementById('mktPayoutSelectedText');
    const menu = document.getElementById('mktPayoutDropdownMenu');
    const phoneBox = document.getElementById('mktManualPayPhoneBox');
    const ssBox = document.getElementById('mktManualPayScreenshotBox');

    if (hidden) hidden.value = value;
    if (display) {
        if (imgSrc) {
            display.innerHTML = `<img src="${imgSrc}" style="width:20px;height:20px;border-radius:4px;object-fit:cover;vertical-align:middle;margin-right:6px;"><span>${label}</span>`;
        } else {
            display.innerHTML = `<span>💵 ${label}</span>`;
        }
        display.style.color = '#0F172A';
    }
    if (menu) menu.classList.remove('open');

    // Show/hide fields
    if (value === 'cash') {
        if (phoneBox) phoneBox.style.display = 'none';
        if (ssBox) ssBox.style.display = 'none';
    } else {
        if (phoneBox) phoneBox.style.display = 'block';
        if (ssBox) ssBox.style.display = 'block';

        const lbl = document.getElementById('mktPhoneLabel');
        if (lbl) {
            lbl.textContent = value === 'bank' ? 'Account Number' : 'Your Mobile Number';
        }
    }
};

// Screenshot filename updater
window.updateScreenshotName = function(input, targetId) {
    const display = document.getElementById(targetId);
    if (input.files && input.files[0]) {
        display.textContent = input.files[0].name;
        display.style.color = '#059669';
        display.style.fontWeight = '700';
    }
};

// Open manual pay modal
window.openManualPayModal = function() {
    const item = allMarketItems.find(i => i.id === currentViewItemId);
    if (!item) return;
    if (item.sellerPhone === currentUserPhone) { alert('❌ You cannot buy your own item.'); return; }
    if (item.status === 'sold') { alert('❌ This item has already been sold.'); return; }

    document.getElementById('manualPayItemTitle').textContent = `Paying for: ${item.title} (৳${Number(item.price).toLocaleString('en-IN')})`;
    document.getElementById('manualPayModal').style.display = 'flex';
    
    // Reset form
    document.getElementById('mktManualPayMethod').value = '';
    document.getElementById('mktPayoutSelectedText').innerHTML = 'Select Method...';
    document.getElementById('mktPayoutSelectedText').style.color = '#64748B';
    document.getElementById('mktManualPayPhone').value = '';
    document.getElementById('mktManualPayScreenshot').value = '';
    document.getElementById('mktScreenshotName').textContent = 'Tap to upload screenshot';
    document.getElementById('mktScreenshotName').style.color = '#64748B';
    document.getElementById('manualPayStatus').style.display = 'none';
    document.getElementById('mktManualPayPhoneBox').style.display = 'none';
    document.getElementById('mktManualPayScreenshotBox').style.display = 'none';
    document.getElementById('manualPayBtn').disabled = false;
    document.getElementById('manualPayBtn').textContent = 'Submit Payment Request';
};

// Submit payment
window.submitManualPayment = async function() {
    if (!currentUserPhone || !currentViewItemId) return;

    const item = allMarketItems.find(i => i.id === currentViewItemId);
    if (!item) return;

    const method = document.getElementById('mktManualPayMethod').value;
    const phone = document.getElementById('mktManualPayPhone').value.trim();
    const screenshotInput = document.getElementById('mktManualPayScreenshot');
    const file = screenshotInput.files && screenshotInput.files[0];
    const statusEl = document.getElementById('manualPayStatus');
    const btn = document.getElementById('manualPayBtn');

    // Validation
    if (!method) { alert('Please select a payment method.'); return; }
    if (method !== 'cash') {
        if (!/^01\d{9}$/.test(phone)) {
            alert('Enter a valid 11-digit mobile number.');
            return;
        }
        if (!file) {
            alert('Please upload a payment screenshot.');
            return;
        }
    }

    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
    statusEl.className = 'pay-status-box loading';
    statusEl.textContent = 'Uploading payment proof...';
    statusEl.style.display = 'block';

    try {
        let screenshotBase64 = null;
        if (file) {
            screenshotBase64 = await new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = e => resolve(e.target.result);
                reader.onerror = reject;
                reader.readAsDataURL(file);
            });
        }

        const db = _fs();
        const FV = firebase.firestore.FieldValue;
        const orderRef = db.collection('orders').doc();

        const price = Math.round(Number(item.price) || 0);

        // Create order (awaiting admin verification)
        await orderRef.set({
            itemId: currentViewItemId,
            title: item.title || '',
            category: item.category || '',
            price: price,
            unit: item.unit || '',
            buyerPhone: currentUserPhone,
            sellerPhone: item.sellerPhone,
            paymentMethod: method,
            paymentPhone: phone,
            paymentScreenshot: screenshotBase64,
            status: 'pending_verification',
            createdAtMs: Date.now(),
            createdAt: FV.serverTimestamp()
        });

        statusEl.className = 'pay-status-box success';
        statusEl.textContent = '✅ Payment proof submitted! Admin will verify your payment within 24 hours and notify you.';
        btn.innerHTML = '<i class="fas fa-check-circle"></i> Submitted!';

        setTimeout(() => {
            document.getElementById('manualPayModal').style.display = 'none';
            document.getElementById('detailsModal').style.display = 'none';
            loadMarketItems(); // refresh
        }, 2500);

    } catch (err) {
        console.error('Manual payment failed:', err);
        statusEl.className = 'pay-status-box error';
        statusEl.textContent = '❌ ' + (err.message || 'Submission failed. Please try again.');
        btn.disabled = false;
        btn.textContent = 'Submit Payment Request';
    }
};

window.openPostModal = openPostModal;
window.closePostModal = closePostModal;
window.saveMarketItem = saveMarketItem;
window.filterMarketItems = filterMarketItems;
window.setCategoryFilter = setCategoryFilter;
window.openDetailsModal = openDetailsModal;
window.handleMarketImages = handleMarketImages;
window.removeMarketImage = removeMarketImage;
window.editMarketItemFromDetails = editMarketItemFromDetails;
window.deleteMarketItemFromDetails = deleteMarketItemFromDetails;
window.openLightbox = openLightbox;
window.loadMoreItems = loadMoreItems;