/**
 * DailyVet — AI Proxy Client Helper
 * ---------------------------------
 * On Netlify / Vercel → all AI calls go through serverless proxy
 *   (keys never leave the server, Network tab only shows /api or /.netlify/functions)
 * On VS Code Live Server / localhost → direct calls with client keys
 *   (so local testing still works without a backend)
 *
 * Usage:
 *   const res = await DV_AI_PROXY.call({
 *     provider: 'gemini',   // 'gemini' | 'groq' | 'openrouter'
 *     model: 'gemini-2.5-flash',
 *     body: { ... },        // exact payload the upstream expects
 *     keyIndex: 0,          // optional preferred key index
 *     timeoutMs: 8000
 *   });
 *   // res is the parsed JSON from upstream (or throws)
 */
(function (global) {
  'use strict';

  const HOST = (typeof location !== 'undefined' && location.hostname) || '';
  const IS_LOCAL =
    HOST === 'localhost' ||
    HOST === '127.0.0.1' ||
    HOST.startsWith('192.168.') ||
    HOST.endsWith('.local') ||
    HOST === '';

  /* Detect platform */
  const IS_NETLIFY =
    HOST.includes('netlify.app') ||
    HOST.includes('netlify.com') ||
    (typeof window !== 'undefined' && window.NETLIFY);
  const IS_VERCEL =
    HOST.includes('vercel.app') ||
    HOST.includes('vercel.com') ||
    (typeof window !== 'undefined' && window.VERCEL);

  function proxyUrl() {
    if (IS_NETLIFY) return '/.netlify/functions/ai-proxy';
    if (IS_VERCEL) return '/api/ai-proxy';
    /* Prefer Netlify-style path first (many deploys use Netlify) */
    if (!IS_LOCAL) return '/.netlify/functions/ai-proxy';
    return null; // local → direct
  }

  /**
   * Call AI via proxy (or direct on local).
   * @param {object} opts
   * @param {string} opts.provider
   * @param {string} opts.model
   * @param {object} opts.body
   * @param {number} [opts.keyIndex]
   * @param {number} [opts.timeoutMs=12000]
   * @param {string} [opts.directUrl]  — required only for local direct mode
   * @param {object} [opts.directHeaders]
   * @returns {Promise<object>}
   */
  async function call(opts) {
    const {
      provider,
      model,
      body,
      keyIndex,
      timeoutMs = 12000,
      directUrl,
      directHeaders
    } = opts || {};

    if (!provider || !model || !body) {
      throw new Error('provider, model, body required');
    }

    const url = proxyUrl();
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);

    try {
      let res;
      if (url) {
        /* ── Proxy path (Netlify / Vercel) ── */
        res = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ provider, model, body, keyIndex }),
          signal: controller.signal
        });
      } else {
        /* ── Local direct path (Live Server) ── */
        if (!directUrl) {
          throw new Error('Local mode requires directUrl (keys still in client for Live Server)');
        }
        res = await fetch(directUrl, {
          method: 'POST',
          headers: Object.assign({ 'Content-Type': 'application/json' }, directHeaders || {}),
          body: JSON.stringify(body),
          signal: controller.signal
        });
      }

      const text = await res.text();
      let data;
      try { data = JSON.parse(text); } catch { data = { raw: text }; }

      if (!res.ok) {
        const err = new Error((data && (data.error || data.message)) || ('HTTP ' + res.status));
        err.status = res.status;
        err.data = data;
        throw err;
      }
      return data;
    } finally {
      clearTimeout(timer);
    }
  }

  /** True when we are on a platform that has the serverless proxy */
  function isProxyMode() {
    return !!proxyUrl();
  }

  global.DV_AI_PROXY = {
    call,
    isProxyMode,
    isLocal: IS_LOCAL,
    proxyUrl
  };
})(typeof window !== 'undefined' ? window : globalThis);
