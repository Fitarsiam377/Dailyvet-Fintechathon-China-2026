/* ============================================================
   DailyVet - Insurance Coverage Advisor v1.1 (Segment 4 Fix)
   Reads:  active policy  (users/{phone}/insurance_policies)
           live risk      (fetchLiveRiskData from insurance.js)
           gap analysis   (detectTriggers from insurance.js)
   Output: coverage gap report + next actions
   - SEGMENT 4 FIX: DEFAULT_COVERED_HAZARDS now matches
     insurance.js (flood + heat + air). Previously only flood
     was listed, so heat and air were always shown as "not covered"
     even though the premium calculation includes them.
   ============================================================ */
(function () {
'use strict';

const _fs = () => firebase.firestore();

const HAZARD_LABELS = {
  flood:   { name: 'Flood',       icon: 'W', color: '#2563EB' },
  heat:    { name: 'Heat stress', icon: 'T', color: '#DC2626' },
  drought: { name: 'Drought',     icon: 'D', color: '#D97706' },
  air:     { name: 'Air quality', icon: 'A', color: '#0891B2' }
};

/* SEGMENT 4 FIX: must match DEFAULT_COVERED_HAZARDS in insurance.js */
const DEFAULT_COVERED_HAZARDS = ['flood', 'heat', 'air'];

const SEVERITY_RANK = { high: 0, medium: 1, low: 2 };

const _cleanPhone = p => String(p || '').replace(/[^0-9+]/g, '');
const _myPhone = () => _cleanPhone(
  (typeof sessionStorage !== 'undefined' && sessionStorage.getItem('userPhone')) ||
  (typeof localStorage !== 'undefined' && localStorage.getItem('userPhone'))
);

const esc = t => String(t == null ? '' : t)
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;').replace(/'/g, '&#39;');

async function _loadPolicy(phone) {
  try {
    const snap = await _fs()
      .collection('users').doc(phone)
      .collection('insurance_policies')
      .where('status', '==', 'active')
      .limit(1)
      .get();

    if (snap.empty) return null;
    const doc = snap.docs[0];
    return { id: doc.id, ...doc.data() };
  } catch (err) {
    console.warn('[InsuranceAdvisor] policy load failed:', err.message);
    return null;
  }
}

function _analyseRisk(risk, triggers) {
  const hazards = [];

  const floodScore = risk?.flood?.score || 0;
  const heatLevel  = risk?.heat?.level || 'normal';
  const heatThi    = risk?.heat?.thi || 0;
  const aqi        = risk?.air?.aqi;

  hazards.push({
    key: 'flood',
    level: floodScore > 70 ? 'high' : floodScore > 40 ? 'medium' : 'low',
    value: floodScore + '%',
    score: floodScore
  });

  hazards.push({
    key: 'heat',
    level: heatLevel === 'severe' ? 'high' : heatLevel === 'moderate' ? 'medium' : 'low',
    value: heatThi ? 'THI ' + Math.round(heatThi) : 'n/a',
    score: heatLevel === 'severe' ? 80 : heatLevel === 'moderate' ? 50 : 10
  });

  const droughtTriggered = Array.isArray(triggers) && triggers.some(t => t.type === 'drought');
  hazards.push({
    key: 'drought',
    level: droughtTriggered ? 'high' : 'low',
    value: droughtTriggered ? 'Active' : 'None',
    score: droughtTriggered ? 75 : 5
  });

  hazards.push({
    key: 'air',
    level: Number.isFinite(aqi) ? (aqi > 200 ? 'high' : aqi > 100 ? 'medium' : 'low') : 'low',
    value: Number.isFinite(aqi) ? 'AQI ' + Math.round(aqi) : 'n/a',
    score: Number.isFinite(aqi) ? Math.min(100, aqi / 3) : 5
  });

  return hazards;
}

function _findGaps(hazards, coveredHazards) {
  const gaps = [];

  hazards.forEach(h => {
    const covered = coveredHazards.includes(h.key);
    if (!covered && h.level !== 'low') {
      const meta = HAZARD_LABELS[h.key] || { name: h.key, icon: '*' };
      gaps.push({
        hazard: h.key,
        name: meta.name,
        icon: meta.icon,
        level: h.level,
        current: h.value,
        severity: h.level === 'high' ? 'high' : 'medium',
        message:
          h.level === 'high'
            ? `${meta.name} risk is HIGH (${h.value}) but your policy does not cover it.`
            : `${meta.name} risk is moderate (${h.value}) and is not covered.`,
        action:
          h.level === 'high'
            ? `Add ${meta.name.toLowerCase()} coverage before the next season.`
            : `Consider adding ${meta.name.toLowerCase()} coverage at renewal.`
      });
    }
  });

  gaps.sort((a, b) => (SEVERITY_RANK[a.severity] ?? 9) - (SEVERITY_RANK[b.severity] ?? 9));
  return gaps;
}

function _buildNarrative(policy, risk, gaps) {
  if (!policy) {
    return {
      title: 'No active policy',
      summary: 'You have no insurance policy yet. Buy one to protect your income from weather risk.',
      ctaLabel: 'Buy a policy',
      ctaUrl: 'insurance-policy.html'
    };
  }

  const animal = String(policy.animalType || 'livestock').toUpperCase();
  const where = (policy.area ? policy.area + ', ' : '') +
                (policy.districtName || policy.district || '').toUpperCase();

  if (!gaps.length) {
    return {
      title: 'Coverage looks good',
      summary: `Your ${animal} policy in ${where} covers the main hazards right now. No gaps detected.`,
      ctaLabel: 'View policy',
      ctaUrl: 'insurance-dashboard.html'
    };
  }

  const top = gaps[0];
  return {
    title: `${gaps.length} coverage gap${gaps.length > 1 ? 's' : ''} detected`,
    summary: `Your ${animal} policy in ${where} covers flood, heat and air quality, but ${top.name.toLowerCase()} risk is not covered.`,
    ctaLabel: 'Review and upgrade',
    ctaUrl: 'insurance-policy.html'
  };
}

async function compute(phone) {
  const target = _cleanPhone(phone || _myPhone());
  if (!target) return { ok: false, error: 'not_logged_in' };

  try {
    const policy = await _loadPolicy(target);

    let risk = null;
    let triggers = [];
    try {
      if (typeof window.fetchLiveRiskData === 'function') {
        risk = await window.fetchLiveRiskData(
          policy?.district || 'dhaka',
          policy?.lat,
          policy?.lng
        );
      }
    } catch (err) {
      console.warn('[InsuranceAdvisor] risk fetch failed:', err.message);
    }
    try {
      if (typeof window.detectTriggers === 'function') {
        triggers = await window.detectTriggers(
          policy?.district || 'dhaka',
          policy?.animalType || 'cow',
          policy?.lat,
          policy?.lng
        );
      }
    } catch (err) {
      console.warn('[InsuranceAdvisor] trigger fetch failed:', err.message);
    }

    const hazards = _analyseRisk(risk, triggers);
    const coveredHazards = DEFAULT_COVERED_HAZARDS.slice();
    const gaps = _findGaps(hazards, coveredHazards);
    const narrative = _buildNarrative(policy, risk, gaps);

    return {
      ok: true,
      policy,
      risk,
      hazards,
      gaps,
      coveredHazards,
      narrative
    };
  } catch (err) {
    console.warn('[InsuranceAdvisor] compute failed:', err.message);
    return { ok: false, error: err.message };
  }
}

async function render(containerId, phone) {
  const host = document.getElementById(containerId);
  if (!host) return null;

  host.innerHTML = `
    <div style="text-align:center;padding:1.25rem;color:#64748B;font-size:13px;">
      <i class="fas fa-spinner fa-spin"></i>
      Analysing coverage gaps...
    </div>`;

  const r = await compute(phone);

  if (!r.ok) {
    host.innerHTML = `
      <div style="color:#DC2626;font-size:13px;text-align:center;padding:1rem;">
        Analysis failed: ${esc(r.error || 'unknown error')}
      </div>`;
    return r;
  }

  const { gaps, hazards, narrative } = r;

  const gapRows = gaps.length
    ? gaps.map(g => `
      <div style="display:flex;gap:10px;padding:11px 12px;border-radius:10px;margin-bottom:6px;
                  background:${g.severity === 'high' ? '#fef2f2' : '#fffbeb'};
                  border:1px solid ${g.severity === 'high' ? '#fecaca' : '#fde68a'};">
        <span style="font-size:18px;line-height:1;">${g.icon}</span>
        <div style="min-width:0;flex:1;">
          <div style="font-size:13px;font-weight:800;color:${g.severity === 'high' ? '#b91c1c' : '#92400e'};">
            ${esc(g.name)} - ${esc(g.level.toUpperCase())}
          </div>
          <div style="font-size:12px;color:#475569;margin-top:1px;">${esc(g.message)}</div>
          <div style="font-size:11.5px;color:#64748B;margin-top:3px;"><b>Action:</b> ${esc(g.action)}</div>
        </div>
      </div>`).join('')
    : `
      <div style="display:flex;gap:10px;padding:12px;border-radius:10px;background:#ecfdf5;border:1px solid #86efac;">
        <span style="font-size:16px;">OK</span>
        <div style="font-size:13px;font-weight:700;color:#047857;">
          No gaps detected - your coverage matches current risk.
        </div>
      </div>`;

  const hazardTable = hazards.map(h => {
    const meta = HAZARD_LABELS[h.key] || { name: h.key, icon: '*' };
    const covered = r.coveredHazards.includes(h.key);
    const lvlColor = h.level === 'high' ? '#DC2626' : h.level === 'medium' ? '#D97706' : '#059669';
    return `
      <div style="display:flex;justify-content:space-between;align-items:center;
                  padding:8px 10px;border-bottom:1px dashed #e2e8f0;font-size:12.5px;">
        <span style="color:#334155;">${meta.icon} ${esc(meta.name)}</span>
        <span style="display:flex;gap:8px;align-items:center;">
          <b style="color:${lvlColor};">${esc(h.value)}</b>
          <span style="font-size:10px;padding:2px 8px;border-radius:999px;
                       background:${covered ? '#ecfdf5' : '#fef2f2'};
                       color:${covered ? '#047857' : '#b91c1c'};
                       border:1px solid ${covered ? '#86efac' : '#fecaca'};">
            ${covered ? 'Covered' : 'Not covered'}
          </span>
        </span>
      </div>`;
  }).join('');

  host.innerHTML = `
    <div style="background:#fff;border:1.5px solid #e2e8f0;border-radius:16px;padding:1.25rem;">

      <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:1rem;">
        <div style="width:38px;height:38px;border-radius:10px;background:#eff6ff;color:#1e40af;
                    display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0;">
          <i class="fas fa-shield-halved"></i>
        </div>
        <div style="min-width:0;flex:1;">
          <div style="font-size:15px;font-weight:900;color:#0f172a;">${esc(narrative.title)}</div>
          <div style="font-size:12.5px;color:#475569;margin-top:2px;line-height:1.5;">${esc(narrative.summary)}</div>
        </div>
      </div>

      <div style="font-size:12px;font-weight:800;color:#0f172a;text-transform:uppercase;
                  letter-spacing:.04em;margin-bottom:6px;">Coverage gaps</div>
      ${gapRows}

      <div style="font-size:12px;font-weight:800;color:#0f172a;text-transform:uppercase;
                  letter-spacing:.04em;margin:14px 0 6px;">Current hazard exposure</div>
      <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:2px 4px;">
        ${hazardTable}
      </div>

      <a href="${esc(narrative.ctaUrl)}"
         style="display:inline-flex;align-items:center;justify-content:center;gap:6px;
                width:100%;margin-top:14px;padding:0.75rem 1rem;background:#0F2C59;color:#fff;
                border-radius:10px;font-weight:800;font-size:13px;text-decoration:none;">
        <i class="fas fa-arrow-right"></i>
        ${esc(narrative.ctaLabel)}
      </a>
    </div>`;

  return r;
}

window.DVInsuranceAdvisor = {
  compute,
  render,
  HAZARD_LABELS,
  DEFAULT_COVERED_HAZARDS
};

console.log('Insurance Advisor v1.1 loaded (Segment 4 fix applied)');
})();