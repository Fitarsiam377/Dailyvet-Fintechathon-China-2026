/* DailyVet — Flood Early Warning Page v2.7 (Free OpenStreetMap Layer) */
(function () {
'use strict';

const DISTRICT_COORDS = {
    dhaka:      { lat: 23.8103, lng: 90.4125, name: 'Dhaka' },
    kurigram:   { lat: 25.8072, lng: 89.6295, name: 'Kurigram' },
    gaibandha:  { lat: 25.3288, lng: 89.5286, name: 'Gaibandha' },
    lalmonirhat:{ lat: 25.9923, lng: 89.2847, name: 'Lalmonirhat' },
    sirajganj:  { lat: 24.4533, lng: 89.7009, name: 'Sirajganj' },
    jamalpur:   { lat: 24.9375, lng: 89.9372, name: 'Jamalpur' },
    sunamganj:  { lat: 25.0658, lng: 91.3950, name: 'Sunamganj' },
    sylhet:     { lat: 24.8949, lng: 91.8687, name: 'Sylhet' },
    kishoreganj:{ lat: 24.4449, lng: 90.7766, name: 'Kishoreganj' },
    chandpur:   { lat: 23.2333, lng: 90.6711, name: 'Chandpur' },
    shariatpur: { lat: 23.2423, lng: 90.4348, name: 'Shariatpur' },
    munshiganj: { lat: 23.5422, lng: 90.5305, name: 'Munshiganj' },
    bogura:     { lat: 24.8465, lng: 89.3773, name: 'Bogura' },
    pabna:      { lat: 24.0064, lng: 89.2372, name: 'Pabna' },
    faridpur:   { lat: 23.6070, lng: 89.8429, name: 'Faridpur' },
    rangpur:    { lat: 25.7439, lng: 89.2752, name: 'Rangpur' },
    chittagong: { lat: 22.3569, lng: 91.7832, name: 'Chittagong' },
    khulna:     { lat: 22.8456, lng: 89.5403, name: 'Khulna' },
    barisal:    { lat: 22.7010, lng: 90.3535, name: 'Barisal' },
    rajshahi:   { lat: 24.3745, lng: 88.6042, name: 'Rajshahi' },
    mymensingh: { lat: 24.7471, lng: 90.4203, name: 'Mymensingh' }
};

const BASIN_FALLBACK = {
    brahmaputra: { name: 'Brahmaputra (Assam)', points: [{ lat: 26.85, lng: 94.20 }, { lat: 26.63, lng: 92.80 }, { lat: 26.18, lng: 91.75 }], lagDays: 4, note: 'Assam tributaries (Beki, Jiabharali, Dikhow, Kopili) — WRF 48h forecast models used by ASDMA' },
    ganges: { name: 'Ganges (Bihar/Nepal)', points: [{ lat: 25.60, lng: 85.10 }, { lat: 25.56, lng: 83.98 }, { lat: 26.70, lng: 85.30 }], lagDays: 7, note: 'Bihar CWC forecast stations (Buxar, Patna, Munger) + Nepal tributaries (Koshi, Gandak)' },
    meghna: { name: 'Meghna / Barak (Assam-Meghalaya)', points: [{ lat: 24.80, lng: 92.80 }, { lat: 25.20, lng: 91.70 }], lagDays: 2, note: 'Barak River (Silchar) + Meghalaya hills — flash flood prone (Sunamganj haor)' }
};

const _el = id => document.getElementById(id);
const _ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const escapeHtml = t => String(t == null ? '' : t).replace(/[&<>"']/g, c => _ESC[c]);
const fmt = n => Number(n || 0).toLocaleString('en-IN');

let currentDistrict = 'sirajganj';
let loadToken = 0;
let floodMapInstance = null;
let inundToken = 0;

async function getUpstreamBasinRainfall(districtKey) {
    if (!window.NasaPower) return null;
    let basinKey = null;
    if (window.NasaFlood && typeof NasaFlood.getBasinForDistrict === 'function') {
        basinKey = NasaFlood.getBasinForDistrict(districtKey);
    }
    if (!basinKey) return null;

    let basin = null;
    if (window.NasaFlood && NasaFlood.UPSTREAM_BASINS && NasaFlood.UPSTREAM_BASINS[basinKey]) {
        const b = NasaFlood.UPSTREAM_BASINS[basinKey];
        const points = [];
        if (Number.isFinite(b.lat) && Number.isFinite(b.lng)) points.push({ lat: b.lat, lng: b.lng });
        if (Number.isFinite(b.altLat) && Number.isFinite(b.altLng)) points.push({ lat: b.altLat, lng: b.altLng });
        basin = { name: b.name || basinKey, points, lagDays: b.lagDays || null, note: b.note || null };
    } else if (BASIN_FALLBACK[basinKey]) {
        basin = BASIN_FALLBACK[basinKey];
    }

    if (!basin || !basin.points || !basin.points.length) return null;

    const results = await Promise.all(basin.points.map(async pt => {
        try {
            const parameter = await NasaPower.getPowerData(pt.lat, pt.lng, 7);
            if (!parameter) return { ...pt, rainMm: 0, ok: false };
            const series = NasaPower.getSeries(parameter, 'PRECTOTCORR');
            const rainMm = series.reduce((s, d) => s + (d.value > 0 ? d.value : 0), 0);
            return { ...pt, rainMm: Math.round(rainMm * 10) / 10, ok: true };
        } catch (_) {
            return { ...pt, rainMm: 0, ok: false };
        }
    }));

    const okPoints = results.filter(p => p.ok);
    if (!okPoints.length) return null;

    const avgRain = okPoints.reduce((s, p) => s + p.rainMm, 0) / okPoints.length;
    return { basinKey, basinName: basin.name, lagDays: basin.lagDays, note: basin.note, upstreamRainMm: Math.round(avgRain * 10) / 10, pointCount: okPoints.length, points: results, source: 'nasa-power' };
}

function withTimeout(p, ms) {
    return Promise.race([Promise.resolve(p), new Promise(res => setTimeout(() => res(null), ms))]);
}

/* Real river gauge (live source, then 24h cache). Returns null if neither works.
   Split out so it can start in parallel with the other requests. */
async function fetchRealRiver(districtKey) {
    if (window.NasaFloodRiver && typeof NasaFloodRiver.fetchRiverGauge === 'function') {
        try {
            const gauge = await withTimeout(NasaFloodRiver.fetchRiverGauge(districtKey), 8000);
            if (gauge) {
                try { localStorage.setItem('dv_flood_river_cache_' + districtKey, JSON.stringify({ gauge, cachedAt: Date.now() })); } catch (_) {}
                return { gauge, source: 'ffwc-or-manual', estimated: false };
            }
        } catch (err) {}
    }
    try {
        const cached = localStorage.getItem('dv_flood_river_cache_' + districtKey);
        if (cached) {
            const parsed = JSON.parse(cached);
            const age = Date.now() - (parsed.cachedAt || 0);
            if (age < 24 * 60 * 60 * 1000 && parsed.gauge) return { gauge: parsed.gauge, source: 'cache', estimated: false };
        }
    } catch (_) {}
    return null;
}

async function fetchRiverGaugeSafely(districtKey, riskScore, realPromise) {
    const real = await (realPromise || fetchRealRiver(districtKey));
    if (real) return real;
    if (Number.isFinite(riskScore) && window.NasaFloodRiver && typeof NasaFloodRiver.calcRiverScore === 'function') {
        try {
            const DANGER_LEVELS = { brahmaputra: { danger: 19.5, name: 'Jamuna/Brahmaputra' }, ganges: { danger: 17.0, name: 'Padma/Ganges' }, meghna: { danger: 12.0, name: 'Meghna' }, coastal: { danger: 4.5, name: 'Coastal' } };
            const basinKey = window.NasaFlood && typeof NasaFlood.getBasinForDistrict === 'function' ? NasaFlood.getBasinForDistrict(districtKey) : null;
            const cfg = DANGER_LEVELS[basinKey] || DANGER_LEVELS.brahmaputra;
            const estimateRatio = 0.70 + (riskScore / 100) * 0.40;
            const currentLevel = Math.round(cfg.danger * estimateRatio * 100) / 100;
            const gap = Math.round((cfg.danger - currentLevel) * 100) / 100;
            const percentOfDanger = Math.round((currentLevel / cfg.danger) * 100);
            const estimatedGauge = { riverName: cfg.name + ' (estimated)', stationName: districtKey.charAt(0).toUpperCase() + districtKey.slice(1) + ' (estimated)', currentLevel, dangerLevel: cfg.danger, gap, percentOfDanger, trend: riskScore > 60 ? 'rising' : riskScore < 30 ? 'falling' : 'stable', status: gap < 0 ? 'danger' : gap < 1 ? 'warning' : 'normal', lastUpdatedMs: Date.now() };
            return { gauge: estimatedGauge, source: 'estimated', estimated: true };
        } catch (err) {}
    }
    return { gauge: null, source: 'unavailable', estimated: false };
}

async function fetchAllFloodData(districtKey) {
    const coords = DISTRICT_COORDS[districtKey];
    if (!coords) return null;
    /* ⚡ River gauge now starts together with everything else (was: after all of them) */
    const riverPromise = fetchRealRiver(districtKey).catch(() => null);
    const [parameter, rainForecast, sedac, upstream] = await Promise.all([
        withTimeout(NasaPower.getPowerData(coords.lat, coords.lng, 7), 15000).catch(() => null),
        withTimeout(OpenMeteo.getRainfallCumulative(coords.lat, coords.lng, 72), 10000).catch(() => null),
        withTimeout(NasaSedac.fetchSedacData(districtKey), 10000).catch(() => null),
        withTimeout(getUpstreamBasinRainfall(districtKey), 12000).catch(() => null)
    ]);
    let quickRiskScore = 0;
    if (window.NasaFlood && parameter) {
        try {
            const rainSeries = NasaPower.getSeries(parameter, 'PRECTOTCORR');
            const rain7 = rainSeries.reduce((s, d) => s + (d.value > 0 ? d.value : 0), 0);
            const soilRoot = NasaPower.getLatest(parameter, 'GWETROOT');
            const soilTop = NasaPower.getLatest(parameter, 'GWETTOP');
            const quickRisk = NasaFlood.calculateFloodRisk({ rain7dayMm: rain7, soilRoot: soilRoot ? soilRoot.value : 0, soilTop: soilTop ? soilTop.value : 0, rain48hForecast: rainForecast && rainForecast.rain48hMm ? rainForecast.rain48hMm : 0, rain72hForecast: rainForecast && rainForecast.rain72hMm ? rainForecast.rain72hMm : 0, upstreamRainMm: upstream ? upstream.upstreamRainMm : 0, upstreamLagDays: upstream ? upstream.lagDays : null, district: districtKey });
            quickRiskScore = quickRisk.score;
        } catch (_) {}
    }
    const riverResult = await fetchRiverGaugeSafely(districtKey, quickRiskScore, riverPromise);
    return { coords, parameter, rainForecast, sedac, riverGauge: riverResult.gauge, riverSource: riverResult.source, riverEstimated: riverResult.estimated, upstream };
}

function renderFloodDashboard(body, districtKey, data) {
    const { coords, parameter, rainForecast, sedac, riverGauge, riverSource, riverEstimated, upstream } = data;
    const rainSeries = parameter ? NasaPower.getSeries(parameter, 'PRECTOTCORR') : [];
    const soilRootLatest = parameter ? NasaPower.getLatest(parameter, 'GWETROOT') : null;
    const soilTopLatest = parameter ? NasaPower.getLatest(parameter, 'GWETTOP') : null;
    const rain7dayMm = rainSeries.reduce((s, d) => s + (d.value > 0 ? d.value : 0), 0);
    const daysOfRain = rainSeries.filter(d => d.value > 5).length;
    const rain48h = rainForecast && rainForecast.rain48hMm ? rainForecast.rain48hMm : 0;
    const rain72h = rainForecast && rainForecast.rain72hMm ? rainForecast.rain72hMm : 0;
    const peakHourly = rainForecast && rainForecast.peakHourlyMm ? rainForecast.peakHourlyMm : 0;

    const upstreamRainMm = upstream ? upstream.upstreamRainMm : 0;
    const upstreamLagDays = upstream ? upstream.lagDays : null;

    const risk = NasaFlood.calculateFloodRisk({ rain7dayMm, soilRoot: soilRootLatest ? soilRootLatest.value : 0, soilTop: soilTopLatest ? soilTopLatest.value : 0, rain48hForecast: rain48h, rain72hForecast: rain72h, upstreamRainMm, upstreamLagDays, district: districtKey, daysOfRain });

    let riverBonus = 0;
    let riverScoreData = null;
    if (riverGauge && !riverEstimated && window.NasaFloodRiver && typeof NasaFloodRiver.calcRiverScore === 'function') {
        riverScoreData = NasaFloodRiver.calcRiverScore(riverGauge);
        if (riverScoreData && riverScoreData.available) riverBonus = Math.round(riverScoreData.score * 0.5);
    }
    if (riverBonus > 0) {
        const newScore = Math.min(100, risk.score + riverBonus);
        const newLevel = NasaFlood.FLOOD_LEVELS.find(l => newScore >= l.min);
        risk.score = newScore;
        if (newLevel) Object.assign(risk, newLevel);
        risk.breakdown = risk.breakdown || [];
        risk.breakdown.push({ icon: '🌊', label: 'River Water Level (FFWC)', value: `${riverGauge.currentLevel}m / Danger ${riverGauge.dangerLevel}m`, score: riverBonus, max: 15, reason: riverScoreData.reason });
    }

    const livestockCounts = sedac && sedac.livestock ? sedac.livestock : { cattle: 100000, goat: 50000, poultry: 500000, sheep: 10000 };
    const totalAnimals = (livestockCounts.cattle || 0) + (livestockCounts.goat || 0) + (livestockCounts.sheep || 0) + (livestockCounts.poultry || 0);
    const animalsAtRisk = Math.round(totalAnimals * (risk.score / 100));
    const marginalFarmers = sedac && sedac.marginalFarmers ? sedac.marginalFarmers : 0;
    const farmersAtRisk = Math.round(marginalFarmers * (risk.score / 100));

    const speciesList = ['Cow', 'Goat', 'Sheep', 'Chicken', 'Duck'];
    const relocationPlan = NasaFlood.getRelocationPriority(risk.level, speciesList);
    const shelters = NasaFlood.getSafeShelterAdvice(risk.level, districtKey);
    const feedPlan = NasaFlood.getEmergencyFeedPlan(risk.level, ['Cow', 'Goat', 'Chicken']);

    const breakdownHtml = risk.breakdown.map(b => `
        <div style="margin-bottom:14px;">
            <div style="display:flex;justify-content:space-between;font-size:12.5px;font-weight:700;margin-bottom:5px;gap:10px;flex-wrap:wrap;">
                <span>${b.icon} ${escapeHtml(b.label)} <span style="color:#64748b;font-weight:600;">(${escapeHtml(b.value)})</span></span>
                <span style="color:${risk.color};font-weight:800;">+${b.score} / ${b.max}</span>
            </div>
            <div style="height:6px;background:#e2e8f0;border-radius:999px;overflow:hidden;"><div style="width:${Math.min(100, (b.score/b.max)*100)}%;background:${risk.color};height:100%;border-radius:999px;"></div></div>
            <div style="font-size:11px;color:#64748b;margin-top:4px;">${escapeHtml(b.reason)}</div>
        </div>`).join('');

    let upstreamSectionHtml = '';
    if (upstream) {
        const uMm = upstream.upstreamRainMm;
        const uColor = uMm > 300 ? '#dc2626' : uMm > 200 ? '#ea580c' : uMm > 120 ? '#d97706' : uMm > 60 ? '#0891b2' : '#059669';
        const uBg = uMm > 300 ? '#fef2f2' : uMm > 200 ? '#fff7ed' : uMm > 120 ? '#fef9e7' : uMm > 60 ? '#ecfeff' : '#ecfdf5';
        const uLabel = uMm > 300 ? 'Extreme Upstream Rain' : uMm > 200 ? 'Heavy Upstream Rain' : uMm > 120 ? 'Significant Upstream Rain' : uMm > 60 ? 'Moderate Upstream Rain' : 'Low Upstream Rain';
        const uIcon = uMm > 300 ? '🚨' : uMm > 200 ? '⚠️' : uMm > 120 ? '👀' : uMm > 60 ? '💧' : '✅';
        const pointsHtml = (upstream.points && upstream.points.length > 1) ? `<div style="margin-top:8px;padding:8px 10px;background:#fff;border-radius:10px;border:1px dashed #cbd5e1;"><div style="font-size:10.5px;font-weight:800;color:#64748b;text-transform:uppercase;margin-bottom:4px;">Monitoring ${upstream.pointCount} upstream points</div><div style="display:flex;flex-wrap:wrap;gap:6px;">${upstream.points.map(p => `<span style="font-size:10.5px;font-weight:700;padding:2px 7px;border-radius:6px;background:${p.ok ? '#ECFDF5' : '#FEF2F2'};color:${p.ok ? '#047857' : '#B91C1C'};border:1px solid ${p.ok ? '#A7F3D0' : '#FECACA'};">${p.lat.toFixed(1)}°N, ${p.lng.toFixed(1)}°E — ${p.ok ? Math.round(p.rainMm) + 'mm' : 'n/a'}</span>`).join('')}</div></div>` : '';
        const upstreamContribution = (risk.breakdown.find(b => b.label && b.label.indexOf('Upstream') >= 0) || {}).score || 0;
        upstreamSectionHtml = `<div class="dva-card" style="border:2px solid ${uColor}30;background:${uBg};"><div class="dva-card-title"><span><i class="fas fa-mountain" style="color:${uColor};"></i> Upstream Basin Rainfall — ${escapeHtml(upstream.basinName)}</span><span class="dva-hero-status-pill" style="background:#fff;color:${uColor};border:1px solid ${uColor}30;font-size:11px;">${uIcon} ${escapeHtml(uLabel)}</span></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;"><div style="padding:14px;background:#fff;border:1px solid #e2e8f0;border-radius:14px;text-align:center;"><div style="font-size:11px;font-weight:800;color:#64748b;text-transform:uppercase;">7-Day Cumulative</div><div style="font-size:24px;font-weight:900;color:${uColor};margin-top:4px;">${Math.round(uMm)} <span style="font-size:13px;">mm</span></div></div><div style="padding:14px;background:#fff;border:1px solid #e2e8f0;border-radius:14px;text-align:center;"><div style="font-size:11px;font-weight:800;color:#64748b;text-transform:uppercase;">Typical Lag</div><div style="font-size:24px;font-weight:900;color:#0f172a;margin-top:4px;">${upstream.lagDays != null ? '~' + upstream.lagDays : '—'} <span style="font-size:13px;">${upstream.lagDays != null ? 'days' : ''}</span></div></div><div style="padding:14px;background:#fff;border:1px solid #e2e8f0;border-radius:14px;text-align:center;"><div style="font-size:11px;font-weight:800;color:#64748b;text-transform:uppercase;">Risk Contribution</div><div style="font-size:24px;font-weight:900;color:${uColor};margin-top:4px;">+${upstreamContribution} <span style="font-size:13px;">pts</span></div></div></div>${pointsHtml}<div style="margin-top:10px;padding:10px 12px;background:#fff;border-radius:12px;border:1px dashed ${uColor}40;"><div style="font-size:11.5px;color:#475569;line-height:1.6;"><b style="color:${uColor};">${escapeHtml(upstream.basinName)}:</b> ${escapeHtml(upstream.note || 'Upstream rainfall feeds into Bangladesh rivers. Even if local rain is low, heavy upstream rain can cause flooding downstream.')}</div></div></div>`;
    }

    const relocationHtml = relocationPlan.map((r, i) => `<div style="display:flex;align-items:flex-start;gap:12px;padding:12px 14px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:14px;margin-bottom:8px;"><div style="width:32px;height:32px;border-radius:50%;background:${i === 0 ? '#dc2626' : i === 1 ? '#f59e0b' : '#0891b2'};color:#fff;font-weight:900;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;">${i + 1}</div><div><div style="font-size:14px;font-weight:800;color:#0f172a;">${escapeHtml(r.species)}</div><div style="font-size:12px;color:#475569;line-height:1.5;margin-top:2px;">${escapeHtml(r.reason)}</div></div></div>`).join('');
    const shelterHtml = shelters.map(s => `<div style="display:flex;align-items:flex-start;gap:10px;padding:10px 12px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;margin-bottom:6px;"><span style="font-size:20px;flex-shrink:0;">${s.icon}</span><div><div style="font-size:13px;font-weight:800;color:#1e40af;">${escapeHtml(s.title)}</div><div style="font-size:11.5px;color:#475569;margin-top:1px;">${escapeHtml(s.note)}</div></div></div>`).join('');
    const feedHtml = feedPlan.plan.map(p => `<div class="cl-feed-card-premium"><div class="cl-feed-header"><div class="cl-feed-title"><span style="font-size:18px;">🐾</span> ${escapeHtml(p.species)}</div><div class="cl-feed-badge">${p.days} Days Plan</div></div><div class="cl-feed-grid"><div class="cl-feed-item"><div class="cl-feed-item-lbl"><i class="fas fa-wheat-awn"></i> Dry Hay</div><div class="cl-feed-item-val">${p.hayKg}<span class="cl-feed-item-unit">kg</span></div></div><div class="cl-feed-item"><div class="cl-feed-item-lbl"><i class="fas fa-seedling"></i> Grain/Bran</div><div class="cl-feed-item-val">${p.concentrateKg}<span class="cl-feed-item-unit">kg</span></div></div><div class="cl-feed-item"><div class="cl-feed-item-lbl"><i class="fas fa-droplet"></i> Water</div><div class="cl-feed-item-val">${p.waterLt}<span class="cl-feed-item-unit">L</span></div></div></div><div class="cl-feed-note"><i class="fas fa-circle-info" style="color:#d97706;"></i> ${escapeHtml(p.note)}</div></div>`).join('');
    const feedTips = feedPlan.tips.map(t => `<li>${escapeHtml(t)}</li>`).join('');

    let riverSectionHtml = '';
    if (riverGauge && window.NasaFloodRiver && typeof NasaFloodRiver.classifyRiverStatus === 'function') {
        const riverStatus = NasaFloodRiver.classifyRiverStatus(riverGauge.status);
        const rsData = riverScoreData || NasaFloodRiver.calcRiverScore(riverGauge);
        const lastUpdatedText = riverGauge.lastUpdatedMs ? new Date(riverGauge.lastUpdatedMs).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—';
        const sourceBadge = riverEstimated ? `<span style="font-size:10px;font-weight:800;padding:2px 7px;border-radius:6px;background:#FEF3C7;color:#92400E;border:1px solid #FDE68A;margin-left:6px;">⚠️ ESTIMATED</span>` : riverSource === 'cache' ? `<span style="font-size:10px;font-weight:800;padding:2px 7px;border-radius:6px;background:#EFF6FF;color:#1E40AF;border:1px solid #BFDBFE;margin-left:6px;">CACHED</span>` : `<span style="font-size:10px;font-weight:800;padding:2px 7px;border-radius:6px;background:#ECFDF5;color:#047857;border:1px solid #A7F3D0;margin-left:6px;">LIVE</span>`;
        const estimationNote = riverEstimated ? `<div style="margin-top:8px;padding:8px 10px;background:#FFFBEB;border-radius:10px;border:1px dashed #FDE68A;font-size:11px;color:#92400E;line-height:1.5;">⚠️ <b>Estimated water level</b> — FFWC has no public API. This is a rough approximation based on flood risk score, NOT a real river gauge reading. Check <a href="http://www.ffwc.gov.bd" target="_blank" rel="noopener" style="color:#0E7490;text-decoration:underline;font-weight:800;">FFWC official site</a> for real data.</div>` : '';
        riverSectionHtml = `<div class="dva-card" style="border:2px solid ${riverStatus.color}30;${riverEstimated ? 'opacity:0.92;' : ''}"><div class="dva-card-title"><span><i class="fas fa-water" style="color:${riverStatus.color};"></i> River Water Level — ${escapeHtml(riverGauge.riverName)}${sourceBadge}</span><span class="dva-hero-status-pill" style="background:${riverStatus.bg};color:${riverStatus.color};border:1px solid ${riverStatus.border};font-size:11px;">${riverStatus.icon} ${escapeHtml(riverStatus.label)}</span></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;"><div style="padding:14px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:14px;text-align:center;"><div style="font-size:11px;font-weight:800;color:#64748b;text-transform:uppercase;">Current Water Level</div><div style="font-size:24px;font-weight:900;color:${riverStatus.color};margin-top:4px;">${riverGauge.currentLevel} <span style="font-size:13px;">m</span></div></div><div style="padding:14px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:14px;text-align:center;"><div style="font-size:11px;font-weight:800;color:#64748b;text-transform:uppercase;">Danger Level</div><div style="font-size:24px;font-weight:900;color:#0f172a;margin-top:4px;">${riverGauge.dangerLevel} <span style="font-size:13px;">m</span></div></div><div style="padding:14px;background:${riverStatus.bg};border:1px solid ${riverStatus.border};border-radius:14px;text-align:center;"><div style="font-size:11px;font-weight:800;color:${riverStatus.color};text-transform:uppercase;">${riverGauge.gap >= 0 ? 'Remaining' : 'Exceeded'}</div><div style="font-size:24px;font-weight:900;color:${riverStatus.color};margin-top:4px;">${Math.abs(riverGauge.gap)} <span style="font-size:13px;">m</span></div></div></div><div style="margin-top:6px;"><div style="display:flex;justify-content:space-between;font-size:11px;font-weight:700;color:#64748b;margin-bottom:5px;"><span>% of danger level — ${riverGauge.percentOfDanger}%</span><span>${riverGauge.trend === 'rising' ? '📈 Rising' : riverGauge.trend === 'falling' ? '📉 Falling' : '➡️ Stable'}</span></div><div style="height:10px;background:#e2e8f0;border-radius:999px;overflow:hidden;"><div style="width:${Math.min(100, riverGauge.percentOfDanger)}%;height:100%;background:${riverStatus.color};border-radius:999px;"></div></div><div style="font-size:11.5px;color:${riverStatus.color};font-weight:700;margin-top:6px;">💡 ${escapeHtml(rsData.reason)}</div></div>${estimationNote}<div style="display:flex;justify-content:space-between;align-items:center;font-size:11px;color:#94a3b8;padding-top:8px;border-top:1px dashed #e2e8f0;margin-top:6px;flex-wrap:wrap;gap:6px;"><span><i class="fas fa-clock"></i> Last Updated: ${lastUpdatedText}</span><span><i class="fas fa-map-marker-alt"></i> ${escapeHtml(riverGauge.stationName)}</span></div></div>`;
    } else if (riverSource === 'unavailable') {
        riverSectionHtml = `<div class="dva-card" style="border:2px dashed #CBD5E1;background:#F8FAFC;"><div class="dva-card-title"><span><i class="fas fa-water" style="color:#64748B;"></i> River Water Level</span><span class="dva-hero-status-pill" style="background:#FFF;color:#64748B;border:1px solid #CBD5E1;font-size:11px;">ℹ️ Data unavailable</span></div><div style="padding:12px 14px;font-size:12px;color:#475569;line-height:1.65;">FFWC (Flood Forecasting & Warning Centre) does not provide a public API for river gauge data. Live water level for <b>${escapeHtml(coords.name)}</b> could not be loaded from any source.</div><a href="http://www.ffwc.gov.bd" target="_blank" rel="noopener" style="display:inline-flex;align-items:center;gap:6px;margin-top:10px;padding:8px 14px;background:#0E7490;color:#fff;border-radius:10px;font-size:12px;font-weight:800;text-decoration:none;"><i class="fas fa-external-link-alt"></i> Check FFWC official site</a></div>`;
    }

    body.innerHTML = `
        <div class="dva-box dva-box-fresh">
            <div class="dva-hero-card" style="border-color:${risk.color};background:${risk.bg};"><div class="dva-hero-top"><span class="dva-hero-title" style="color:${risk.color};font-size:15px;"><i class="fas fa-water"></i> Flood Risk Score — ${escapeHtml(coords.name)}</span><span class="dva-hero-status-pill" style="background:#fff;color:${risk.color};border:1.5px solid ${risk.color};">${risk.icon} ${escapeHtml(risk.label)}</span></div><div class="dva-hero-val-row"><div><span class="dva-hero-num" style="color:${risk.color};">${risk.score}</span><span class="dva-hero-unit">%</span></div><div style="text-align:right;"><div style="font-size:13.5px;font-weight:800;color:${risk.color};">${escapeHtml(risk.action)}</div></div></div><div class="dva-meter-track"><div class="dva-meter-fill" style="width:${risk.score}%;background:${risk.color};"></div></div><div class="dva-meter-labels"><span style="color:#059669;">✅ 0-35%</span><span style="color:#d97706;">👀 35-55%</span><span style="color:#c2410c;">⚠️ 55-75%</span><span style="color:#dc2626;">🚨 75-100%</span></div></div>
            ${risk.level !== 'safe' ? `<div style="padding:16px 20px;background:#fef2f2;border:2px solid ${risk.color};border-radius:18px;display:flex;align-items:flex-start;gap:14px;"><span style="font-size:28px;flex-shrink:0;">${risk.icon}</span><div><div style="font-size:16px;font-weight:900;color:${risk.color};margin-bottom:4px;">${escapeHtml(risk.label)} — Take Action Now</div><div style="font-size:13px;color:#334155;line-height:1.55;">Flood risk in ${escapeHtml(coords.name)} over the next 48-72 hours is <b>${risk.score}%</b>. ${totalAnimals > 0 ? `<b>${fmt(animalsAtRisk)}</b> livestock and <b>${fmt(farmersAtRisk)}</b> farmers are at risk.` : ''}</div></div></div>` : ''}
            ${upstreamSectionHtml}
            ${riverSectionHtml}
            <div class="dva-card"><div class="dva-card-title"><span><i class="fas fa-chart-simple text-blue-600"></i> Potential Impact (Population at Risk)</span><span style="font-size:11.5px;font-weight:700;color:#64748b;">NASA SEDAC + DLS</span></div><div class="dva-pollutant-grid" style="grid-template-columns:repeat(auto-fit,minmax(140px,1fr));"><div class="dva-pollutant-card"><div class="dva-pollutant-top"><span class="dva-pollutant-icon">🐾</span></div><div class="dva-pollutant-val">${fmt(animalsAtRisk)}</div><div class="dva-pollutant-lbl">Livestock at risk</div></div><div class="dva-pollutant-card"><div class="dva-pollutant-top"><span class="dva-pollutant-icon">🧑‍🌾</span></div><div class="dva-pollutant-val">${fmt(farmersAtRisk)}</div><div class="dva-pollutant-lbl">Farmer households</div></div><div class="dva-pollutant-card"><div class="dva-pollutant-top"><span class="dva-pollutant-icon">🌧️</span></div><div class="dva-pollutant-val">${Math.round(rain72h)}<span style="font-size:12px;"> mm</span></div><div class="dva-pollutant-lbl">72h forecast rain</div></div><div class="dva-pollutant-card"><div class="dva-pollutant-top"><span class="dva-pollutant-icon">💧</span></div><div class="dva-pollutant-val">${Math.round((soilRootLatest ? soilRootLatest.value : 0) * 100)}<span style="font-size:12px;"> %</span></div><div class="dva-pollutant-lbl">Soil moisture</div></div></div></div>
            <div class="dva-card"><div class="dva-card-title"><span><i class="fas fa-calculator text-blue-600"></i> Why ${risk.score}% flood risk?</span><span style="font-size:11.5px;font-weight:700;color:#64748b;">All factors</span></div>${breakdownHtml}</div>
            <div class="dva-card"><div class="dva-card-title"><span><i class="fas fa-truck-ramp-box text-rose-600"></i> Livestock Relocation Priority</span><span style="font-size:11.5px;font-weight:700;color:#dc2626;background:#fef2f2;padding:3px 10px;border-radius:8px;border:1px solid #fecaca;">${risk.level === 'critical' ? '🚨 Now' : risk.level === 'alert' ? '⚠️ Within 48 Hours' : '👀 Be Prepared'}</span></div>${relocationHtml}</div>
            <div class="dva-card"><div class="dva-card-title"><span><i class="fas fa-house-chimney text-emerald-600"></i> Safe Shelter Advice</span><span style="font-size:11.5px;font-weight:700;color:#047857;background:#ecfdf5;padding:3px 10px;border-radius:8px;border:1px solid #a7f3d0;">${escapeHtml((risk.vulnerability && risk.vulnerability.type ? risk.vulnerability.type.toUpperCase() : 'GENERAL'))} ZONE</span></div>${shelterHtml}</div>
            <div class="dva-card"><div class="dva-card-title"><span><i class="fas fa-wheat-awn text-amber-600"></i> ${feedPlan.days}-Day Emergency Feed Plan</span><span style="font-size:11.5px;font-weight:700;color:#92400e;background:#fffbeb;padding:3px 10px;border-radius:8px;border:1px solid #fde68a;">Per Animal</span></div>${feedHtml}<div class="cl-feed-tips-container"><div class="cl-feed-tips-title"><i class="fas fa-lightbulb"></i> Feed Storage Tips</div><ul class="cl-feed-tips-list">${feedTips}</ul></div></div>
            ${rainForecast && Array.isArray(rainForecast.hourly) && rainForecast.hourly.length > 0 ? `<div class="dva-card"><div class="dva-card-title"><span><i class="fas fa-clock text-indigo-600"></i> Next 72 Hours Rainfall (hourly)</span><span style="font-size:11.5px;font-weight:700;color:#64748b;">Open-Meteo</span></div><div style="display:flex;align-items:flex-end;gap:2px;height:80px;padding:8px 0;overflow-x:auto;position:relative;">${peakHourly === 0 || rainForecast.hourly.every(p => Number(p.mm) === 0) ? `<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:#f8fafc;border-radius:8px;border:1px dashed #cbd5e1;z-index:10;"><span style="font-size:12px;font-weight:600;color:#64748b;"><i class="fas fa-cloud-sun" style="margin-right:6px;"></i>No rainfall expected in the next 72 hours</span></div>` : ''}${rainForecast.hourly.slice(0, 72).map((p, i) => { const mm = Number(p.mm) || 0; const h = Math.min(70, mm * 3); const c = mm > 15 ? '#dc2626' : mm > 8 ? '#ea580c' : mm > 3 ? '#d97706' : '#0891b2'; if (mm === 0) return `<div title="Hour ${i}: 0 mm" style="width:6px;height:2px;background:#cbd5e1;border-radius:2px;flex-shrink:0;margin-top:auto;"></div>`; return `<div title="Hour ${i}: ${mm.toFixed(1)} mm" style="width:6px;height:${h}px;background:${c};border-radius:2px;flex-shrink:0;min-height:3px;"></div>`; }).join('')}</div><div style="font-size:11px;color:#64748b;text-align:center;margin-top:4px;">First 72 hours &bull; Peak hourly ${peakHourly} mm</div></div>` : ''}
            <div class="dvf-card-footer"><i class="fas fa-info-circle text-slate-400"></i><span>Sources: NASA GPM IMERG rainfall radar + NASA SMAP soil moisture satellite + NASA POWER 7-day rainfall${upstream ? ` + upstream basin rainfall (${escapeHtml(upstream.basinName)})` : ''} + Open-Meteo 48-72h forecast${riverGauge && !riverEstimated ? ' + FFWC river water level' : ''}${riverEstimated ? ' + Estimated river level (approximate)' : ''}. Flood forecast is a planning aid model — not a substitute for official warnings.</span></div>
        </div>`;
}

/* ============================================================
   ✅ FREE MAP LAYER (No API Key Required)
   ============================================================ */
/* Shared base layers: Street (OSM) + Satellite (Esri imagery + place labels); registers map for GPS */
function dvAddBaseLayers(map, mobile) {
    const street = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        { attribution: '&copy; OpenStreetMap contributors', maxZoom: 19 });
    const sat = L.layerGroup([
        L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
            { attribution: 'Tiles &copy; Esri', maxZoom: 19 }),
        L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}',
            { maxZoom: 19, opacity: 0.9 })
    ]);
    street.addTo(map);
    L.control.layers({ '🗺️ Street Map': street, '🛰️ Satellite': sat }, null,
        { position: 'topright', collapsed: !!mobile }).addTo(map);
    (window.__dvMaps = window.__dvMaps || []).push(map);
    return { street, sat };
}

let _borderGeoPromise = null;
function getBorderGeo() {
    if (!_borderGeoPromise) {
        _borderGeoPromise = fetch('data/bd-divisions.geojson')
            .then(res => res.ok ? res.json() : null)
            .catch(() => null);
    }
    return _borderGeoPromise;
}

/* Build the map only when it is (nearly) on screen — keeps the first paint fast */
function whenVisible(el, fn) {
    if (!el || !('IntersectionObserver' in window)) { fn(); return; }
    const io = new IntersectionObserver(entries => {
        if (entries.some(e => e.isIntersecting)) { io.disconnect(); fn(); }
    }, { rootMargin: '400px' });
    io.observe(el);
}

let keepMapOnce = false;
function loadInundationCard() {
    /* After a GPS fly-to, keep the existing map (and its location marker) */
    if (keepMapOnce && floodMapInstance) { keepMapOnce = false; return; }
    keepMapOnce = false;
    const card = _el('floodInundationCard');
    const c = DISTRICT_COORDS[currentDistrict];
    if (!card || !c) return;
    const body = card.querySelector('.climate-section-body') || card;
    const token = ++inundToken;

    if (typeof L === 'undefined') {
        body.innerHTML = '<div class="cl-empty" style="padding:30px;text-align:center;color:#64748b;">Map library (Leaflet) not loaded.</div>';
        return;
    }

    if (floodMapInstance) {
        try { floodMapInstance.remove(); } catch(_) {}
        floodMapInstance = null;
    }

    body.innerHTML = '<div id="floodLeafletMap" style="width:100%;height:420px;border-radius:12px;z-index:1;"></div>';
    
    whenVisible(body, () => {
        if (token !== inundToken) return;
        const mapEl = _el('floodLeafletMap');
        if (!mapEl) return;

        // 1. Initialize Map
        floodMapInstance = L.map(mapEl, {
            center: [c.lat, c.lng],
            zoom: 8,
            zoomControl: true,
            scrollWheelZoom: false
        });

        // 2. Street + Satellite (shared with all climate maps)
        dvAddBaseLayers(floodMapInstance, false);

        // 3. Marker
        const marker = L.circleMarker([c.lat, c.lng], {
            radius: 10,
            fillColor: "#2563eb",
            color: "#fff",
            weight: 3,
            opacity: 1,
            fillOpacity: 0.9
        }).addTo(floodMapInstance);

        marker.bindPopup(`<b>${escapeHtml(c.name)}</b><br>Flood Risk Area`).openPopup();

        // 4. Add Bangladesh Border (if file exists)
        getBorderGeo()
            .then(geo => {
                if (geo && floodMapInstance) {
                    L.geoJSON(geo, {
                        style: {
                            color: '#2563eb',
                            weight: 2,
                            opacity: 0.6,
                            fillOpacity: 0.1,
                            dashArray: '4,4'
                        }
                    }).addTo(floodMapInstance);
                }
            })
            .catch(() => console.log('GeoJSON border not found - map still works.'));

        setTimeout(() => { 
            if(floodMapInstance) floodMapInstance.invalidateSize(); 
        }, 300);

    });
}

async function loadFloodData() {
    const body = _el('floodAppRoot');
    if (!body) return;
    const token = ++loadToken;
    loadInundationCard(); // ✅ Will now render the interactive map

    body.innerHTML = `
        <div class="climate-empty" style="padding: 2rem;">
            <div class="dvsk-circle dvsk" style="width: 48px; height: 48px; margin-bottom: 1rem;"></div>
            <div class="dvsk-line-lg dvsk" style="width: 60%; margin: 0 auto 1rem;"></div>
            <div class="dvsk-line dvsk" style="width: 80%; margin: 0 auto 1rem;"></div>
            <div class="dvsk-line dvsk" style="width: 40%; margin: 0 auto;"></div>
        </div>`;

    try {
        const data = await fetchAllFloodData(currentDistrict);
        if (token !== loadToken) return;
        if (!data || !data.parameter) throw new Error('NASA data not available');
        renderFloodDashboard(body, currentDistrict, data);
    } catch (err) {
        if (token !== loadToken) return;
        console.error('[Flood] Load failed:', err);
        body.innerHTML = `<div class="climate-empty"><i class="fas fa-exclamation-triangle" style="color:#dc2626;font-size:32px;"></i><span class="font-extrabold text-slate-800">Could not load flood data</span><span class="text-xs text-slate-500">${escapeHtml(err.message)}</span></div>`;
    }
}

window.__dvmUseMyLocation = function () {
    if (!window.DVGpsAnimator) {
        if (!navigator.geolocation) { alert('Geolocation not supported by your browser.'); return; }
        navigator.geolocation.getCurrentPosition(
            (pos) => {
                const lat = pos.coords.latitude;
                const lng = pos.coords.longitude;
                let closestKey = currentDistrict;
                let minDist = Infinity;
                Object.keys(DISTRICT_COORDS).forEach(k => {
                    const c = DISTRICT_COORDS[k];
                    const d = Math.hypot(c.lat - lat, c.lng - lng);
                    if (d < minDist) { minDist = d; closestKey = k; }
                });
                currentDistrict = closestKey;
                const sel = _el('climateDistrict');
                if (sel) sel.value = closestKey;
                loadFloodData();
            },
            (err) => { alert('Could not get location: ' + err.message); },
            { enableHighAccuracy: true, timeout: 10000 }
        );
        return;
    }
    DVGpsAnimator.locate({
        buttonId: 'dvmGpsBtn', accentColor: '#2563eb', districtName: '',
        findClosest: (lat, lng) => {
            let closestKey = currentDistrict;
            let minDist = Infinity;
            Object.keys(DISTRICT_COORDS).forEach(k => {
                const c = DISTRICT_COORDS[k];
                const d = Math.hypot(c.lat - lat, c.lng - lng);
                if (d < minDist) { minDist = d; closestKey = k; }
            });
            return { key: closestKey, nameBn: DISTRICT_COORDS[closestKey].name };
        },
        onSuccess: (closest) => {
            currentDistrict = closest.key;
            const sel = _el('climateDistrict');
            if (sel) sel.value = closest.key;
            keepMapOnce = true;
            loadFloodData();
        }
    });
};

function init() {
    const select = _el('climateDistrict');
    if (select) {
        select.value = currentDistrict;
        select.addEventListener('change', e => {
            if (!DISTRICT_COORDS[e.target.value]) return;
            currentDistrict = e.target.value;
            loadFloodData();
        });
    }
    loadFloodData();
}

if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
else init();

})();