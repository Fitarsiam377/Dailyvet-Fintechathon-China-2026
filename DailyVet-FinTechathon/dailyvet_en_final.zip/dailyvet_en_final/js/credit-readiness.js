/* ============================================================
   DailyVet — SME Credit Readiness & Loan Simulation v2.0
   ------------------------------------------------------------
   Reads:  users/{phone}/ledger  (type, amount, description, timestamp)
   Uses:   Live NASA Weather Risk (via insurance.js)
   Output: 0–999 credit score + Safe Loan Limit + Loan Simulator
   ============================================================ */
(function () {
'use strict';

const _fs = () => firebase.firestore();

/* ============================================================
   CONFIG — tunable thresholds
   ============================================================ */
const CFG = {
    MIN_MONTHS_HISTORY: 3,
    MIN_TRANSACTIONS: 10,
    MIN_MONTHLY_INCOME: 5000,
    MIN_PROFIT_MONTHS_RATIO: 0.6,
    MAX_EXPENSE_RATIO: 0.85,
    CONSISTENCY_WINDOW_DAYS: 90,
    BASE_SAFE_LOAN_MULTIPLIER: 3, // 3x monthly income
    MAX_RISK_MULTIPLIER: 1.8
};

const BANDS = [
    { min: 700, key: 'bank',      label: 'Bank loan ready',       color: '#059669', bg: '#ecfdf5' },
    { min: 600, key: 'mfi',       label: 'Micro-finance ready',   color: '#0891b2', bg: '#ecfeff' },
    { min: 500, key: 'improving', label: 'Improving — 1–2 fixes', color: '#d97706', bg: '#fffbeb' },
    { min: 0,   key: 'not_ready', label: 'Not ready yet',         color: '#dc2626', bg: '#fef2f2' }
];

/* ============================================================
   HELPERS
   ============================================================ */
const _cleanPhone = p => String(p || '').replace(/[^0-9+]/g, '');
const _myPhone = () => _cleanPhone(
    (typeof sessionStorage !== 'undefined' && sessionStorage.getItem('userPhone')) ||
    (typeof localStorage !== 'undefined' && localStorage.getItem('userPhone'))
);

const _toDate = ts => {
    if (!ts) return null;
    if (typeof ts.toDate === 'function') return ts.toDate();
    const d = new Date(ts);
    return isNaN(d) ? null : d;
};

const _monthKey = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
const _fmtTk = n => '৳ ' + Math.round(Number(n) || 0).toLocaleString('en-IN');
const _band = score => BANDS.find(b => score >= b.min) || BANDS[BANDS.length - 1];

/* ============================================================
   LOAD LEDGER
   ============================================================ */
async function _loadLedger(phone, limit = 500) {
    const snap = await _fs()
        .collection('users').doc(phone)
        .collection('ledger')
        .orderBy('timestamp', 'desc')
        .limit(limit)
        .get();

    const rows = [];
    snap.forEach(doc => {
        const d = doc.data() || {};
        const dt = _toDate(d.timestamp) || new Date();
        rows.push({
            type: d.type === 'income' ? 'income' : 'expense',
            amount: Number(d.amount) || 0,
            description: String(d.description || '').trim(),
            date: dt
        });
    });
    return rows;
}

/* ============================================================
   ANALYSE LEDGER → monthly buckets + totals
   ============================================================ */
function _analyse(rows) {
    const months = {};
    let totalIncome = 0, totalExpense = 0;

    rows.forEach(r => {
        const k = _monthKey(r.date);
        const m = months[k] || (months[k] = { income: 0, expense: 0, count: 0 });
        if (r.type === 'income') { m.income += r.amount; totalIncome += r.amount; }
        else { m.expense += r.amount; totalExpense += r.amount; }
        m.count += 1;
    });

    const keys = Object.keys(months).sort();
    const monthly = keys.map(k => ({
        key: k,
        income: months[k].income,
        expense: months[k].expense,
        net: months[k].income - months[k].expense,
        count: months[k].count
    }));

    const profitMonths = monthly.filter(m => m.net > 0).length;
    const activeMonths = monthly.filter(m => m.income > 0 || m.expense > 0).length;
    const avgIncome = activeMonths ? totalIncome / activeMonths : 0;
    const avgExpense = activeMonths ? totalExpense / activeMonths : 0;
    const expenseRatio = totalIncome > 0 ? totalExpense / totalIncome : 1;

    const cutoff = Date.now() - CFG.CONSISTENCY_WINDOW_DAYS * 86400000;
    const recentDays = new Set();
    rows.forEach(r => { if (r.date.getTime() >= cutoff) recentDays.add(r.date.toDateString()); });
    const consistencyPct = Math.min(100, Math.round(recentDays.size / 30 * 100));

    return {
        monthly, totalIncome, totalExpense, totalNet: totalIncome - totalExpense,
        activeMonths, profitMonths, avgIncome, avgExpense, expenseRatio, consistencyPct,
        txCount: rows.length
    };
}

/* ============================================================
   SCORE ENGINE (max 999)
   ============================================================ */
function _score(a) {
    let score = 500;
    const gaps = [];
    const strengths = [];

    /* 1. History length */
    if (a.activeMonths >= CFG.MIN_MONTHS_HISTORY) {
        strengths.push(`${a.activeMonths} months of transaction history`);
    } else {
        gaps.push({
            code: 'history_short', severity: 'blocker', title: 'Short transaction history',
            detail: `Need ${CFG.MIN_MONTHS_HISTORY} months, have ${a.activeMonths}`,
            fix: 'Record income and expenses regularly every day'
        });
    }

    /* 2. Transaction count */
    if (a.txCount < CFG.MIN_TRANSACTIONS) {
        gaps.push({
            code: 'few_transactions', severity: 'warning', title: 'Few transactions recorded',
            detail: `Need ${CFG.MIN_TRANSACTIONS}+, have ${a.txCount}`,
            fix: 'Log every income and expense, including small amounts'
        });
    }

    /* 3. Income presence */
    if (a.avgIncome > 0) {
        const incomeBoost = Math.min(200, Math.round(
            (Math.log10(a.avgIncome / CFG.MIN_MONTHLY_INCOME + 1) / Math.log10(20)) * 200
        ));
        score += Math.max(0, incomeBoost);
        if (a.avgIncome >= CFG.MIN_MONTHLY_INCOME * 3) {
            strengths.push(`Average monthly income ${_fmtTk(a.avgIncome)} — good`);
        }
    } else {
        gaps.push({
            code: 'no_income', severity: 'blocker', title: 'No income recorded',
            detail: 'Income is required for credit assessment',
            fix: 'Add income entries (milk sales, crops, etc.)'
        });
    }

    /* 4. Profitability */
    if (a.activeMonths > 0) {
        const profitRatio = a.profitMonths / a.activeMonths;
        score += Math.round(150 * profitRatio);
        if (profitRatio >= CFG.MIN_PROFIT_MONTHS_RATIO) {
            strengths.push(`${Math.round(profitRatio * 100)}% of months were profitable`);
        } else {
            gaps.push({
                code: 'low_profit_months', severity: 'warning', title: 'Many months without profit',
                detail: `Only ${a.profitMonths}/${a.activeMonths} months profitable`,
                fix: 'Reduce expenses or find ways to increase income'
            });
        }
    }

    /* 5. Expense discipline */
    if (a.totalIncome > 0) {
        if (a.expenseRatio <= CFG.MAX_EXPENSE_RATIO) {
            score += Math.round(100 * (1 - a.expenseRatio));
            strengths.push(`Expenses at ${Math.round(a.expenseRatio * 100)}% of income — controlled`);
        } else {
            gaps.push({
                code: 'high_expense_ratio', severity: 'blocker', title: 'Expenses too high vs income',
                detail: `Expenses are ${Math.round(a.expenseRatio * 100)}% of income (limit ${CFG.MAX_EXPENSE_RATIO * 100}%)`,
                fix: 'Cut non-essential spending and build a monthly budget'
            });
        }
    }

    /* 6. Consistency */
    score += Math.round(49 * (a.consistencyPct / 100));
    if (a.consistencyPct >= 70) {
        strengths.push('Regular entry habits');
    } else if (a.consistencyPct < 30 && a.txCount > 0) {
        gaps.push({
            code: 'low_consistency', severity: 'warning', title: 'Irregular entries',
            detail: `Only ${a.consistencyPct}% of days in the last 30 had entries`,
            fix: 'Spend 1 minute at day-end to record transactions'
        });
    }

    /* 7. Hard penalties for blockers */
    const blockers = gaps.filter(g => g.severity === 'blocker');
    if (blockers.length > 0) score = Math.min(score, 499);

    score = Math.max(0, Math.min(999, Math.round(score)));
    return { score, gaps, strengths };
}

/* ============================================================
   SAFE LOAN LIMIT CALCULATOR (NASA + Cashflow)
   ============================================================ */
async function _calculateSafeLoanLimit(phone, stats, creditScore) {
    let weatherFactor = 1.0;
    let weatherRisk = 'Low';
    let weatherReason = 'Normal weather conditions';

    try {
        const doc = await _fs().collection('users').doc(phone).get();
        const district = doc.exists && (doc.data().district || doc.data().city) ? (doc.data().district || doc.data().city) : 'dhaka';

        if (typeof window.fetchLiveRiskData === 'function') {
            const risk = await window.fetchLiveRiskData(district);
            const flood = risk.flood?.score || 0;
            const heat = risk.heat?.level || 'normal';

            if (flood > 70 || heat === 'severe') {
                weatherFactor = 0.5;
                weatherRisk = 'High';
                weatherReason = 'Severe flood or heat risk detected in your district';
            } else if (flood > 40 || heat === 'moderate') {
                weatherFactor = 0.7;
                weatherRisk = 'Medium';
                weatherReason = 'Moderate weather risk may affect farm income';
            }
        }
    } catch (e) {
        console.warn('[Credit] Weather fetch failed:', e);
    }

    const baseSafeLimit = stats.avgIncome > 0 ? stats.avgIncome * CFG.BASE_SAFE_LOAN_MULTIPLIER : 0;
    const scoreFactor = creditScore / 999;
    const riskAdjustedLimit = baseSafeLimit * scoreFactor * weatherFactor;

    return {
        limit: Math.round(riskAdjustedLimit / 1000) * 1000,
        weatherRisk,
        weatherReason
    };
}

/* ============================================================
   PUBLIC: compute
   ============================================================ */
async function compute(phone) {
    const target = _cleanPhone(phone || _myPhone());
    if (!target) return { ok: false, error: 'not_logged_in' };

    try {
        const rows = await _loadLedger(target);
        if (!rows.length) {
            return {
                ok: true, empty: true, score: 0, band: _band(0),
                gaps: [{ code: 'no_data', severity: 'blocker', title: 'No transactions yet', detail: 'Ledger is empty', fix: 'Add income and expenses in Finance Copilot' }],
                strengths: [], stats: null, safeLoan: null
            };
        }

        const stats = _analyse(rows);
        const { score, gaps, strengths } = _score(stats);
        const band = _band(score);
        const safeLoan = await _calculateSafeLoanLimit(target, stats, score);

        gaps.sort((a, b) => {
            const rank = { blocker: 0, warning: 1 };
            return (rank[a.severity] ?? 2) - (rank[b.severity] ?? 2);
        });

        return { ok: true, empty: false, score, band, gaps, strengths, stats, safeLoan, thresholds: { bank: 700, mfi: 600 } };
    } catch (err) {
        console.warn('[CreditReadiness] compute failed:', err.message);
        return { ok: false, error: err.message };
    }
}

/* ============================================================
   PUBLIC: Loan Simulator Logic
   ============================================================ */
function _evaluateLoanAmount(amount, maxSafeLimit) {
    if (amount <= maxSafeLimit) {
        return { status: 'safe', title: '✅ Safe to borrow', message: 'This amount fits your cashflow and weather risk profile.', color: '#059669', bg: '#ecfdf5' };
    } else if (amount <= maxSafeLimit * 1.5) {
        return { status: 'caution', title: '⚠️ Caution advised', message: 'This is slightly above our recommended limit. Ensure you have a backup plan for repayments.', color: '#d97706', bg: '#fffbeb' };
    } else {
        return { status: 'risky', title: '🚨 High Financial Risk', message: 'This amount exceeds your safe limit. Extreme weather or a bad month could make repayment impossible.', color: '#dc2626', bg: '#fef2f2' };
    }
}

/* ============================================================
   PUBLIC: render
   ============================================================ */
async function render(containerId, phone) {
    const host = document.getElementById(containerId);
    if (!host) return null;

    host.innerHTML = `
        <div class="dvcr-card dvsk-card" style="padding: 1.5rem;">
            <div class="dvsk-line-lg dvsk" style="width: 50%; margin-bottom: 1rem;"></div>
            <div class="dvsk-line dvsk" style="height: 12px; border-radius: 6px;"></div>
            <div class="dvsk-line dvsk" style="height: 12px; border-radius: 6px;"></div>
            <div class="dvsk-box dvsk" style="height: 80px; margin-top: 1rem; border-radius: 14px;"></div>
        </div>`;

    const r = await compute(phone);

    if (!r.ok) {
        host.innerHTML = `<div style="color:#DC2626;font-size:13px;text-align:center;padding:1rem;">Calculation failed: ${r.error || 'unknown error'}</div>`;
        return r;
    }

    if (r.empty) {
        host.innerHTML = `
            <div style="background:#fff;border:1.5px dashed #CBD5E1;border-radius:14px;padding:1.5rem;text-align:center;">
                <div style="font-size:2rem;margin-bottom:0.5rem;">📊</div>
                <div style="font-weight:800;color:#0F172A;margin-bottom:0.25rem;">No transactions yet</div>
                <div style="font-size:12.5px;color:#64748B;margin-bottom:1rem;">Add income and expenses in Finance Copilot to see your score.</div>
                <a href="finance-copilot.html" style="display:inline-block;background:#059669;color:#fff;padding:0.5rem 1.25rem;border-radius:10px;font-weight:700;text-decoration:none;font-size:13px;">Add Now</a>
            </div>`;
        return r;
    }

    const { score, band, gaps, strengths, stats, safeLoan } = r;
    const pct = Math.min(100, Math.round(score / 999 * 100));

    const gapRows = gaps.length ? gaps.map(g => `
        <div style="display:flex;gap:10px;padding:10px 12px;border-radius:10px;margin-bottom:6px;background:${g.severity === 'blocker' ? '#fef2f2' : '#fffbeb'};border:1px solid ${g.severity === 'blocker' ? '#fecaca' : '#fde68a'};">
            <span style="font-size:16px;">${g.severity === 'blocker' ? '🚫' : '⚠️'}</span>
            <div style="min-width:0;flex:1;">
                <div style="font-size:13px;font-weight:800;color:${g.severity === 'blocker' ? '#b91c1c' : '#92400e'};">${g.title}</div>
                <div style="font-size:12px;color:#475569;margin-top:1px;">${g.detail}</div>
                <div style="font-size:11.5px;color:#64748B;margin-top:3px;"><b>Fix:</b> ${g.fix}</div>
            </div>
        </div>`).join('') : `
        <div style="display:flex;gap:10px;padding:12px;border-radius:10px;background:#ecfdf5;border:1px solid #86efac;">
            <span style="font-size:16px;">✅</span>
            <div style="font-size:13px;font-weight:700;color:#047857;">No blockers — you are ready!</div>
        </div>`;

    const strengthHtml = strengths.length ? `
        <div style="margin-top:12px;">
            <div style="font-size:12px;font-weight:800;color:#047857;text-transform:uppercase;letter-spacing:.04em;margin-bottom:6px;">💪 Strengths</div>
            <ul style="margin:0;padding-left:18px;font-size:12.5px;color:#334155;line-height:1.7;">
                ${strengths.map(s => `<li>${s}</li>`).join('')}
            </ul>
        </div>` : '';

    const safeLimitColor = safeLoan.weatherRisk === 'High' ? '#dc2626' : safeLoan.weatherRisk === 'Medium' ? '#d97706' : '#059669';

    host.innerHTML = `
        <div style="background:#fff;border:1.5px solid ${band.color}40;border-radius:16px;padding:1.25rem;">
            
            <!-- Header -->
            <div style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:1rem;">
                <div>
                    <div style="font-size:11px;font-weight:800;color:#64748B;text-transform:uppercase;letter-spacing:.06em;">Credit Readiness</div>
                    <div style="font-size:2.25rem;font-weight:900;color:${band.color};line-height:1;">${score}<span style="font-size:14px;color:#94A3B8;font-weight:700;">/999</span></div>
                </div>
                <span style="padding:6px 12px;border-radius:999px;background:${band.bg};color:${band.color};font-size:12px;font-weight:800;border:1px solid ${band.color}40;white-space:nowrap;">
                    ${band.label}
                </span>
            </div>

            <!-- Progress Bar -->
            <div style="height:10px;background:#f1f5f9;border-radius:999px;overflow:hidden;margin-bottom:4px;">
                <div style="width:${pct}%;height:100%;background:${band.color};border-radius:999px;transition:width .6s;"></div>
            </div>
            <div style="display:flex;justify-content:space-between;font-size:10.5px;color:#94A3B8;font-weight:700;margin-bottom:1.25rem;">
                <span>0</span><span style="color:#0891b2;">MFI 600</span><span style="color:#059669;">Bank 700</span><span>999</span>
            </div>

            <!-- Stats Grid -->
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(90px,1fr));gap:8px;margin-bottom:1.25rem;">
                <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:8px;text-align:center;">
                    <div style="font-size:10px;color:#64748B;font-weight:700;">Income/mo</div>
                    <div style="font-size:13px;font-weight:900;color:#059669;">${_fmtTk(stats.avgIncome)}</div>
                </div>
                <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:8px;text-align:center;">
                    <div style="font-size:10px;color:#64748B;font-weight:700;">Expense/mo</div>
                    <div style="font-size:13px;font-weight:900;color:#DC2626;">${_fmtTk(stats.avgExpense)}</div>
                </div>
                <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:8px;text-align:center;">
                    <div style="font-size:10px;color:#64748B;font-weight:700;">Months</div>
                    <div style="font-size:13px;font-weight:900;color:#0F172A;">${stats.activeMonths}</div>
                </div>
                <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:8px;text-align:center;">
                    <div style="font-size:10px;color:#64748B;font-weight:700;">Profit months</div>
                    <div style="font-size:13px;font-weight:900;color:#0F172A;">${stats.profitMonths}/${stats.activeMonths}</div>
                </div>
            </div>

            <!-- Safe Loan Limit (AI Decision) -->
            <div style="background:linear-gradient(135deg, #f8fafc, #f1f5f9); border:1px solid #cbd5e1; border-radius:12px; padding:1rem; margin-bottom:1.25rem;">
                <div style="font-size:11px; font-weight:800; color:#475569; text-transform:uppercase; margin-bottom:4px;">
                    <i class="fas fa-shield-check" style="color:${safeLimitColor};"></i> AI Safe Loan Limit
                </div>
                <div style="font-size:1.75rem; font-weight:900; color:#0F172A; line-height:1;">${_fmtTk(safeLoan.limit)}</div>
                <div style="font-size:11px; color:${safeLimitColor}; margin-top:4px; font-weight:600;">
                    ${safeLoan.weatherRisk} Weather Risk: ${safeLoan.weatherReason}
                </div>
            </div>

            <!-- Loan Simulator -->
            <div style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:12px; padding:1rem; margin-bottom:1.25rem;">
                <div style="font-size:12px; font-weight:800; color:#1e40af; margin-bottom:6px;"><i class="fas fa-calculator"></i> Loan Simulator</div>
                <div style="display:flex; gap:8px; margin-bottom:8px;">
                    <input type="number" id="loanSimInput_${containerId}" placeholder="e.g. 50000" style="flex:1; padding:8px; border:1px solid #93c5fd; border-radius:8px; font-size:13px; outline:none;">
                    <button type="button" onclick="window.DVCreditReadiness.simulateLoan('${containerId}', ${safeLoan.limit})" style="background:#2563eb; color:#fff; border:none; padding:8px 14px; border-radius:8px; font-weight:700; cursor:pointer; font-size:12px;">Check</button>
                </div>
                <div id="loanSimResult_${containerId}" style="display:none; padding:8px; border-radius:8px; font-size:12px; font-weight:600; line-height:1.5;"></div>
            </div>

            <!-- Gaps -->
            <div style="font-size:12px;font-weight:800;color:#0F172A;text-transform:uppercase;letter-spacing:.04em;margin-bottom:8px;">🚧 Gaps &amp; Fixes</div>
            ${gapRows}
            ${strengthHtml}
        </div>`;

    return r;
}

/* ============================================================
   PUBLIC: Simulate Loan Function
   ============================================================ */
function simulateLoan(containerId, safeLimit) {
    const input = document.getElementById(`loanSimInput_${containerId}`);
    const resBox = document.getElementById(`loanSimResult_${containerId}`);
    if (!input || !resBox) return;

    const amount = Number(input.value);
    if (!amount || amount <= 0) {
        resBox.style.display = 'block';
        resBox.style.background = '#fef2f2';
        resBox.style.color = '#b91c1c';
        resBox.innerHTML = 'Please enter a valid amount.';
        return;
    }

    const evalResult = _evaluateLoanAmount(amount, safeLimit);
    
    resBox.style.display = 'block';
    resBox.style.background = evalResult.bg;
    resBox.style.color = evalResult.color;
    resBox.innerHTML = `<strong>${evalResult.title}</strong><br>${evalResult.message}`;
}

/* ============================================================
   PUBLIC API
   ============================================================ */
window.DVCreditReadiness = {
    compute,
    render,
    simulateLoan,
    CFG,
    BANDS
};

console.log('✅ Credit Readiness & Loan Simulation v2.0 loaded');
})();
