# DailyVet — Deploy Guide (VS Code Live Server / Netlify / Vercel)

## 1. VS Code Live Server
1. Open the project folder in VS Code.
2. Install "Live Server" extension.
3. Right-click `index.html` or `home.html` → "Open with Live Server".
4. AI works with direct API calls (keys in client JS — normal for local).
5. All buttons / navigation work relative to the folder.

## 2. Netlify
1. Push this folder to GitHub (or drag-drop the folder in Netlify UI).
2. Build settings:
   - Publish directory: `.` (root of this folder)
   - Build command: leave empty
3. Functions directory is already set in `netlify.toml` → `netlify/functions`
4. (Optional but recommended) Site settings → Environment variables:
   - `GEMINI_KEY_1` … `GEMINI_KEY_18`
   - `GROQ_KEY_1` … `GROQ_KEY_4`
   - `OPENROUTER_KEY_1` … `OPENROUTER_KEY_3`
   - `FIREBASE_SERVICE_KEY` (for payment functions)
5. After deploy, AI calls go to `/.netlify/functions/ai-proxy`  
   → **keys never appear in Network tab**.

## 3. Vercel
1. Import the same Git repo (or `vercel` CLI from this folder).
2. Framework preset: Other
3. Root directory: this folder
4. `vercel.json` already routes `/api/ai-proxy` to the serverless function.
5. Add the same environment variables as above (optional).
6. After deploy, AI calls go to `/api/ai-proxy`  
   → **keys never appear in Network tab**.

## Security summary
- Production (Netlify / Vercel): Gemini → first, fail → Groq → OpenRouter.  
  All requests proxied. Network tab only shows your own domain.
- Local Live Server: direct calls so you can test without backend.
- Console Guard redacts keys from console output.
- Source maps blocked, security headers set, `.bak` / `netlify/` probing blocked.
- Fintech payment functions remain server-side only.

## Order of AI providers (enforced)
1. Gemini (primary)
2. On fail / rate-limit → Groq
3. Then OpenRouter

No further code changes needed. Just deploy.
