/**
 * DailyVet AI Proxy — Vercel Serverless Function
 * Same contract as Netlify: POST /api/ai-proxy
 * Body: { provider, model, body, keyIndex? }
 */
const KEYS = {
  gemini: [
    process.env.GEMINI_KEY_1 || 'AQ.Ab8RN6IwMTDWn8wV4X3h4HBdastHE169JXxe5IKQ1gM3PjWEGQ',
    process.env.GEMINI_KEY_2 || 'AQ.Ab8RN6KuvW83A3OajaqM7GovoyBuNDQ8tj9K5SiwsFNUsy-iWA',
    process.env.GEMINI_KEY_3 || 'AQ.Ab8RN6IRaFeokk9yKJoygmT5Oue5hr3beuU1nZ1TEv2rLbGT1g',
    process.env.GEMINI_KEY_4 || 'AQ.Ab8RN6Joa7nU4V5GGOdv6cE2dH3KEz7oj71ut3NtpjsZSzoc-A',
    process.env.GEMINI_KEY_5 || 'AQ.Ab8RN6JngIBhA1HyUmtoMHzPMVgsCJfXVKGDjHYMcoRNXgrVpg',
    process.env.GEMINI_KEY_6 || 'AQ.Ab8RN6KVbxl1e0ZJ4jQOkGZ2yqdFxx2u5Jl1yN6AnCW4m3jpIQ',
    process.env.GEMINI_KEY_7 || 'AQ.Ab8RN6LCLH0Kv7-dEX61LqheZyT3eWXZn9vljhEwalolNrw5lg',
    process.env.GEMINI_KEY_8 || 'AQ.Ab8RN6KrfN1vve0A4o9DbRrKlJwduI6_FvBkCD4CGLeQcGAoxQ',
    process.env.GEMINI_KEY_9 || 'AQ.Ab8RN6IH30YKZEOVwVd_28Xesv6jHunMVFwc7BnqyevDwY5vSw',
    process.env.GEMINI_KEY_10 || 'AQ.Ab8RN6L2ucdsVMCOBdhZGSYeL_KzvcUKVlJZ9R8Ov8FuxXnJZw',
    process.env.GEMINI_KEY_11 || 'AQ.Ab8RN6JURo6GM-erOA_GzQTIrix34mRH_wwh7Mi3McjquuWf0g',
    process.env.GEMINI_KEY_12 || 'AQ.Ab8RN6K_FYnOKLOtYQ_me-ikqMro19izQCEQ91p50uqCjhc9Vw',
    process.env.GEMINI_KEY_13 || 'AQ.Ab8RN6LOnEJNNw1ZnudbaWtiTwlMxIIL2YzmjQchRbotREe1Bw',
    process.env.GEMINI_KEY_14 || 'AQ.Ab8RN6Lw1hLrmOpHhxXcrbItIvQPqrjhXij-NQ4DWAfsrQaBOQ',
    process.env.GEMINI_KEY_15 || 'AQ.Ab8RN6IfcISj48ZUdezZBtrefHQ6lAXxQ_vtZxXFIJItAhAyUQ',
    process.env.GEMINI_KEY_16 || 'AQ.Ab8RN6KrX988Q8EXWNG9iF9CbsmqLIlL7hKiAaXRCa1aGgMoSA',
    process.env.GEMINI_KEY_17 || 'AQ.Ab8RN6LBkDemnP94Jsk8jpyoMhv-yE5URct4YnRs-HnM-R6ihQ',
    process.env.GEMINI_KEY_18 || 'AQ.Ab8RN6K2rZlu0_5Q5DS7zbBvk3f4D0aWqRVBPCch_78_qwnkSw'
  ].filter(Boolean),
  groq: [
    process.env.GROQ_KEY_1 || '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',
    process.env.GROQ_KEY_2 || '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',
    process.env.GROQ_KEY_3 || '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',
    process.env.GROQ_KEY_4 || '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'
  ].filter(Boolean),
  openrouter: [
    process.env.OPENROUTER_KEY_1 || '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',
    process.env.OPENROUTER_KEY_2 || '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',
    process.env.OPENROUTER_KEY_3 || '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'
  ].filter(Boolean)
};

const ENDPOINTS = {
  gemini: (model) => `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
  groq: () => 'https://api.groq.com/openai/v1/chat/completions',
  openrouter: () => 'https://openrouter.ai/api/v1/chat/completions'
};

function pickKey(provider, preferredIndex) {
  const list = KEYS[provider] || [];
  if (!list.length) return null;
  const idx = (typeof preferredIndex === 'number' && preferredIndex >= 0)
    ? preferredIndex % list.length
    : Math.floor(Math.random() * list.length);
  return { key: list[idx], index: idx };
}

function setCors(res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
}

module.exports = async function handler(req, res) {
  setCors(res);
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const payload = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
  const { provider, model, body, keyIndex } = payload;

  if (!provider || !model || !body) {
    return res.status(400).json({ error: 'provider, model, body required' });
  }
  if (!['gemini', 'groq', 'openrouter'].includes(provider)) {
    return res.status(400).json({ error: 'Invalid provider' });
  }

  const picked = pickKey(provider, keyIndex);
  if (!picked) {
    return res.status(503).json({ error: 'No keys configured for ' + provider });
  }

  let url;
  const headers = { 'Content-Type': 'application/json' };

  if (provider === 'gemini') {
    url = ENDPOINTS.gemini(model) + '?key=' + encodeURIComponent(picked.key);
  } else if (provider === 'groq') {
    url = ENDPOINTS.groq();
    headers['Authorization'] = 'Bearer ' + picked.key;
  } else {
    url = ENDPOINTS.openrouter();
    headers['Authorization'] = 'Bearer ' + picked.key;
    headers['HTTP-Referer'] = 'https://dailyvet.app';
    headers['X-Title'] = 'DailyVet';
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 25000);

    const upstream = await fetch(url, {
      method: 'POST',
      headers,
      body: JSON.stringify(body),
      signal: controller.signal
    });
    clearTimeout(timeout);

    const text = await upstream.text();
    let data;
    try { data = JSON.parse(text); } catch { data = { raw: text }; }

    res.setHeader('X-Key-Index', String(picked.index));
    return res.status(upstream.status).json(data);
  } catch (err) {
    const isAbort = err.name === 'AbortError';
    return res.status(isAbort ? 504 : 502).json({
      error: isAbort ? 'Upstream timeout' : (err.message || 'Proxy error')
    });
  }
};
