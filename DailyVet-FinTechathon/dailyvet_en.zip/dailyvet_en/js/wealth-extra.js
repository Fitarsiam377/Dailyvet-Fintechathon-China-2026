/* ============================================================
   DailyVet — Wealth Extra (Live Data, ROI, Carbon Selling & AI) v7.0
   ============================================================ */

let currentUserPhone = null;
let currentUserRiskProfile = 'moderate';
let totalCarbonCredits = 0;
let currentCarbonSource = '';
let carbonImageBase64 = null;

// Payment State
let currentAssetName = '';
let currentTargetValue = 0;
let currentMinInvestment = 5000;
let currentPaymentMethod = 'bkash';

const _fs = () => firebase.firestore();

/* AI Keys (Gemini) */
const GEMINI_KEYS = [
    'AQ.Ab8RN6JURo6GM-erOA_GzQTIrix34mRH_wwh7Mi3McjquuWf0g',
    'AQ.Ab8RN6K_FYnOKLOtYQ_me-ikqMro19izQCEQ91p50uqCjhc9Vw',
    'AQ.Ab8RN6LOnEJNNw1ZnudbaWtiTwlMxIIL2YzmjQchRbotREe1Bw'
];
const VISION_MODEL = 'gemini-3.5-flash-lite';
const API_URL = 'https://generativelanguage.googleapis.com/v1beta/models';

document.addEventListener('DOMContentLoaded', async () => {
    currentUserPhone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
    if (!currentUserPhone) {
        window.location.href = 'login.html';
        return;
    }

    try {
        const doc = await _fs().collection('users').doc(currentUserPhone).get();
        if (doc.exists && doc.data().riskProfile) {
            currentUserRiskProfile = doc.data().riskProfile;
        }
    } catch (e) { console.warn(e); }

    // Load all live data
    loadInvestmentPortfolio();
    loadCarbonBalance();
    loadLiveFundingData();
});

/* ============================================================
   TAB SWITCH
   ============================================================ */
function switchExtraTab(tab) {
    document.getElementById('tabFrac').classList.remove('active');
    document.getElementById('tabCarbon').classList.remove('active');
    document.getElementById('contentFrac').style.display = 'none';
    document.getElementById('contentCarbon').style.display = 'none';

    if (tab === 'frac') {
        document.getElementById('tabFrac').classList.add('active');
        document.getElementById('contentFrac').style.display = 'block';
    } else {
        document.getElementById('tabCarbon').classList.add('active');
        document.getElementById('contentCarbon').style.display = 'block';
    }
}

/* ============================================================
   1. LIVE FUNDING DATA
   ============================================================ */
async function loadLiveFundingData() {
    let targets = { cow: 120000, goat: 15000, buffalo: 200000, sheep: 12000, chicken: 10000 };
    let raised = { cow: 0, goat: 0, buffalo: 0, sheep: 0, chicken: 0 };

    try {
        const poolDoc = await _fs().collection('meta').doc('funding_pools').get();
        
        if (poolDoc.exists) {
            const d = poolDoc.data();
            
            if (d.targets) {
                targets = {
                    cow: d.targets.cow || targets.cow,
                    goat: d.targets.goat || targets.goat,
                    buffalo: d.targets.buffalo || targets.buffalo,
                    sheep: d.targets.sheep || targets.sheep,
                    chicken: d.targets.chicken || targets.chicken
                };
            }

            raised = {
                cow: d.cowRaised || 0,
                goat: d.goatRaised || 0,
                buffalo: d.buffaloRaised || 0,
                sheep: d.sheepRaised || 0,
                chicken: d.chickenRaised || 0
            };
        } else {
            raised = { cow: 85000, goat: 6000, buffalo: 50000, sheep: 3000, chicken: 2000 };
        }

        updateProgressBar('cow', raised.cow, targets.cow);
        updateProgressBar('goat', raised.goat, targets.goat);
        updateProgressBar('buffalo', raised.buffalo, targets.buffalo);
        updateProgressBar('sheep', raised.sheep, targets.sheep);
        updateProgressBar('chicken', raised.chicken, targets.chicken);

    } catch (err) {
        console.warn('Failed to load live pool data', err);
    }
}

function updateProgressBar(type, raised, target) {
    const pct = Math.min(100, Math.round((raised / target) * 100));
    
    const pctEl = document.getElementById(`${type}FundedPercent`);
    const amtEl = document.getElementById(`${type}FundedAmount`);
    const barEl = document.getElementById(`${type}ProgressBar`);
    const targetEl = document.getElementById(`${type}TargetAmount`);

    if (pctEl) pctEl.textContent = `${pct}%`;
    if (amtEl) amtEl.textContent = `৳${raised.toLocaleString('en-IN')}`;
    if (barEl) barEl.style.width = `${pct}%`;
    if (targetEl) targetEl.textContent = `৳${target.toLocaleString('en-IN')}`;
}

/* ============================================================
   2. PAYMENT GATEWAY
   ============================================================ */
function openPaymentModal(assetName, targetValue, minInvestment) {
    currentAssetName = assetName;
    currentTargetValue = targetValue;
    currentMinInvestment = minInvestment || 5000;
    
    document.getElementById('paymentSubTitle').textContent = `Investing in ${assetName}`;
    document.getElementById('paymentAmountInput').value = '';
    document.getElementById('paymentAmountInput').min = currentMinInvestment;
    document.getElementById('paymentAmountInput').placeholder = currentMinInvestment;
    
    const minLabel = document.getElementById('minInvestmentLabel');
    if (minLabel) {
        minLabel.textContent = `Minimum investment: ৳${currentMinInvestment.toLocaleString('en-IN')}`;
    }

    document.getElementById('payNowBtn').disabled = true;
    document.getElementById('paymentModal').style.display = 'flex';
    
    const firstMethod = document.querySelector('.pm-card');
    if(firstMethod) selectPaymentMethod(firstMethod);
}

function closePaymentModal() {
    document.getElementById('paymentModal').style.display = 'none';
}

function selectPaymentMethod(el) {
    document.querySelectorAll('.pm-card').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
    currentPaymentMethod = el.querySelector('input').value;
}

function updatePaymentButton() {
    const amount = Number(document.getElementById('paymentAmountInput').value);
    document.getElementById('payNowBtn').disabled = !(amount >= currentMinInvestment);
}

async function processRealPayment() {
    const amount = Number(document.getElementById('paymentAmountInput').value);
    if (amount < currentMinInvestment) return;

    const btn = document.getElementById('payNowBtn');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Connecting to Gateway...';
    btn.disabled = true;

    setTimeout(async () => {
        try {
            const investRef = _fs().collection('users').doc(currentUserPhone).collection('investments').doc();
            await investRef.set({
                animalName: currentAssetName,
                amount,
                targetValue: currentTargetValue,
                sharePercentage: ((amount / currentTargetValue) * 100).toFixed(2),
                status: 'active',
                paymentMethod: currentPaymentMethod,
                transactionId: 'TXN-' + Date.now().toString().slice(-8),
                roiPercent: 15,
                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                createdAtMs: Date.now()
            });

            try {
                const poolRef = _fs().collection('meta').doc('funding_pools');
                const poolDoc = await poolRef.get();
                
                let field = 'cowRaised';
                if (currentAssetName.includes('Goat')) field = 'goatRaised';
                else if (currentAssetName.includes('Buffalo')) field = 'buffaloRaised';
                else if (currentAssetName.includes('Sheep')) field = 'sheepRaised';
                else if (currentAssetName.includes('Chicken')) field = 'chickenRaised';
                
                if (poolDoc.exists) {
                    await poolRef.update({ [field]: firebase.firestore.FieldValue.increment(amount) });
                } else {
                    await poolRef.set({ [field]: amount });
                }
            } catch (poolErr) { console.warn('[Payment] Pool update failed:', poolErr.message); }

            try {
                await _fs().collection('users').doc(currentUserPhone).collection('ai_action_plans').add({
                    action: 'micro_investment',
                    summary: `Invested ৳${amount.toLocaleString('en-IN')} in ${currentAssetName} via ${currentPaymentMethod.toUpperCase()}`,
                    status: 'executed',
                    createdAtMs: Date.now(),
                    createdAt: firebase.firestore.FieldValue.serverTimestamp()
                });
            } catch(logErr) { console.warn('Log failed:', logErr.message); }

            btn.innerHTML = '<i class="fas fa-check-circle"></i> Payment Successful';
            btn.style.background = '#059669';
            
            setTimeout(() => {
                closePaymentModal();
                loadInvestmentPortfolio();
                loadLiveFundingData();
                alert(`✅ Payment Successful!\n\nYou invested ৳${amount.toLocaleString('en-IN')} in ${currentAssetName} using ${currentPaymentMethod.toUpperCase()}.`);
                btn.innerHTML = 'Pay Securely';
                btn.style.background = '';
            }, 1200);

        } catch (err) {
            console.error('Payment failed:', err);
            alert('❌ Payment failed: ' + (err.message || 'Please try again.'));
            btn.innerHTML = 'Pay Securely';
            btn.disabled = false;
        }
    }, 2000); 
}

/* ============================================================
   3. PORTFOLIO & TRANSACTIONS
   ============================================================ */
async function loadInvestmentPortfolio() {
    const list = document.getElementById('investmentLedger');
    if (!list) return;

    try {
        const snap = await _fs().collection('users').doc(currentUserPhone)
            .collection('investments').orderBy('createdAtMs', 'desc').get();

        if (snap.empty) {
            list.innerHTML = '<div style="text-align:center; padding:1rem; color:#64748b;">No active investments yet.</div>';
            loadTransactions(); 
            return;
        }

        let html = '';
        snap.forEach(doc => {
            const d = doc.data();
            const date = new Date(d.createdAtMs).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
            
            // ROI Calculation (1.25% monthly based on 15% annual)
            const monthlyROI = Math.round(d.amount * 0.0125); 
            
            html += `
                <div class="ledger-item">
                    <div class="li-left">
                        <div class="li-title">${d.animalName}</div>
                        <div class="li-date">${date} • Share: ${d.sharePercentage}%</div>
                    </div>
                    <div class="li-right" style="display:flex; align-items:center; gap:10px;">
                        <div style="text-align:right;">
                            <div class="li-val">৳ ${d.amount.toLocaleString('en-IN')}</div>
                            <div class="li-status">ACTIVE</div>
                        </div>
                        <!-- 🆕 Withdraw Button -->
                        <button onclick="withdrawROI('${d.animalName}', ${monthlyROI})" style="padding:6px 10px; background:#10b981; color:#fff; border:none; border-radius:6px; font-weight:bold; font-size:0.75rem; cursor:pointer;">
                            Claim ROI
                        </button>
                    </div>
                </div>`;
        });
        list.innerHTML = html;
        loadTransactions(); 
    } catch (e) { console.warn(e); }
}

async function withdrawROI(assetName, roiAmount) {
    if (!confirm(`Claim ৳${roiAmount} ROI for ${assetName} to your bKash?`)) return;

    try {
        await _fs().collection('users').doc(currentUserPhone).collection('transactions').add({
            type: 'ROI Claim',
            assetName: assetName,
            amount: roiAmount,
            method: 'bKash',
            status: 'completed',
            date: new Date().toLocaleDateString(),
            createdAtMs: Date.now()
        });

        alert(`✅ Success! ৳${roiAmount} has been sent to your bKash account.`);
        loadTransactions(); 

        await _fs().collection('users').doc(currentUserPhone).collection('ai_action_plans').add({
            action: 'roi_claim',
            summary: `Claimed ৳${roiAmount} ROI from ${assetName}.`,
            status: 'executed',
            createdAtMs: Date.now(),
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch(e) { console.error(e); }
}

async function loadTransactions() {
    const list = document.getElementById('transactionHistory');
    if (!list) return;

    const snap = await _fs().collection('users').doc(currentUserPhone)
        .collection('transactions').orderBy('createdAtMs', 'desc').get();

    if (snap.empty) {
        list.innerHTML = '<div style="text-align:center; padding:1rem; color:#64748b;">No transactions yet.</div>';
        return;
    }

    list.innerHTML = snap.docs.map(doc => {
        const d = doc.data();
        return `
            <div class="ledger-item" style="background:#f0fdf4; border-color:#bbf7d0;">
                <div class="li-left">
                    <div class="li-title" style="color:#166534;">${d.type}: ${d.assetName}</div>
                    <div class="li-date">${d.date} • ${d.method}</div>
                </div>
                <div class="li-right">
                    <div class="li-val" style="color:#166534;">+ ৳ ${d.amount}</div>
                    <div class="li-status" style="background:#dcfce7;">${d.status}</div>
                </div>
            </div>
        `;
    }).join('');
}

/* ============================================================
   4. CARBON CREDITS & SELLING
   ============================================================ */
function openCarbonUpload(source) {
    currentCarbonSource = source;
    document.getElementById('modalSourceName').textContent = source;
    document.getElementById('carbonModal').style.display = 'flex';
    
    carbonImageBase64 = null;
    document.getElementById('carbonPreviewImg').style.display = 'none';
    document.getElementById('carbonPreviewImg').src = '';
    document.getElementById('carbonAiStatus').style.display = 'none';
    document.getElementById('carbonSubmitBtn').disabled = true;
}

function closeCarbonModal() {
    document.getElementById('carbonModal').style.display = 'none';
}

async function handleCarbonImage(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        carbonImageBase64 = e.target.result;
        const img = document.getElementById('carbonPreviewImg');
        img.src = carbonImageBase64;
        img.style.display = 'block';
        document.getElementById('carbonSubmitBtn').disabled = false;
    };
    reader.readAsDataURL(file);
}

async function processCarbonVerification() {
    if (!carbonImageBase64) return;

    const btn = document.getElementById('carbonSubmitBtn');
    const statusBox = document.getElementById('carbonAiStatus');
    
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> AI Analyzing...';
    statusBox.style.display = 'block';
    statusBox.className = 'ai-status ai-loading';
    statusBox.innerHTML = 'Verifying image with AI Vision... Please wait.';

    const prompt = `You are a carbon credit verification AI. The user claims they have a "${currentCarbonSource}" setup.
Analyze this image. Does the image clearly show a ${currentCarbonSource}?
If yes, reply ONLY with valid JSON: {"valid": true, "credits": 50, "reason": "Verified ${currentCarbonSource}"}
If no, reply ONLY: {"valid": false, "reason": "Image does not match ${currentCarbonSource}"}`;

    try {
        let success = false;
        let resultData = null;

        for (const key of GEMINI_KEYS) {
            if (success) break;
            try {
                const res = await fetch(`${API_URL}/${VISION_MODEL}:generateContent?key=${key}`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        contents: [{
                            role: 'user',
                            parts: [
                                { inline_data: { mime_type: 'image/jpeg', data: carbonImageBase64.split(',')[1] } },
                                { text: prompt }
                            ]
                        }],
                        generationConfig: { temperature: 0.1, responseMimeType: 'application/json' }
                    })
                });

                if (!res.ok) continue;
                const data = await res.json();
                const raw = (data.candidates?.[0]?.content?.parts || []).find(p => p.text)?.text;
                if (!raw) continue;

                resultData = JSON.parse(raw.replace(/```json/gi, '').replace(/```/g, '').trim());
                success = true;
            } catch (e) { console.warn('Key failed:', e); }
        }

        if (!success || !resultData) throw new Error('AI service unavailable.');

        if (resultData.valid === true) {
            const credits = resultData.credits || 50;
            const valueBdt = credits * 250;

            await _fs().collection('users').doc(currentUserPhone).collection('carbon_credits').add({
                source: currentCarbonSource,
                credits,
                valueBdt,
                status: 'verified',
                aiReason: resultData.reason,
                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                createdAtMs: Date.now()
            });

            await _fs().collection('users').doc(currentUserPhone).collection('ai_action_plans').add({
                action: 'carbon_credit',
                summary: `AI verified ${currentCarbonSource}. Earned ${credits} credits.`,
                status: 'executed',
                createdAtMs: Date.now(),
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            statusBox.className = 'ai-status ai-success';
            statusBox.innerHTML = `<i class="fas fa-check-circle"></i> Verified! You earned ${credits} Carbon Credits (≈ ৳${valueBdt.toLocaleString()}).`;
            
            setTimeout(() => {
                closeCarbonModal();
                loadCarbonBalance();
            }, 2000);
        } else {
            statusBox.className = 'ai-status ai-error';
            statusBox.innerHTML = `<i class="fas fa-times-circle"></i> Fraud Detected: ${resultData.reason || 'Image does not match.'}`;
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-robot"></i> AI Verify & Claim Credits';
        }

    } catch (err) {
        console.error(err);
        statusBox.className = 'ai-status ai-error';
        statusBox.innerHTML = `<i class="fas fa-exclamation-triangle"></i> Verification failed. Please try again.`;
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-robot"></i> AI Verify & Claim Credits';
    }
}

async function loadCarbonBalance() {
    const list = document.getElementById('carbonLedger');
    const totalEl = document.getElementById('totalCarbonCredits');
    if (!list || !totalEl) return;

    try {
        const snap = await _fs().collection('users').doc(currentUserPhone)
            .collection('carbon_credits').orderBy('createdAtMs', 'desc').get();

        let totalCredits = 0;
        let totalValue = 0;
        let html = '';

        snap.forEach(doc => {
            const d = doc.data();
            totalCredits += d.credits;
            totalValue += d.valueBdt;
            
            const date = new Date(d.createdAtMs).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
            html += `
                <div class="ledger-item">
                    <div class="li-left">
                        <div class="li-title">${d.source}</div>
                        <div class="li-date">${date} • AI Verified</div>
                    </div>
                    <div class="li-right">
                        <div class="li-val">${d.credits} Credits</div>
                        <div class="li-status">৳ ${d.valueBdt.toLocaleString()}</div>
                    </div>
                </div>`;
        });

        totalEl.textContent = totalCredits.toFixed(2);
        const usdEl = document.querySelector('.cb-usd');
        if (usdEl) usdEl.textContent = `≈ ৳${totalValue.toLocaleString('en-IN')} BDT`;

        list.innerHTML = html || '<div style="text-align:center; padding:1rem; color:#64748b;">No carbon credits yet.</div>';
    } catch (e) { console.warn(e); }
}

async function sellCarbonCredits() {
    const totalEl = document.getElementById('totalCarbonCredits');
    const credits = parseFloat(totalEl.textContent) || 0;
    
    if (credits <= 0) return alert("You don't have any carbon credits to sell.");

    const valueUSD = (credits * 2).toFixed(2); // 1 Credit = $2
    const valueBDT = Math.round(valueUSD * 120); // 1 USD = 120 BDT

    if (!confirm(`Sell ${credits} Carbon Credits for $${valueUSD} (≈ ৳${valueBDT})?`)) return;

    try {
        await _fs().collection('users').doc(currentUserPhone).collection('transactions').add({
            type: 'Carbon Sale',
            assetName: `${credits} Credits`,
            amount: valueBDT,
            method: 'Bank Transfer',
            status: 'completed',
            date: new Date().toLocaleDateString(),
            createdAtMs: Date.now()
        });

        // Clear carbon credits
        const snap = await _fs().collection('users').doc(currentUserPhone).collection('carbon_credits').get();
        const batch = _fs().batch();
        snap.forEach(doc => batch.delete(doc.ref));
        await batch.commit();

        alert(`✅ Sold Successfully!\n\nYou received $${valueUSD} (৳${valueBDT}) in your bank.`);
        loadCarbonBalance();
        loadTransactions();

    } catch(e) { console.error(e); }
}

/* ============================================================
   EXPORTS
   ============================================================ */
window.openPaymentModal = openPaymentModal;
window.closePaymentModal = closePaymentModal;
window.selectPaymentMethod = selectPaymentMethod;
window.updatePaymentButton = updatePaymentButton;
window.processRealPayment = processRealPayment;
window.switchExtraTab = switchExtraTab;
window.openCarbonUpload = openCarbonUpload;
window.closeCarbonModal = closeCarbonModal;
window.handleCarbonImage = handleCarbonImage;
window.processCarbonVerification = processCarbonVerification;
window.withdrawROI = withdrawROI;
window.sellCarbonCredits = sellCarbonCredits;