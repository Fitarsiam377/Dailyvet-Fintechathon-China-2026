/* ============================================================
 DailyVet — GPS Auto-District Detection for Flood Warning
 ------------------------------------------------------------
 Auto-detects district from GPS. Works with the district
 dropdown without reverse-geocoding (finds nearest district
 from each district's coordinates).
 ============================================================ */
(function () {
'use strict';

/* All districts + coords — matches climate-flood.js */
const DISTRICT_COORDS = {
 dhaka: { lat: 23.8103, lng: 90.4125, name: 'Dhaka' },
 kurigram: { lat: 25.8072, lng: 89.6295, name: 'Kurigram' },
 gaibandha: { lat: 25.3288, lng: 89.5286, name: 'Gaibandha' },
 lalmonirhat:{ lat: 25.9923, lng: 89.2847, name: 'Lalmonirhat' },
 sirajganj: { lat: 24.4533, lng: 89.7009, name: 'Sirajganj' },
 jamalpur: { lat: 24.9375, lng: 89.9372, name: 'Jamalpur' },
 sunamganj: { lat: 25.0658, lng: 91.3950, name: 'Sunamganj' },
 sylhet: { lat: 24.8949, lng: 91.8687, name: 'Sylhet' },
 kishoreganj:{ lat: 24.4449, lng: 90.7766, name: 'Kishoreganj' },
 chandpur: { lat: 23.2333, lng: 90.6711, name: 'Chandpur' },
 shariatpur: { lat: 23.2423, lng: 90.4348, name: 'Shariatpur' },
 munshiganj: { lat: 23.5422, lng: 90.5305, name: 'Munshiganj' },
 bogura: { lat: 24.8465, lng: 89.3773, name: 'Bogura' },
 pabna: { lat: 24.0064, lng: 89.2372, name: 'Pabna' },
 faridpur: { lat: 23.6070, lng: 89.8429, name: 'Faridpur' },
 rangpur: { lat: 25.7439, lng: 89.2752, name: 'Rangpur' },
 chittagong: { lat: 22.3569, lng: 91.7832, name: 'Chittagong' },
 khulna: { lat: 22.8456, lng: 89.5403, name: 'Khulna' },
 barisal: { lat: 22.7010, lng: 90.3535, name: 'Barisal' },
 rajshahi: { lat: 24.3745, lng: 88.6042, name: 'Rajshahi' },
 mymensingh: { lat: 24.7471, lng: 90.4203, name: 'Mymensingh' }
};

/* Find nearest district from a lat/lng using Haversine */
function findNearestDistrict(lat, lng) {
 let nearest = 'dhaka';
 let minDist = Infinity;

 for (const [key, c] of Object.entries(DISTRICT_COORDS)) {
 const d = haversineKm(lat, lng, c.lat, c.lng);
 if (d < minDist) {
 minDist = d;
 nearest = key;
 }
 }
 return { district: nearest, distanceKm: Math.round(minDist), name: DISTRICT_COORDS[nearest].name };
}

/* Haversine distance */
function haversineKm(lat1, lng1, lat2, lng2) {
 const R = 6371;
 const toRad = d => d * Math.PI / 180;
 const dLat = toRad(lat2 - lat1);
 const dLng = toRad(lng2 - lng1);
 const a = Math.sin(dLat / 2) ** 2 +
 Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
 Math.sin(dLng / 2) ** 2;
 return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/* Bangladesh bounds check */
function isInBangladesh(lat, lng) {
 return lat >= 20.0 && lat <= 27.0 && lng >= 87.5 && lng <= 93.5;
}

/* ============================================================
 MAIN FUNCTION — Public API
 ============================================================ */
window.detectMyFloodDistrict = function () {
 const btn = document.getElementById('floodGpsBtn');
 const originalHTML = btn ? btn.innerHTML : '';

 if (!navigator.geolocation) {
 alert('GPS is not supported in your browser. Please select a district from the dropdown.');
 return;
 }

 /* Loading state */
 if (btn) {
 btn.disabled = true;
 btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Searching...</span>';
 }

 navigator.geolocation.getCurrentPosition(
 function (pos) {
 const lat = pos.coords.latitude;
 const lng = pos.coords.longitude;
 const accuracy = Math.round(pos.coords.accuracy);

 if (!isInBangladesh(lat, lng)) {
 if (btn) { btn.disabled = false; btn.innerHTML = originalHTML; }
 alert(
 '❌ Your location appears to be outside Bangladesh.\n' +
 'Coordinates: ' + lat.toFixed(2) + ', ' + lng.toFixed(2) + '\n' +
 'Please select a district from the dropdown.'
 );
 return;
 }

 const result = findNearestDistrict(lat, lng);

 /* Update the district dropdown */
 const select = document.getElementById('climateDistrict');
 if (select) {
 select.value = result.district;
 /* Fire change event so the page reloads with new district */
 select.dispatchEvent(new Event('change', { bubbles: true }));
 }

 /* Update button to show detected location */
 if (btn) {
 btn.disabled = false;
 btn.innerHTML = '<i class="fas fa-check-circle"></i><span>' + result.name + '</span>';
 }

 /* Success feedback */
 console.log('📍 GPS detected:', result);
 },
 function (err) {
 if (btn) { btn.disabled = false; btn.innerHTML = originalHTML; }

 let msg = 'Could not detect location.';
 if (err.code === 1) msg = 'Location permission is denied. Please enable it in browser settings.';
 else if (err.code === 2) msg = 'GPS signal unavailable. Please move to an open area.';
 else if (err.code === 3) msg = 'Location timed out. Please try again.';

 alert('❌ ' + msg);
 },
 {
 enableHighAccuracy: true,
 timeout: 12000,
 maximumAge: 5 * 60 * 1000 /* 5 min cache */
 }
 );
};

/* ============================================================
 Button injection — flood toolbar- 
 ============================================================ */
window.injectFloodGpsButton = function () {
 /* Already injected? skip */
 if (document.getElementById('floodGpsBtn')) return;

 /* Find the flood toolbar */
 const toolbar = document.querySelector('.dvm-toolbar-flood');
 if (!toolbar) {
 console.warn('[FloodGPS] Toolbar not found yet, retrying...');
 return;
 }

 /* Create the button */
 const btn = document.createElement('button');
 btn.type = 'button';
 btn.id = 'floodGpsBtn';
 btn.className = 'dvf-gps-btn dvm-gps-flood';
 btn.title = 'Detect my district from GPS';
 btn.innerHTML = '<i class="fas fa-location-crosshairs"></i><span>My location</span>';
 btn.onclick = window.detectMyFloodDistrict;

 /* Append to toolbar */
 toolbar.appendChild(btn);
 console.log('✅ Flood GPS button injected');
};

/* Auto-inject when DOM ready (with retry) */
document.addEventListener('DOMContentLoaded', function () {
 let attempts = 0;
 const maxAttempts = 20; /* retry for 10 seconds */

 const tryInject = () => {
 if (document.getElementById('floodGpsBtn')) return;
 if (document.querySelector('.dvm-toolbar-flood')) {
 window.injectFloodGpsButton();
 return;
 }
 attempts++;
 if (attempts < maxAttempts) setTimeout(tryInject, 500);
 };

 /* Try after main flood JS has rendered (2 sec delay) */
 setTimeout(tryInject, 2000);
});

console.log('✅ flood-gps-district.js loaded');

})();