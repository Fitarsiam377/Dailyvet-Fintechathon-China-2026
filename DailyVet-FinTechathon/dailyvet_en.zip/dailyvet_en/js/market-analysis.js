/* ============================================================
 DailyVet — Livestock Market Price Analyzer v2.6 (English only)
 ✅ AI output is guaranteed English via DVLangGuard
 ✅ Prompt no longer asks for Bengali script
 ✅ speciesBengali / ageBengali / observationsBengali now
    produced from LOCAL English maps, never from the model
 ✅ Hard limit ~7.5s, staggered hedging, slow-slot penalty
 ✅ Firestore → Google Sheet → localStorage cache → fallback
 ✅ NEW: Link to Insurance (coverage amount)
 ============================================================ */

(function () {
'use strict';

/* ============================================================
 0. GEMINI CONFIG
 ============================================================ */
const MK_GEMINI_KEYS = [
  'AQ.Ab8RN6LBkDemnP94Jsk8jpyoMhv-yE5URct4YnRs-HnM-R6ihQ',
  'AQ.Ab8RN6K2rZlu0_5Q5DS7zbBvk3f4D0aWqRVBPCch_78_qwnkSw',
  'AQ.Ab8RN6LmyF3xejWyuSN7EDCA06eGOVjJp-9qbksPvCEj7GfS6A',
  'AQ.Ab8RN6IcihAmmQyi6HY0pANG6AF-ZXDfpIGYfa_68GoCiCejLQ',
  'AQ.Ab8RN6KDeOwlWCKGPjtrSZ2xBu_e_Aq0coY1nzSJqZiXWaaqpg'
];

const MK_GROQ_KEYS = [];
const MK_OPENROUTER_KEYS = [];

const MK_PROVIDER_KEYS = {
  gemini: MK_GEMINI_KEYS,
  groq: MK_GROQ_KEYS,
  openrouter: MK_OPENROUTER_KEYS
};

const MK_MODELS = {
  gemini: [
    'gemini-3.5-flash-lite',
    'gemini-3.1-flash-lite',
    'gemini-2.5-flash-lite',
    'gemini-3.8-flash',
    'gemini-3.6-flash',
    'gemini-2.5-flash'
  ],
  groq: ['meta-llama/llama-4-scout-17b-16e-instruct', 'llama-3.2-11b-vision-preview'],
  openrouter: ['qwen/qwen2.5-vl-72b-instruct:free']
};

const MK_ENDPOINTS = {
  gemini: 'https://generativelanguage.googleapis.com/v1beta/models',
  groq: 'https://api.groq.com/openai/v1/chat/completions',
  openrouter: 'https://openrouter.ai/api/v1/chat/completions'
};

const MK_TIMING = { total: 7000, perCall: 5000, hedge: 650, parallel: 3 };
const MK_WATCHDOG_EXTRA_MS = 500;

const MK_COOLDOWN = {
  rateLimit: 20e3, rateLimitMax: 12 * 60e3,
  server: 15e3, timeout: 12e3, badRequest: 60e3,
  badOutput: 15e3, slow: 20e3,
  authKey: 6 * 3600e3, modelDead: 24 * 3600e3,
  quotaZero: 6 * 3600e3, perDay: 3 * 3600e3
};

const MK_GEMINI_SAFETY = [
  'HARM_CATEGORY_HARASSMENT',
  'HARM_CATEGORY_HATE_SPEECH',
  'HARM_CATEGORY_SEXUALLY_EXPLICIT',
  'HARM_CATEGORY_DANGEROUS_CONTENT'
].map(category => ({ category, threshold: 'BLOCK_ONLY_HIGH' }));

const MK_MAX_IMAGE_MB = 25;
const MK_IMG_MAX_DIM = 1024;
const MK_TARGET_MAX_BYTES = 0.8 * 1024 * 1024;
const MK_CACHE_TTL_MS = 30 * 60 * 1000;
const MK_CACHE_MAX = 20;

/* ============================================================
 1. SPECIES
 ============================================================ */
const MK_ALLOWED_SPECIES = [
  'cow', 'goat', 'sheep', 'buffalo', 'duck',
  'chicken_broiler', 'chicken_sonali', 'chicken_deshi'
];

const MK_SPECIES_ALIAS = {
  cattle: 'cow', bull: 'cow', ox: 'cow', calf: 'cow', 'beef cattle': 'cow',
  'water buffalo': 'buffalo', 'milk buffalo': 'buffalo',
  'black bengal goat': 'goat', 'bengal goat': 'goat',
  ram: 'sheep', ewe: 'sheep', lamb: 'sheep',
  'domestic duck': 'duck',
  broiler: 'chicken_broiler', 'broiler chicken': 'chicken_broiler',
  'meat chicken': 'chicken_broiler', poultry: 'chicken_broiler',
  'farm chicken': 'chicken_broiler',
  sonali: 'chicken_sonali', 'sonali chicken': 'chicken_sonali',
  'sonali murgi': 'chicken_sonali',
  deshi: 'chicken_deshi', 'deshi chicken': 'chicken_deshi',
  'desi chicken': 'chicken_deshi', 'native chicken': 'chicken_deshi',
  'country chicken': 'chicken_deshi', 'local chicken': 'chicken_deshi',
  hen: 'chicken_deshi', rooster: 'chicken_deshi', cock: 'chicken_deshi',
  chicken: 'chicken_broiler'
};

const MK_SPECIES_EN = {
  cow: 'Cow', goat: 'Goat', sheep: 'Sheep', buffalo: 'Buffalo',
  duck: 'Duck', chicken_broiler: 'Broiler Chicken',
  chicken_sonali: 'Sonali Chicken', chicken_deshi: 'Deshi Chicken'
};

/* ============================================================
 2. MARKET PRICES
 ============================================================ */
const MK_SHEET_CSV_URL = '';

const MK_FALLBACK_PRICES = {
  cow: { meatPerKg: [750, 820], livePerKg: [400, 500], enName: 'Cow' },
  goat: { meatPerKg: [1100, 1300], livePerKg: [700, 900], enName: 'Goat' },
  sheep: { meatPerKg: [1000, 1200], livePerKg: [600, 800], enName: 'Sheep' },
  buffalo: { meatPerKg: [700, 780], livePerKg: [350, 450], enName: 'Buffalo' },
  chicken_broiler: { meatPerKg: [180, 200], livePerKg: [150, 175], enName: 'Broiler Chicken' },
  chicken_sonali: { meatPerKg: [280, 340], livePerKg: [230, 290], enName: 'Sonali Chicken' },
  chicken_deshi: { meatPerKg: [450, 500], livePerKg: [400, 600], enName: 'Deshi Chicken' },
  duck: { meatPerKg: [450, 550], livePerKg: [350, 450], enName: 'Duck' }
};

let MK_CURRENT_PRICES = null;
let MK_PRICE_MONTH = null;
let MK_PRICE_SOURCE = 'fallback';

/* ============================================================
 3. DATE / TIME (English only)
 ============================================================ */
const MK_TZ = 'Asia/Dhaka';
const MK_EN_MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];
const MK_EN_DAYS = [
  'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
];

let _mkDhakaFmt = null;
try {
  _mkDhakaFmt = new Intl.DateTimeFormat('en-US', {
    timeZone: MK_TZ,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
    hourCycle: 'h23'
  });
} catch (_) { _mkDhakaFmt = null; }

function mkNow() {
  if (_mkDhakaFmt) {
    try {
      const p = {};
      _mkDhakaFmt.formatToParts(new Date()).forEach(x => {
        if (x.type !== 'literal') p[x.type] = x.value;
      });
      const y = +p.year, mo = +p.month, d = +p.day;
      let h = +p.hour; if (h === 24) h = 0;
      return { y, mo, d, h, mi: +p.minute, s: +p.second, wd: new Date(Date.UTC(y, mo - 1, d)).getUTCDay() };
    } catch (_) {}
  }
  const n = new Date();
  return { y: n.getFullYear(), mo: n.getMonth() + 1, d: n.getDate(), h: n.getHours(), mi: n.getMinutes(), s: n.getSeconds(), wd: n.getDay() };
}

const _pad2 = n => String(n).padStart(2, '0');
function mkCurrentMonthKey() { const n = mkNow(); return `${n.y}-${_pad2(n.mo)}`; }
function mkCurrentDayKey() { const n = mkNow(); return `${n.y}-${_pad2(n.mo)}-${_pad2(n.d)}`; }

function mkTodayEnFull() {
  const n = mkNow();
  return `${MK_EN_DAYS[n.wd]}, ${n.d} ${MK_EN_MONTHS[n.mo - 1]} ${n.y}`;
}
function _mkPeriodEn(h) { return h < 12 ? 'AM' : 'PM'; }
function mkTimeEn(withSeconds = true) {
  const n = mkNow();
  const h12 = n.h % 12 || 12;
  const base = `${h12}:${_pad2(n.mi)}`;
  return `${base}${withSeconds ? ':' + _pad2(n.s) : ''} ${_mkPeriodEn(n.h)}`;
}
function mkNowEnFull(withSeconds = false) { return `${mkTodayEnFull()} · ${mkTimeEn(withSeconds)}`; }

function mkFormatPriceDateEn(key) {
  if (!key) return '—';
  let m = /^(\d{4})-(\d{2})$/.exec(key);
  if (m) {
    const mo = +m[2];
    if (mo < 1 || mo > 12) return '—';
    return `${MK_EN_MONTHS[mo - 1]} ${m[1]}`;
  }
  m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(key);
  if (m) {
    const mo = +m[2];
    if (mo < 1 || mo > 12) return '—';
    return `${+m[3]} ${MK_EN_MONTHS[mo - 1]} ${m[1]}`;
  }
  return '—';
}

/* ============================================================
 4. HERO CLOCK
 ============================================================ */
let _mkLastDayKey = null;
let _mkClockTimer = null;

function mkUpdateClock() {
  const dateEl = _el('mkHeroDate');
  const timeEl = _el('mkHeroTime');
  const refEl  = _el('mkRefDate');
  if (dateEl && timeEl) {
    dateEl.textContent = mkTodayEnFull();
    timeEl.textContent = mkTimeEn(true);
  } else if (dateEl) dateEl.textContent = mkNowEnFull(true);
  else if (timeEl) timeEl.textContent = mkTimeEn(true);
  if (refEl) refEl.textContent = 'Reference Rates';

  const dayKey = mkCurrentDayKey();
  if (_mkLastDayKey && _mkLastDayKey !== dayKey) { _mkLastDayKey = dayKey; loadMarketPrices(); }
  else if (!_mkLastDayKey) _mkLastDayKey = dayKey;
}

function mkStartClock() {
  mkUpdateClock();
  if (_mkClockTimer) clearInterval(_mkClockTimer);
  _mkClockTimer = setInterval(mkUpdateClock, 1000);
}

/* ============================================================
 5. PRICE LOADERS
 ============================================================ */
const _mkWithTimeout = (promise, ms) =>
  Promise.race([promise, new Promise(r => setTimeout(() => r(null), ms))]);

function _mkNormalizePriceEntry(entry) {
  if (!entry || typeof entry !== 'object') return null;
  const meat = Array.isArray(entry.meatPerKg) && entry.meatPerKg.length === 2
    ? [Number(entry.meatPerKg[0]) || 0, Number(entry.meatPerKg[1]) || 0] : null;
  const live = Array.isArray(entry.livePerKg) && entry.livePerKg.length === 2
    ? [Number(entry.livePerKg[0]) || 0, Number(entry.livePerKg[1]) || 0] : null;
  if (!meat || !live) return null;
  return { meatPerKg: meat, livePerKg: live, enName: entry.enName || '' };
}

function _mkNormalizePriceTable(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const out = {};
  let valid = 0;
  Object.keys(raw).forEach(k => {
    const norm = _mkNormalizePriceEntry(raw[k]);
    if (norm) { out[k.toLowerCase()] = norm; valid++; }
  });
  return valid > 0 ? out : null;
}

async function _mkLoadFromFirestore(monthKey, dayKey) {
  if (!window.firebase || !firebase.firestore) return null;
  try {
    const db = firebase.firestore();
    if (dayKey) {
      const dayDoc = await db.collection('market_prices').doc(dayKey).get();
      if (dayDoc.exists) {
        const prices = _mkNormalizePriceTable(dayDoc.data()?.prices);
        if (prices) return { prices, month: dayKey, source: 'firestore' };
      }
    }
    const monthDoc = await db.collection('market_prices').doc(monthKey).get();
    if (monthDoc.exists) {
      const prices = _mkNormalizePriceTable(monthDoc.data()?.prices);
      if (prices) return { prices, month: monthKey, source: 'firestore' };
    }
    const latest = await db.collection('market_prices').orderBy('__name__', 'desc').limit(1).get();
    if (!latest.empty) {
      const prices = _mkNormalizePriceTable(latest.docs[0].data()?.prices);
      if (prices) return { prices, month: latest.docs[0].id, source: 'firestore' };
    }
  } catch (err) { console.warn('[Market] Firestore load failed:', err.message); }
  return null;
}

async function _mkLoadFromSheet(monthKey) {
  if (!MK_SHEET_CSV_URL) return null;
  try {
    const res = await fetch(MK_SHEET_CSV_URL, { cache: 'no-store' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const csv = await res.text();
    const lines = csv.split(/\r?\n/).filter(Boolean);
    if (lines.length < 2) return null;
    const header = lines[0].split(',').map(s => s.trim().toLowerCase());
    const idx = {
      month: header.indexOf('month'), species: header.indexOf('species'),
      meatMin: header.indexOf('meat_min'), meatMax: header.indexOf('meat_max'),
      liveMin: header.indexOf('live_min'), liveMax: header.indexOf('live_max')
    };
    if (idx.month < 0 || idx.species < 0) return null;
    const byMonth = {};
    let latestMonth = null;
    lines.slice(1).forEach(line => {
      const cols = line.split(',').map(s => s.trim());
      const m = cols[idx.month];
      const species = (cols[idx.species] || '').toLowerCase();
      if (!m || !species || !/^\d{4}-\d{2}$/.test(m)) return;
      if (!byMonth[m]) byMonth[m] = {};
      byMonth[m][species] = {
        meatPerKg: [Number(cols[idx.meatMin]) || 0, Number(cols[idx.meatMax]) || 0],
        livePerKg: [Number(cols[idx.liveMin]) || 0, Number(cols[idx.liveMax]) || 0],
        enName: ''
      };
      if (!latestMonth || m > latestMonth) latestMonth = m;
    });
    if (byMonth[monthKey]) return { prices: byMonth[monthKey], month: monthKey, source: 'sheet' };
    if (latestMonth && byMonth[latestMonth]) return { prices: byMonth[latestMonth], month: latestMonth, source: 'sheet' };
  } catch (err) { console.warn('[Market] Sheet load failed:', err.message); }
  return null;
}

const MK_PRICE_CACHE_KEY = 'dvMarketPricesCache_v1';
function _mkSaveCacheToLocal() {
  try {
    localStorage.setItem(MK_PRICE_CACHE_KEY, JSON.stringify({
      prices: MK_CURRENT_PRICES, month: MK_PRICE_MONTH,
      source: MK_PRICE_SOURCE, cachedAt: Date.now()
    }));
  } catch (_) {}
}
function _mkLoadCacheFromLocal() {
  try {
    const raw = localStorage.getItem(MK_PRICE_CACHE_KEY);
    if (!raw) return null;
    const obj = JSON.parse(raw);
    if (!obj || !obj.prices || !obj.month) return null;
    if (obj.cachedAt && Date.now() - obj.cachedAt > 90 * 24 * 3600e3) return null;
    return { prices: obj.prices, month: obj.month };
  } catch (_) { return null; }
}

function _mkApplyPrices(result, source) {
  MK_CURRENT_PRICES = { ...MK_FALLBACK_PRICES, ...result.prices };
  MK_PRICE_MONTH = result.month;
  MK_PRICE_SOURCE = source;
}

async function loadMarketPrices() {
  const monthKey = mkCurrentMonthKey();
  const dayKey = mkCurrentDayKey();
  MK_PRICE_MONTH = MK_PRICE_MONTH || monthKey;

  let result = await _mkWithTimeout(_mkLoadFromFirestore(monthKey, dayKey), 3000);
  if (result) { _mkApplyPrices(result, result.source); _mkSaveCacheToLocal(); return; }

  result = await _mkWithTimeout(_mkLoadFromSheet(monthKey), 3000);
  if (result) { _mkApplyPrices(result, result.source); _mkSaveCacheToLocal(); return; }

  const cached = _mkLoadCacheFromLocal();
  if (cached) { _mkApplyPrices(cached, 'cache'); return; }

  MK_CURRENT_PRICES = MK_FALLBACK_PRICES;
  MK_PRICE_MONTH = monthKey;
  MK_PRICE_SOURCE = 'fallback';
}

/* ============================================================
 6. STATE
 ============================================================ */
let mkSelectedImage = null;
let mkCurrentPhone = null;
let mkScanning = false;
let mkLastAnalysis = null;
let mkLastProviderInfo = null;

/* ============================================================
 7. HELPERS
 ============================================================ */
function _el(id) { return document.getElementById(id); }
const _lsGet = k => { try { return localStorage.getItem(k); } catch (_) { return null; } };
const _lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (_) {} };

function escapeHtmlMK(text) {
  const div = document.createElement('div');
  div.textContent = String(text ?? '');
  return div.innerHTML;
}

function _mkParseJSON(raw) {
  if (!raw || typeof raw !== 'string') return null;
  const t = raw.replace(/<think>[\s\S]*?<\/think>/gi, '').replace(/```(?:json)?/gi, '').trim();
  try { return JSON.parse(t); } catch (_) {}
  const m = t.match(/\{[\s\S]*\}/);
  if (m) { try { return JSON.parse(m[0]); } catch (_) {} }
  return null;
}

function _mkParseImage(img) {
  const m = /^data:([^;]+);base64,(.*)$/.exec(img || '');
  return m ? { mime: m[1], data: m[2] } : { mime: 'image/jpeg', data: img };
}

/* ============================================================
 8. BLOCK REGISTRY
 ============================================================ */
const MK_BLOCK_STORE = 'dvMarketBlocks';
const _mkBlocks = new Map();
const _mkStrikes = new Map();
const _mkRot = { gemini: 0, groq: 0, openrouter: 0 };

(function _mkLoadBlocks() {
  try {
    Object.entries(JSON.parse(_lsGet(MK_BLOCK_STORE) || '{}')).forEach(([id, until]) => {
      if (until > Date.now()) _mkBlocks.set(id, until);
    });
  } catch (_) {}
})();

const _mkTail = k => k.slice(-8);
const _mkKeyId = s => `k:${s.provider}:${_mkTail(s.key)}`;
const _mkModelId = s => `m:${s.provider}:${s.model}`;
const _mkIsBlocked = id => (_mkBlocks.get(id) || 0) > Date.now();
const _mkSlotBlocked = s => _mkIsBlocked(s.id) || _mkIsBlocked(_mkKeyId(s)) || _mkIsBlocked(_mkModelId(s));

function _mkBlock(id, ms) {
  _mkBlocks.set(id, Date.now() + ms);
  const live = {};
  _mkBlocks.forEach((until, k) => { if (until > Date.now()) live[k] = until; });
  _lsSet(MK_BLOCK_STORE, JSON.stringify(live));
}

const _mkValidKeys = provider =>
  (MK_PROVIDER_KEYS[provider] || []).filter(k => k && !/^YOUR_/i.test(k));

function _mkInterleave(lists) {
  const out = [];
  const idx = lists.map(() => 0);
  let added = true;
  while (added) {
    added = false;
    lists.forEach((list, i) => {
      if (idx[i] < list.length) { out.push(list[idx[i]++]); added = true; }
    });
  }
  return out;
}

function _mkBuildSlots() {
  const perProvider = ['gemini', 'groq', 'openrouter'].map(provider => {
    const keys = _mkValidKeys(provider);
    if (!keys.length) return [];
    const shift = _mkRot[provider] % keys.length;
    const rotated = keys.slice(shift).concat(keys.slice(0, shift));
    const seen = new Set();
    const out = [];
    for (const model of MK_MODELS[provider]) {
      for (const key of rotated) {
        const id = `s:${provider}:${model}:${_mkTail(key)}`;
        if (seen.has(id)) continue;
        seen.add(id);
        out.push({ provider, model, key, id });
      }
    }
    return out;
  });
  const live = _mkInterleave(perProvider.map(list => list.filter(s => !_mkSlotBlocked(s))));
  if (live.length) return live;
  return _mkInterleave(perProvider.map(list => list.filter(s =>
    !_mkIsBlocked(_mkKeyId(s)) && !_mkIsBlocked(_mkModelId(s))
  ))).slice(0, 4);
}

/* ============================================================
 9. IMAGE COMPRESSION
 ============================================================ */
function compressMKImage(file, maxDim = MK_IMG_MAX_DIM, quality = 0.82) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          const scale = maxDim / Math.max(width, height);
          width = Math.round(width * scale);
          height = Math.round(height * scale);
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        canvas.getContext('2d').drawImage(img, 0, 0, width, height);
        let q = quality;
        let dataUrl = canvas.toDataURL('image/jpeg', q);
        for (let i = 0; i < 5 && dataUrl.length * 0.75 > MK_TARGET_MAX_BYTES && q > 0.4; i++) {
          q -= 0.12;
          dataUrl = canvas.toDataURL('image/jpeg', q);
        }
        resolve(dataUrl);
      };
      img.onerror = () => reject(new Error('Image decode failed'));
      img.src = e.target.result;
    };
    reader.onerror = () => reject(new Error('File read failed'));
    reader.readAsDataURL(file);
  });
}

/* ============================================================
 10. AI PROMPT — ENGLISH ONLY
 ============================================================ */
const MK_PROMPT = `You are a veterinary livestock market analyst for Bangladesh.

Analyze the attached photo of a farm animal (cow, goat, sheep, buffalo, chicken, duck).

Your task:
1. Identify the animal species and breed (if visible)
2. Estimate age in months/years
3. Estimate live weight in kg (range)
4. Estimate meat yield in kg (approximately 55-65% of live weight for cattle, 45-55% for goat/sheep, 65-70% for poultry)
5. Assess general health/body condition
6. Give confidence percentage

STRICT RULES:
- Reply ONLY in clean English. Do NOT use Bengali, Hindi, or any non-English script or romanized words.
- ONLY analyze: cow, goat, sheep, buffalo, chicken, duck
- "species" MUST be exactly one of:
  cow, goat, sheep, buffalo, duck,
  chicken_broiler, chicken_sonali, chicken_deshi
- For CHICKENS, identify the type from physical appearance:
  * "chicken_broiler" = white feathered, heavy breast, plump body
  * "chicken_sonali" = reddish-brown / brown-golden feathered, medium size
  * "chicken_deshi" = small native chicken, mixed/colorful feathers, long legs
  * If unclear → use "chicken_broiler"
  * NEVER output just "chicken"
- If image shows dog, cat, bird, or non-farm animal → return error
- Give realistic estimates based on Bangladesh market animals

Return ONLY valid JSON (no markdown):
{
  "status": "success",
  "species": "cow",
  "breed": "Local Deshi / Crossbreed / etc",
  "ageMonths": 24,
  "liveWeightKg": 350,
  "liveWeightRange": { "min": 300, "max": 400 },
  "meatYieldKg": 210,
  "bodyCondition": "Good — normal frame, no signs of artificial fattening",
  "confidencePercentage": 78,
  "observations": "The animal has normal height and proportions. Healthy body condition."
}

If NOT a farm animal:
{
  "status": "error",
  "error": "not_farm_animal",
  "errorEnglish": "This analysis is only for livestock. Please upload a cow, goat, sheep, buffalo, chicken, or duck."
}

IMPORTANT:
- Return ONLY the JSON. No markdown.
- All text fields MUST be in English.
- Weight estimation is approximate.`;

const MK_USER_NUDGE = 'Analyze this farm animal. Reply with JSON only, in English.';

/* ============================================================
 11. NORMALIZE AI OUTPUT — English-only enforced
 ============================================================ */
function _mkNormalize(d) {
  if (!d || typeof d !== 'object') return null;

  if (d.status === 'error') {
    return {
      status: 'error',
      error: String(d.error || 'not_supported'),
      errorEnglish: String(d.errorEnglish || 'This analysis is only for livestock.')
    };
  }

  let species = String(d.species || '').toLowerCase().trim();
  species = MK_SPECIES_ALIAS[species] || species;
  if (!MK_ALLOWED_SPECIES.includes(species)) {
    if (species.startsWith('chicken')) species = 'chicken_broiler';
    else {
      return {
        status: 'error',
        error: 'not_farm_animal',
        errorEnglish: 'Please upload a cow, goat, sheep, buffalo, chicken, or duck.'
      };
    }
  }

  const w = Number(d.liveWeightKg);
  if (!isFinite(w) || w < 0.3 || w > 2000) return null;
  const liveWeight = Math.round(w * 10) / 10;

  let min = Number(d.liveWeightRange?.min);
  let max = Number(d.liveWeightRange?.max);
  if (!isFinite(min) || !isFinite(max) || min <= 0 || min > liveWeight || max < liveWeight) {
    min = Math.round(liveWeight * 0.88 * 10) / 10;
    max = Math.round(liveWeight * 1.12 * 10) / 10;
  }

  const meat = Number(d.meatYieldKg);
  const meatYield = isFinite(meat) && meat > 0 && meat < liveWeight ? Math.round(meat * 10) / 10 : null;

  const ageM = Number(d.ageMonths);
  const ageMonths = isFinite(ageM) && ageM > 0 ? Math.round(ageM) : null;

  let conf = Number(d.confidencePercentage);
  if (!isFinite(conf)) conf = 60;
  conf = Math.max(0, Math.min(100, Math.round(conf)));

  return {
    status: 'success',
    species,
    speciesEnglish: MK_SPECIES_EN[species] || '—',
    breed: String(d.breed || '').trim(),
    ageMonths,
    liveWeightKg: liveWeight,
    liveWeightRange: { min, max },
    meatYieldKg: meatYield,
    bodyCondition: String(d.bodyCondition || '').trim(),
    confidencePercentage: conf,
    observations: String(d.observations || '').trim()
  };
}

/* ============================================================
 12. REQUEST BUILDERS
 ============================================================ */
function _mkGeminiRequest(slot, img) {
  const { mime, data } = _mkParseImage(img);
  const generationConfig = {
    temperature: 0.15, maxOutputTokens: 900, topP: 0.95,
    responseMimeType: 'application/json'
  };
  if (slot.model.includes('2.5')) generationConfig.thinkingConfig = { thinkingBudget: 0 };
  return {
    url: `${MK_ENDPOINTS.gemini}/${slot.model}:generateContent?key=${slot.key}`,
    headers: { 'Content-Type': 'application/json' },
    body: {
      contents: [{
        role: 'user',
        parts: [
          { inline_data: { mime_type: mime, data } },
          { text: MK_PROMPT }
        ]
      }],
      generationConfig,
      safetySettings: MK_GEMINI_SAFETY
    }
  };
}

function _mkChatRequest(slot, img) {
  const url = img.startsWith('data:') ? img : `data:image/jpeg;base64,${img}`;
  const headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${slot.key}` };
  if (slot.provider === 'openrouter') {
    headers['HTTP-Referer'] = location.origin || 'https://dailyvet.app';
    headers['X-Title'] = 'DailyVet Market';
  }
  return {
    url: MK_ENDPOINTS[slot.provider],
    headers,
    body: {
      model: slot.model,
      messages: [
        { role: 'system', content: MK_PROMPT },
        {
          role: 'user',
          content: [
            { type: 'text', text: MK_USER_NUDGE },
            { type: 'image_url', image_url: { url } }
          ]
        }
      ],
      temperature: 0.15,
      max_tokens: 900
    }
  };
}

/* ============================================================
 13. HTTP ERROR HANDLER
 ============================================================ */
function _mkOnHttpError(slot, status, retryAfter, bodyText) {
  const body = String(bodyText || '').slice(0, 500);
  if (status === 429) {
    const n = (_mkStrikes.get(slot.id) || 0) + 1;
    _mkStrikes.set(slot.id, n);
    const hinted = (parseInt(retryAfter, 10) || 0) * 1000;
    let ms = Math.min(Math.max(hinted, MK_COOLDOWN.rateLimit * 2 ** (n - 1)), MK_COOLDOWN.rateLimitMax);
    if (/limit:\s*0/i.test(body)) ms = MK_COOLDOWN.quotaZero;
    else if (/PerDay|per\s*day/i.test(body)) ms = MK_COOLDOWN.perDay;
    _mkBlock(slot.id, ms);
  } else if (status === 400) {
    if (/api[_ ]key (?:not valid|invalid|expired)|API_KEY_INVALID|key expired/i.test(body))
      _mkBlock(_mkKeyId(slot), MK_COOLDOWN.authKey);
    else
      _mkBlock(slot.id, MK_COOLDOWN.badRequest);
  } else if (status === 401 || status === 403) {
    _mkBlock(_mkKeyId(slot), MK_COOLDOWN.authKey);
  } else if (status === 404) {
    _mkBlock(_mkModelId(slot), MK_COOLDOWN.modelDead);
  } else if (status >= 500 || status === 408) {
    _mkBlock(slot.id, MK_COOLDOWN.server);
  }
}

/* ============================================================
 14. SLOT CALL
 ============================================================ */
async function _mkCallSlot(slot, img, ctrl, timeoutMs, strictEnglish) {
  let timedOut = false;
  const timer = setTimeout(() => { timedOut = true; ctrl.abort(); }, timeoutMs);
  try {
    const req = slot.provider === 'gemini'
      ? _mkGeminiRequest(slot, img)
      : _mkChatRequest(slot, img);

    const res = await fetch(req.url, {
      method: 'POST',
      headers: req.headers,
      body: JSON.stringify(req.body),
      signal: ctrl.signal
    });

    if (!res.ok) {
      const errBody = await res.text().catch(() => '');
      _mkOnHttpError(slot, res.status, res.headers.get('retry-after'), errBody);
      return null;
    }

    const data = await res.json();
    let raw;
    if (slot.provider === 'gemini') {
      raw = (data.candidates?.[0]?.content?.parts || [])
        .filter(p => p && p.text && !p.thought)
        .map(p => p.text).join('');
    } else {
      raw = data.choices?.[0]?.message?.content;
    }

    let parsed = _mkNormalize(_mkParseJSON(raw));
    if (!parsed) {
      _mkBlock(slot.id, MK_COOLDOWN.badOutput);
      return null;
    }

    if (window.DVLangGuard) {
      if (!window.DVLangGuard.deepIsEnglish(parsed)) {
        if (!strictEnglish) {
          _mkBlock(slot.id, MK_COOLDOWN.badOutput);
          return null;
        }
        const guarded = await window.DVLangGuard.ensureEnglishJson(parsed);
        parsed = _mkNormalize(guarded.data) || parsed;
      }
    }

    _mkStrikes.delete(slot.id);
    const keys = _mkValidKeys(slot.provider);
    _mkRot[slot.provider] = keys.indexOf(slot.key) + 1;
    return parsed;
  } catch (err) {
    if (timedOut) _mkBlock(slot.id, MK_COOLDOWN.timeout);
    else if (!ctrl.signal.aborted) _mkBlock(slot.id, MK_COOLDOWN.server);
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/* ============================================================
 15. HEDGED CASCADE
 ============================================================ */
function _mkCascade(slots, img, cfg, strictEnglish) {
  return new Promise(resolve => {
    let next = 0, done = false;
    let deadline = null, hedgeTimer = null;
    const inflight = new Map();
    const preBlocked = new Set(slots.filter(_mkSlotBlocked).map(s => s.id));
    const skipSlot = s => _mkSlotBlocked(s) && !preBlocked.has(s.id);

    const finish = result => {
      if (done) return;
      done = true;
      clearTimeout(deadline);
      clearTimeout(hedgeTimer);
      inflight.forEach((_, c) => { try { c.abort(); } catch (_) {} });
      inflight.clear();
      resolve(result);
    };

    const launch = () => {
      if (done || inflight.size >= cfg.parallel) return;
      while (next < slots.length && skipSlot(slots[next])) next++;
      if (next >= slots.length) { if (!inflight.size) finish(null); return; }
      const slot = slots[next++];
      const ctrl = new AbortController();
      inflight.set(ctrl, slot);
      _mkCallSlot(slot, img, ctrl, cfg.perCall, strictEnglish).then(res => {
        inflight.delete(ctrl);
        if (res) finish({ provider: slot.provider, model: slot.model, data: res });
        else launch();
      }).catch(() => {
        inflight.delete(ctrl);
        launch();
      });
    };

    const stagger = () => {
      if (done) return;
      launch();
      if (!done && inflight.size < cfg.parallel && next < slots.length) {
        hedgeTimer = setTimeout(stagger, cfg.hedge);
      }
    };

    deadline = setTimeout(() => finish(null), cfg.total);
    launch();
    hedgeTimer = setTimeout(stagger, cfg.hedge);
  });
}

/* ============================================================
 16. CACHE
 ============================================================ */
const _mkCache = new Map();
function _mkImgKey(img) {
  let h = 2166136261 >>> 0;
  const step = Math.max(1, Math.floor(img.length / 4000));
  for (let i = 0; i < img.length; i += step) {
    h ^= img.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return `${img.length}:${h}`;
}
function _mkCacheGet(key) {
  const e = _mkCache.get(key);
  if (!e) return null;
  if (Date.now() - e.t > MK_CACHE_TTL_MS) { _mkCache.delete(key); return null; }
  return e;
}
function _mkCacheSet(key, data, provider, model) {
  _mkCache.set(key, { data, provider, model, t: Date.now() });
  if (_mkCache.size > MK_CACHE_MAX) _mkCache.delete(_mkCache.keys().next().value);
}

async function mkAnalyzeAnimal(img) {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return { unavailable: true, reason: 'offline' };
  }
  const cacheKey = _mkImgKey(img);
  const hit = _mkCacheGet(cacheKey);
  if (hit) return { data: hit.data, provider: hit.provider, model: hit.model, cached: true };

  const slots = _mkBuildSlots();
  if (!slots.length) return { unavailable: true, reason: 'no_keys' };

  let res = null;
  try { res = await _mkCascade(slots, img, MK_TIMING, false); } catch (_) { res = null; }
  if (res && res.data) {
    _mkCacheSet(cacheKey, res.data, res.provider, res.model);
    return { data: res.data, provider: res.provider, model: res.model, cached: false };
  }
  return { unavailable: true, reason: 'busy' };
}

/* ============================================================
 17. PRICE COMPUTATION
 ============================================================ */
function _mkPriceForSpecies(species) {
  const s = String(species || '').toLowerCase();
  const table = MK_CURRENT_PRICES || MK_FALLBACK_PRICES;
  const entry = table[s] || MK_FALLBACK_PRICES[s];
  if (!entry) return null;
  return {
    meatPerKg: entry.meatPerKg || [0, 0],
    livePerKg: entry.livePerKg || [0, 0],
    enName: entry.enName || MK_SPECIES_EN[s] || s
  };
}

function computePrice(analysis) {
  if (!analysis || analysis.status !== 'success') return null;
  const price = _mkPriceForSpecies(analysis.species);
  if (!price) return null;

  const live = analysis.liveWeightKg || 0;
  const range = analysis.liveWeightRange || { min: live * 0.88, max: live * 1.12 };
  const meat = analysis.meatYieldKg || Math.round(live * 0.6 * 10) / 10;

  const [meatMin, meatMax] = price.meatPerKg;
  const [liveMin, liveMax] = price.livePerKg;

  return {
    price,
    liveWeight: live,
    liveRange: range,
    meatYield: meat,
    meatRevenue: { min: Math.round(meat * meatMin), max: Math.round(meat * meatMax) },
    liveValue: { min: Math.round(range.min * liveMin), max: Math.round(range.max * liveMax) },
    buySuggestion: {
      min: Math.round(meat * meatMin * 0.60),
      max: Math.round(meat * meatMax * 0.70)
    }
  };
}

/* ============================================================
 18. FORMATTER
 ============================================================ */
function _mkFormatTk(n) {
  if (!isFinite(n)) return '—';
  return '৳ ' + Math.round(n).toLocaleString('en-IN');
}

function _mkSourceLabel(source) {
  switch (source) {
    case 'firestore': return 'Firestore live';
    case 'sheet': return 'Google Sheet';
    case 'cache': return 'Cached data';
    default: return 'Default data';
  }
}

/* ============================================================
 19. SPECIES DROPDOWN
 ============================================================ */
function _mkSpeciesDropdownHtml(currentSpecies) {
  const options = [
    { v: 'cow', t: '🐄 Cow' },
    { v: 'goat', t: '🐐 Goat' },
    { v: 'sheep', t: '🐑 Sheep' },
    { v: 'buffalo', t: '🐃 Buffalo' },
    { v: 'chicken_broiler', t: '🐔 Broiler Chicken' },
    { v: 'chicken_sonali', t: '🐔 Sonali Chicken' },
    { v: 'chicken_deshi', t: '🐔 Deshi Chicken' },
    { v: 'duck', t: '🦆 Duck' }
  ];
  const opts = options.map(o =>
    `<option value="${o.v}"${o.v === currentSpecies ? ' selected' : ''}>${o.t}</option>`
  ).join('');
  return `
    <div class="mk-override">
      <label class="mk-override-label" for="mkSpeciesOverride">
        <i class="fas fa-pen-to-square"></i>
        AI wrong? Choose yourself:
      </label>
      <select id="mkSpeciesOverride" class="mk-override-select"
              onchange="window.__mkOverrideSpecies(this.value)">
        ${opts}
      </select>
    </div>`;
}

window.__mkOverrideSpecies = function (newSpecies) {
  if (!mkLastAnalysis || !newSpecies) return;
  if (!MK_ALLOWED_SPECIES.includes(newSpecies)) return;
  const updated = {
    ...mkLastAnalysis,
    species: newSpecies,
    speciesEnglish: MK_SPECIES_EN[newSpecies] || mkLastAnalysis.speciesEnglish
  };
  mkLastAnalysis = updated;
  const resultEl = _el('mkResult');
  if (resultEl) renderMKResultInternal(updated, true);
};

/* ============================================================
 20. RENDER RESULT
 ============================================================ */
function renderMKResult(analysis) {
  mkLastAnalysis = analysis;
  renderMKResultInternal(analysis, false);
}

function renderMKResultInternal(analysis, isOverride) {
  const resultEl = _el('mkResult');
  if (!resultEl) return;

  if (analysis.status === 'error') {
    resultEl.innerHTML = `
      <div class="mk-error-box">
        <i class="fas fa-triangle-exclamation"></i>
        <h3>Not Supported</h3>
        <p>${escapeHtmlMK(analysis.errorEnglish || 'This analysis is only for livestock.')}</p>
      </div>`;
    resultEl.style.display = 'flex';
    return;
  }

  const price = computePrice(analysis);
  if (!price) {
    resultEl.innerHTML = `
      <div class="mk-error-box">
        <i class="fas fa-info-circle"></i>
        <h3>Price data unavailable</h3>
        <p>Market price not available for ${escapeHtmlMK(analysis.speciesEnglish || '')}.</p>
      </div>`;
    resultEl.style.display = 'flex';
    return;
  }

  const nowEn = mkNowEnFull(false);
  const priceDateEn = mkFormatPriceDateEn(MK_PRICE_MONTH);
  const userImg = mkSelectedImage
    ? `<div class="mk-user-image"><img src="${mkSelectedImage}" alt="Analyzed"/></div>`
    : '';
  const dropdownHtml = _mkSpeciesDropdownHtml(analysis.species);

  resultEl.innerHTML = `
    <div class="mk-result-card">
      ${userImg}

      <div class="mk-result-head">
        <div class="mk-result-icon"><i class="fas fa-chart-line"></i></div>
        <div>
          <h3>Market analysis complete</h3>
          <span class="mk-confidence">${analysis.confidencePercentage}% confidence</span>
        </div>
      </div>

      <div class="mk-section">
        <div class="mk-section-title">🐾 Animal info</div>
        <div class="mk-grid">
          <div class="mk-item"><span>Species</span><b>${escapeHtmlMK(analysis.speciesEnglish)}</b></div>
          <div class="mk-item"><span>Breed</span><b>${escapeHtmlMK(analysis.breed || '—')}</b></div>
          <div class="mk-item"><span>Age</span><b>${analysis.ageMonths ? analysis.ageMonths + ' months' : '—'}</b></div>
          <div class="mk-item"><span>Live weight</span><b>${analysis.liveWeightKg} kg</b></div>
          <div class="mk-item"><span>Weight range</span><b>${analysis.liveWeightRange.min}–${analysis.liveWeightRange.max} kg</b></div>
          <div class="mk-item"><span>Est. meat</span><b>${price.meatYield} kg</b></div>
        </div>
        ${analysis.observations ? `<p class="mk-obs">${escapeHtmlMK(analysis.observations)}</p>` : ''}
      </div>

      <div class="mk-section">
        <div class="mk-section-title">📅 Current market rates — ${escapeHtmlMK(nowEn)}</div>
        <div class="mk-grid">
          <div class="mk-item"><span>Meat price/kg</span><b>${_mkFormatTk(price.price.meatPerKg[0])} – ${_mkFormatTk(price.price.meatPerKg[1])}</b></div>
          <div class="mk-item"><span>Live price/kg</span><b>${_mkFormatTk(price.price.livePerKg[0])} – ${_mkFormatTk(price.price.livePerKg[1])}</b></div>
        </div>
        <div class="mk-price-source">📌 Rate update: ${escapeHtmlMK(priceDateEn)} · Source: ${escapeHtmlMK(_mkSourceLabel(MK_PRICE_SOURCE))}</div>
      </div>

      <div class="mk-section mk-highlight">
        <div class="mk-section-title">💰 Estimated meat value</div>
        <div class="mk-revenue">
          <div class="mk-revenue-val">${_mkFormatTk(price.meatRevenue.min)} – ${_mkFormatTk(price.meatRevenue.max)}</div>
          <div class="mk-revenue-sub">${price.meatYield} kg meat</div>
        </div>
      </div>

      <div class="mk-section mk-live">
        <div class="mk-section-title">🐄 Live animal market value</div>
        <div class="mk-revenue">
          <div class="mk-revenue-val">${_mkFormatTk(price.liveValue.min)} – ${_mkFormatTk(price.liveValue.max)}</div>
          <div class="mk-revenue-sub">Based on live weight</div>
        </div>
      </div>

      <div class="mk-section mk-buy">
        <div class="mk-section-title">✅ Suggested purchase price</div>
        <div class="mk-buy-val">${_mkFormatTk(price.buySuggestion.min)} – ${_mkFormatTk(price.buySuggestion.max)}</div>
        <p class="mk-buy-note">
          At this price you can profit from meat sales (assuming 60-70% margin).
          Try to negotiate within this range in the market.
        </p>
      </div>

      ${dropdownHtml}

      <!-- ✅ NEW: Get Insurance Link -->
      <div style="margin-top: 12px; padding-top: 12px; border-top: 1px dashed #CBD5E1;">
        <button type="button" onclick="window.redirectToInsurance(${price.liveValue.max})" 
                style="width: 100%; padding: 12px; background: #0F2C59; color: #fff; border: none; border-radius: 10px; font-weight: 700; font-size: 14px; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; box-shadow: 0 4px 12px rgba(15,44,89,0.2);">
          <i class="fas fa-shield-halved"></i>
          Insure for ৳${price.liveValue.max.toLocaleString('en-IN')}
        </button>
        <div style="font-size: 11px; color: #64748B; text-align: center; margin-top: 6px;">
          Protect this animal with parametric weather insurance
        </div>
      </div>

      <div class="mk-disclaimer">
        ⚠️ This estimate is approximate. Actual prices depend on market, area, season and animal health.
      </div>
    </div>`;
  resultEl.style.display = 'flex';
  if (!isOverride) resultEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderMKUnavailable(reason) {
  const resultEl = _el('mkResult');
  if (!resultEl) return;
  const msg = reason === 'offline'
    ? 'No internet connection. Please try again when online.'
    : reason === 'no_keys'
    ? 'AI configuration issue. Please contact admin.'
    : 'AI service is busy right now. Please try again shortly.';
  resultEl.innerHTML = `
    <div class="mk-error-box">
      <i class="fas fa-triangle-exclamation"></i>
      <h3>AI is busy</h3>
      <p>${escapeHtmlMK(msg)}</p>
      <button type="button" onclick="runMarketScan()">Try again</button>
    </div>`;
  resultEl.style.display = 'flex';
}

/* ============================================================
 21. UI FLOW
 ============================================================ */
function showMKPreview(dataURL) {
  mkSelectedImage = dataURL;
  const field = _el('mkImageField');
  const preview = _el('mkPreview');
  const img = _el('mkPreviewImg');
  if (field) field.style.display = 'none';
  if (preview && img) { img.src = dataURL; preview.style.display = 'flex'; }
  const result = _el('mkResult');
  if (result) result.style.display = 'none';
  mkLastAnalysis = null;
  mkLastProviderInfo = null;
}

window.removeMKPreview = function () {
  mkSelectedImage = null;
  mkLastAnalysis = null;
  mkLastProviderInfo = null;
  const field = _el('mkImageField');
  const preview = _el('mkPreview');
  const result = _el('mkResult');
  if (field) field.style.display = 'flex';
  if (preview) preview.style.display = 'none';
  if (result) result.style.display = 'none';
};

async function processMKFile(file) {
  if (!file || !file.type.startsWith('image/')) return;
  if (file.size > MK_MAX_IMAGE_MB * 1024 * 1024) {
    alert(`Image too large. Max ${MK_MAX_IMAGE_MB}MB.`);
    return;
  }
  try {
    const dataUrl = await compressMKImage(file);
    showMKPreview(dataUrl);
  } catch (err) {
    alert('Failed to read image: ' + err.message);
  }
}

window.runMarketScan = async function () {
  if (mkScanning) return;
  if (!mkSelectedImage) { alert('Please select or take a photo first.'); return; }
  mkScanning = true;

  const btn = _el('mkScanBtn');
  const preview = _el('mkPreview');
  const loading = _el('mkLoading');
  const result = _el('mkResult');
  if (btn) btn.disabled = true;
  if (preview) preview.style.display = 'none';
  if (result) result.style.display = 'none';
  if (loading) loading.style.display = 'flex';

  const hideLoading = () => { if (loading) loading.style.display = 'none'; };

  try {
    const out = await Promise.race([
      mkAnalyzeAnimal(mkSelectedImage),
      new Promise(r => setTimeout(() => r({ unavailable: true, reason: 'busy' }),
        MK_TIMING.total + MK_WATCHDOG_EXTRA_MS))
    ]);
    hideLoading();
    if (out && out.data) {
      mkLastProviderInfo = { provider: out.provider, model: out.model, cached: out.cached };
      renderMKResult(out.data);
    } else {
      renderMKUnavailable(out && out.reason);
    }
  } catch (err) {
    console.error('Market scan error:', err);
    hideLoading();
    renderMKUnavailable('busy');
  } finally {
    mkScanning = false;
    if (btn) btn.disabled = false;
  }
};

/* ============================================================
 22. REDIRECT TO INSURANCE
 ============================================================ */
window.redirectToInsurance = function (coverageAmount) {
  localStorage.setItem('dvInsuranceCoverage', coverageAmount);
  window.location.href = 'insurance-hub.html';
};

/* ============================================================
 23. INIT
 ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  mkCurrentPhone = _lsGet('userPhone') || (function () {
    try { return sessionStorage.getItem('userPhone'); } catch (_) { return null; }
  })();

  mkStartClock();

  const cached = _mkLoadCacheFromLocal();
  if (cached) _mkApplyPrices(cached, 'cache');
  else { MK_CURRENT_PRICES = MK_FALLBACK_PRICES; MK_PRICE_MONTH = mkCurrentMonthKey(); }

  ['mkCameraInput', 'mkGalleryInput'].forEach(id => {
    const el = _el(id);
    if (el) el.addEventListener('change', e => {
      const f = e.target.files?.[0];
      if (f) processMKFile(f);
      e.target.value = '';
    });
  });

  const field = _el('mkImageField');
  if (field) {
    field.addEventListener('click', e => {
      if (e.target.closest('button')) return;
      const g = _el('mkGalleryInput');
      if (g) g.click();
    });
    field.addEventListener('dragover', e => { e.preventDefault(); field.classList.add('dragover'); });
    field.addEventListener('dragleave', e => { e.preventDefault(); field.classList.remove('dragover'); });
    field.addEventListener('drop', e => {
      e.preventDefault();
      field.classList.remove('dragover');
      const img = Array.from(e.dataTransfer?.files || []).find(f => f.type.startsWith('image/'));
      if (img) processMKFile(img);
    });
  }

  document.addEventListener('paste', e => {
    const item = Array.from(e.clipboardData?.items || []).find(i => i.type.indexOf('image') !== -1);
    if (!item) return;
    const file = item.getAsFile();
    if (file) { e.preventDefault(); processMKFile(file); }
  });

  loadMarketPrices();
  console.log('✅ Market Analyzer v2.6 ready (Insurance link added) —', mkNowEnFull(true));
});

/* ============================================================
 24. DEBUG
 ============================================================ */
window.MKDebug = {
  status() {
    const now = Date.now();
    console.table([..._mkBlocks].filter(([, until]) => until > now)
      .map(([id, until]) => ({ id, secsLeft: Math.round((until - now) / 1000) })));
    console.log('Usable slots:', _mkBuildSlots().length);
    console.log('Price source:', MK_PRICE_SOURCE, '| Date:', MK_PRICE_MONTH);
    console.log('Last analysis species:', mkLastAnalysis?.species);
  },
  reset() {
    _mkBlocks.clear();
    _mkStrikes.clear();
    _lsSet(MK_BLOCK_STORE, '{}');
    console.log('✅ MK blocks cleared');
  },
  clearCache() { _mkCache.clear(); console.log('✅ MK AI cache cleared'); },
  clearPriceCache() { try { localStorage.removeItem(MK_PRICE_CACHE_KEY); } catch (_) {} console.log('✅ MK price cache cleared'); },
  reloadPrices: loadMarketPrices,
  analyze: mkAnalyzeAnimal,
  nowEn: () => mkNowEnFull(true),
  override: window.__mkOverrideSpecies
};

})();