/* ============================================================
   DailyVet — Unified Dashboard (Weather + Insurance + Finance)
   Depends on: bd-districts.js, district-area-picker.js,
               NASA engines, insurance.js, firebase
   Picker callback: window.onUnifiedLocationChange
   ============================================================ */
(function () {
'use strict';

const $ = id => document.getElementById(id);
const money = n => '৳ ' + Math.round(Number(n) || 0).toLocaleString('en-IN');

const state = {
    phone: null,
    loc: null,            // latest picker payload
    risk: null,           // latest live risk
    policies: [],
    fin: { income: 0, expense: 0 },
    token: 0
};

/* ============================================================
   PICKER CALLBACK (defined immediately so the picker finds it)
   ============================================================ */
window.onUnifiedLocationChange = function (payload) {
    state.loc = payload;
    try { localStorage.setItem('userDistrict', payload.districtKey); } catch (_) {}   // shared with finance page
    const label = $('udDistrictLabel');
    if (label) {
        label.textContent = ((payload.area ? payload.area + ', ' : '') + payload.districtName).toUpperCase();
    }
    if (state.phone) loadWeather();
};

/* ============================================================
   INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', async () => {
    state.phone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
    if (!state.phone) { window.location.href = 'login.html'; return; }

    const dateEl = $('udDate');
    if (dateEl) {
        dateEl.textContent = new Date().toLocaleDateString('en-GB',
            { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' });
    }

    /* Restore last used district into the picker */
    const saved = localStorage.getItem('userDistrict');
    const pickerRoot = document.querySelector('.dv-picker');
    if (saved && saved !== 'dhaka' && pickerRoot && typeof pickerRoot.setDistrict === 'function') {
        pickerRoot.setDistrict(saved);      // triggers onUnifiedLocationChange
    }

    /* Run the three data loads in parallel; weather also re-runs on picker changes */
    await Promise.all([loadWeather(), loadInsurance(), loadFinance()]);
    renderInsight();
});

/* ============================================================
   1. WEATHER
   ============================================================ */
async function loadWeather() {
    const host = $('weatherData');
    if (!host || !state.loc) return;
    const my = ++state.token;

    host.innerHTML = `<div style="text-align:center;padding:2rem 0;color:#64748B;">
        <i class="fas fa-spinner fa-spin fa-2x" style="color:#1E40AF;margin-bottom:1rem;"></i>
        <div>Fetching NASA data...</div></div>`;

    try {
        if (typeof fetchLiveRiskData !== 'function') throw new Error('insurance.js not loaded');
        const hasArea = state.loc.hasArea;
        const r = await fetchLiveRiskData(
            state.loc.districtKey,
            hasArea ? state.loc.lat : undefined,
            hasArea ? state.loc.lng : undefined
        );
        if (my !== state.token) return;       // stale response
        state.risk = r;

        const flood = r.flood?.score || 0;
        const thi = r.heat?.thi || 0;
        const aqi = r.air?.aqi;
        const floodC = flood > 70 ? '#DC2626' : flood > 40 ? '#D97706' : '#059669';
        const heatC = r.heat?.level === 'severe' ? '#DC2626' : r.heat?.level === 'moderate' ? '#D97706' : '#059669';
        const aqiC = aqi > 150 ? '#DC2626' : aqi > 100 ? '#D97706' : '#059669';

        const cell = (icon, label, val, color) => `
            <div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:12px;padding:0.75rem;text-align:center;">
                <div style="font-size:0.6875rem;font-weight:700;color:#64748B;">${icon} ${label}</div>
                <div style="font-size:1.25rem;font-weight:900;color:${color};margin-top:2px;">${val}</div>
            </div>`;

        host.innerHTML = `
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:0.5rem;">
                ${cell('🌊', 'Flood', flood + '%', floodC)}
                ${cell('🌡️', 'Heat THI', thi || '--', heatC)}
                ${cell('💨', 'AQI', aqi ?? '--', aqi ? aqiC : '#64748B')}
            </div>
            <div style="margin-top:0.75rem;font-size:0.75rem;color:#64748B;display:flex;justify-content:space-between;">
                <span>7-day rain: <b>${r.flood?.rainfall7d ?? 0} mm</b></span>
                <span>${r.meta?.source === 'demo-fallback' ? '⚠️ Estimated (live data timed out)' : '🛰️ NASA live'}</span>
            </div>`;
    } catch (err) {
        if (my !== state.token) return;
        console.warn('[Unified] weather failed:', err);
        host.innerHTML = `<div style="color:#DC2626;font-size:0.875rem;text-align:center;padding:1rem;">Weather data unavailable.</div>`;
        state.risk = null;
    }
    renderInsight();
}

/* ============================================================
   2. INSURANCE
   ============================================================ */
async function loadInsurance() {
    const host = $('insuranceData');
    if (!host) return;
    try {
        /* insurance.js sets currentUserPhone in its own DOMContentLoaded — it runs before ours */
        state.policies = typeof loadActivePolicies === 'function' ? await loadActivePolicies() : [];

        if (!state.policies.length) {
            host.innerHTML = `
                <div style="text-align:center;padding:1rem 0;">
                    <div style="font-size:2rem;">🛡️</div>
                    <div style="font-weight:800;color:#1E293B;margin:0.25rem 0;">No active policy</div>
                    <div style="font-size:0.8125rem;color:#64748B;margin-bottom:1rem;">Protect your livestock from weather risk.</div>
                    <a href="insurance-policy.html" style="display:inline-block;background:#059669;color:#fff;padding:0.625rem 1.25rem;border-radius:10px;font-weight:800;text-decoration:none;font-size:0.875rem;">Buy Policy</a>
                </div>`;
            return;
        }

        const p = state.policies[0];
        const claims = Array.isArray(p.claims) ? p.claims.length : 0;
        const loc = (p.area ? p.area + ', ' : '') + (p.districtName || p.district || '');
        host.innerHTML = `
            <div style="font-size:0.6875rem;font-weight:800;color:#10B981;letter-spacing:.05em;">ACTIVE COVERAGE</div>
            <div style="font-size:1.125rem;font-weight:900;color:#0F172A;">${esc((p.animalType || 'cow').toUpperCase())} • ${esc(loc.toUpperCase())}</div>
            <div style="font-size:0.75rem;color:#64748B;margin:2px 0 0.75rem;">Policy No: <b>${esc(p.policyNumber || '—')}</b></div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:0.5rem;border-top:1px dashed #CBD5E1;padding-top:0.75rem;">
                <div><div style="font-size:0.6875rem;color:#64748B;font-weight:700;">Premium</div><div style="font-weight:900;color:#1E40AF;">৳${p.premium}/mo</div></div>
                <div><div style="font-size:0.6875rem;color:#64748B;font-weight:700;">Paid out</div><div style="font-weight:900;color:#047857;">${money(p.totalPaidOut)}</div></div>
                <div><div style="font-size:0.6875rem;color:#64748B;font-weight:700;">Claims</div><div style="font-weight:900;">${claims}</div></div>
            </div>
            <a href="insurance-dashboard.html" style="display:block;text-align:center;margin-top:0.75rem;font-size:0.8125rem;font-weight:800;color:#1E40AF;text-decoration:none;">Open insurance dashboard →</a>`;
    } catch (err) {
        console.warn('[Unified] insurance failed:', err);
        host.innerHTML = `<div style="color:#DC2626;font-size:0.875rem;text-align:center;padding:1rem;">Failed to load policies.</div>`;
    }
}

/* ============================================================
   3. FINANCE (same ledger as cashflow-forecast.js)
   ============================================================ */
async function loadFinance() {
    const host = $('financeData');
    if (!host) return;
    try {
        const snap = await firebase.firestore()
            .collection('users').doc(state.phone).collection('ledger').get();

        let inc = 0, exp = 0;
        const now = new Date();
        snap.forEach(doc => {
            const d = doc.data();
            const dt = d.timestamp && d.timestamp.toDate ? d.timestamp.toDate() : now;
            if (dt.getMonth() === now.getMonth() && dt.getFullYear() === now.getFullYear()) {
                if (d.type === 'income') inc += Number(d.amount) || 0;
                if (d.type === 'expense') exp += Number(d.amount) || 0;
            }
        });
        state.fin = { income: inc, expense: exp };
        const net = inc - exp;

        host.innerHTML = `
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.5rem;">
                <div style="background:#ECFDF5;border-radius:12px;padding:0.75rem;">
                    <div style="font-size:0.6875rem;font-weight:700;color:#047857;">Income (this month)</div>
                    <div style="font-size:1.125rem;font-weight:900;color:#047857;">${money(inc)}</div>
                </div>
                <div style="background:#FEF2F2;border-radius:12px;padding:0.75rem;">
                    <div style="font-size:0.6875rem;font-weight:700;color:#B91C1C;">Expense (this month)</div>
                    <div style="font-size:1.125rem;font-weight:900;color:#B91C1C;">${money(exp)}</div>
                </div>
            </div>
            <div style="margin-top:0.75rem;display:flex;justify-content:space-between;align-items:center;">
                <span style="font-size:0.8125rem;font-weight:700;color:#64748B;">Net profit</span>
                <span style="font-size:1.25rem;font-weight:900;color:${net >= 0 ? '#0F2C59' : '#DC2626'};">${net < 0 ? '- ' : ''}${money(Math.abs(net))}</span>
            </div>
            ${inc === 0 && exp === 0 ? `<div style="font-size:0.75rem;color:#64748B;margin-top:0.5rem;">No entries yet — add income/expense in Finance Copilot.</div>` : ''}`;
    } catch (err) {
        console.warn('[Unified] finance failed:', err);
        host.innerHTML = `<div style="color:#DC2626;font-size:0.875rem;text-align:center;padding:1rem;">Failed to load finance data.</div>`;
    }
}

/* ============================================================
   4. AI-STYLE INSIGHT (rule-based, combines all three cards)
   ============================================================ */
function renderInsight() {
    const el = $('aiInsightText');
    if (!el) return;
    const parts = [];
    const r = state.risk;
    const where = state.loc ? state.loc.districtName : 'your area';

    if (r) {
        const flood = r.flood?.score || 0;
        if (flood > 70) parts.push(`Flood risk in ${where} is high (${flood}%).`);
        else if (flood > 40) parts.push(`Flood risk in ${where} is moderate (${flood}%) — keep an eye on rainfall.`);
        if (r.heat?.level === 'severe' || r.heat?.level === 'moderate') parts.push(`Heat stress is ${r.heat.level} (THI ${r.heat.thi}) — provide shade and water.`);
        if (!parts.length) parts.push(`Weather indices look normal in ${where}.`);
    }

    const risky = r && ((r.flood?.score || 0) > 40 || ['moderate', 'severe'].includes(r.heat?.level));
    if (!state.policies.length) {
        parts.push(risky ? 'You have no insurance policy — consider buying one before the risk rises.' : 'You have no active insurance policy yet.');
    } else {
        parts.push('Your livestock are covered by an active parametric policy.');
    }

    const net = state.fin.income - state.fin.expense;
    if (state.fin.income || state.fin.expense) {
        parts.push(net >= 0 ? `Net profit this month: ${money(net)}.` : `You are ${money(-net)} in deficit this month — review expenses.`);
    }
    el.textContent = parts.join(' ') || 'Analyzing your farm\'s data to generate a summary...';
}

function esc(s) {
    const d = document.createElement('div');
    d.textContent = String(s == null ? '' : s);
    return d.innerHTML;
}

})();