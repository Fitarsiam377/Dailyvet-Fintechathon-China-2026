const _fs = () => firebase.firestore();
let currentUserPhone = null;
let allMarketItems = [];
let currentCategory = 'All';
let uploadedImages = [];
let currentViewItemId = null;

document.addEventListener('DOMContentLoaded', () => {
    currentUserPhone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
    if (!currentUserPhone) {
        window.location.href = 'login.html';
        return;
    }
    loadMarketItems();
});

function compressImage(file, maxWidth = 600, quality = 0.7) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
            const img = new Image();
            img.onload = () => {
                const canvas = document.createElement('canvas');
                let width = img.width;
                let height = img.height;

                if (width > maxWidth) {
                    height = (maxWidth / width) * height;
                    width = maxWidth;
                }

                canvas.width = width;
                canvas.height = height;
                canvas.getContext('2d').drawImage(img, 0, 0, width, height);
                resolve(canvas.toDataURL('image/jpeg', quality));
            };
            img.onerror = reject;
            img.src = e.target.result;
        };
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

async function handleMarketImages(event) {
    const files = Array.from(event.target.files);
    const remainingSlots = 5 - uploadedImages.length;

    if (files.length > remainingSlots) {
        alert(`You can only upload up to 5 images. Adding the first ${remainingSlots}.`);
    }

    const filesToProcess = files.slice(0, remainingSlots);

    for (const file of filesToProcess) {
        try {
            const base64 = await compressImage(file);
            uploadedImages.push(base64);
        } catch (e) {
            console.warn('Image compression failed', e);
        }
    }

    renderImagePreviews();
    event.target.value = '';
}

function renderImagePreviews() {
    const grid = document.getElementById('mktImagePreviews');
    if (!grid) return;

    grid.innerHTML = uploadedImages.map((img, index) => `
        <div class="mkt-preview-item">
            <img src="${img}" alt="Preview">
            <button class="mkt-preview-remove" onclick="removeMarketImage(${index})" type="button"><i class="fas fa-times"></i></button>
        </div>
    `).join('');
}

function removeMarketImage(index) {
    uploadedImages.splice(index, 1);
    renderImagePreviews();
}

function openPostModal() {
    document.getElementById('mktEditId').value = '';
    document.getElementById('mktTitle').value = '';
    document.getElementById('mktPrice').value = '';
    document.getElementById('mktUnit').value = '';
    document.getElementById('mktLocation').value = '';
    document.getElementById('mktContact').value = '';
    uploadedImages = [];
    renderImagePreviews();
    
    document.getElementById('postModalTitle').textContent = 'List an Item for Sale';
    document.getElementById('saveItemBtn').textContent = 'Publish Listing';
    document.getElementById('postModal').style.display = 'flex';
}

function closePostModal() {
    document.getElementById('postModal').style.display = 'none';
}

async function saveMarketItem() {
    const editId = document.getElementById('mktEditId').value;
    const title = document.getElementById('mktTitle').value.trim();
    const category = document.getElementById('mktCategory').value;
    const price = Number(document.getElementById('mktPrice').value);
    const unit = document.getElementById('mktUnit').value.trim() || 'Piece';
    const location = document.getElementById('mktLocation').value.trim();
    const contact = document.getElementById('mktContact').value.trim();

    if (!title || !price || !location || !contact) return alert('Please fill in all required fields.');
    if (uploadedImages.length === 0) return alert('Please upload at least 1 photo.');

    const data = { title, category, price, unit, location, contact, images: uploadedImages };

    try {
        if (editId) {
            await _fs().collection('marketplace').doc(editId).update(data);
            alert('✅ Item updated successfully.');
        } else {
            data.sellerPhone = currentUserPhone;
            data.createdAt = firebase.firestore.FieldValue.serverTimestamp();
            data.createdAtMs = Date.now();
            await _fs().collection('marketplace').add(data);
            alert('✅ Item published successfully.');
        }
        
        closePostModal();
        loadMarketItems();
    } catch (err) {
        console.error('Save failed:', err);
        alert('❌ Failed to save item. Check Firestore rules.');
    }
}

function editMarketItemFromDetails() {
    const item = allMarketItems.find(i => i.id === currentViewItemId);
    if (!item) return;

    document.getElementById('detailsModal').style.display = 'none';

    document.getElementById('mktEditId').value = item.id;
    document.getElementById('mktTitle').value = item.title;
    document.getElementById('mktCategory').value = item.category;
    document.getElementById('mktPrice').value = item.price;
    document.getElementById('mktUnit').value = item.unit;
    document.getElementById('mktLocation').value = item.location;
    document.getElementById('mktContact').value = item.contact;
    
    uploadedImages = item.images || [];
    renderImagePreviews();

    document.getElementById('postModalTitle').textContent = 'Edit Item';
    document.getElementById('saveItemBtn').textContent = 'Update Listing';
    document.getElementById('postModal').style.display = 'flex';
}

async function loadMarketItems() {
    const grid = document.getElementById('marketGrid');
    
    // 1. Render 6 Skeleton Cards instead of the spinner
    const skeletonHTML = Array(6).fill(0).map(() => `
        <div class="skeleton-card">
            <div class="skeleton-img"></div>
            <div class="skeleton-body">
                <div class="skeleton-text price"></div>
                <div class="skeleton-text title"></div>
                <div class="skeleton-text location"></div>
            </div>
        </div>
    `).join('');
    
    grid.innerHTML = skeletonHTML;

    try {
        const snap = await _fs().collection('marketplace').orderBy('createdAtMs', 'desc').get();
        
        if (snap.empty) {
            grid.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding:3rem; color:#64748b;"><i class="fas fa-store-slash" style="font-size:2rem; margin-bottom:1rem; color:#cbd5e1;"></i><div>No items listed yet. Be the first to sell!</div></div>';
            return;
        }

        allMarketItems = [];
        snap.forEach(doc => allMarketItems.push({ id: doc.id, ...doc.data() }));
        
        // 2. Once data loads, this function will overwrite the skeletons with real cards
        applyFilters(); 
    } catch (err) {
        console.error('Load failed:', err);
        grid.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding:2rem; color:#dc2626;">Failed to load marketplace.</div>';
    }
}

function setCategoryFilter(category, btnEl) {
    currentCategory = category;
    document.querySelectorAll('.mkt-chip').forEach(c => c.classList.remove('active'));
    if (btnEl) btnEl.classList.add('active');
    applyFilters();
}

function filterMarketItems() {
    applyFilters();
}

function applyFilters() {
    const query = document.getElementById('mktSearchInput').value.toLowerCase();
    
    const filtered = allMarketItems.filter(item => {
        const matchesSearch = item.title.toLowerCase().includes(query) || item.location.toLowerCase().includes(query);
        const matchesCategory = currentCategory === 'All' || item.category === currentCategory;
        return matchesSearch && matchesCategory;
    });

    renderMarketItems(filtered);
}

function renderMarketItems(items) {
    const grid = document.getElementById('marketGrid');
    
    if (!items.length) {
        grid.innerHTML = '<div style="grid-column: 1/-1; text-align:center; padding:2rem; color:#64748b;">No items found matching your criteria.</div>';
        return;
    }

    grid.innerHTML = items.map(d => {
        let imgHtml = `<i class="fas fa-box placeholder-icon"></i>`;
        if (d.images && d.images.length > 0) {
            imgHtml = `<img src="${d.images[0]}" alt="${d.title}">`;
            if (d.images.length > 1) {
                imgHtml += `<span style="position:absolute; bottom:10px; right:10px; background:rgba(15,23,42,0.85); color:#fff; font-size:0.75rem; font-weight:800; padding:4px 10px; border-radius:99px; backdrop-filter:blur(4px); display:flex; align-items:center; gap:4px;"><i class="fas fa-images"></i> +${d.images.length - 1}</span>`;
            }
        }

        return `
        <div class="mkt-card" onclick="openDetailsModal('${d.id}')" style="cursor:pointer;">
            <div class="mkt-img-wrap">
                ${imgHtml}
                <span class="mkt-category-badge">${d.category}</span>
            </div>
            <div class="mkt-card-body">
                <div class="mkt-price">৳ ${d.price.toLocaleString('en-IN')} <span style="font-size:0.75rem; font-weight:600; color:#64748b;">/ ${d.unit}</span></div>
                <div class="mkt-item-name">${d.title}</div>
                <div class="mkt-loc"><i class="fas fa-map-marker-alt"></i> ${d.location}</div>
            </div>
        </div>
        `;
    }).join('');
}

function openDetailsModal(id) {
    const item = allMarketItems.find(i => i.id === id);
    if (!item) return;
    
    currentViewItemId = id;
    const isOwner = item.sellerPhone === currentUserPhone;

    document.getElementById('detailsTitle').textContent = item.title;
    document.getElementById('detailsCategory').textContent = item.category;
    document.getElementById('detailsPrice').textContent = `৳ ${item.price.toLocaleString('en-IN')}`;
    document.getElementById('detailsUnit').textContent = `/ ${item.unit}`;
    document.getElementById('detailsLocation').innerHTML = `<i class="fas fa-map-marker-alt text-emerald"></i> ${item.location}`;
    
    if (isOwner) {
        document.getElementById('detailsSeller').textContent = `You (${item.contact})`;
    } else {
        document.getElementById('detailsSeller').textContent = item.contact;
    }

    const imgContainer = document.getElementById('detailsImages');
    if (item.images && item.images.length > 0) {
        imgContainer.innerHTML = item.images.map(img => 
            `<img src="${img}" onclick="openLightbox('${img}')" style="width:100%; height:150px; object-fit:cover; cursor:pointer; transition:opacity 0.2s;" onmouseover="this.style.opacity=0.8" onmouseout="this.style.opacity=1">`
        ).join('');
    } else {
        imgContainer.innerHTML = `<div style="grid-column: 1/-1; height:100px; background:#f1f5f9; display:flex; align-items:center; justify-content:center; color:#94a3b8;"><i class="fas fa-image fa-2x"></i></div>`;
    }

    let cleanPhone = String(item.contact).replace(/[\s\-+]/g, '');
    if (cleanPhone.startsWith('880')) cleanPhone = '+' + cleanPhone;
    else if (cleanPhone.startsWith('0')) cleanPhone = '+880' + cleanPhone.slice(1);
    else cleanPhone = '+880' + cleanPhone;
    
    document.getElementById('detailsCallBtn').href = 'tel:' + cleanPhone;
    const msg = encodeURIComponent(`Hello, I am interested in your "${item.title}" listed on DailyVet Marketplace.`);
    document.getElementById('detailsWaBtn').href = 'https://wa.me/' + cleanPhone.replace('+', '') + '?text=' + msg;

    const callBtn = document.getElementById('detailsCallBtn');
    const waBtn = document.getElementById('detailsWaBtn');
    const ownerActions = document.getElementById('detailsOwnerActions');

    if (isOwner) {
        callBtn.style.display = 'none';
        waBtn.style.display = 'none';
        ownerActions.style.display = 'flex';
    } else {
        callBtn.style.display = 'block';
        waBtn.style.display = 'block';
        ownerActions.style.display = 'none';
    }

    document.getElementById('detailsModal').style.display = 'flex';
}

function openLightbox(imageUrl) {
    const lightboxImg = document.getElementById('lightboxImage');
    const lightboxModal = document.getElementById('lightboxModal');
    
    if (lightboxImg && lightboxModal) {
        lightboxImg.src = imageUrl;
        lightboxModal.style.display = 'flex';
    }
}

async function deleteMarketItemFromDetails() {
    const item = allMarketItems.find(i => i.id === currentViewItemId);
    if (!item) return;

    if (!confirm(`Are you sure you want to delete "${item.title}"?\n\nThis cannot be undone.`)) return;

    try {
        await _fs().collection('marketplace').doc(currentViewItemId).delete();
        
        document.getElementById('detailsModal').style.display = 'none';
        allMarketItems = allMarketItems.filter(i => i.id !== currentViewItemId);
        applyFilters();
        
        alert('✅ Item deleted successfully.');
    } catch (err) {
        console.error('Delete failed:', err);
        alert('❌ Failed to delete item. Check Firestore rules.');
    }
}

window.openPostModal = openPostModal;
window.closePostModal = closePostModal;
window.saveMarketItem = saveMarketItem;
window.filterMarketItems = filterMarketItems;
window.setCategoryFilter = setCategoryFilter;
window.openDetailsModal = openDetailsModal;
window.handleMarketImages = handleMarketImages;
window.removeMarketImage = removeMarketImage;
window.editMarketItemFromDetails = editMarketItemFromDetails;
window.deleteMarketItemFromDetails = deleteMarketItemFromDetails;
window.openLightbox = openLightbox;