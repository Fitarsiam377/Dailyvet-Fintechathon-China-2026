/* ============================================================
   DailyVet — Smart Cashflow Forecast v4.0
   ✅ Location-specific risk profile (district hazard + seasonality)
   ✅ Live NASA data blended in when available (no stale data)
   ✅ 30 / 60 / 90 days are now genuinely different (month-by-month model)
   ✅ Scenario impact recalculates on location / period change
   ============================================================ */

let currentPeriod = 30;
let currentScenario = 'normal';

let currentDistrictKey = '';
let currentAreaName = '';
let currentAreaLat = null;
let currentAreaLng = null;

let baseMonthlyIncome = 30000;
let baseMonthlyExpense = 15000;
let liveWeatherRisk = null;
let hasLoadedData = false;
let locationToken = 0; // stale-response guard

const _elCF = id => document.getElementById(id);
const fmtCF = n => '৳ ' + Math.round(Number(n) || 0).toLocaleString('en-IN');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const prettyName = s => String(s || '').replace(/[_-]+/g, ' ').replace(/\b\w/g, c => c.toUpperCase());

/* ============================================================
   HAZARD MODEL
   ============================================================ */
// profile = { f: flood, h: heat, d: drought, c: cyclone }, each 0..1
const PROFILES = {};
const DEFAULT_PROFILE = { f: 0.3, h: 0.35, d: 0.25, c: 0.1 };
(function buildProfiles() {
    const add = (names, p) => names.split(',').forEach(n => { PROFILES[n.trim()] = p; });
    add('sunamganj,netrokona,kishoreganj,habiganj,sylhet,moulvibazar,brahmanbaria', { f: 0.9, h: 0.3, d: 0.1, c: 0.05 });
    add('kurigram,gaibandha,jamalpur,sirajganj,bogura,bogra,lalmonirhat,sherpur,tangail,manikganj,munshiganj,shariatpur,madaripur,chandpur,faridpur,rajbari,gopalganj', { f: 0.8, h: 0.4, d: 0.2, c: 0.05 });
    add('feni,noakhali,laxmipur,lakshmipur,cumilla,comilla', { f: 0.6, h: 0.35, d: 0.15, c: 0.45 });
    add('khulna,satkhira,bagerhat,barguna,patuakhali,bhola,pirojpur,jhalokati,barishal,barisal,coxsbazar,coxbazar,chattogram,chittagong', { f: 0.55, h: 0.3, d: 0.1, c: 0.85 });
    add('rajshahi,naogaon,chapainawabganj,natore,joypurhat,dinajpur,thakurgaon,panchagarh,pabna,nilphamari,rangpur', { f: 0.3, h: 0.7, d: 0.8, c: 0 });
    add('jashore,jessore,jhenaidah,magura,narail,kushtia,chuadanga,meherpur', { f: 0.3, h: 0.8, d: 0.5, c: 0.1 });
    add('bandarban,rangamati,khagrachhari', { f: 0.5, h: 0.3, d: 0.3, c: 0.1 });
    add('dhaka,gazipur,narayanganj,narsingdi,mymensingh', { f: 0.45, h: 0.5, d: 0.15, c: 0 });
})();

// Seasonality by month (Jan..Dec), 0..1
const SEASON = {
    f: [0, 0, .05, .15, .3, .7, 1, 1, .9, .5, .1, 0],
    h: [.05, .1, .5, .9, 1, 1, .8, .7, .6, .4, .1, 0],
    d: [.8, .9, .9, .7, .3, 0, 0, 0, 0, .1, .4, .7],
    c: [0, 0, 0, .3, .9, .4, .1, .1, .2, .7, .8, .2]
};
// Worst-case income loss per hazard
const MAX_LOSS = { f: 0.35, h: 0.25, d: 0.20, c: 0.30 };

const SCENARIOS = [
    { id: 'normal',  name: 'Current Weather', icon: '🛰️', color: '#0891B2', hazard: null, shock: 0,    expUp: 0 },
    { id: 'drought', name: 'Severe Drought',  icon: '🏜️', color: '#F59E0B', hazard: 'd',  shock: 0.30, expUp: 0.08, desc: 'No rain for next 2 weeks' },
    { id: 'flood',   name: 'Flooding',        icon: '🌊', color: '#DC2626', hazard: 'f',  shock: 0.40, expUp: 0.06, desc: 'Heavy rain causes waterlogging' },
    { id: 'heat',    name: 'Extreme Heat',    icon: '🔥', color: '#EA580C', hazard: 'h',  shock: 0.28, expUp: 0.05, desc: 'THI crosses 85 (Heat Stress)' }
];
const SHOCK_TAIL = [1, 0.5, 0.25]; // shock fades over following months

const getProfile = () => {
    const key = String(currentDistrictKey || '').toLowerCase().replace(/[^a-z]/g, '');
    return PROFILES[key] || DEFAULT_PROFILE;
};

// Live NASA/forecast data → loss rate (null if unusable)
function liveLossFrom(risk) {
    if (!risk) return null;
    const flood = risk.flood?.score ?? risk.floodScore;
    const heat = risk.heat?.level ?? risk.thiLevel;
    if (flood == null && heat == null) return null;
    const f = Number(flood) || 0;
    if (f > 70 || heat === 'severe') return 0.35;
    if (f > 40 || heat === 'moderate') return 0.15;
    if (f > 20 || heat === 'mild') return 0.05;
    return 0;
}

// Expected weather loss for the i-th 30-day window
function windowLoss(i) {
    const p = getProfile();
    const mid = new Date(Date.now() + (15 + 30 * i) * 86400000).getMonth();
    let keep = 1;
    ['f', 'h', 'd', 'c'].forEach(k => { keep *= 1 - MAX_LOSS[k] * p[k] * SEASON[k][mid]; });
    const seasonal = 1 - keep;

    const live = liveLossFrom(liveWeatherRisk);
    if (live == null) return seasonal;
    const w = [0.7, 0.35, 0.15][i] ?? 0.1; // live data matters most for the near term
    return seasonal * (1 - w) + live * w;
}

function forecast(days, scenarioId) {
    const sc = SCENARIOS.find(s => s.id === scenarioId) || SCENARIOS[0];
    const p = getProfile();
    const months = days / 30;
    let income = 0, expense = 0, noRisk = 0;

    for (let i = 0; i < months; i++) {
        const tail = SHOCK_TAIL[i] ?? 0.1;
        const vuln = sc.hazard ? 0.5 + p[sc.hazard] : 0; // 0.5 .. 1.5
        const shock = Math.min(0.7, sc.shock * vuln) * tail;
        const loss = 1 - (1 - windowLoss(i)) * (1 - shock);
        income += baseMonthlyIncome * (1 - loss);
        expense += baseMonthlyExpense * (1 + sc.expUp * vuln * tail);
        noRisk += baseMonthlyIncome;
    }
    return { income, expense, net: income - expense, noRisk, avgLoss: noRisk ? 1 - income / noRisk : 0 };
}

/* ============================================================
   INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', async () => {
    const phone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
    if (!phone) {
        window.location.href = 'login.html';
        return;
    }

    renderScenarios();
    updateProjections();
    await loadBaseFinancials(phone);
    updateProjections();
});

/* ============================================================
   MAP CALLBACK
   ============================================================ */
window.onCashflowLocationChange = async function (payload) {
    if (!payload || !payload.districtKey) return;

    const token = ++locationToken;
    currentDistrictKey = payload.districtKey;
    currentAreaName = payload.hasArea ? payload.area : '';
    currentAreaLat = payload.hasArea ? payload.lat : null;
    currentAreaLng = payload.hasArea ? payload.lng : null;

    // Never reuse the previous place's weather
    liveWeatherRisk = null;
    currentScenario = 'normal';
    hasLoadedData = true;

    setLoading(true);
    renderScenarios();
    updateProjections();

    await checkLiveWeather(currentDistrictKey, currentAreaLat, currentAreaLng, token);
    if (token !== locationToken) return; // user already picked another place

    setLoading(false);
    updateProjections();
};

function setLoading(on) {
    const box = _elCF('cfSource');
    if (box && on) box.textContent = 'Fetching live NASA data…';
}

/* ============================================================
   LOAD FINANCIALS (average of months that have ledger data)
   ============================================================ */
async function loadBaseFinancials(phone) {
    try {
        const snap = await firebase.firestore()
            .collection('users').doc(phone)
            .collection('ledger').get();

        const months = {};
        snap.forEach(doc => {
            const d = doc.data();
            const dt = d.timestamp ? d.timestamp.toDate() : new Date();
            const key = dt.getFullYear() + '-' + dt.getMonth();
            const m = months[key] || (months[key] = { inc: 0, exp: 0 });
            if (d.type === 'income') m.inc += Number(d.amount) || 0;
            if (d.type === 'expense') m.exp += Number(d.amount) || 0;
        });

        const list = Object.values(months);
        const incMonths = list.filter(m => m.inc > 0);
        const expMonths = list.filter(m => m.exp > 0);
        if (incMonths.length) baseMonthlyIncome = incMonths.reduce((a, m) => a + m.inc, 0) / incMonths.length;
        if (expMonths.length) baseMonthlyExpense = expMonths.reduce((a, m) => a + m.exp, 0) / expMonths.length;
    } catch (err) {
        console.warn('Finance load failed, using sample dataset:', err);
    }
}

/* ============================================================
   LIVE WEATHER (per location, with timeout)
   ============================================================ */
async function checkLiveWeather(districtKey, lat, lng, token) {
    try {
        if (typeof window.fetchLiveRiskData !== 'function') return;
        const timeout = new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 8000));
        const risk = await Promise.race([window.fetchLiveRiskData(districtKey, lat, lng), timeout]);
        if (token === locationToken && risk) liveWeatherRisk = risk;
    } catch (err) {
        console.warn('[Cashflow] Weather check failed:', err.message);
    }
}

/* ============================================================
   TABS
   ============================================================ */
window.switchForecastPeriod = function (days, btn) {
    currentPeriod = days;
    document.querySelectorAll('.cf-tab').forEach(t => {
        t.classList.remove('active');
        t.setAttribute('aria-selected', 'false');
    });
    if (btn) {
        btn.classList.add('active');
        btn.setAttribute('aria-selected', 'true');
    }
    updateProjections();
};

/* ============================================================
   RENDER PROJECTIONS
   ============================================================ */
function setText(id, v) { const e = _elCF(id); if (e) e.textContent = v; }

function updateProjections() {
    const ids = ['cfProjIncome', 'cfProjExpense', 'barIncomeVal', 'barExpenseVal', 'barNetVal'];

    if (!hasLoadedData) {
        ids.forEach(id => setText(id, '৳ 0'));
        ['barIncome', 'barExpense', 'barNet'].forEach(id => { const e = _elCF(id); if (e) e.style.width = '0%'; });
        setText('cfLocationLabel', 'Select a location on the map');
        setText('cfSource', '');
        setText('cfRiskNote', '');
        const cmp = _elCF('cfCompare');
        if (cmp) cmp.innerHTML = '';
        const box = _elCF('impactBox');
        if (box) box.style.display = 'none';
        return;
    }

    const f = forecast(currentPeriod, currentScenario);
    const f90 = forecast(90, currentScenario);

    setText('cfProjIncome', fmtCF(f.income));
    setText('cfProjExpense', fmtCF(f.expense));
    setText('barIncomeVal', fmtCF(f.income));
    setText('barExpenseVal', fmtCF(f.expense));
    setText('barNetVal', fmtCF(f.net));

    // Bars share one scale (the 90-day maximum) so they visibly grow 30 → 60 → 90
    const maxVal = Math.max(f90.income, f90.expense, 1000);
    const set = (id, v, bg) => {
        const e = _elCF(id);
        if (!e) return;
        e.style.width = `${Math.min(100, (Math.abs(v) / maxVal) * 100)}%`;
        if (bg) e.style.background = bg;
    };
    set('barIncome', f.income);
    set('barExpense', f.expense);
    set('barNet', f.net, f.net >= 0 ? '#0F2C59' : '#DC2626');

    const netVal = _elCF('barNetVal');
    if (netVal) netVal.style.color = f.net >= 0 ? '#0F2C59' : '#DC2626';

    // Location + data source
    const place = currentAreaName ? `${currentAreaName}, ${prettyName(currentDistrictKey)}` : prettyName(currentDistrictKey);
    setText('cfLocationLabel', place);
    setText('cfSource', liveLossFrom(liveWeatherRisk) != null ? '🛰️ Live NASA data + seasonal model' : '📅 Seasonal estimate (live data unavailable)');
    setText('cfRiskNote', `Weather impact on income: -${(f.avgLoss * 100).toFixed(1)}% over ${currentPeriod} days`);

    // 30 / 60 / 90 side by side
    const cmp = _elCF('cfCompare');
    if (cmp) {
        cmp.innerHTML = [30, 60, 90].map(d => {
            const r = forecast(d, currentScenario);
            return `<div class="cf-cmp-item${d === currentPeriod ? ' on' : ''}">
                <span class="cf-cmp-d">${d} days</span>
                <span class="cf-cmp-v ${r.net >= 0 ? 'pos' : 'neg'}">${fmtCF(r.net)}</span>
            </div>`;
        }).join('');
    }

    renderScenarioDescriptions(place);
    renderImpact(place);
}

/* ============================================================
   SCENARIOS
   ============================================================ */
function scenarioDesc(s, place) {
    if (s.id === 'normal') return hasLoadedData ? `Live data + season for ${place}` : 'Select location on map first';
    return s.desc;
}

function renderScenarios() {
    const list = _elCF('scenarioList');
    if (!list) return;
    const place = currentAreaName ? `${currentAreaName}, ${prettyName(currentDistrictKey)}` : prettyName(currentDistrictKey);

    list.innerHTML = SCENARIOS.map(s => `
        <button type="button" class="cf-scenario-btn${hasLoadedData && s.id === currentScenario ? ' active' : ''}"
                id="btn-${s.id}" data-id="${s.id}" ${hasLoadedData ? '' : 'disabled'}>
            <span class="cf-scenario-icon" style="background:${s.color}1A;color:${s.color};">${s.icon}</span>
            <span class="cf-scenario-info">
                <span class="cf-scenario-name">${s.name}</span>
                <span class="cf-scenario-desc" data-desc="${s.id}">${esc(scenarioDesc(s, place))}</span>
            </span>
            <i class="fas fa-chevron-right cf-scenario-arrow" aria-hidden="true"></i>
        </button>`).join('');
}
window.renderScenarios = renderScenarios;

function renderScenarioDescriptions(place) {
    const el = document.querySelector('[data-desc="normal"]');
    if (el) el.textContent = scenarioDesc(SCENARIOS[0], place);
}

document.addEventListener('click', e => {
    const btn = e.target.closest('.cf-scenario-btn');
    if (btn && btn.dataset.id) window.selectScenario(btn.dataset.id);
});

window.selectScenario = function (id) {
    if (!hasLoadedData) return;
    currentScenario = id;
    document.querySelectorAll('.cf-scenario-btn').forEach(b => b.classList.toggle('active', b.dataset.id === id));
    updateProjections();
};

function renderImpact(place) {
    const box = _elCF('impactBox');
    if (!box) return;
    box.style.display = 'block';

    const sc = SCENARIOS.find(s => s.id === currentScenario);
    const cur = forecast(currentPeriod, 'normal');

    if (sc.id === 'normal') {
        const lost = cur.noRisk - cur.income;
        box.className = 'cf-impact-box positive';
        box.innerHTML = `
            <div class="cf-impact-emoji">✅</div>
            <div class="cf-impact-title">Current weather applied</div>
            <div class="cf-impact-text">${esc(place)}: expected weather loss is
                <b>${fmtCF(lost)}</b> (${(cur.avgLoss * 100).toFixed(1)}%) in the next ${currentPeriod} days.</div>`;
        return;
    }

    const f = forecast(currentPeriod, sc.id);
    const incomeLoss = cur.income - f.income;
    const extraCost = f.expense - cur.expense;
    box.className = 'cf-impact-box';
    box.innerHTML = `
        <div class="cf-impact-emoji">⚠️</div>
        <div class="cf-impact-label">Extra loss if ${esc(sc.name.toLowerCase())} hits</div>
        <div class="cf-impact-amount">- ${fmtCF(incomeLoss + extraCost)}</div>
        <div class="cf-impact-text">Lost income ${fmtCF(incomeLoss)} + extra cost ${fmtCF(extraCost)}
            in ${esc(place)} over ${currentPeriod} days.</div>`;
}