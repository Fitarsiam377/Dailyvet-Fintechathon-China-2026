// ============================================
// DAILYVET PHARMA — Medicine Search + AI Fallback v2.1
// ✅ English-only guaranteed via DVLangGuard
// ✅ Local DB first — AI ONLY if not found locally
// ✅ ai.js-style smooth engine: hedged cascade, fast failover
// ✅ Reply NEVER off — 4-layer fallback + guaranteed reply
// ✅ Own API keys — NOT shared with ai.js / scanner.js
// ✅ Hard target 5–7s
// ============================================

let allDiseases = [];
let isLoaded = false;
let isSearching = false;

const _el = id => document.getElementById(id);
const _sleep = ms => new Promise(r => setTimeout(r, ms));
const _lsGet = k => { try { return localStorage.getItem(k); } catch (_) { return null; } };
const _lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (_) {} };

/* ============================================
   AI CONFIG — pharma's own keys
   ⚠️ Rotate before launch.
   ============================================ */
const PHARMA_GEMINI_KEYS = [
  'AQ.Ab8RN6JURo6GM-erOA_GzQTIrix34mRH_wwh7Mi3McjquuWf0g',
  'AQ.Ab8RN6K_FYnOKLOtYQ_me-ikqMro19izQCEQ91p50uqCjhc9Vw',
  'AQ.Ab8RN6LOnEJNNw1ZnudbaWtiTwlMxIIL2YzmjQchRbotREe1Bw',
  'AQ.Ab8RN6Lw1hLrmOpHhxXcrbItIvQPqrjhXij-NQ4DWAfsrQaBOQ',
  'AQ.Ab8RN6IfcISj48ZUdezZBtrefHQ6lAXxQ_vtZxXFIJItAhAyUQ'
];

const PHARMA_GROQ_KEYS = [
  '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'
];

const PHARMA_OPENROUTER_KEYS = [
  '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'
];

const PHARMA_PROVIDER_KEYS = {
  gemini: PHARMA_GEMINI_KEYS,
  groq: PHARMA_GROQ_KEYS,
  openrouter: PHARMA_OPENROUTER_KEYS
};

const PHARMA_MODELS = {
  gemini: {
    text: [
      'gemini-3.5-flash-lite',
      'gemini-3.1-flash-lite',
      'gemini-2.5-flash-lite',
      'gemini-3.8-flash',
      'gemini-3.6-flash',
      'gemini-2.5-flash'
    ]
  },
  groq: { text: ['llama-3.3-70b-versatile', 'llama-3.1-8b-instant', 'openai/gpt-oss-20b'] },
  openrouter: { text: ['meta-llama/llama-3.3-70b-instruct:free', 'google/gemma-2-9b-it:free'] }
};

const PHARMA_ENDPOINTS = {
  gemini: 'https://generativelanguage.googleapis.com/v1beta/models',
  groq: 'https://api.groq.com/openai/v1/chat/completions',
  openrouter: 'https://openrouter.ai/api/v1/chat/completions'
};

const PHARMA_TIMING = { text: { total: 7000, perCall: 4200, hedge: 450, parallel: 2 } };

const PHARMA_COOLDOWN = {
  rateLimit: 20e3, rateLimitMax: 12 * 60e3,
  server: 15e3, timeout: 12e3, badRequest: 8 * 60e3,
  badOutput: 15e3,
  authKey: 6 * 3600e3, modelGone: 24 * 3600e3,
  quotaZero: 6 * 3600e3, perDay: 3 * 3600e3
};

/* ============================================
   Block registry (per-file, isolated)
   ============================================ */
const PHARMA_BLOCK_STORE = 'dvPharmaBlocks';
const _blocks = new Map();
const _strikes = new Map();
const _rot = { gemini: 0, groq: 0, openrouter: 0 };

(function _loadBlocks() {
  try {
    Object.entries(JSON.parse(_lsGet(PHARMA_BLOCK_STORE) || '{}')).forEach(([id, until]) => {
      if (until > Date.now()) _blocks.set(id, until);
    });
  } catch (_) {}
})();

const _tail = k => k.slice(-8);
const _keyId = s => `k:${s.provider}:${_tail(s.key)}`;
const _modelId = s => `m:${s.provider}:${s.model}`;
const _isBlocked = id => (_blocks.get(id) || 0) > Date.now();
const _slotBlocked = s => _isBlocked(s.id) || _isBlocked(_keyId(s)) || _isBlocked(_modelId(s));

function _block(id, ms) {
  _blocks.set(id, Date.now() + ms);
  const live = {};
  _blocks.forEach((until, k) => { if (until > Date.now()) live[k] = until; });
  _lsSet(PHARMA_BLOCK_STORE, JSON.stringify(live));
}

function _buildSlots() {
  const make = provider => {
    const keys = PHARMA_PROVIDER_KEYS[provider].filter(Boolean);
    const shift = keys.length ? _rot[provider] % keys.length : 0;
    const rotated = keys.slice(shift).concat(keys.slice(0, shift));
    const seen = new Set();
    const out = [];
    for (const model of PHARMA_MODELS[provider].text) {
      for (const key of rotated) {
        const id = `s:${provider}:${model}:${_tail(key)}`;
        if (seen.has(id)) continue;
        seen.add(id);
        out.push({ provider, model, key, id });
      }
    }
    return out;
  };
  const arrange = ([g, q, o]) => {
    const out = [];
    let gi = 0, qi = 0, oi = 0;
    const take = (arr, i) => (i < arr.length ? arr[i] : null);
    const steps = [
      () => take(q, qi++), () => take(q, qi++), () => take(g, gi++),
      () => take(q, qi++), () => take(g, gi++), () => take(o, oi++)
    ];
    for (const step of steps) { const s = step(); if (s) out.push(s); }
    while (gi < g.length) out.push(g[gi++]);
    while (qi < q.length) out.push(q[qi++]);
    while (oi < o.length) out.push(o[oi++]);
    return out;
  };
  const all = ['gemini', 'groq', 'openrouter'].map(make);
  const live = arrange(all.map(list => list.filter(s => !_slotBlocked(s))));
  if (live.length) return live;
  return arrange(all.map(list => list.filter(s =>
    !_isBlocked(_keyId(s)) && !_isBlocked(_modelId(s))
  ))).slice(0, 4);
}

/* ============================================
   Helpers
   ============================================ */
function escapeHtml(text) {
  if (text === null || text === undefined) return '';
  const div = document.createElement('div');
  div.textContent = String(text);
  return div.innerHTML;
}

const ANIMAL_EMOJI_MAP = [
  [['cow', 'cattle'], '🐄'], [['buffalo'], '🐃'], [['goat'], '🐐'],
  [['sheep'], '🐑'], [['dog'], '🐕'], [['cat'], '🐈'],
  [['chicken', 'poultry'], '🐔'], [['duck'], '🦆'], [['pigeon'], '🕊️'],
  [['horse'], '🐎'], [['rabbit'], '🐇'], [['turtle', 'reptile'], '🐢']
];

function getAnimalEmoji(animal) {
  if (!animal) return '💊';
  const a = String(animal).toLowerCase();
  for (const [keys, emoji] of ANIMAL_EMOJI_MAP) if (keys.some(k => a.includes(k))) return emoji;
  return '💊';
}

/* ============================================
   Preload diseases
   ============================================ */
async function preloadDiseases() {
  try {
    const snap = await firebase.firestore().collection('diseases').get();
    if (snap.empty) return;
    allDiseases = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    isLoaded = true;
  } catch (err) { console.error('❌ Load failed:', err); }
}

/* ============================================
   Main search
   ============================================ */
async function searchMedicine() {
  if (isSearching) return;
  const input = _el('diseaseSearchInput');
  const query = (input?.value || '').trim();
  if (!query) { alert('Please enter a disease name'); input?.focus(); return; }
  if (!isLoaded) await preloadDiseases();
  isSearching = true;

  const searchBtn = _el('searchBtn');
  const originalHTML = searchBtn?.innerHTML || '';
  if (searchBtn) {
    searchBtn.disabled = true;
    searchBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>Searching...</span>';
  }

  const resultArea = _el('resultArea');
  const emptyState = _el('emptyState');
  const quickChips = _el('quickChips');
  if (emptyState) emptyState.style.display = 'none';
  if (quickChips) quickChips.style.display = 'none';
  if (resultArea) {
    resultArea.innerHTML = `
      <div class="loading">
        <div class="spinner"></div>
        <p>Searching for "${escapeHtml(query)}"...</p>
      </div>`;
  }

  try {
    const matchedDiseases = findMatchingDiseases(query);
    if (matchedDiseases.length > 0) {
      renderResults(matchedDiseases, query, 'local');
    } else {
      await aiFallbackSearch(query, resultArea);
    }
  } catch (err) {
    console.error('Search failed:', err);
    if (resultArea) resultArea.innerHTML = renderGuaranteedFallback(query, 'error');
  } finally {
    isSearching = false;
    if (searchBtn) {
      searchBtn.disabled = false;
      searchBtn.innerHTML = originalHTML;
    }
  }
}

function renderGuaranteedFallback(query, reason = 'timeout') {
  const reasonMsg = reason === 'error'
    ? 'Something went wrong while searching.'
    : 'AI lookup is taking longer than expected.';
  return `
    <div class="no-result">
      <i class="fas fa-search-minus"></i>
      <h4>No result for "${escapeHtml(query)}"</h4>
      <p>${reasonMsg} Please try one of these:</p>
      <ul style="text-align:left;max-width:340px;margin:10px auto 0;font-size:12.5px;line-height:1.9;color:#4b5563;">
        <li>Use the full English disease name</li>
        <li>Try shorter keywords (FMD, PPR, Parvo, Rabies)</li>
        <li>Combine animal + disease (e.g. <em>cow lumpy</em>, <em>dog parvo</em>)</li>
        <li>Check spelling</li>
      </ul>
      <div style="margin-top:14px;padding:10px 12px;background:#fef3c7;border-radius:10px;font-size:12px;color:#92400e;border:1px solid #fcd34d;">
        ⚠️ For emergency cases, contact a registered veterinarian immediately.
      </div>
      <button onclick="searchMedicine()" style="margin-top:12px;padding:8px 18px;background:#088F8F;color:#fff;border:none;border-radius:8px;font-weight:600;cursor:pointer;">
        <i class="fas fa-rotate-right"></i> Try Again
      </button>
    </div>`;
}

/* ============================================
   AI fallback — English-only guaranteed
   ============================================ */
async function aiFallbackSearch(query, resultArea) {
  if (resultArea) {
    resultArea.innerHTML = `
      <div class="loading">
        <div class="spinner"></div>
        <p>🔍 Not in database. Asking DailyVet AI...</p>
      </div>`;
  }

  const prompt = buildPharmaPrompt(query);
  const startedAt = Date.now();
  let aiReply = null;
  let usedAI = null;

  try {
    const result = await _pharmaCascade(prompt, PHARMA_TIMING.text, false);
    if (result && result.reply) {
      aiReply = result.reply;
      usedAI = result.provider;
    }
  } catch (err) {
    console.warn('Pharma cascade failed:', err?.message || err);
  }

  if (!aiReply) {
    if (resultArea) resultArea.innerHTML = renderGuaranteedFallback(query, 'timeout');
    return;
  }

  renderAIResponse(query, aiReply, usedAI, resultArea);
}

/* ============================================
   Pharma hedged cascade
   ============================================ */
function _pharmaCascade(prompt, cfg, strictEnglish) {
  return new Promise(resolve => {
    const slots = _buildSlots();
    if (!slots.length) return resolve(null);

    let next = 0, inflight = 0, done = false, deadline = null;
    const ctrls = new Set();
    const preBlocked = new Set(slots.filter(_slotBlocked).map(sl => sl.id));
    const skipSlot = sl => _slotBlocked(sl) && !preBlocked.has(sl.id);

    const finish = result => {
      if (done) return;
      done = true;
      clearTimeout(deadline);
      ctrls.forEach(c => { try { c.abort(); } catch (_) {} });
      resolve(result);
    };

    const launch = () => {
      if (done || inflight >= cfg.parallel) return;
      while (next < slots.length && skipSlot(slots[next])) next++;
      if (next >= slots.length) { if (!inflight) finish(null); return; }
      const slot = slots[next++];
      const ctrl = new AbortController();
      ctrls.add(ctrl);
      inflight++;
      _pharmaCallSlot(slot, prompt, ctrl, cfg.perCall, strictEnglish).then(res => {
        ctrls.delete(ctrl);
        inflight--;
        if (res && res.reply) finish({ provider: slot.provider, model: slot.model, reply: res.reply });
        else launch();
      }).catch(() => {
        ctrls.delete(ctrl);
        inflight--;
        launch();
      });
    };

    deadline = setTimeout(() => finish(null), cfg.total);
    const initial = Math.min(cfg.parallel, slots.length);
    for (let i = 0; i < initial; i++) launch();
  });
}

async function _pharmaCallSlot(slot, prompt, ctrl, timeoutMs, strictEnglish) {
  let timedOut = false;
  const timer = setTimeout(() => { timedOut = true; ctrl.abort(); }, timeoutMs);
  try {
    const req = slot.provider === 'gemini'
      ? _pharmaGeminiReq(slot, prompt)
      : _pharmaChatReq(slot, prompt);

    const res = await fetch(req.url, {
      method: 'POST',
      headers: req.headers,
      body: JSON.stringify(req.body),
      signal: ctrl.signal
    });

    if (!res.ok) {
      const errBody = await res.text().catch(() => '');
      _pharmaOnHttpError(slot, res.status, res.headers.get('retry-after'), errBody);
      return null;
    }

    const data = await res.json();
    let raw = '';
    if (slot.provider === 'gemini') {
      raw = (data.candidates?.[0]?.content?.parts || [])
        .filter(p => p && p.text && !p.thought).map(p => p.text).join('');
    } else {
      raw = data.choices?.[0]?.message?.content || '';
    }

    if (!raw || raw.includes('NOT_FOUND')) return null;

    /* ── English-only hard check ── */
    if (window.DVLangGuard) {
      if (!window.DVLangGuard.isEnglishEnough(raw)) {
        if (!strictEnglish) {
          // fail this slot → cascade tries next
          _block(slot.id, PHARMA_COOLDOWN.badOutput);
          return null;
        }
        // retry pass: strip foreign scripts
        raw = window.DVLangGuard.stripForeign(raw);
        raw = window.DVLangGuard.stripRomanizedFiller(raw);
      }
    }

    _strikes.delete(slot.id);
    const keys = PHARMA_PROVIDER_KEYS[slot.provider].filter(Boolean);
    _rot[slot.provider] = keys.indexOf(slot.key) + 1;
    return { reply: raw.trim() };
  } catch (err) {
    if (timedOut) _block(slot.id, PHARMA_COOLDOWN.timeout);
    else if (!ctrl.signal.aborted) _block(slot.id, PHARMA_COOLDOWN.server);
    return null;
  } finally {
    clearTimeout(timer);
  }
}

/* ============================================
   Request builders
   ============================================ */
const PHARMA_SYSTEM_JSON =
  'You are DailyVet Pharma AI — a veterinary medicine assistant for Bangladesh. ' +
  'You reply ONLY in clean English. Never use Bengali, Hindi, or any non-English script. ' +
  'Always output valid JSON only. No markdown, no explanation.';

function _pharmaGeminiReq(slot, prompt) {
  const body = {
    system_instruction: { parts: [{ text: PHARMA_SYSTEM_JSON }] },
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    generationConfig: {
      temperature: 0.2, maxOutputTokens: 900, topP: 0.95,
      responseMimeType: 'application/json'
    }
  };
  if (slot.model.includes('2.5')) body.generationConfig.thinkingConfig = { thinkingBudget: 0 };
  return {
    url: `${PHARMA_ENDPOINTS.gemini}/${slot.model}:generateContent?key=${slot.key}`,
    headers: { 'Content-Type': 'application/json' },
    body
  };
}

function _pharmaChatReq(slot, prompt) {
  const reasoning = /gpt-oss/.test(slot.model);
  const body = {
    model: slot.model,
    messages: [
      { role: 'system', content: PHARMA_SYSTEM_JSON },
      { role: 'user', content: prompt }
    ],
    temperature: 0.2,
    max_tokens: 900,
    response_format: { type: 'json_object' }
  };
  if (reasoning && slot.provider === 'groq') {
    Object.assign(body, { reasoning_effort: 'low', include_reasoning: false });
  }
  const headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${slot.key}` };
  if (slot.provider === 'openrouter') {
    headers['HTTP-Referer'] = location.origin || 'https://dailyvet.app';
    headers['X-Title'] = 'DailyVet Pharma';
  }
  return { url: PHARMA_ENDPOINTS[slot.provider], headers, body };
}

/* ============================================
   HTTP error handler
   ============================================ */
function _pharmaOnHttpError(slot, status, retryAfter, bodyText) {
  const body = String(bodyText || '').slice(0, 500);
  if (status === 429) {
    const n = (_strikes.get(slot.id) || 0) + 1;
    _strikes.set(slot.id, n);
    const hinted = (parseInt(retryAfter, 10) || 0) * 1000;
    let ms = Math.min(Math.max(hinted, PHARMA_COOLDOWN.rateLimit * 2 ** (n - 1)), PHARMA_COOLDOWN.rateLimitMax);
    if (/limit:\s*0/i.test(body)) ms = PHARMA_COOLDOWN.quotaZero;
    else if (/PerDay|per\s*day/i.test(body)) ms = PHARMA_COOLDOWN.perDay;
    _block(slot.id, ms);
  } else if (status === 400) {
    if (/api[_ ]key (?:not valid|invalid|expired)|API_KEY_INVALID|key expired/i.test(body))
      _block(_keyId(slot), PHARMA_COOLDOWN.authKey);
    else _block(slot.id, PHARMA_COOLDOWN.badRequest);
  } else if (status === 401 || status === 403) {
    _block(_keyId(slot), PHARMA_COOLDOWN.authKey);
  } else if (status === 404) {
    _block(_modelId(slot), PHARMA_COOLDOWN.modelGone);
  } else if (status >= 500 || status === 408) {
    _block(slot.id, PHARMA_COOLDOWN.server);
  }
}

/* ============================================
   Prompt — English only, no Bengali fields
   ============================================ */
function buildPharmaPrompt(query) {
  return `You are DailyVet Pharma AI — a veterinary medicine information assistant for BANGLADESH.

USER QUERY: "${query}"

STRICT RULES:
1. Reply ONLY in clean English. No Bengali, Hindi, or any non-English script.
2. ONLY suggest medicines that are ACTUALLY AVAILABLE in Bangladesh (Renata, Square, ACI, ACME, Incepta, Techno, Popular, Eskayef, Elanco, Shinil, Novartis BD, SK+F, Beacon, Aristopharma).
3. If you are not confident, give the MOST LIKELY match and set "confidence" to "low".
4. NEVER invent brand names. If unsure about brands, use [] (empty array).
5. Use ONLY generic (INN) names for medicine names.
6. Maximum 3 medicines.
7. Do NOT include human-only medicines.
8. Output MUST be valid JSON only — no markdown, no explanation.

OUTPUT JSON SCHEMA (follow EXACTLY):
{
  "disease_name": "English name",
  "animal": "Cow/Goat/Dog/Cat/Chicken/etc",
  "category": "Viral/Bacterial/Parasitic/Fungal/etc",
  "danger": "Low/Medium/High/Critical",
  "confidence": "high/medium/low",
  "medicines": [
    {
      "name": "Generic (INN) name",
      "purpose": "Short English purpose",
      "route": "IM/IV/Oral/SC/Topical",
      "dosage": "Adult dosage (e.g. 1 ml/10 kg IM)",
      "brands": ["Brand1", "Brand2"]
    }
  ]
}

If the query is not veterinary-related or unclear, return:
{
  "disease_name": "",
  "medicines": [],
  "error": "not_veterinary"
}

Return ONLY the JSON object. All text fields in English.`;
}

/* ============================================
   Parse AI response — English-only fallback
   ============================================ */
function parseAIResponse(text) {
  let cleaned = String(text || '').trim()
    .replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```\s*$/i, '').trim();

  let data = null;
  try { data = JSON.parse(cleaned); }
  catch {
    const match = cleaned.match(/\{[\s\S]*\}/);
    if (match) { try { data = JSON.parse(match[0]); } catch {} }
  }
  if (!data || typeof data !== 'object') {
    return { disease_name: '', animal: '', category: '', danger: '', confidence: '', medicines: [] };
  }

  const meds = Array.isArray(data.medicines) ? data.medicines : [];
  const safeMeds = meds.map(m => ({
    name: String(m?.name || '').trim(),
    purpose: String(m?.purpose || '').trim(),
    route: String(m?.route || '').trim(),
    dosage: String(m?.dosage || '').trim(),
    brands: Array.isArray(m?.brands)
      ? m.brands.map(b => String(b || '').trim()).filter(Boolean).slice(0, 8) : []
  })).filter(m => m.name.length > 1).slice(0, 3);

  return {
    disease_name: String(data.disease_name || '').trim(),
    animal: String(data.animal || '').trim(),
    category: String(data.category || '').trim(),
    danger: String(data.danger || '').trim(),
    confidence: String(data.confidence || '').trim(),
    medicines: safeMeds,
    error: String(data.error || '').trim()
  };
}

/* ============================================
   Render AI response
   ============================================ */
function renderAIResponse(query, aiText, usedAI, resultArea) {
  if (!resultArea) return;
  const parsed = parseAIResponse(aiText);

  if (parsed.error === 'not_veterinary' || (!parsed.disease_name && parsed.medicines.length === 0)) {
    resultArea.innerHTML = `
      <div class="no-result">
        <i class="fas fa-robot"></i>
        <h4>AI couldn't find a match</h4>
        <p>The query "${escapeHtml(query)}" doesn't match a known veterinary disease.<br>
        Try: animal + symptom (e.g. <em>cow fever</em>, <em>dog vomiting</em>).</p>
        <button onclick="searchMedicine()" style="margin-top:12px;padding:8px 18px;background:#088F8F;color:#fff;border:none;border-radius:8px;font-weight:600;cursor:pointer;">
          <i class="fas fa-rotate-right"></i> Try Again
        </button>
      </div>`;
    return;
  }

  const animalEmoji = getAnimalEmoji(parsed.animal);
  const parts = [];
  const providerName = usedAI === 'gemini' ? 'Gemini'
    : usedAI === 'groq' ? 'Groq'
    : usedAI === 'openrouter' ? 'OpenRouter' : 'AI';

  parts.push(`<div class="result-count" style="font-size:12.5px;color:#7d3c98;font-weight:600;padding:0 4px;">
    🤖 AI result for "${escapeHtml(query)}"
    ${parsed.confidence ? `· <span style="color:#5b2c6f;">confidence: ${escapeHtml(parsed.confidence)}</span>` : ''}
  </div>`);

  parts.push(`
    <div class="disease-header-card" style="background: linear-gradient(135deg, #7d3c98, #5b2c6f);">
      <h3>${animalEmoji} ${escapeHtml(parsed.disease_name || query)}</h3>
      <div class="sub-info">
        ${parsed.animal ? `<span><i class="fas fa-paw"></i> ${escapeHtml(parsed.animal)}</span>` : ''}
        ${parsed.category ? `<span><i class="fas fa-virus"></i> ${escapeHtml(parsed.category)}</span>` : ''}
        ${parsed.danger ? `<span><i class="fas fa-exclamation-triangle"></i> ${escapeHtml(parsed.danger)}</span>` : ''}
        <span><i class="fas fa-robot"></i> AI-generated</span>
      </div>
    </div>`);

  if (parsed.medicines.length === 0) {
    parts.push(`
      <div class="no-result">
        <i class="fas fa-info-circle"></i>
        <h4>No medicine data</h4>
        <p>AI didn't return any medicines for this query. Please consult a vet.</p>
      </div>`);
  } else {
    parsed.medicines.forEach(med => {
      parts.push(`
        <div class="medicine-card" style="border-left-color: #7d3c98;">
          <h4 class="med-name"><i class="fas fa-pills" style="color:#7d3c98;"></i> ${escapeHtml(med.name)}</h4>
          ${med.purpose ? `<p class="med-purpose">${escapeHtml(med.purpose)}</p>` : ''}
          ${(med.route || med.dosage) ? `
            <div class="med-info-grid">
              ${med.route ? `<div class="med-info-item"><span class="label">Route</span><span class="value">${escapeHtml(med.route)}</span></div>` : ''}
              ${med.dosage ? `<div class="med-info-item"><span class="label">Dose (Adult)</span><span class="value">${escapeHtml(med.dosage)}</span></div>` : ''}
            </div>` : ''}
          ${med.brands.length > 0 ? `
            <div class="brand-section">
              <div class="brand-title"><i class="fas fa-trademark"></i> BD Brands (${med.brands.length})</div>
              <div class="brand-list">${med.brands.map(b => brandPillHtml(b)).join('')}</div>
            </div>` : ''}
          <div class="vet-badge"><i class="fas fa-user-md"></i> Use under vet supervision</div>
        </div>`);
    });
  }

  parts.push(`
    <div style="display:flex;align-items:center;gap:8px;background:#f3e8ff;border:1px solid #d8b4fe;color:#5b2c6f;border-radius:12px;padding:10px 14px;font-size:11.5px;font-weight:600;line-height:1.5;">
      <i class="fas fa-robot" style="font-size:14px;"></i>
      <span>This result was generated by <strong>${providerName} AI</strong> because it was not found in the local database. Always verify with a registered veterinarian.</span>
    </div>`);

  resultArea.innerHTML = parts.join('');
  resultArea.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ============================================
   Local DB matching — unchanged
   ============================================ */
const WORD_SYNONYMS = {
  'mites': 'mite', 'ticks': 'tick', 'worms': 'worm',
  'fleas': 'flea', 'cattle': 'cow', 'puppy': 'dog',
  'puppies': 'dog', 'kitten': 'cat', 'kittens': 'cat',
  'chicks': 'chicken', 'poultry': 'chicken',
  'itchy': 'itch', 'itching': 'itch',
  'vomiting': 'vomit', 'swelling': 'swollen',
  'fever': 'fever', 'diarrhea': 'diarrhoea',
  'diarrhoea': 'diarrhea', 'parvo': 'parvovirus',
  'rabies': 'rabies', 'fmd': 'foot and mouth'
};

function findMatchingDiseases(query) {
  const rawQuery = query.toLowerCase().trim();
  if (!rawQuery) return [];
  const words = rawQuery.split(/\s+/).map(w => w.trim()).filter(w => w.length >= 2);
  if (!words.length) return [];

  const scored = [];
  allDiseases.forEach(disease => {
    let totalScore = 0, matchedWords = 0;
    const haystackParts = [
      disease.disease_name_en || '', disease.disease_name_bn || '',
      disease.disease_name_local || '', disease.slug || '',
      disease.animal_type || '', disease.disease_category || '',
      ...(disease.tags || []),
      ...(disease.symptoms?.en || []), ...(disease.symptoms?.bn || []),
      ...(disease.treatment || []).map(t => t.generic_name || ''),
      ...(disease.treatment || []).map(t => t.purpose_en || ''),
      ...(disease.treatment || []).map(t => t.purpose || ''),
      ...(disease.treatment || []).flatMap(t => t.market_brands_bd || [])
    ].map(s => String(s).toLowerCase());

    const haystack = haystackParts.join(' | ');
    const primaryFields = [
      disease.disease_name_en || '', disease.disease_name_bn || '',
      disease.disease_name_local || '', disease.animal_type || '', disease.slug || ''
    ].map(s => String(s).toLowerCase()).join(' | ');
    const nameParts = (disease.disease_name_en || '').toLowerCase().split(/[\s()/,]+/);

    words.forEach(word => {
      let wordScore = 0, wordMatched = false;
      const variants = [word, WORD_SYNONYMS[word], word.endsWith('s') ? word.slice(0, -1) : word + 's'].filter(Boolean);
      variants.forEach(variant => {
        if (primaryFields.includes(variant)) {
          wordScore += 50; wordMatched = true;
          if (nameParts.includes(variant)) wordScore += 20;
        } else if (haystack.includes(variant)) {
          wordScore += 10; wordMatched = true;
        }
      });
      if (wordMatched) { matchedWords++; totalScore += wordScore; }
    });

    const requiredMatches = Math.ceil(words.length / 2);
    if (matchedWords >= requiredMatches && totalScore > 0) {
      if (matchedWords === words.length) totalScore += 30;
      totalScore += matchedWords * 5;
      scored.push({ disease, score: totalScore });
    }
  });

  return scored.sort((a, b) => b.score - a.score).slice(0, 8).map(x => x.disease);
}

/* ============================================
   Render local results — unchanged
   ============================================ */
function renderResults(diseases, query, source = 'local') {
  const resultArea = _el('resultArea');
  if (!resultArea) return;
  const html = `<div class="result-count" style="font-size:12.5px;color:#088F8F;font-weight:600;padding:0 4px;">
    ${diseases.length} result${diseases.length !== 1 ? 's' : ''} for "${escapeHtml(query)}"
    ${source === 'local' ? '· <span style="color:#0F5132;">from database</span>' : ''}
  </div>` + diseases.map(renderDiseaseCard).join('');
  resultArea.innerHTML = html;
  resultArea.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderDiseaseCard(disease) {
  const nameEn = disease.disease_name_en || '';
  const nameBn = disease.disease_name_bn || '';
  const animal = disease.animal_type || '';
  const category = disease.disease_category || '';
  const danger = disease.danger_level?.level || '';
  const animalEmoji = getAnimalEmoji(animal);
  const treatments = disease.treatment || [];

  let html = `
    <div class="disease-header-card">
      <h3>${animalEmoji} ${escapeHtml(nameEn || nameBn)}</h3>
      <div class="sub-info">
        ${nameBn && nameBn !== nameEn ? `<span><i class="fas fa-language"></i> ${escapeHtml(nameBn)}</span>` : ''}
        ${animal ? `<span><i class="fas fa-paw"></i> ${escapeHtml(animal)}</span>` : ''}
        ${category ? `<span><i class="fas fa-virus"></i> ${escapeHtml(category)}</span>` : ''}
        ${danger ? `<span><i class="fas fa-exclamation-triangle"></i> ${escapeHtml(danger)}</span>` : ''}
      </div>
    </div>`;

  if (treatments.length === 0) {
    html += `<div class="no-result"><i class="fas fa-info-circle"></i><h4>No medicine data available</h4><p>No medicine information has been added for this disease yet.</p></div>`;
    return html;
  }

  treatments.forEach(tr => {
    const genericName = tr.generic_name || 'Unknown';
    const purpose = pickPurpose(tr);
    const route = tr.route || '';
    const form = tr.medicine_form || '';
    const dose = tr.dosage_adult || '';
    const frequency = tr.frequency || '';
    const duration = tr.duration || '';
    const brands = tr.market_brands_bd || [];
    const verify = tr.verify_with_vet !== false;
    const infoItems = [
      route ? { label: 'Route', value: route } : null,
      form ? { label: 'Form', value: form } : null,
      dose ? { label: 'Dose (Adult)', value: dose } : null,
      frequency ? { label: 'Frequency', value: frequency } : null,
      duration ? { label: 'Duration', value: duration } : null
    ].filter(Boolean);
    const uniqueBrands = [...new Set(brands.map(b => String(b).trim()).filter(Boolean))];

    html += `
      <div class="medicine-card">
        <h4 class="med-name"><i class="fas fa-pills" style="color:#088F8F;"></i> ${escapeHtml(genericName)}</h4>
        ${purpose ? `<p class="med-purpose">${escapeHtml(purpose)}</p>` : ''}
        ${infoItems.length > 0 ? `<div class="med-info-grid">
          ${infoItems.map(it => `<div class="med-info-item"><span class="label">${escapeHtml(it.label)}</span><span class="value">${escapeHtml(it.value)}</span></div>`).join('')}
        </div>` : ''}
        ${uniqueBrands.length > 0 ? `<div class="brand-section">
          <div class="brand-title"><i class="fas fa-trademark"></i> BD Brands (${uniqueBrands.length})</div>
          <div class="brand-list">${uniqueBrands.map(b => brandPillHtml(b)).join('')}</div>
        </div>` : ''}
        ${verify ? `<div class="vet-badge"><i class="fas fa-user-md"></i> Use under vet supervision</div>` : ''}
      </div>`;
  });

  return html;
}

function brandPillHtml(brandName) {
  const name = String(brandName).trim();
  const googleUrl = `https://www.google.com/search?q=${encodeURIComponent(name + ' veterinary medicine Bangladesh')}`;
  return `<a href="${googleUrl}" target="_blank" rel="noopener noreferrer" class="brand-pill"
    title="Search &quot;${escapeHtml(name)}&quot; on Google">
    <i class="fas fa-magnifying-glass" style="font-size:9px;opacity:0.7;"></i>${escapeHtml(name)}</a>`;
}

function pickPurpose(treatment) {
  if (!treatment) return '';
  const en = (treatment.purpose_en || '').trim();
  const bn = (treatment.purpose || '').trim();
  return en || bn || '';
}

/* ============================================
   Clear / Quick search
   ============================================ */
function clearSearch() {
  const input = _el('diseaseSearchInput');
  const clearBtn = _el('clearBtn');
  const resultArea = _el('resultArea');
  const emptyState = _el('emptyState');
  const quickChips = _el('quickChips');
  if (input) input.value = '';
  if (clearBtn) clearBtn.style.display = 'none';
  if (resultArea) resultArea.innerHTML = '';
  if (emptyState) emptyState.style.display = 'flex';
  if (quickChips) quickChips.style.display = 'flex';
  input?.focus();
}

function quickSearch(query) {
  const input = _el('diseaseSearchInput');
  const clearBtn = _el('clearBtn');
  if (input) { input.value = query; if (clearBtn) clearBtn.style.display = 'flex'; }
  searchMedicine();
}

/* ============================================
   INIT
   ============================================ */
document.addEventListener('DOMContentLoaded', () => {
  if (!sessionStorage.getItem('userPhone')) {
    window.location.href = 'login.html';
    return;
  }
  const input = _el('diseaseSearchInput');
  if (input) {
    input.addEventListener('keypress', e => {
      if (e.key === 'Enter') { e.preventDefault(); searchMedicine(); }
    });
    input.addEventListener('input', () => {
      const clearBtn = _el('clearBtn');
      if (clearBtn) clearBtn.style.display = input.value.trim() ? 'flex' : 'none';
    });
  }
  preloadDiseases();
  console.log('💊 DailyVet Pharma v2.1 ready (English only)');
});

window.searchMedicine = searchMedicine;
window.clearSearch = clearSearch;
window.quickSearch = quickSearch;

window.PharmaDebug = {
  status() {
    const now = Date.now();
    console.table([..._blocks].filter(([, until]) => until > now)
      .map(([id, until]) => ({ id, secsLeft: Math.round((until - now) / 1000) })));
    console.log('Usable slots:', _buildSlots().length);
  },
  reset() {
    _blocks.clear(); _strikes.clear();
    _lsSet(PHARMA_BLOCK_STORE, '{}');
    console.log('♻️ Pharma blocks cleared');
  }
};