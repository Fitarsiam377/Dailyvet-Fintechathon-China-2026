/* ============================================================
 DailyVet — Profile Page (FINAL v3.5)
 ✅ Multiple pets
 ✅ Profile pic saved to FIRESTORE as Base64
 ✅ View other user's profile
 ✅ Vet Account section (only for vets)
 ✅ Persistent login (localStorage)
 ✅ Insurance Policy Section (Active + Pending + Rejected)
 ✅ Payout Account (bKash / Nagad / Rocket / Bank) with Custom Dropdown Logos
 ============================================================ */
(function () {
'use strict';

/* ---------- STATE ---------- */
let selectedPets = [];
let currentUserPhone = null;
let loadedPhotoURL = '';
let viewingPhone = null;
let isViewMode = false;
let viewedUserData = null;

const _el = id => document.getElementById(id);
const _fs = () => firebase.firestore();

const DEFAULT_AVATAR = 'data:image/svg+xml;utf8,' + encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
  <circle cx="50" cy="50" r="50" fill="#d9d9d9"/>
  <circle cx="50" cy="40" r="18" fill="#ffffff"/>
  <path d="M50 62c-22 0-34 12-34 26v6h68v-6c0-14-12-26-34-26z" fill="#ffffff"/>
</svg>`);

function isPlaceholderPhoto(url) {
  if (!url) return true;
  return url.indexOf('dailyvetlogo') !== -1 || url.indexOf('data:image/svg+xml') === 0;
}

const _cleanPhone = p => String(p || '').replace(/[^0-9+]/g, '');
const _toE164 = p => {
  let clean = String(p).replace(/[\s\-+]/g, '');
  if (clean.startsWith('880')) clean = '880' + clean.slice(3);
  else if (clean.startsWith('0')) clean = '880' + clean.slice(1);
  return clean;
};

/* ---------- CUSTOM DROPDOWN LOGIC ---------- */
window.togglePayoutDropdown = function(e) {
  if (e) e.stopPropagation();
  const menu = _el('payoutDropdownMenu');
  if (menu) menu.classList.toggle('open');
};

window.selectPayout = function(value, label, imgSrc) {
  const hiddenInput = _el('payoutMethod');
  const displaySpan = _el('payoutSelectedText');
  const menu = _el('payoutDropdownMenu');

  if (hiddenInput) hiddenInput.value = value;
  
  if (displaySpan) {
    let html = '';
    if (imgSrc) {
      html = `<img src="${imgSrc}" style="width:20px; height:20px; border-radius:4px; object-fit:cover;" /><span>${label}</span>`;
    } else {
      html = `<span style="font-size:16px;">🏦</span><span>${label}</span>`;
    }
    displaySpan.innerHTML = html;
    displaySpan.style.color = '#0F172A';
  }

  if (menu) menu.classList.remove('open');

  toggleBankFields(value);
  const hint = _el('payoutStatusHint');
  if (hint && value) hint.style.display = 'block';
};

document.addEventListener('click', (e) => {
  const dropdown = _el('payoutDropdown');
  if (dropdown && !dropdown.contains(e.target)) {
    const menu = _el('payoutDropdownMenu');
    if (menu) menu.classList.remove('open');
  }
});

/* ---------- PAYOUT HELPERS ---------- */
function toggleBankFields(method) {
  const box = _el('payoutBankFields');
  const numLabel = _el('payoutNumberLabel');
  const numInput = _el('payoutNumber');
  if (!box) return;
  const isBank = method === 'bank';
  box.style.display = isBank ? 'block' : 'none';
  if (numLabel) numLabel.textContent = isBank ? 'Account Number' : 'Mobile Number';
  if (numInput) numInput.placeholder = isBank ? 'Account number' : '01XXXXXXXXX';
}
window.__toggleBankFields = toggleBankFields;

/* ---------- FIREBASE READY ---------- */
function waitForFirebase(timeout = 8000) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    (function check() {
      if (window.firebase && firebase.apps && firebase.apps.length && firebase.firestore) return resolve();
      if (Date.now() - start > timeout) return reject(new Error('Firebase not initialized'));
      setTimeout(check, 100);
    })();
  });
}

function phoneVariants(p) {
  const raw = String(p || '').trim();
  const clean = _cleanPhone(raw);
  const digits = clean.replace(/\D/g, '');
  let local = digits;
  if (local.startsWith('880')) local = local.slice(3);
  if (local.startsWith('0')) local = local.slice(1);
  const list = [raw, clean, digits, '0' + local, '880' + local, '+880' + local, local];
  return [...new Set(list.filter(Boolean))];
}

async function fetchUserDoc(phone) {
  const variants = phoneVariants(phone);
  for (const id of variants) {
    try {
      const d = await _fs().collection('users').doc(id).get();
      if (d.exists) return d;
    } catch (e) {
      console.warn('users/' + id + ' read failed:', e.message);
    }
  }
  for (const v of variants) {
    try {
      const q = await _fs().collection('users').where('phone', '==', v).limit(1).get();
      if (!q.empty) return q.docs[0];
    } catch (e) {}
  }
  return null;
}

function showLoadError(msg) {
  let box = _el('profileLoadError');
  if (!box) {
    box = document.createElement('div');
    box.id = 'profileLoadError';
    box.style.cssText = 'background:#fdecea;color:#b71c1c;padding:10px 14px;border-radius:10px;margin:10px 0;font-size:14px;';
    const form = _el('profileForm');
    if (form && form.parentNode) form.parentNode.insertBefore(box, form);
  }
  box.textContent = '⚠️ ' + msg;
}

/* ---------- AUTH ---------- */
function getUserPhone() {
  return localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone') || null;
}

function setUserAuth(phone, name) {
  if (phone) {
    localStorage.setItem('userPhone', phone);
    sessionStorage.setItem('userPhone', phone);
  }
  if (name !== undefined && name !== null) {
    localStorage.setItem('userName', name);
    sessionStorage.setItem('userName', name);
  }
}

function clearUserAuth() {
  try {
    localStorage.removeItem('userPhone');
    localStorage.removeItem('userName');
    localStorage.removeItem('userProfileCache');
    localStorage.removeItem('pendingGoogleLogin');
    localStorage.removeItem('vetPhone');
    localStorage.removeItem('vetName');
  } catch (e) {}
  sessionStorage.clear();
}

/* ---------- IMAGE ---------- */
function compressImageToBlob(file, maxWidth = 250, quality = 0.65) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width, height = img.height;
        if (width > maxWidth) {
          height = (maxWidth / width) * height;
          width = maxWidth;
        }
        canvas.width = width;
        canvas.height = height;
        canvas.getContext('2d').drawImage(img, 0, 0, width, height);
        canvas.toBlob(b => b ? resolve(b) : reject(new Error('Compression failed')), 'image/jpeg', quality);
      };
      img.onerror = reject;
      img.src = e.target.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}

/* ---------- HELPERS ---------- */
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = String(text ?? '');
  return div.innerHTML;
}

function escapeJs(text) {
  return String(text).replace(/'/g, "\\'").replace(/"/g, '\\"');
}

function normalizePet(raw) {
  if (raw == null) return '';
  if (typeof raw === 'string') return raw.trim();
  if (typeof raw === 'number') return String(raw);
  if (typeof raw === 'object') {
    return String(raw.name || raw.value || raw.label || raw.pet || raw.type || '').trim();
  }
  return String(raw).trim();
}

function normalizePetsArray(arr) {
  if (!Array.isArray(arr)) return [];
  const seen = new Set();
  const out = [];
  arr.forEach(item => {
    const s = normalizePet(item);
    if (s && !seen.has(s)) { seen.add(s); out.push(s); }
  });
  return out;
}

/* ---------- MULTIPLE PETS ---------- */
function addSelectedPet() {
  if (isViewMode) return;
  const select = _el('petTypeSelect');
  if (!select) return;
  const pet = String(select.value || '').trim();
  if (!pet) { alert('Please select a pet first.'); return; }
  if (selectedPets.includes(pet)) {
    alert(pet + ' is already added.');
    select.value = '';
    return;
  }
  selectedPets.push(pet);
  renderSelectedPets();
  select.value = '';
  select.focus();
}

function removePet(petName) {
  if (isViewMode) return;
  selectedPets = selectedPets.filter(p => p !== petName);
  renderSelectedPets();
}

function renderSelectedPets() {
  const wrapper = _el('selectedPetsWrapper');
  if (!wrapper) return;
  wrapper.innerHTML = selectedPets
    .map(normalizePet)
    .filter(Boolean)
    .map(pet => `
      <div class="selected-pet-chip">
        <span class="pet-name">${escapeHtml(pet)}</span>
        ${isViewMode ? '' : `<button type="button" class="remove-pet-btn"
          onclick="removePet('${escapeJs(pet)}')" title="Remove">
          <i class="fas fa-times"></i>
        </button>`}
      </div>`).join('');
}

function getSelectedPets() { return normalizePetsArray(selectedPets); }

function loadPets(petsArray) {
  selectedPets = normalizePetsArray(petsArray);
  renderSelectedPets();
}

window.addSelectedPet = addSelectedPet;
window.removePet = removePet;
window.getSelectedPets = getSelectedPets;
window.loadPets = loadPets;

/* ---------- PROFILE PICTURE PREVIEW ---------- */
function initProfilePicUpload() {
  const input = _el('profilePicInput');
  const img = _el('profileImage');
  if (!input || !img) return;
  img.src = DEFAULT_AVATAR;

  input.addEventListener('change', (e) => {
    if (isViewMode) return;
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      alert('Image too large. Please choose under 5MB.');
      input.value = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = (ev) => {
      img.onerror = null;
      img.src = ev.target.result;
    };
    reader.readAsDataURL(file);
  });

  img.addEventListener('error', () => { img.src = DEFAULT_AVATAR; });
}

/* ============================================================
 ✅ LOAD PROFILE
 ============================================================ */
async function loadProfileData(userPhone) {
  try {
    await waitForFirebase();
    const doc = await fetchUserDoc(userPhone);
    if (!doc) {
      console.warn('❌ User doc not found for:', userPhone, phoneVariants(userPhone));
      if (isViewMode) {
        alert('User not found.');
        window.location.href = 'home.html';
      } else {
        showLoadError('Profile not found (phone: ' + userPhone + '). Please logout and login again.');
      }
      return;
    }

    if (!isViewMode) currentUserPhone = doc.id;

    const data = doc.data();
    if (isViewMode) viewedUserData = data;

    const nameEl = _el('profileName');
    const phoneEl = _el('profilePhone');
    const cityEl = _el('profileCity');
    const areaEl = _el('profileArea');
    const joinedEl = _el('profileJoined');

    [nameEl, phoneEl, cityEl, areaEl, joinedEl].forEach(el => {
      if (el) {
        el.disabled = false;
        el.readOnly = false;
      }
    });

    if (nameEl) nameEl.value = data.name || '';
    if (phoneEl) phoneEl.value = data.phone || userPhone || '';
    if (cityEl) cityEl.value = data.city || '';
    if (areaEl) areaEl.value = data.area || '';

    if (joinedEl && data.createdAt) {
      const ts = data.createdAt;
      const d = ts && typeof ts.toDate === 'function' ? ts.toDate() : new Date(ts);
      if (!isNaN(d)) {
        joinedEl.value = d.toLocaleDateString('en-GB', {
          day: '2-digit', month: 'short', year: 'numeric'
        });
      }
    }

    const imgEl = _el('profileImage');
    if (imgEl) {
      loadedPhotoURL = isPlaceholderPhoto(data.photoURL) ? '' : (data.photoURL || '');
      imgEl.src = loadedPhotoURL || DEFAULT_AVATAR;
    }

    if (isViewMode) {
      const viewingNameEl = _el('viewingName');
      if (viewingNameEl) viewingNameEl.textContent = data.name || 'User';
    }

    const petsArray = Array.isArray(data.pets)
      ? data.pets
      : (data.petType ? [data.petType] : []);
    loadPets(petsArray);

    /* ===== Payout account ===== */
    if (_el('payoutNumber')) _el('payoutNumber').value = data.payoutNumber || '';
    if (_el('payoutBankName')) _el('payoutBankName').value = data.payoutBankName || '';
    if (_el('payoutAccountName')) _el('payoutAccountName').value = data.payoutAccountName || '';
    
    if (data.payoutMethod) {
      const methodMap = {
        bkash: { label: 'bKash', img: 'assets/bkash.jpg' },
        nagad: { label: 'Nagad', img: 'assets/nagad.jpg' },
        rocket: { label: 'Rocket', img: 'assets/rocket.jpg' },
        bank: { label: 'Bank Account', img: '' }
      };
      const m = methodMap[data.payoutMethod];
      if (m) {
        window.selectPayout(data.payoutMethod, m.label, m.img);
      }
    } else {
      toggleBankFields('');
    }

    await checkVetAccount(userPhone);

    if (!isViewMode) {
      loadInsurancePolicies();
    }

    if (isViewMode) {
      [nameEl, phoneEl, cityEl, areaEl, joinedEl].forEach(el => {
        if (el) {
          el.disabled = true;
          el.readOnly = true;
        }
      });
      ['payoutMethod', 'payoutNumber', 'payoutBankName', 'payoutAccountName'].forEach(id => {
        const el = _el(id);
        if (el) el.disabled = true;
      });
    }

    console.log('✅ Profile loaded:', { userPhone, isViewMode, name: data.name });

  } catch (err) {
    console.error('Load profile error:', err);
    showLoadError('Failed to load profile: ' + (err.message || err));
  }
}

/* ---------- CHECK VET ACCOUNT ---------- */
async function checkVetAccount(userPhone) {
  const vetSection = _el('vetAccountSection');
  if (!vetSection) return;

  if (isViewMode) {
    vetSection.style.display = 'none';
    return;
  }

  try {
    const vetDoc = await _fs().collection('vets').doc(userPhone).get();
    if (vetDoc.exists) {
      vetSection.style.display = 'flex';
    } else {
      vetSection.style.display = 'none';
    }
  } catch (err) {
    console.warn('Vet check skipped:', err);
    vetSection.style.display = 'none';
  }
}

/* ============================================================
   ✅ INSURANCE POLICIES (Active + Pending + Rejected)
   ============================================================ */
async function loadInsurancePolicies() {
  const section = _el('insuranceSection');
  const list = _el('insurancePolicyList');
  if (!section || !list || !currentUserPhone) return;

  section.style.display = 'block';

  try {
    // active-only এর বদলে সব পলিসি নিয়ে আসছি
    const snap = await _fs().collection('users').doc(currentUserPhone)
      .collection('insurance_policies')
      .orderBy('createdAtMs', 'desc')
      .limit(5)
      .get();

    if (snap.empty) {
      list.innerHTML = `
        <div style="text-align: center; padding: 1.5rem; background: #F8FAFC; border: 1.5px dashed #CBD5E1; border-radius: 14px;">
          <div style="font-size: 2rem; margin-bottom: 0.5rem;">🛡️</div>
          <div style="font-size: 0.9rem; font-weight: 700; color: #334155; margin-bottom: 0.25rem;">No policies found</div>
          <div style="font-size: 0.75rem; color: #64748B;">Protect your animals with parametric weather insurance.</div>
          <a href="insurance-hub.html" style="display: inline-block; margin-top: 1rem; padding: 0.5rem 1rem; background: #0F2C59; color: #fff; text-decoration: none; border-radius: 8px; font-size: 0.8125rem; font-weight: 700;">
            Buy Policy Now
          </a>
        </div>
      `;
      return;
    }

    let html = '';

    snap.forEach(doc => {
      const p = doc.data();
      const claims = Array.isArray(p.claims) ? p.claims : [];
      const totalPaid = p.totalPaidOut || 0;
      const animal = (p.animalType || 'cow').toUpperCase();
      const dist = (p.districtName || p.district || 'dhaka').toUpperCase();

      // স্ট্যাটাস অনুযায়ী ব্যাজ
      let statusBadge = '';
      if (p.status === 'active') statusBadge = `<div class="pf-policy-badge" style="background:#10B981;">ACTIVE</div>`;
      else if (p.status === 'pending') statusBadge = `<div class="pf-policy-badge" style="background:#F59E0B;">PENDING</div>`;
      else if (p.status === 'rejected') statusBadge = `<div class="pf-policy-badge" style="background:#DC2626;">REJECTED</div>`;
      else statusBadge = `<div class="pf-policy-badge" style="background:#64748B;">${p.status || 'UNKNOWN'}</div>`;

      let claimsHtml = '<div class="pf-claim-empty">No claims filed yet.</div>';
      if (claims.length > 0) {
        claimsHtml = claims.slice(-3).reverse().map(c => `
          <div class="pf-claim-item">
            <span>${c.icon || '💰'} ${c.label} <small style="color:#94a3b8;">(${new Date(c.filedAt).toLocaleDateString('en-GB')})</small></span>
            <span class="pf-claim-amount">৳${c.payout.toLocaleString('en-IN')}</span>
          </div>
        `).join('');
      }

      html += `
        <div class="pf-policy-card" style="${p.status === 'rejected' ? 'border-color:#FCA5A5;' : p.status === 'pending' ? 'border-color:#FCD34D;' : ''}">
          <div class="pf-policy-header">
            ${statusBadge}
            <div class="pf-policy-premium">৳${p.premium}/mo</div>
          </div>
          <div class="pf-policy-rows">
            <div class="pf-policy-row">
              <span>Policy No</span>
              <b>${p.policyNumber || '—'}</b>
            </div>
            <div class="pf-policy-row">
              <span>Coverage</span>
              <b>${animal} • ${dist}</b>
            </div>
            
            ${p.status === 'pending' ? `
            <div class="pf-policy-row">
              <span>Verification</span>
              <b style="color:#D97706;">Awaiting admin approval</b>
            </div>
            ` : ''}
            
            ${p.status === 'active' ? `
            <div class="pf-policy-row">
              <span>Total Paid Out</span>
              <b style="color:#047857;">৳${totalPaid.toLocaleString('en-IN')}</b>
            </div>
            ` : ''}

            ${p.status === 'rejected' ? `
            <div class="pf-policy-row">
              <span>Status</span>
              <b style="color:#DC2626;">Payment proof invalid</b>
            </div>
            ` : ''}
          </div>
          <div class="pf-claim-history">
            <div class="pf-claim-title">Recent Claims</div>
            ${claimsHtml}
          </div>
        </div>
      `;
    });

    list.innerHTML = html;

  } catch (err) {
    console.warn('[Profile] Insurance load failed:', err.message);
    list.innerHTML = `<div style="color: #DC2626; font-size: 0.8125rem; text-align: center;">Failed to load policies. Please check your connection.</div>`;
  }
}

/* ---------- SAVE PROFILE ---------- */
function initProfileSave() {
  const form = _el('profileForm');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (isViewMode) {
      alert('You cannot edit another user\'s profile.');
      return;
    }
    if (!currentUserPhone) {
      alert('Not logged in. Please login again.');
      window.location.href = 'login.html';
      return;
    }

    const name = _el('profileName').value.trim();
    const city = _el('profileCity').value.trim();
    const area = _el('profileArea').value.trim();
    const pets = getSelectedPets();

    if (!name) { alert('Please enter your name.'); return; }
    if (pets.length === 0) { alert('Please add at least one pet.'); return; }

    // ===== Payout validation =====
    const payoutMethod = _el('payoutMethod')?.value || '';
    const payoutNumber = _el('payoutNumber')?.value.trim() || '';
    const payoutBankName = _el('payoutBankName')?.value.trim() || '';
    const payoutAccountName = _el('payoutAccountName')?.value.trim() || '';

    if (!payoutMethod) {
      alert('Please select a payout method (bKash/Nagad/Rocket/Bank).');
      _el('payoutDropdown')?.querySelector('button')?.focus();
      return;
    }
    if (payoutMethod === 'bank') {
      if (!payoutNumber || payoutNumber.length < 8) {
        alert('Enter a valid bank account number.'); return;
      }
      if (!payoutBankName) { alert('Enter bank name.'); return; }
      if (!payoutAccountName) { alert('Enter account holder name.'); return; }
    } else {
      if (!/^01\d{9}$/.test(payoutNumber)) {
        alert('Enter a valid 11-digit mobile number (e.g. 01712345678).');
        _el('payoutNumber')?.focus();
        return;
      }
    }

    const saveBtn = form.querySelector('.pf-save-btn') || form.querySelector('.save-btn');
    if (!saveBtn) return;
    const originalHTML = saveBtn.innerHTML;
    saveBtn.disabled = true;
    saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Saving...';

    try {
      const updateData = {
        name, city, area,
        pets,
        petType: pets[0] || '',
        photoURL: loadedPhotoURL || '',
        payoutMethod,
        payoutNumber,
        payoutBankName: payoutMethod === 'bank' ? payoutBankName : '',
        payoutAccountName: payoutMethod === 'bank' ? payoutAccountName : '',
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
      };

      const fileInput = _el('profilePicInput');
      const file = fileInput?.files?.[0];

      if (file) {
        const blob = await compressImageToBlob(file, 250, 0.65);
        if (blob.size > 700 * 1024) {
          alert('Image too large even after compression. Try a smaller image.');
          return;
        }
        const base64 = await blobToBase64(blob);
        updateData.photoURL = base64;
        loadedPhotoURL = base64;
      }

      await _fs().collection('users').doc(currentUserPhone).update(updateData);
      setUserAuth(currentUserPhone, name);

      alert('✅ Profile updated!');
      window.location.href = 'home.html';

    } catch (err) {
      console.error('❌ Save error:', err);
      if (err.message && err.message.includes('maximum size')) {
        alert('Image too large for Firestore. Try a smaller image.');
      } else {
        alert('❌ Failed to save: ' + (err.message || 'Try again.'));
      }
    } finally {
      saveBtn.disabled = false;
      saveBtn.innerHTML = originalHTML;
    }
  });
}

/* ---------- LOGOUT ---------- */
window.logout = function () {
  if (isViewMode) { window.location.href = 'home.html'; return; }
  if (!confirm('Logout from DailyVet?')) return;
  clearUserAuth();
  window.location.href = 'login.html';
};

/* ---------- DELETE USER ACCOUNT ---------- */
window.deleteAccount = async function () {
  if (isViewMode || !currentUserPhone) return;
  if (!confirm('⚠️ Delete your account permanently?\n\nThis cannot be undone.')) return;
  if (!confirm('Are you absolutely sure?')) return;

  try {
    try { localStorage.removeItem('photo_' + currentUserPhone); } catch (e) {}
    await _fs().collection('users').doc(currentUserPhone).delete();
    clearUserAuth();
    alert('Account deleted.');
    window.location.href = 'login.html';
  } catch (err) {
    console.error('Delete error:', err);
    alert('Failed to delete: ' + err.message);
  }
};

/* ---------- DELETE VET ACCOUNT ---------- */
window.deleteVetAccount = async function () {
  if (isViewMode || !currentUserPhone) return;

  if (!confirm('⚠️ Delete your VET account?\n\nYou will no longer appear in the vet community list.\n\nYour user account stays active.\n\nThis cannot be undone.')) return;
  if (!confirm('Are you absolutely sure?')) return;

  try {
    await _fs().collection('vets').doc(currentUserPhone).delete();
    localStorage.removeItem('vetPhone');
    localStorage.removeItem('vetName');

    alert('✅ Your Vet account has been deleted.\n\nYour user account is still active.');

    const vetSection = _el('vetAccountSection');
    if (vetSection) vetSection.style.display = 'none';

  } catch (err) {
    console.error('Delete vet error:', err);
    alert('❌ Failed to delete vet account: ' + (err.message || 'Try again.'));
  }
};

/* ---------- OPEN DOCTOR PROFILE ---------- */
window.openMyDoctorProfile = function () {
  if (!currentUserPhone) {
    alert('Not logged in. Please login again.');
    return;
  }
  window.location.href = 'vet-profile.html?phone=' + encodeURIComponent(currentUserPhone);
};

/* ---------- VIEW MODE ---------- */
function _hide(ids, value = 'none') {
  (Array.isArray(ids) ? ids : [ids]).forEach(id => {
    const el = _el(id);
    if (el) el.style.display = value;
  });
}

function enableViewMode() {
  const titleEl = _el('profileTitle');
  if (titleEl) titleEl.textContent = 'Profile';

  _hide('logoutBtn');
  _hide('editPicBtn');
  _hide('picHint');
  _hide('petSelectWrapper');
  _hide('petHint');
  _hide('profileActions');
  _hide('dangerZone');
  _hide('vetAccountSection');
  _hide('insuranceSection');
  const _pic = _el('profilePicInput');
  if (_pic) _pic.disabled = true;

  _hide('viewModeBanner', 'flex');
  _hide('viewModeActions', 'flex');

  _el('profileContainer')?.classList.add('view-mode');
}

/* ---------- VIEW MODE ACTIONS ---------- */
function _getViewPhone() {
  if (!viewedUserData) return null;
  return viewedUserData.phone || viewingPhone || null;
}

window.callFromProfile = function () {
  const phone = _getViewPhone();
  if (!phone) return alert('Phone not available');
  window.location.href = 'tel:+' + _toE164(phone);
};

window.whatsappFromProfile = function () {
  const phone = _getViewPhone();
  if (!phone) return alert('Phone not available');
  const msg = encodeURIComponent('Hello! I found you on DailyVet. Can we talk?');
  window.open('https://wa.me/' + _toE164(phone) + '?text=' + msg, '_blank');
};

/* ============================================================
 INIT
 ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  initProfilePicUpload();
  initProfileSave();

  const petSelect = _el('petTypeSelect');
  if (petSelect) {
    petSelect.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); addSelectedPet(); }
    });
  }

  const params = new URLSearchParams(window.location.search);
  const phoneFromUrl = params.get('phone');
  const myPhone = getUserPhone();

  if (!myPhone) {
    window.location.href = 'login.html';
    return;
  }

  currentUserPhone = myPhone;
  const cleanMy = _cleanPhone(myPhone);
  const cleanPhoneFromUrl = phoneFromUrl ? phoneFromUrl.trim() : null;

  if (cleanPhoneFromUrl && _cleanPhone(cleanPhoneFromUrl) !== cleanMy) {
    isViewMode = true;
    viewingPhone = cleanPhoneFromUrl;
    enableViewMode();
    loadProfileData(cleanPhoneFromUrl);
  } else {
    isViewMode = false;
    viewingPhone = myPhone;
    renderSelectedPets();
    loadProfileData(myPhone);
  }
});

})();