/* ============================================================
   FarmFin AI — Global Sidebar Injector (glossy, square corners)
   >=1860px : full sidebar (label shoho), content shore na
   <1860px  : choto icon-rail (mobile/tablet), content ektu dane shore;
              logo te tap korle full menu overlay hishebe khole
   ============================================================ */
(function () {
    'use strict';

    const path = (window.location.pathname.split('/').pop() || 'farmfin-ai.html').toLowerCase();

    const features = [
        { url: 'farmfin-ai.html',          icon: 'fas fa-house',               name: 'Dashboard',
          match: ['farmfin-ai.html', 'unified-dashboard.html'] },
        { url: 'ai-agent-dashboard.html',  icon: 'fas fa-robot',               name: 'AI Agent Dashboard' }, // 🆕 NEW LINK ADDED HERE
        { url: 'insurance-policy.html',    icon: 'fas fa-file-signature',      name: 'Buy Insurance' },
        { url: 'insurance-claim.html',     icon: 'fas fa-hand-holding-dollar', name: 'File a Claim' },
        { url: 'finance-copilot.html',     icon: 'fas fa-wallet',              name: 'Finance Copilot' },
        { url: 'cashflow-forecast.html',   icon: 'fas fa-chart-bar',           name: 'Cashflow Forecast' },
        { url: 'wealth-agent.html',        icon: 'fas fa-chart-pie',           name: 'Wealth Advisory' },
        { url: 'wealth-extra.html',        icon: 'fas fa-leaf',                name: 'Micro-Investment' },
        { url: 'insurance-risk-map.html',  icon: 'fas fa-map-location-dot',    name: 'Risk Map' },
        { url: 'insurance-dashboard.html', icon: 'fas fa-chart-line',          name: 'Insurance Dashboard',
          match: ['insurance-dashboard.html', 'insurance-hub.html'] }
    ];

    // Profile ar Help page
    const account = [
        { url: 'profile.html', icon: 'far fa-user',            name: 'Profile' },
        { url: 'support.html', icon: 'far fa-circle-question', name: 'Help & Support' }
    ];

    const THEME_KEY = 'ff-sidebar-theme';
    const getTheme = () => { try { return localStorage.getItem(THEME_KEY) === 'light' ? 'light' : 'dark'; } catch (e) { return 'dark'; } };
    const saveTheme = t => { try { localStorage.setItem(THEME_KEY, t); } catch (e) {} };

    const link = f => {
        const active = (f.match || [f.url]).includes(path);
        return `
            <a href="${f.url}" class="ff-nav-link${active ? ' active' : ''}" title="${f.name}" aria-label="${f.name}">
                <i class="${f.icon}"></i><span>${f.name}</span>
            </a>`;
    };

    const html = `
        <div class="ff-backdrop"></div>
        <aside class="ff-sidebar" aria-label="FarmFin AI menu">
            <div class="ff-top">
                <a href="farmfin-ai.html" class="ff-brand" title="FarmFin AI">
                    <span class="ff-logo"><i class="fas fa-seedling"></i></span>
                    <span class="ff-brand-text">
                        <b>FarmFin AI</b>
                        <small>Smart Finance for Smart Farming</small>
                    </span>
                </a>
                <button type="button" class="ff-close" aria-label="Close menu"><i class="fas fa-xmark"></i></button>
            </div>

            <nav class="ff-nav">${features.map(link).join('')}</nav>
            <div class="ff-divider"></div>
            <nav class="ff-nav">${account.map(link).join('')}</nav>

            <div class="ff-bottom">
                <button type="button" class="ff-mode" aria-label="Toggle light/dark mode" title="Light / Dark">
                    <i class="fas fa-moon ff-mode-icon"></i>
                    <span class="ff-mode-label">Light Mode</span>
                    <span class="ff-switch"><i></i></span>
                </button>
            </div>
        </aside>`;

    function inject() {
        if (document.querySelector('.ff-sidebar')) return;
        document.body.insertAdjacentHTML('beforeend', html);

        const sidebar  = document.querySelector('.ff-sidebar');
        const backdrop = document.querySelector('.ff-backdrop');
        const closeBtn = document.querySelector('.ff-close');
        const brand    = document.querySelector('.ff-brand');
        const modeBtn  = document.querySelector('.ff-mode');
        const modeIcon = modeBtn.querySelector('.ff-mode-icon');
        const modeText = modeBtn.querySelector('.ff-mode-label');

        // content-ke rail-er jonno jayga dite body-te class
        document.body.classList.add('ff-has-sidebar');

        const isRail = () => window.innerWidth < 1860;

        // Rail <-> expanded overlay
        const setOpen = open => {
            sidebar.classList.toggle('open', open);
            backdrop.classList.toggle('show', open);
        };
        // rail mode e logo tap = menu khola/bondho (full mode e hub e jay)
        brand.addEventListener('click', e => {
            if (!isRail()) return;
            e.preventDefault();
            setOpen(!sidebar.classList.contains('open'));
        });
        closeBtn.addEventListener('click', () => setOpen(false));
        backdrop.addEventListener('click', () => setOpen(false));
        document.addEventListener('keydown', e => { if (e.key === 'Escape') setOpen(false); });
        window.addEventListener('resize', () => { if (!isRail()) setOpen(false); });

        // Light / Dark
        const applyTheme = t => {
            const light = t === 'light';
            sidebar.classList.toggle('ff-light', light);
            modeIcon.className = 'ff-mode-icon fas ' + (light ? 'fa-sun' : 'fa-moon');
            modeText.textContent = light ? 'Dark Mode' : 'Light Mode';
        };
        applyTheme(getTheme());
        modeBtn.addEventListener('click', () => {
            const next = sidebar.classList.contains('ff-light') ? 'dark' : 'light';
            applyTheme(next);
            saveTheme(next);
        });

        // '#' link e click korle page upore jump korbe na
        sidebar.querySelectorAll('a[href="#"]').forEach(a =>
            a.addEventListener('click', e => e.preventDefault()));
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', inject);
    else inject();
})();
(function () {
    var SIDEBAR_SEL = '.farmfin-sidebar'; // change to your sidebar's real selector
    var BURGER_SEL  = '#navToggle';       // change to the 3-line button's selector
    var KEY = 'ffSidebarHidden';
    var isMobile = function () { return window.matchMedia('(max-width: 767px)').matches; };

    function setHidden(hidden) {
        document.body.classList.toggle('ff-sidebar-hidden', hidden);
        try { localStorage.setItem(KEY, hidden ? '1' : '0'); } catch (e) {}
    }

    // Restore the last state on mobile
    try { if (isMobile() && localStorage.getItem(KEY) === '1') setHidden(true); } catch (e) {}

    // Delegated click, so it works even if the navbar is injected by dailyvet-nav.js
    document.addEventListener('click', function (e) {
        if (!isMobile()) return;
        if (!e.target.closest(BURGER_SEL)) return;
        setHidden(!document.body.classList.contains('ff-sidebar-hidden'));
    });
})();