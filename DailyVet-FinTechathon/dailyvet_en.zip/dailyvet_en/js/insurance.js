/* ============================================================
   DailyVet — Insurance Agent v4.6 (Manual Payout Flow)
   ✅ Multi-key / multi-model race (for Muzzle biometrics)
   ✅ Policy management via Firestore
   ✅ 64 districts from window.BD_DISTRICTS_LIST
   ✅ Coverage Gap Analysis (returns { triggers, coverageGaps })
   ✅ Manual Claim Flow: Saves claim to Firestore as 'pending'
   ============================================================ */

let currentUserPhone = null;
let image1Base64 = null;
let image2Base64 = null;
let currentDistrict = 'dhaka';

/* ---------- Multi-key rotation ---------- */
const INS_GEMINI_KEYS = [
  'AQ.Ab8RN6KrX988Q8EXWNG9iF9CbsmqLIlL7hKiAaXRCa1aGgMoSA',
  'AQ.Ab8RN6KVbxl1e0ZJ4jQOkGZ2yqdFxx2u5Jl1yN6AnCW4m3jpIQ',
  'AQ.Ab8RN6LCLH0Kv7-dEX61LqheZyT3eWXZn9vljhEwalolNrw5lg',
  'AQ.Ab8RN6KrfN1vve0A4o9DbRrKlJwduI6_FvBkCD4CGLeQcGAoxQ',
  'AQ.Ab8RN6IH30YKZEOVwVd_28Xesv6jHunMVFwc7BnqyevDwY5vSw'
];

const INS_VISION_MODELS = [
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-2.5-flash-lite',
  'gemini-3.8-flash',
  'gemini-3.6-flash',
  'gemini-2.5-flash'
];

const INS_API_BASE = 'https://generativelanguage.googleapis.com/v1beta/models';
const INS_PER_CALL_TIMEOUT_MS = 4200;
const INS_OVERALL_TIMEOUT_MS = 5500;

const INS_BLOCK_MS = {
  rate_limit: 25 * 1000,
  invalid: 20 * 60 * 1000,
  network: 5 * 1000,
  timeout: 4 * 1000,
  server: 8 * 1000,
  model_gone: 90 * 60 * 1000,
  badOutput: 15 * 1000
};

const _insKeyStatus = INS_GEMINI_KEYS.map(() => ({ blockedUntil: 0, failCount: 0 }));
let _insBestKeyIndex = 0;

/* ============================================================
   DISTRICT → COORDINATES (via shared bd-districts.js)
   ============================================================ */
const INS_DISTRICT_COORDS = window.BD_DISTRICTS_LIST || {};

/* ============================================================
   PREMIUM ENGINE CONFIG
   ============================================================ */
const INS_BASE_PREMIUM = {
  cow: 500, buffalo: 700, goat: 150, sheep: 150, poultry: 30,
  chicken: 30, duck: 30, pigeon: 20, horse: 800,
  dog: 200, cat: 100, rabbit: 60
};

function _insResolveCoords(districtKey, lat, lng) {
  if (Number.isFinite(lat) && Number.isFinite(lng)) return { lat, lng };
  const list = window.BD_DISTRICTS_LIST || INS_DISTRICT_COORDS || {};
  return list[districtKey] || list.dhaka || null;
}

let _insCurrentCoords = null;
let _insPremiumToken = 0;
const _insRiskCache = {};
const INS_RISK_CACHE_MS = 5 * 60 * 1000;

/* ============================================================
   TRIGGER CONFIG
   ============================================================ */
const INS_TRIGGER_CONFIG = {
  heat: {
    thiThreshold: 89,
    consecutiveDays: 3,
    payoutPerDay: 150,
    label: 'Heat Stress',
    icon: '🌡️'
  },
  drought: {
    rainThresholdMm: 10,
    daysWindow: 30,
    payoutFlat: 800,
    label: 'Drought',
    icon: '🏜️'
  },
  flood: {
    scoreThreshold: 75,
    payoutFlat: 1200,
    label: 'Flood',
    icon: '🌊'
  },
  air: {
    aqiThreshold: 200,
    consecutiveDays: 3,
    payoutPerDay: 80,
    label: 'Air Quality',
    icon: '💨'
  }
};

/* ============================================================
   Get live NASA + Open-Meteo data for a district
   ============================================================ */
async function fetchLiveRiskData(districtKey, lat, lng) {
  const coords = _insResolveCoords(districtKey, lat, lng);
  const cacheKey = districtKey + '|' + (coords ? coords.lat.toFixed(3) + ',' + coords.lng.toFixed(3) : '');
  const hit = _insRiskCache[cacheKey];
  if (hit && Date.now() - hit.at < INS_RISK_CACHE_MS) return hit.data;
  const result = await _fetchLiveRiskDataRaw(districtKey, coords);
  if (result.meta.source !== 'demo-fallback') _insRiskCache[cacheKey] = { at: Date.now(), data: result };
  return result;
}

async function _fetchLiveRiskDataRaw(districtKey, coords) {
  const out = {
    district: districtKey,
    flood:    { score: 0, level: 'safe', rainfall7d: 0, soilMoisture: 0 },
    heat:     { thi: 0, level: 'normal', temp: 0, humidity: 0 },
    air:      { aqi: null, pm25: null, level: 'unknown' },
    meta:     { source: 'fallback', fetchedAt: Date.now() }
  };

  const timeout = (p, ms) => Promise.race([
    p,
    new Promise(resolve => setTimeout(() => resolve(null), ms))
  ]);

  if (window.NasaPower && typeof NasaPower.getPowerData === 'function' && coords) {
    try {
      const parameter = await timeout(NasaPower.getPowerData(coords.lat, coords.lng, 7), 8000);
      
      if (parameter) {
        const rainSeries = NasaPower.getSeries(parameter, 'PRECTOTCORR') || [];
        const rain7d = rainSeries.reduce((s, d) => s + (d.value > 0 ? d.value : 0), 0);
        const soilRoot = NasaPower.getLatest(parameter, 'GWETROOT');
        const soilTop  = NasaPower.getLatest(parameter, 'GWETTOP');
        const temp     = NasaPower.getLatest(parameter, 'T2M');
        const rh       = NasaPower.getLatest(parameter, 'RH2M');

        if (window.NasaFlood && typeof NasaFlood.calculateFloodRisk === 'function') {
          const floodRisk = NasaFlood.calculateFloodRisk({
            rain7dayMm: rain7d,
            soilRoot: soilRoot ? soilRoot.value : 0,
            soilTop:  soilTop  ? soilTop.value  : 0,
            rain48hForecast: 0,
            rain72hForecast: 0,
            district: districtKey,
            daysOfRain: rainSeries.filter(d => d.value > 5).length
          });
          out.flood = {
            score: floodRisk.score || 0,
            level: floodRisk.level || 'safe',
            rainfall7d: Math.round(rain7d),
            soilMoisture: soilRoot ? Math.round(soilRoot.value * 100) : 0
          };
        }

        if (window.NasaClimate && temp && rh) {
          const thi = NasaClimate.calculateTHI(temp.value, rh.value);
          if (thi !== null) {
            const cls = NasaClimate.classifyTHI(thi, 'cow');
            out.heat = {
              thi: Math.round(thi * 10) / 10,
              level: cls.level,
              temp: Math.round(temp.value * 10) / 10,
              humidity: Math.round(rh.value)
            };
          }
        }

        out.meta.source = 'nasa-power';
      }
    } catch (err) {
      console.warn('[Insurance] NASA POWER failed:', err.message);
    }
  }

  if (window.OpenMeteo && typeof OpenMeteo.getAQI === 'function' && coords) {
    try {
      const aqi = await timeout(OpenMeteo.getAQI(coords.lat, coords.lng), 5000);
      if (aqi && Number.isFinite(aqi.usAqi)) {
        out.air = {
          aqi: Math.round(aqi.usAqi),
          pm25: Number.isFinite(aqi.pm25) ? Math.round(aqi.pm25 * 10) / 10 : null,
          level: OpenMeteo.classifyAQI(aqi.usAqi).labelEn || 'Moderate'
        };
      }
    } catch (err) {
      console.warn('[Insurance] AQI failed:', err.message);
    }
  }

  if (out.meta.source === 'fallback' && out.flood.score === 0 && out.heat.thi === 0) {
    out.flood.score = 45; 
    out.flood.level = 'watch';
    out.heat.thi = 78;
    out.heat.level = 'moderate';
    out.heat.temp = 32.5;
    out.heat.humidity = 75;
    out.air.aqi = 120;
    out.meta.source = 'demo-fallback';
  }

  return out;
}

/* ============================================================
   Premium calculation
   ============================================================ */
function calculatePremiumFromRisk(riskData, animalType) {
  const type = (animalType || 'cow').toLowerCase();
  const base = INS_BASE_PREMIUM[type] || INS_BASE_PREMIUM.cow;

  const floodScore = Number(riskData.flood.score) || 0;
  const floodFactor = floodScore / 100;

  const heatLevel = riskData.heat.level || 'normal';
  const heatFactorMap = { normal: 0.05, mild: 0.25, moderate: 0.55, severe: 0.9 };
  const heatFactor = heatFactorMap[heatLevel] !== undefined ? heatFactorMap[heatLevel] : 0.05;

  const aqi = riskData.air.aqi;
  let airFactor = 0.05;
  if (Number.isFinite(aqi)) {
    if (aqi > 200) airFactor = 0.9;
    else if (aqi > 150) airFactor = 0.6;
    else if (aqi > 100) airFactor = 0.35;
    else if (aqi > 50)  airFactor = 0.15;
    else airFactor = 0.05;
  }

  const weighted = floodFactor * 0.40 + heatFactor * 0.35 + airFactor * 0.25;
  const multiplier = 1 + weighted * 1.5;

  const raw = Math.round(base * multiplier);
  const premium = Math.max(100, Math.min(2500, raw));

  let level = 'Low';
  let color = '#059669';
  let bg = '#ecfdf5';
  if (weighted > 0.65) { level = 'Very High'; color = '#991b1b'; bg = '#fef2f2'; }
  else if (weighted > 0.45) { level = 'High'; color = '#dc2626'; bg = '#fef2f2'; }
  else if (weighted > 0.25) { level = 'Moderate'; color = '#d97706'; bg = '#fef9e7'; }

  return {
    premium, base,
    multiplier: Math.round(multiplier * 100) / 100,
    riskScore: Math.round(weighted * 100),
    level, color, bg,
    components: {
      flood: { score: floodScore, factor: Math.round(floodFactor * 100) },
      heat:  { level: heatLevel, factor: Math.round(heatFactor * 100) },
      air:   { aqi: aqi, factor: Math.round(airFactor * 100) }
    }
  };
}

function renderPremiumCard(riskData, animalType) {
  const calc = calculatePremiumFromRisk(riskData, animalType);

  const premiumValEl = document.getElementById('premiumVal');
  if (premiumValEl) premiumValEl.innerText = `৳ ${calc.premium}`;

  const statusEl = document.getElementById('premiumStatus');
  if (statusEl) {
    statusEl.innerText = `${calc.level} Risk`;
    statusEl.style.color = calc.color;
    statusEl.style.background = calc.color + '20';
  }

  const breakdownEl = document.getElementById('premiumBreakdown');
  if (breakdownEl) {
    const f = calc.components.flood;
    const h = calc.components.heat;
    const a = calc.components.air;
    breakdownEl.innerHTML = `
      <div class="premium-breakdown-title">
        <i class="fas fa-satellite"></i>
        Live NASA Risk Breakdown
      </div>
      <div class="premium-breakdown-row">
        <span>🌊 Flood risk <small>(40%)</small></span>
        <b style="color:${f.score > 70 ? '#dc2626' : f.score > 40 ? '#d97706' : '#059669'};">
          ${f.score}%
        </b>
      </div>
      <div class="premium-breakdown-row">
        <span>🌡️ Heat stress <small>(35%)</small></span>
        <b style="color:${h.level === 'severe' ? '#dc2626' : h.level === 'moderate' ? '#d97706' : '#059669'};">
          THI ${riskData.heat.thi || 0} (${h.level})
        </b>
      </div>
      <div class="premium-breakdown-row">
        <span>💨 Air quality <small>(25%)</small></span>
        <b>AQI ${a.aqi != null ? a.aqi : '—'}</b>
      </div>
      <div class="premium-breakdown-row premium-total">
        <span>Risk score</span>
        <b style="color:${calc.color};">${calc.riskScore}% → ×${calc.multiplier}</b>
      </div>
      <div class="premium-breakdown-note">
        Base ৳${calc.base} × ${calc.multiplier} = <strong>৳${calc.premium}/month</strong>
      </div>
    `;
  }
}

async function loadLivePremium(districtKey, animalType, lat, lng) {
  const myToken = ++_insPremiumToken;
  const premiumValEl = document.getElementById('premiumVal');
  const statusEl = document.getElementById('premiumStatus');
  const breakdownEl = document.getElementById('premiumBreakdown');

  if (premiumValEl) premiumValEl.innerText = '...';
  if (statusEl) {
    statusEl.innerText = 'Fetching NASA data...';
    statusEl.style.color = '#64748b';
    statusEl.style.background = '#f1f5f9';
  }
  if (breakdownEl) {
    breakdownEl.innerHTML = `
      <div style="text-align:center;padding:14px;color:#64748b;font-size:13px;">
        <i class="fas fa-satellite-dish fa-bounce" style="color:#0891b2;font-size:20px;"></i>
        <div style="margin-top:6px;">Reading NASA POWER + Open-Meteo...</div>
      </div>`;
  }

  try {
    const useC = (Number.isFinite(lat) && Number.isFinite(lng)) ? { lat, lng } : _insCurrentCoords;
    const riskData = await fetchLiveRiskData(districtKey || currentDistrict, useC && useC.lat, useC && useC.lng);
    if (myToken !== _insPremiumToken) return;
    renderPremiumCard(riskData, animalType || 'cow');

    try {
      localStorage.setItem('dvInsuranceLastRisk', JSON.stringify({
        district: districtKey,
        animal: animalType,
        riskData,
        at: Date.now()
      }));
    } catch (_) {}
  } catch (err) {
    console.error('[Insurance] Live premium failed:', err);
    const fallbackRisk = {
      flood: { score: 30 }, heat: { level: 'mild', thi: 72 }, air: { aqi: null }
    };
    renderPremiumCard(fallbackRisk, animalType);
  }
}

function showCachedPremium() {
  try {
    const raw = localStorage.getItem('dvInsuranceLastRisk');
    if (!raw) return false;
    const obj = JSON.parse(raw);
    if (!obj || !obj.riskData) return false;
    if (Date.now() - obj.at > 30 * 60 * 1000) return false;
    renderPremiumCard(obj.riskData, obj.animal || 'cow');
    return true;
  } catch (_) {
    return false;
  }
}

window.refreshInsurancePremium = function (districtKey, animalType, lat, lng) {
  if (districtKey) currentDistrict = districtKey;
  _insCurrentCoords = (Number.isFinite(lat) && Number.isFinite(lng)) ? { lat, lng } : null;
  loadLivePremium(currentDistrict, animalType || window.__insuranceAnimalType || 'cow', lat, lng);
};

/* ============================================================
   PARAMETRIC CLAIM ENGINE
   ============================================================ */

async function detectTriggers(districtKey, animalType, lat, lng) {
  const coords = _insResolveCoords(districtKey, lat, lng);
  const triggers = [];
  const hazards = {};

  const DEFAULT_COVERED_HAZARDS = ['flood'];

  let parameter = null;
  if (window.NasaPower && typeof NasaPower.getPowerData === 'function' && coords) {
    try {
      parameter = await Promise.race([
        NasaPower.getPowerData(coords.lat, coords.lng, 30),
        new Promise(r => setTimeout(() => r(null), 8000))
      ]);
    } catch (err) {
      console.warn('[Claim] NASA fetch failed:', err.message);
    }
  }

  if (!parameter) {
    console.warn('[Claim] No NASA data — returning empty triggers (safe mode)');
    return { triggers, coverageGaps: [] };
  }

  /* ---------- HEAT ---------- */
  const tempSeries = NasaPower.getSeries(parameter, 'T2M') || [];
  const rhSeries   = NasaPower.getSeries(parameter, 'RH2M') || [];
  const rhMap = {};
  rhSeries.forEach(r => { rhMap[r.date] = r.value; });

  let heatStreak = 0;
  let heatDaysTriggered = 0;
  let maxHeatStreak = 0;
  let currentHeatLevel = 'low';

  tempSeries.forEach(t => {
    const rh = rhMap[t.date] !== undefined ? rhMap[t.date] : 70;
    if (window.NasaClimate) {
      const thi = NasaClimate.calculateTHI(t.value, rh);
      if (thi !== null && thi > INS_TRIGGER_CONFIG.heat.thiThreshold) {
        heatStreak++;
        heatDaysTriggered++;
        if (heatStreak > maxHeatStreak) maxHeatStreak = heatStreak;
      } else {
        heatStreak = 0;
      }
    }
  });

  if (maxHeatStreak >= INS_TRIGGER_CONFIG.heat.consecutiveDays) {
    currentHeatLevel = maxHeatStreak >= 7 ? 'high' : 'medium';
    const payout = heatDaysTriggered * INS_TRIGGER_CONFIG.heat.payoutPerDay;
    triggers.push({
      type: 'heat',
      label: INS_TRIGGER_CONFIG.heat.label,
      icon: INS_TRIGGER_CONFIG.heat.icon,
      days: heatDaysTriggered,
      maxStreak: maxHeatStreak,
      payout,
      evidence: `${heatDaysTriggered} days with THI > ${INS_TRIGGER_CONFIG.heat.thiThreshold} (max streak: ${maxHeatStreak} days)`,
      severity: maxHeatStreak >= 7 ? 'critical' : 'alert'
    });
  } else {
    currentHeatLevel = maxHeatStreak > 0 ? 'low' : 'low'; 
  }
  hazards['heat'] = { level: currentHeatLevel };

  /* ---------- DROUGHT ---------- */
  const rainSeries = NasaPower.getSeries(parameter, 'PRECTOTCORR') || [];
  const last30 = rainSeries.slice(-30);
  const totalRain = last30.reduce((s, d) => s + (d.value > 0 ? d.value : 0), 0);

  if (totalRain < INS_TRIGGER_CONFIG.drought.rainThresholdMm && last30.length >= 20) {
    hazards['drought'] = { level: totalRain < 5 ? 'high' : 'medium' };
    triggers.push({
      type: 'drought',
      label: INS_TRIGGER_CONFIG.drought.label,
      icon: INS_TRIGGER_CONFIG.drought.icon,
      totalRain: Math.round(totalRain * 10) / 10,
      payout: INS_TRIGGER_CONFIG.drought.payoutFlat,
      evidence: `Only ${totalRain.toFixed(1)}mm rain in last ${last30.length} days`,
      severity: totalRain < 5 ? 'critical' : 'alert'
    });
  } else {
    hazards['drought'] = { level: 'low' };
  }

  /* ---------- FLOOD ---------- */
  if (window.NasaFlood && typeof NasaFlood.calculateFloodRisk === 'function') {
    const soilRoot = NasaPower.getLatest(parameter, 'GWETROOT');
    const soilTop  = NasaPower.getLatest(parameter, 'GWETTOP');
    const rain7d   = rainSeries.slice(-7).reduce((s, d) => s + (d.value > 0 ? d.value : 0), 0);

    const floodRisk = NasaFlood.calculateFloodRisk({
      rain7dayMm: rain7d,
      soilRoot: soilRoot ? soilRoot.value : 0,
      soilTop:  soilTop  ? soilTop.value  : 0,
      rain48hForecast: 0,
      rain72hForecast: 0,
      district: districtKey,
      daysOfRain: rainSeries.filter(d => d.value > 5).length
    });

    if (floodRisk.score >= INS_TRIGGER_CONFIG.flood.scoreThreshold) {
      hazards['flood'] = { level: floodRisk.level === 'critical' ? 'high' : 'medium' };
      triggers.push({
        type: 'flood',
        label: INS_TRIGGER_CONFIG.flood.label,
        icon: INS_TRIGGER_CONFIG.flood.icon,
        score: floodRisk.score,
        level: floodRisk.level,
        payout: INS_TRIGGER_CONFIG.flood.payoutFlat,
        evidence: `Flood risk ${floodRisk.score}% (${floodRisk.level})`,
        severity: floodRisk.level === 'critical' ? 'critical' : 'alert'
      });
    } else {
      hazards['flood'] = { level: 'low' };
    }
  }

  /* ---------- AIR ---------- */
  if (window.OpenMeteo && typeof OpenMeteo.getAQI === 'function' && coords) {
    try {
      const aqi = await Promise.race([
        OpenMeteo.getAQI(coords.lat, coords.lng),
        new Promise(r => setTimeout(() => r(null), 5000))
      ]);
      if (aqi && Number.isFinite(aqi.usAqi) && aqi.usAqi > INS_TRIGGER_CONFIG.air.aqiThreshold) {
        hazards['air'] = { level: aqi.usAqi > 300 ? 'high' : 'medium' };
        const payout = INS_TRIGGER_CONFIG.air.payoutPerDay * INS_TRIGGER_CONFIG.air.consecutiveDays;
        triggers.push({
          type: 'air',
          label: INS_TRIGGER_CONFIG.air.label,
          icon: INS_TRIGGER_CONFIG.air.icon,
          aqi: Math.round(aqi.usAqi),
          payout,
          evidence: `AQI ${Math.round(aqi.usAqi)} (>${INS_TRIGGER_CONFIG.air.aqiThreshold})`,
          severity: aqi.usAqi > 300 ? 'critical' : 'alert'
        });
      } else {
        hazards['air'] = { level: aqi && aqi.usAqi > 100 ? 'medium' : 'low' }; 
      }
    } catch (_) {
      hazards['air'] = { level: 'low' };
    }
  }

  /* ---------- COVERAGE GAP ANALYSIS ---------- */
  const coverageGaps = [];
  const HAZARD_META = {
    flood:   { name: 'Flood',       icon: '🌊' },
    heat:    { name: 'Heat stress', icon: '🌡️' },
    drought: { name: 'Drought',     icon: '🏜️' },
    air:     { name: 'Air quality', icon: '💨' }
  };

  Object.keys(hazards).forEach(key => {
    const isCovered = DEFAULT_COVERED_HAZARDS.includes(key);
    const isRisky = hazards[key].level === 'medium' || hazards[key].level === 'high';

    if (!isCovered && isRisky) {
      coverageGaps.push({
        hazard: key,
        name: HAZARD_META[key]?.name || key,
        icon: HAZARD_META[key]?.icon || '•',
        level: hazards[key].level,
        severity: hazards[key].level === 'high' ? 'high' : 'medium'
      });
    }
  });

  return { triggers, coverageGaps };
}

/* ============================================================
   POLICY STORAGE (Firestore)
   ============================================================ */
async function loadActivePolicies() {
  const phone = currentUserPhone;
  if (!phone) return [];
  try {
    const snap = await firebase.firestore()
      .collection('users').doc(phone)
      .collection('insurance_policies')
      .where('status', '==', 'active')
      .limit(10).get();

    const policies = [];
    snap.forEach(doc => policies.push({ id: doc.id, ...doc.data() }));
    return policies;
  } catch (err) {
    console.warn('[Claim] Load policies failed:', err.message);
    return [];
  }
}

async function savePolicy(policyData) {
  const phone = currentUserPhone;
  if (!phone) return null;
  try {
    const ref = await firebase.firestore()
      .collection('users').doc(phone)
      .collection('insurance_policies')
      .add({
        ...policyData,
        // ম্যানুয়াল পেমেন্ট হলে 'pending', অটোমেটিক হলে 'active'
        status: policyData.paymentMethod === 'manual' ? 'pending' : 'active',
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
        createdAtMs: Date.now(),
        claims: [],
        totalPaidOut: 0
      });
    console.log('✅ Policy saved:', ref.id);
    return ref.id;
  } catch (err) {
    console.warn('[Claim] Save policy failed:', err.message);
    return null;
  }
}

/* ============================================================
   🆕 MANUAL CLAIM FILING (No API call, saves to Firestore as Pending)
   ============================================================ */
async function fileClaim(policyId, trigger) {
  const phone = currentUserPhone;
  if (!phone || !policyId) return null;

  // 1. Payout Account Check
  let userPayout = { method: '', number: '', bankName: '', accountName: '' };
  try {
    const userDoc = await firebase.firestore().collection('users').doc(phone).get();
    const u = userDoc.data() || {};
    if (!u.payoutMethod || !u.payoutNumber) {
      alert('Please add a payout account in your Profile before filing a claim.\n\nGo to: Profile → Payout Account');
      window.location.href = 'profile.html';
      return null;
    }
    userPayout = {
      method: u.payoutMethod,
      number: u.payoutNumber,
      bankName: u.payoutBankName || '',
      accountName: u.payoutAccountName || ''
    };
  } catch (err) {
    console.warn('[Claim] Payout account lookup failed:', err.message);
    alert('Could not verify payout account. Please check your internet and try again.');
    return null;
  }

  // 2. Build the claim object (Pending status for admin to verify)
  const claim = {
    trigger: trigger.type,
    label: trigger.label,
    icon: trigger.icon,
    payout: trigger.payout,
    evidence: trigger.evidence,
    severity: trigger.severity || 'alert',
    status: 'pending_manual_verification', // ⬅️ ডেটা সেভ থাকবে, অ্যাডমিন চেক করবে
    payoutMethod: userPayout.method,
    payoutNumber: userPayout.number,
    payoutBankName: userPayout.bankName,
    payoutAccountName: userPayout.accountName,
    filedAt: Date.now(),
    filedAtServer: firebase.firestore.FieldValue.serverTimestamp()
  };

  // 3. Save to Firestore
  try {
    const ref = firebase.firestore()
      .collection('users').doc(phone)
      .collection('insurance_policies').doc(policyId);

    await ref.update({
      claims: firebase.firestore.FieldValue.arrayUnion(claim),
      lastClaimAt: Date.now()
      // totalPaidOut is NOT updated here. It updates when admin verifies.
    });

    console.log('✅ Claim filed (Pending Verification):', trigger.type);
    return claim;
  } catch (err) {
    console.warn('[Claim] Firestore save failed:', err.message);
    alert('❌ Could not save claim: ' + err.message);
    return null;
  }
}

/* ============================================================
   UI: Trigger Status
   ============================================================ */
function renderTriggerStatus(triggers, policies) {
  const host = document.getElementById('triggerStatus');
  if (!host) return;

  const totalPayout = triggers.reduce((s, t) => s + (t.payout || 0), 0);

  if (!triggers.length) {
    host.innerHTML = `
      <div class="ins-trigger-box ins-trigger-safe">
        <div class="ins-trigger-icon">✅</div>
        <div class="ins-trigger-body">
          <div class="ins-trigger-title">No triggers detected</div>
          <div class="ins-trigger-sub">All weather indices within normal range. Policy is safe.</div>
        </div>
      </div>`;
    return;
  }

  const listHtml = triggers.map(t => `
    <div class="ins-trigger-row ins-trigger-${t.severity}">
      <div class="ins-trigger-row-icon">${t.icon}</div>
      <div class="ins-trigger-row-body">
        <div class="ins-trigger-row-title">${t.label} — Triggered</div>
        <div class="ins-trigger-row-evidence">${t.evidence}</div>
      </div>
      <div class="ins-trigger-row-payout">৳${t.payout.toLocaleString('en-IN')}</div>
    </div>
  `).join('');

  host.innerHTML = `
    <div class="ins-trigger-box ins-trigger-alert">
      <div class="ins-trigger-header">
        <div>
          <div class="ins-trigger-title">
            🚨 ${triggers.length} trigger${triggers.length > 1 ? 's' : ''} detected
          </div>
          <div class="ins-trigger-sub">
            ${policies.length > 0
              ? 'Your active policy qualifies for automatic payout.'
              : 'Buy a policy to claim this payout.'}
          </div>
        </div>
        <div class="ins-trigger-total">৳${totalPayout.toLocaleString('en-IN')}</div>
      </div>
      <div class="ins-trigger-list">${listHtml}</div>
      ${policies.length === 0 ? `
        <button type="button" class="ins-trigger-cta" onclick="window.buyPolicyNow()">
          <i class="fas fa-plus-circle"></i> Buy Policy & Claim ৳${totalPayout.toLocaleString('en-IN')}
        </button>
      ` : `
        <button type="button" class="ins-trigger-cta" onclick="window.claimAllTriggers()">
          <i class="fas fa-hand-holding-dollar"></i> Claim ৳${totalPayout.toLocaleString('en-IN')} Now
        </button>
      `}
    </div>`;
}

/* ============================================================
   UI: Active Policy
   ============================================================ */
function renderActivePolicy(policy) {
  const host = document.getElementById('activePolicyCard');
  if (!host) return;

  if (!policy) {
    host.innerHTML = `
      <div class="ins-policy-empty">
        <div class="ins-policy-empty-icon">🛡️</div>
        <div>
          <div class="ins-policy-empty-title">No active policy</div>
          <div class="ins-policy-empty-sub">Buy a parametric policy to get automatic payouts.</div>
        </div>
      </div>`;
    return;
  }

  const totalPaid = policy.totalPaidOut || 0;
  const claims = Array.isArray(policy.claims) ? policy.claims : [];
  const lastClaim = claims.length > 0 ? claims[claims.length - 1] : null;

  host.innerHTML = `
    <div class="ins-policy-card">
      <div class="ins-policy-header">
        <div class="ins-policy-badge">ACTIVE</div>
        <div class="ins-policy-premium">৳${policy.premium}/mo</div>
      </div>
      <div class="ins-policy-body">
        <div class="ins-policy-row">
          <span>Animal</span>
          <b>${(policy.animalType || 'cow').toUpperCase()}</b>
        </div>
        <div class="ins-policy-row">
          <span>District</span>
          <b>${(policy.district || 'dhaka').toUpperCase()}</b>
        </div>
        <div class="ins-policy-row">
          <span>Total paid out</span>
          <b style="color:#047857;">৳${totalPaid.toLocaleString('en-IN')}</b>
        </div>
        <div class="ins-policy-row">
          <span>Claims filed</span>
          <b>${claims.length}</b>
        </div>
      </div>
      ${lastClaim ? `
        <div class="ins-policy-lastclaim">
          <i class="fas fa-clock"></i>
          Last: ${lastClaim.icon} ${lastClaim.label} — ৳${lastClaim.payout.toLocaleString('en-IN')}
          ${lastClaim.status === 'pending_manual_verification' ? ' (Pending)' : ''}
        </div>
      ` : ''}
    </div>`;
}

/* ============================================================
   BUTTON HANDLERS
   ============================================================ */
window.buyPolicyNow = async function () {
  if (!currentUserPhone) {
    alert('Please login first.');
    return;
  }
  window.location.href = 'insurance-policy.html';
};

window.claimAllTriggers = async function () {
  const policies = await loadActivePolicies();
  if (!policies.length) {
    alert('No active policy. Buy one first.');
    return;
  }
  const policy = policies[0];
  const result = await detectTriggers(currentDistrict, policy.animalType || 'cow');
  const triggers = result.triggers || [];

  if (!triggers.length) {
    alert('No triggers right now.');
    return;
  }

  let total = 0;
  for (const t of triggers) {
    const claim = await fileClaim(policy.id, t);
    if (claim) total += claim.payout;
  }

  if (total > 0) {
    alert(`✅ Claim submitted for ৳${total.toLocaleString('en-IN')}!\n\nAdmin will verify and send the money to your bKash/Nagad within 24 hours.`);
    await refreshInsuranceDashboard();
  } else {
    alert('❌ Could not submit claim. Try again.');
  }
};

/* ============================================================
   MAIN REFRESH
   ============================================================ */
async function refreshInsuranceDashboard() {
  const policies = await loadActivePolicies();
  const policy = policies.length > 0 ? policies[0] : null;
  renderActivePolicy(policy);

  const tDistrict = policy && policy.district ? policy.district : currentDistrict;
  const result = await detectTriggers(
    tDistrict,
    policy ? policy.animalType : 'cow',
    policy ? policy.lat : undefined,
    policy ? policy.lng : undefined
  );

  const triggers = result.triggers || [];

  renderTriggerStatus(triggers, policies);

  window.__lastTriggers = triggers;
  window.__activePolicies = policies;
}

/* ============================================================
   Muzzle biometric (unchanged)
   ============================================================ */
const _elINS = id => document.getElementById(id);
const _insSleep = ms => new Promise(r => setTimeout(r, ms));

function _insMarkKeyFailed(index, errorType) {
  const st = _insKeyStatus[index];
  const base = INS_BLOCK_MS[errorType] || 8 * 1000;
  st.blockedUntil = Date.now() + base * Math.min(1 + st.failCount * 0.3, 2.5);
  st.failCount += 1;
}
function _insMarkKeySuccess(index) {
  _insBestKeyIndex = index;
  Object.assign(_insKeyStatus[index], { failCount: 0, blockedUntil: 0 });
}
function _insGetLiveKeys() {
  const now = Date.now();
  const order = Array.from({ length: INS_GEMINI_KEYS.length }, (_, i) =>
    (_insBestKeyIndex + i) % INS_GEMINI_KEYS.length);
  let live = order.filter(i => _insKeyStatus[i].blockedUntil <= now);
  if (!live.length) live = order.slice(0, 3);
  return live;
}

function compressImage(file, maxSize = 1024, quality = 0.85) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('File read failed'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('Invalid image'));
      img.onload = () => {
        const scale = Math.min(1, maxSize / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

async function setImageForSlot(slot, file) {
  if (!file) return;
  if (!file.type.startsWith('image/')) {
    alert('Please choose an image file.');
    return;
  }
  try {
    const base64 = await compressImage(file);
    const box = document.getElementById('box' + slot);
    const img = document.getElementById('img' + slot);
    if (!box || !img) return;

    img.src = base64;
    img.style.display = 'block';
    box.classList.add('has-image');

    const removeBtn = box.querySelector('.scan-remove');
    if (removeBtn) removeBtn.style.display = 'inline-flex';

    if (slot === 1) image1Base64 = base64;
    else image2Base64 = base64;

    checkReadyToScan();
  } catch (err) {
    alert('Image could not be loaded: ' + err.message);
  }
}

function clearImageSlot(slot, e) {
  if (e) { e.stopPropagation(); e.preventDefault(); }
  const box = document.getElementById('box' + slot);
  const img = document.getElementById('img' + slot);
  const input = document.getElementById('file' + slot);
  if (img) { img.src = ''; img.style.display = 'none'; }
  if (box) {
    box.classList.remove('has-image');
    const removeBtn = box.querySelector('.scan-remove');
    if (removeBtn) removeBtn.style.display = 'none';
  }
  if (input) input.value = '';
  if (slot === 1) image1Base64 = null;
  else image2Base64 = null;
  checkReadyToScan();
}

function setupImageUpload(slot) {
  const input = document.getElementById('file' + slot);
  const box = document.getElementById('box' + slot);
  if (!input || !box) return;

  box.addEventListener('click', (e) => {
    if (e.target.closest('.scan-remove')) return;
    input.click();
  });

  input.addEventListener('change', async (e) => {
    const file = e.target.files && e.target.files[0];
    if (file) await setImageForSlot(slot, file);
  });

  ['dragenter', 'dragover'].forEach(evt => {
    box.addEventListener(evt, (e) => {
      e.preventDefault(); e.stopPropagation();
      box.classList.add('scan-dragover');
    });
  });
  ['dragleave', 'drop'].forEach(evt => {
    box.addEventListener(evt, (e) => {
      e.preventDefault(); e.stopPropagation();
      if (evt === 'dragleave' && box.contains(e.relatedTarget)) return;
      box.classList.remove('scan-dragover');
    });
  });
  box.addEventListener('drop', async (e) => {
    const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
    if (file) await setImageForSlot(slot, file);
  });

  box.setAttribute('tabindex', '0');
  box.addEventListener('paste', async (e) => {
    const items = e.clipboardData && e.clipboardData.items;
    if (!items) return;
    for (const item of items) {
      if (item.type && item.type.startsWith('image/')) {
        e.preventDefault();
        const file = item.getAsFile();
        if (file) await setImageForSlot(slot, file);
        break;
      }
    }
  });
}

document.addEventListener('paste', async (e) => {
  if (!document.querySelector('.scan-grid')) return;
  const items = e.clipboardData && e.clipboardData.items;
  if (!items) return;
  let file = null;
  for (const item of items) {
    if (item.type && item.type.startsWith('image/')) { file = item.getAsFile(); break; }
  }
  if (!file) return;
  const focusedBox = document.activeElement && document.activeElement.closest('.scan-box');
  if (focusedBox) return;
  let slot = null;
  if (!image1Base64) slot = 1;
  else if (!image2Base64) slot = 2;
  if (slot) { e.preventDefault(); await setImageForSlot(slot, file); }
});

function checkReadyToScan() {
  const btn = document.getElementById('verifyBtn');
  if (btn) btn.disabled = !(image1Base64 && image2Base64);
}

function _buildMuzzlePayload(img1, img2) {
  const prompt =
    'You are an insurance fraud analyst. Image 1 is the ORIGINAL registered photo of a cow muzzle (nose print). ' +
    'Image 2 is the CLAIM photo. Compare the muzzle ridge/bead patterns, nostril shape and visible markings. ' +
    'Decide whether both images show the same animal. If an image is not a clear cow muzzle, set match to false ' +
    'and low confidence. Respond with JSON only.';

  return {
    contents: [{
      role: 'user',
      parts: [
        { text: prompt },
        { text: 'Image 1 (original):' },
        { inline_data: { mime_type: 'image/jpeg', data: img1.split(',')[1] } },
        { text: 'Image 2 (claim):' },
        { inline_data: { mime_type: 'image/jpeg', data: img2.split(',')[1] } }
      ]
    }],
    generationConfig: {
      temperature: 0.1,
      maxOutputTokens: 1024,
      topP: 0.95,
      responseMimeType: 'application/json'
    }
  };
}

function parseGeminiJSON(rawText) {
  let parsed;
  try { parsed = JSON.parse(rawText); }
  catch {
    const match = rawText.match(/\{[\s\S]*\}/);
    if (!match) throw new Error('No JSON in response');
    parsed = JSON.parse(match[0]);
  }
  if (parsed && typeof parsed === 'object') {
    if (typeof parsed.match === 'string') parsed.match = /true/i.test(parsed.match);
    if (typeof parsed.confidence === 'string') parsed.confidence = parseInt(parsed.confidence, 10) || 0;
    if (parsed.match === undefined) parsed.match = false;
    if (parsed.confidence === undefined) parsed.confidence = 0;
    if (!parsed.reason) parsed.reason = '';
  }
  return parsed;
}

async function _insCallOne(apiKey, keyIndex, model, payload) {
  const url = `${INS_API_BASE}/${model}:generateContent?key=${apiKey}`;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), INS_PER_CALL_TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (!response.ok) {
      const status = response.status;
      const errBody = await response.text().catch(() => '');
      const errorType =
        status === 429 ? 'rate_limit' :
        (status === 401 || status === 403) ? 'invalid' :
        status === 404 ? 'model_gone' :
        (status === 400 && /api[_ ]key (?:not valid|invalid|expired)|API_KEY_INVALID/i.test(errBody)) ? 'invalid' :
        status >= 500 ? 'server' : 'network';
      return { success: false, errorType, status, keyIndex };
    }

    const data = await response.json();
    const rawText = (data.candidates?.[0]?.content?.parts || [])
      .filter(pt => pt && pt.text && !pt.thought)
      .map(pt => pt.text).join('');
    if (!rawText) return { success: false, errorType: 'empty', keyIndex };

    const parsed = parseGeminiJSON(rawText);
    return { success: true, data: parsed, keyIndex };
  } catch (err) {
    clearTimeout(timeoutId);
    const errorType = err?.name === 'AbortError' ? 'timeout' : 'network';
    return { success: false, errorType, keyIndex };
  }
}

function _insFallbackResult(debugInfo = '') {
  return {
    match: false,
    confidence: 0,
    reason: 'AI service could not complete verification (network/API issue). Claim has been moved to manual review.',
    _fallback: true,
    _debug: debugInfo
  };
}

async function callMuzzleGemini(img1, img2) {
  const payload = _buildMuzzlePayload(img1, img2);
  const start = Date.now();
  const liveKeys = _insGetLiveKeys();

  for (let round = 1; round <= 2; round++) {
    const remaining = INS_OVERALL_TIMEOUT_MS - (Date.now() - start);
    if (remaining < 800) break;

    if (round === 1) {
      const racePromises = [];
      const used = new Set();
      for (let k = 0; k < Math.min(2, liveKeys.length); k++) {
        const keyIdx = liveKeys[k];
        for (let m = 0; m < Math.min(2, INS_VISION_MODELS.length); m++) {
          const model = INS_VISION_MODELS[m];
          const id = `${keyIdx}-${model}`;
          if (used.has(id)) continue;
          used.add(id);
          racePromises.push(
            _insCallOne(INS_GEMINI_KEYS[keyIdx], keyIdx, model, payload)
              .then(r => ({ ...r, model }))
          );
        }
      }

      const timeoutPromise = new Promise(resolve =>
        setTimeout(() => resolve({ success: false, errorType: 'overall_timeout' }), remaining));

      const firstResult = await Promise.race([
        Promise.any(racePromises.map(p => p.then(r => {
          if (r.success) return r;
          throw r;
        }))).catch(() => ({ success: false, errorType: 'all_race_failed' })),
        timeoutPromise
      ]);

      if (firstResult && firstResult.success) {
        _insMarkKeySuccess(firstResult.keyIndex);
        console.log(`✅ Muzzle verify OK via ${firstResult.model} (key #${firstResult.keyIndex + 1})`);
        return firstResult.data;
      }
      await _insSleep(400);
    }

    if (round === 2) {
      for (const keyIdx of liveKeys) {
        for (const model of INS_VISION_MODELS) {
          if (Date.now() - start > INS_OVERALL_TIMEOUT_MS - 700) break;
          const result = await _insCallOne(INS_GEMINI_KEYS[keyIdx], keyIdx, model, payload);
          if (result.success) {
            _insMarkKeySuccess(keyIdx);
            console.log(`✅ Muzzle verify OK (round 2) via ${model} (key #${keyIdx + 1})`);
            return result.data;
          }
          if (result.errorType === 'model_gone') continue;
          if (['rate_limit', 'invalid', 'timeout', 'network', 'badOutput', 'empty'].includes(result.errorType)) {
            _insMarkKeyFailed(keyIdx, result.errorType);
          }
        }
      }
    }
  }

  console.warn('⚠️ All muzzle verification attempts failed — returning fallback');
  return _insFallbackResult('all_attempts_failed');
}

async function verifyMuzzleBiometric() {
  if (!image1Base64 || !image2Base64) return;

  const btn = document.getElementById('verifyBtn');
  const resultBox = document.getElementById('claimResult');
  const resultText = document.getElementById('claimText');

  btn.disabled = true;
  btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> AI Scanning...';
  resultBox.style.display = 'none';
  resultBox.className = 'claim-result';
  resultText.textContent = '';

  let parsed = null;
  try {
    parsed = await callMuzzleGemini(image1Base64, image2Base64);
  } catch (err) {
    console.error('Muzzle scan threw:', err);
    parsed = _insFallbackResult(err.message);
  }

  if (!parsed) parsed = _insFallbackResult('null_result');

  const strong = document.createElement('strong');
  const reasonEl = document.createElement('div');
  const verdict = document.createElement('b');

  if (parsed._fallback) {
    resultBox.classList.add('error');
    strong.textContent = '⚠️ Verification Unavailable';
    reasonEl.textContent = parsed.reason;
    verdict.textContent = 'Claim moved to manual review — please retry shortly.';
  } else {
    const conf = Number(parsed.confidence) || 0;
    const ok = parsed.match === true && conf > 80;
    resultBox.classList.add(ok ? 'success' : 'error');
    strong.textContent = ok
      ? `✅ Match Found (${conf}%)`
      : `❌ Fraud Suspected (match confidence ${conf}%)`;
    reasonEl.textContent = parsed.reason || 'AI analyzed both muzzle images.';
    verdict.textContent = ok ? 'Claim Approved!' : 'Claim Rejected.';
  }

  resultText.append(strong, document.createElement('br'), reasonEl,
    document.createElement('br'), verdict);
  resultBox.style.display = 'block';

  btn.disabled = false;
  btn.innerHTML = '<i class="fas fa-fingerprint"></i> Verify Biometrics';
}

/* ============================================================
   INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  currentUserPhone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
  if (!currentUserPhone) {
    window.location.href = 'login.html';
    return;
  }

  if (!window.BD_DISTRICTS_LIST) {
    console.error('[Insurance] bd-districts.js not loaded — 64 districts unavailable');
  }

  const isHub = !!(document.getElementById('premiumVal') || document.getElementById('activePolicyCard') || document.getElementById('triggerStatus'));
  if (!isHub) return;

  if (!window.__insPickerManaged) {
    const hasCache = showCachedPremium();
    if (!hasCache) {
      loadLivePremium(currentDistrict, 'cow');
    } else {
      setTimeout(() => loadLivePremium(currentDistrict, 'cow'), 2000);
    }
  }

  const coverage = localStorage.getItem('dvInsuranceCoverage');
  if (coverage) {
    setTimeout(() => {
      const box = document.getElementById('premiumBreakdown');
      if (box) {
        const html = `
          <div style="margin-bottom: 12px; padding: 10px 14px; background: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 10px; font-size: 13px; color: #1E40AF; font-weight: 700; display: flex; align-items: center; gap: 8px;">
            <i class="fas fa-info-circle" style="font-size: 16px;"></i>
            Coverage requested: ৳${Number(coverage).toLocaleString('en-IN')}
          </div>
        `;
        box.insertAdjacentHTML('afterbegin', html);
      }
      localStorage.removeItem('dvInsuranceCoverage');
    }, 1500);
  }

  setTimeout(() => refreshInsuranceDashboard(), 3000);
});

/* ============================================================
   Debug
   ============================================================ */
window.INSDebug = {
  status() {
    console.table(_insKeyStatus.map((s, i) => ({
      key: '#' + (i + 1),
      blockedFor_s: Math.max(0, Math.round((s.blockedUntil - Date.now()) / 1000)),
      failCount: s.failCount,
      best: i === _insBestKeyIndex ? '⭐' : ''
    })));
    console.log('Districts loaded:', Object.keys(INS_DISTRICT_COORDS).length);
  },
  reset() {
    _insKeyStatus.forEach(s => Object.assign(s, { blockedUntil: 0, failCount: 0 }));
    console.log('♻️ Insurance keys reset');
  },
  async fetchRisk(district) {
    const r = await fetchLiveRiskData(district || 'dhaka');
    console.log('Live risk data:', r);
    return r;
  },
  calcPremium(riskData, animal) {
    console.log(calculatePremiumFromRisk(riskData, animal || 'cow'));
  },
  refreshPremium: () => loadLivePremium(currentDistrict, 'cow'),
  async testTriggers(district) {
    const t = await detectTriggers(district || currentDistrict, 'cow');
    console.log('Triggers & Gaps:', t);
    return t;
  },
  async policies() {
    const p = await loadActivePolicies();
    console.log('Active policies:', p);
    return p;
  },
  triggerConfig: INS_TRIGGER_CONFIG,
  refresh: refreshInsuranceDashboard
};

window.refreshInsuranceDashboard = refreshInsuranceDashboard;
window.detectTriggers = detectTriggers;