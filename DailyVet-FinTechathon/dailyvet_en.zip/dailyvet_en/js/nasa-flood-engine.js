/* ============================================================
   DailyVet — NASA Flood Early Warning Engine v1.0
   Inputs : NASA GPM (PRECTOTCORR), SMAP (GWETROOT, GWETTOP, GWETPROF)
            + Open-Meteo 48-72h rainfall forecast
   Output : Flood probability (0-100%), relocation advice,
            safe shelter suggestions, emergency feed plan
   ============================================================ */
(function () {
'use strict';

/* ===== REGIONAL FLOOD VULNERABILITY (Bangladesh-specific) ===== */
const FLOOD_VULNERABILITY = {
    kurigram:    { score: 95, type: 'char',     name: 'Kurigram (Char Area)',    river: 'Brahmaputra/Dharla' },
    gaibandha:   { score: 92, type: 'char',     name: 'Gaibandha (Char Area)',   river: 'Brahmaputra' },
    lalmonirhat: { score: 90, type: 'char',     name: 'Lalmonirhat (Char)',      river: 'Teesta/Dharla' },
    sirajganj:   { score: 88, type: 'riverine', name: 'Sirajganj (Jamuna Bank)', river: 'Jamuna' },
    jamalpur:    { score: 85, type: 'riverine', name: 'Jamalpur (Brahmaputra)',  river: 'Brahmaputra' },
    sunamganj:   { score: 92, type: 'haor',     name: 'Sunamganj (Haor)',        river: 'Surma/Kushiyara' },
    sylhet:      { score: 85, type: 'haor',     name: 'Sylhet (Haor)',           river: 'Surma' },
    netrokona:   { score: 80, type: 'haor',     name: 'Netrokona (Haor)',        river: 'Kangsha' },
    kishoreganj: { score: 82, type: 'haor',     name: 'Kishoreganj (Haor)',      river: 'Old Brahmaputra' },
    faridpur:    { score: 78, type: 'riverine', name: 'Faridpur (Padma)',        river: 'Padma' },
    shariatpur:  { score: 80, type: 'riverine', name: 'Shariatpur (Padma)',      river: 'Padma' },
    chandpur:    { score: 82, type: 'riverine', name: 'Chandpur (Meghna)',       river: 'Meghna' },
    munshiganj:  { score: 85, type: 'riverine', name: 'Munshiganj (Padma-Meghna)', river: 'Padma-Meghna' },
    bogura:      { score: 75, type: 'riverine', name: 'Bogura (Jamuna)',         river: 'Jamuna' },
    pabna:       { score: 80, type: 'riverine', name: 'Pabna (Jamuna)',          river: 'Jamuna' },
    tangail:     { score: 75, type: 'riverine', name: 'Tangail (Jamuna)',        river: 'Jamuna' },
    manikganj:   { score: 78, type: 'riverine', name: 'Manikganj (Padma)',       river: 'Padma' },
    rajshahi:    { score: 65, type: 'riverine', name: 'Rajshahi (Padma)',        river: 'Padma' },
    dhaka:       { score: 60, type: 'mixed',    name: 'Dhaka Division',          river: 'Buriganga/Turag' },
    chittagong:  { score: 70, type: 'coastal',  name: 'Chittagong (Coastal)',    river: 'Karnaphuli' },
    khulna:      { score: 72, type: 'coastal',  name: 'Khulna (Coastal)',        river: 'Rupsha' },
    barisal:     { score: 75, type: 'coastal',  name: 'Barisal (Coastal)',       river: 'Meghna' },
    rangpur:     { score: 82, type: 'char',     name: 'Rangpur Division (Char)', river: 'Teesta' },
    mymensingh:  { score: 78, type: 'riverine', name: 'Mymensingh',              river: 'Old Brahmaputra' }
};

/* ===== FLOOD RISK LEVELS ===== */
const FLOOD_LEVELS = [
    { min: 75, level: 'critical', label: 'Extreme Flood Risk',   color: '#dc2626', bg: '#fef2f2', icon: '🚨',
      action: 'Move livestock NOW — relocate to higher ground within 24 hours' },
    { min: 55, level: 'alert',    label: 'High Flood Risk',      color: '#c2410c', bg: '#fff7ed', icon: '⚠️',
      action: 'Move livestock to safe shelter within 48 hours, stockpile feed' },
    { min: 35, level: 'watch',    label: 'Moderate Flood Risk',  color: '#d97706', bg: '#fef9e7', icon: '👀',
      action: 'Water level may rise — prepare feed, medicine and shelter' },
    { min: 0,  level: 'safe',     label: 'Normal Condition',     color: '#059669', bg: '#ecfdf5', icon: '✅',
      action: 'No immediate flood risk — continue normal operations' }
];

/* ===== HELPERS ===== */
const _isNum = v => v !== null && v !== undefined && v !== '' && Number.isFinite(Number(v));

/* ============================================================
   CORE FLOOD RISK CALCULATOR
   ============================================================ */
function calculateFloodRisk(params) {
    const {
        rain7dayMm = 0,
        soilRoot = 0,
        soilTop = 0,
        rain48hForecast = 0,
        rain72hForecast = 0,
        district = 'dhaka',
        daysOfRain = 0
    } = params || {};

    const breakdown = [];
    let score = 0;

    /* ===== 1. PAST 7-DAY RAINFALL (max 25) ===== */
    let rain7Score = 0;
    if (rain7dayMm > 300)       rain7Score = 25;
    else if (rain7dayMm > 200)  rain7Score = 20;
    else if (rain7dayMm > 120)  rain7Score = 15;
    else if (rain7dayMm > 60)   rain7Score = 10;
    else if (rain7dayMm > 25)   rain7Score = 5;

    score += rain7Score;
    breakdown.push({
        icon: '🌧️',
        label: 'Last 7 Days Rainfall',
        value: `${Math.round(rain7dayMm)} mm`,
        score: rain7Score,
        max: 25,
        reason: rain7Score >= 20 ? 'Excess rainfall — rivers already swollen'
                 : rain7Score >= 10 ? 'Moderate rainfall — soil saturation begins'
                 : 'Recent rainfall is low'
    });

    /* ===== 2. SOIL SATURATION (max 25) ===== */
    const soilAvg = _isNum(soilRoot) && _isNum(soilTop)
        ? (Number(soilRoot) + Number(soilTop)) / 2
        : Number(soilRoot) || Number(soilTop) || 0;

    let soilScore = 0;
    if (soilAvg > 0.85)       soilScore = 25;
    else if (soilAvg > 0.75)  soilScore = 20;
    else if (soilAvg > 0.65)  soilScore = 15;
    else if (soilAvg > 0.50)  soilScore = 8;
    else if (soilAvg > 0.35)  soilScore = 3;

    score += soilScore;
    breakdown.push({
        icon: '💧',
        label: 'Soil Moisture (SMAP)',
        value: `${Math.round(soilAvg * 100)}%`,
        score: soilScore,
        max: 25,
        reason: soilScore >= 20 ? '🚨 Soil nearly saturated — new rain will cause flooding directly'
                 : soilScore >= 15 ? 'Soil is very wet — water absorption capacity is dropping fast'
                 : soilScore >= 8  ? 'Soil is getting wet — keep watching'
                 : 'Soil is dry, will absorb water'
    });

    /* ===== 3. FORECAST RAINFALL 48-72h (max 30) ===== */
    let forecastScore = 0;
    if (rain72hForecast > 200)      forecastScore = 30;
    else if (rain72hForecast > 120) forecastScore = 24;
    else if (rain48hForecast > 80)  forecastScore = 18;
    else if (rain48hForecast > 50)  forecastScore = 12;
    else if (rain48hForecast > 25)  forecastScore = 6;
    else if (rain48hForecast > 10)  forecastScore = 3;

    score += forecastScore;
    breakdown.push({
        icon: '🔮',
        label: 'Rainfall Forecast (Next 48-72h)',
        value: rain72hForecast > 0
            ? `48h: ${Math.round(rain48hForecast)} mm • 72h: ${Math.round(rain72hForecast)} mm`
            : `${Math.round(rain48hForecast)} mm (48h)`,
        score: forecastScore,
        max: 30,
        reason: forecastScore >= 24 ? '🚨 Heavy rainfall expected in the next 72 hours'
                 : forecastScore >= 18 ? 'Significant rainfall coming within 48 hours'
                 : forecastScore >= 6  ? 'Light to moderate rainfall possible'
                 : 'Low chance of rain'
    });

    /* ===== 4. REGIONAL VULNERABILITY (max 20) ===== */
    const districtKey = String(district || '').toLowerCase();
    const vuln = FLOOD_VULNERABILITY[districtKey] || { score: 50, type: 'mixed', name: 'General Area', river: '—' };
    const vulnScore = Math.round(vuln.score / 100 * 20);

    score += vulnScore;
    breakdown.push({
        icon: vuln.type === 'char' ? '🏝️' : vuln.type === 'haor' ? '🌊' : vuln.type === 'coastal' ? '🌅' : '🏞️',
        label: `Regional Flood Vulnerability (${vuln.type})`,
        value: vuln.name,
        score: vulnScore,
        max: 20,
        reason: vuln.type === 'char'    ? `Char area — the ${vuln.river} river can overflow anytime`
                 : vuln.type === 'haor'    ? `Haor area — waterlogging even with light rainfall`
                 : vuln.type === 'coastal' ? `Coastal area — tide + rain = flood`
                 : `Low-lying area along the ${vuln.river}`
    });

    const totalRaw = score;
    const finalScore = Math.min(100, totalRaw);

    const levelDef = FLOOD_LEVELS.find(l => finalScore >= l.min);

    return {
        ...levelDef,
        score: finalScore,
        totalRawScore: totalRaw,
        capped: totalRaw > 100,
        breakdown,
        vulnerability: vuln,
        inputs: {
            rain7dayMm: Math.round(rain7dayMm),
            soilRoot: soilAvg,
            rain48hForecast: Math.round(rain48hForecast),
            rain72hForecast: Math.round(rain72hForecast),
            daysOfRain
        }
    };
}

/* ============================================================
   LIVESTOCK RELOCATION ADVICE
   ============================================================ */
function getRelocationPriority(riskLevel, speciesList) {
    const species = Array.isArray(speciesList) && speciesList.length
        ? speciesList : ['Cow', 'Goat', 'Chicken'];

    const PRIORITY = {
        Chicken: { rank: 1, reason: 'Chicken/ducks drown within 24 hours — move them first' },
        Duck:    { rank: 1, reason: 'Ducks tolerate water but get swept away by currents — move first' },
        Pigeon:  { rank: 1, reason: 'Pigeons are trapped in cages — move immediately' },
        Goat:    { rank: 2, reason: 'Goats drown and are smaller than cattle — second priority' },
        Sheep:   { rank: 2, reason: 'Sheep are weak in water — move before cattle' },
        Cow:     { rank: 3, reason: 'Cows can swim — safe to move last' },
        Buffalo: { rank: 3, reason: 'Buffalo can swim — but heavy, hard to move to high ground' }
    };

    return species
        .map(s => ({
            species: s,
            priority: PRIORITY[s]?.rank || 3,
            reason: PRIORITY[s]?.reason || 'Move to higher ground'
        }))
        .sort((a, b) => a.priority - b.priority);
}

/* ============================================================
   SAFE SHELTER SUGGESTIONS
   ============================================================ */
function getSafeShelterAdvice(riskLevel, district) {
    const vuln = FLOOD_VULNERABILITY[String(district || '').toLowerCase()] || {};

    const GENERAL = [
        { icon: '🏫', title: 'Government School / College Building', note: 'Usually 2-3 storeys, suitable for quick shelter' },
        { icon: '🕌', title: 'Mosque / Madrasa',        note: 'Easy to coordinate with local communities' },
        { icon: '🏥', title: 'Upazila Health Complex',   note: 'Medical care + shelter in one place' },
        { icon: '🏛️', title: 'Union Parishad Building',  note: 'Also used as government relief distribution center' },
        { icon: '⛰️', title: 'High Road / Embankment',   note: 'Last resort — tie animals with rope' }
    ];

    const SPECIFIC = vuln.type === 'char'
        ? [{ icon: '🚤', title: 'Boat / Trawler', note: 'Moving animals by boat is safest in char areas' }]
        : vuln.type === 'haor'
        ? [{ icon: '🛖', title: 'Haor Embankment (Pari)', note: 'Move quickly to elevated thatched structures' }]
        : vuln.type === 'coastal'
        ? [{ icon: '🏢', title: 'Cyclone Shelter', note: 'Safest during tide + rain' }]
        : [];

    return [...SPECIFIC, ...GENERAL].slice(0, 5);
}

/* ============================================================
   EMERGENCY FEED PLAN (7-day)
   ============================================================ */
function getEmergencyFeedPlan(riskLevel, speciesList) {
    const species = Array.isArray(speciesList) && speciesList.length ? speciesList : ['Cow'];
    const isCritical = riskLevel === 'critical' || riskLevel === 'alert';
    const days = isCritical ? 7 : 3;

    const perHead = {
        Cow:     { hay: 8,  concentrate: 2, water: 40, note: 'Dry hay + molasses-bran mix' },
        Buffalo: { hay: 10, concentrate: 2.5, water: 50, note: 'Dry hay + oil cake' },
        Goat:    { hay: 1.5, concentrate: 0.4, water: 5, note: 'Dry grass + bran' },
        Sheep:   { hay: 1.5, concentrate: 0.4, water: 5, note: 'Dry grass + bran' },
        Chicken: { hay: 0,  concentrate: 0.12, water: 0.25, note: 'Chicken grain mix' },
        Duck:    { hay: 0,  concentrate: 0.15, water: 0.4, note: 'Wet feed + grain' },
        Pigeon:  { hay: 0,  concentrate: 0.05, water: 0.1, note: 'Grain + crushed chickpea' }
    };

    const plan = species.map(s => {
        const p = perHead[s] || perHead.Cow;
        return {
            species: s,
            days,
            hayKg: Math.round(p.hay * days * 10) / 10,
            concentrateKg: Math.round(p.concentrate * days * 10) / 10,
            waterLt: Math.round(p.water * days),
            note: p.note
        };
    });

    const tips = [
        '🧂 Give a small amount of salt-mineral mix daily — reduces stress',
        '💊 ORS / electrolyte water every 2 days',
        '🌾 Never give wet feed — it rots and causes diarrhea',
        '🥇 Feed pregnant and lactating animals first',
        '📦 Wrap feed in polythene bags and store on high shelves'
    ];

    return { plan, tips, days };
}

/* ============================================================
   PUBLIC API
   ============================================================ */
window.NasaFlood = {
    calculateFloodRisk,
    getRelocationPriority,
    getSafeShelterAdvice,
    getEmergencyFeedPlan,
    FLOOD_VULNERABILITY,
    FLOOD_LEVELS
};

})();