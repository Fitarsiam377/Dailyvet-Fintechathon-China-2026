/* ============================================================
   DailyVet — AI Chat Sidebar (history + my info + logout)
   ✅ Conversations saved in Firestore: users/{phone}/ai_conversations
   ✅ Real-time list, search, switch, delete, new chat
   ✅ Restores messages (with user photo + original time)
   ✅ Sidebar footer shows live user details + Logout
   ✅ Desktop: sidebar always visible · Mobile: drawer
   ============================================================ */
(function () {
'use strict';

/* ---------- STATE ---------- */
let currentConvId = null;
let allConversations = [];
let unsubscribeConversations = null;
let unsubscribeUser = null;
let sidebarOpen = false;

// Live user info (photo + name + phone + city) — used by sidebar list & footer
const me = { photo: '', name: '', phone: '', city: '' };

const _el = id => document.getElementById(id);
const _fs = () => firebase.firestore();
const isDesktop = () => window.innerWidth >= 1024;
const isEn = () => true;
const T = (bn, en) => en;

function _setCurrentConvId(id) {
    currentConvId = id;
    window.__currentConvId = id;   // ai.js reads this to know if a conversation is active
}

/* Same phone value everywhere (home.js / ai.js use the raw value as the users/{doc} id) */
function getMyPhone() {
    const p = (sessionStorage.getItem('userPhone') || localStorage.getItem('userPhone') || '').trim();
    if (p) {
        try {
            sessionStorage.setItem('userPhone', p);
            localStorage.setItem('userPhone', p);
        } catch (_) {}
    }
    return p;
}

const _convRef = () => {
    const phone = getMyPhone();
    return phone ? _fs().collection('users').doc(phone).collection('ai_conversations') : null;
};

/* ---------- HELPERS ---------- */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = String(text ?? '');
    return div.innerHTML;
}
function escapeJs(text) {
    return String(text ?? '').replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/"/g, '&quot;').replace(/\n/g, ' ');
}
function toDate(ts) {
    if (!ts) return null;
    const d = typeof ts.toDate === 'function' ? ts.toDate() : new Date(ts);
    return isNaN(d) ? null : d;
}
function formatRelativeTime(ts) {
    const d = toDate(ts);
    if (!d) return 'Just now';
    const diff = Date.now() - d.getTime();
    const min = 60000, hour = 60 * min, day = 24 * hour;
    if (diff < min) return 'Just now';
    if (diff < hour) return Math.floor(diff / min) + 'm ago';
    if (diff < day) return Math.floor(diff / hour) + 'h ago';
    if (diff < 7 * day) return Math.floor(diff / day) + 'd ago';
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
}
const toBn = n => String(n); // unused, English only

/* ============================================================
   USER INFO (live) → conversation avatars + sidebar footer
   ============================================================ */
function startUserListener() {
    const phone = getMyPhone();
    me.phone = phone;
    me.name = localStorage.getItem('userName') || sessionStorage.getItem('userName') || '';
    renderUserFooter();
    if (!phone) return;

    if (unsubscribeUser) unsubscribeUser();
    unsubscribeUser = _fs().collection('users').doc(phone).onSnapshot(doc => {
        if (!doc.exists) return;
        const d = doc.data();
        me.photo = d.photoURL && d.photoURL.indexOf('dailyvetlogo') === -1 ? d.photoURL : '';
        me.name = (d.name || me.name || '').trim();
        me.city = [d.area, d.city].filter(Boolean).join(', ');
        if (me.name) {
            try {
                localStorage.setItem('userName', me.name);
                sessionStorage.setItem('userName', me.name);
            } catch (_) {}
        }
        renderUserFooter();
        renderConversations();
    }, err => console.warn('User info listener failed:', err.message));
}

function avatarHTML() {
    const initial = escapeHtml((me.name || 'U').trim().charAt(0).toUpperCase() || 'U');
    return me.photo
        ? `<img src="${escapeHtml(me.photo)}" alt="" onerror="this.replaceWith(document.createTextNode('${initial}'))" />`
        : `<span class="conv-icon-initial">${initial}</span>`;
}

function renderUserFooter() {
    const av = _el('aiUserAvatar');
    const nm = _el('aiUserName');
    const sb = _el('aiUserSub');
    if (av) av.innerHTML = avatarHTML();
    if (nm) nm.textContent = me.name || 'My Info';
    if (sb) sb.textContent = [me.phone, me.city].filter(Boolean).join(' · ');
}

/* ============================================================
   SIDEBAR OPEN / CLOSE  (desktop = always visible)
   ============================================================ */
function openSidebar() {
    const sidebar = _el('chatSidebar');
    if (!sidebar) return;
    sidebar.classList.add('open');
    if (!isDesktop()) _el('sidebarOverlay')?.classList.add('show');
    sidebarOpen = true;
}
function closeSidebar() {
    if (isDesktop()) return;
    _el('chatSidebar')?.classList.remove('open');
    _el('sidebarOverlay')?.classList.remove('show');
    sidebarOpen = false;
}
function toggleSidebar() {
    sidebarOpen ? closeSidebar() : openSidebar();
}
window.openSidebar = openSidebar;
window.closeSidebar = closeSidebar;
window.toggleSidebar = toggleSidebar;

/* ============================================================
   LOAD CONVERSATIONS (real-time)
   ============================================================ */
function loadConversations() {
    const listEl = _el('conversationList');
    if (!listEl) return;

    const ref = _convRef();
    if (!ref) {
        listEl.innerHTML = `<div class="ai-conv-empty">${'Login required to load history.'}</div>`;
        return;
    }

    if (unsubscribeConversations) unsubscribeConversations();
    listEl.innerHTML = `<div class="ai-conv-empty">${'Loading...'}</div>`;

    unsubscribeConversations = ref
        .orderBy('updatedAt', 'desc')
        .limit(60)
        .onSnapshot(snapshot => {
            allConversations = snapshot.docs.map(doc => {
                const data = doc.data();
                return {
                    id: doc.id,
                    title: data.title || 'New Chat',
                    lastMessage: data.lastMessage || '',
                    messageCount: data.messageCount || 0,
                    updatedAt: data.updatedAt,
                    createdAt: data.createdAt
                };
            });
            renderConversations();
        }, err => {
            console.warn('Conversation load failed:', err.message);
            listEl.innerHTML = `<div class="ai-conv-empty">${'Could not load conversations'}</div>`;
        });
}
window.loadConversations = loadConversations;

/* ============================================================
   RENDER CONVERSATION LIST
   ============================================================ */
function renderConversations() {
    const listEl = _el('conversationList');
    const countEl = _el('convCount');
    if (!listEl) return;

    const q = (_el('convSearchInput')?.value || '').toLowerCase().trim();
    const filtered = q
        ? allConversations.filter(c =>
            (c.title || '').toLowerCase().includes(q) ||
            (c.lastMessage || '').toLowerCase().includes(q))
        : allConversations;

    if (countEl) {
        const n = allConversations.length;
        countEl.innerHTML = `<i class="fas fa-layer-group"></i><span>${isEn() ? n + ' chat' + (n !== 1 ? 's' : '') : n + ' chats'}</span>`;
    }

    if (!filtered.length) {
        listEl.innerHTML = q
            ? `<div class="ai-conv-empty"><i class="fas fa-magnifying-glass"></i>${'No matches found'}</div>`
            : `<div class="ai-conv-empty"><i class="fas fa-comment-medical"></i>${'No consultations yet.<br>Start chatting to save history.'}</div>`;
        return;
    }

    listEl.innerHTML = filtered.map(conv => {
        const isActive = conv.id === currentConvId;
        const preview = conv.lastMessage
            ? conv.lastMessage.slice(0, 75) + (conv.lastMessage.length > 75 ? '…' : '')
            : 'No messages yet';
        return `
            <div class="conv-item ${isActive ? 'active' : ''}" data-conv-id="${escapeHtml(conv.id)}"
                 onclick="switchConversation('${escapeJs(conv.id)}')">
                <div class="conv-icon">${avatarHTML()}</div>
                <div class="conv-body">
                    <div class="conv-title">${escapeHtml(conv.title)}</div>
                    <div class="conv-preview">${escapeHtml(preview)}</div>
                    <div class="conv-meta">
                        <span><i class="fas fa-clock"></i> ${formatRelativeTime(conv.updatedAt)}</span>
                        <span><i class="fas fa-message"></i> ${conv.messageCount || 0}</span>
                    </div>
                </div>
                <button type="button" class="conv-delete-btn" title="${'Delete'}"
                        onclick="event.stopPropagation(); deleteConversation('${escapeJs(conv.id)}', '${escapeJs(conv.title)}')">
                    <i class="fas fa-trash-alt"></i>
                </button>
            </div>`;
    }).join('');
}

/* ============================================================
   CREATE / SAVE
   ============================================================ */
async function createConversation(firstMessage) {
    const ref = _convRef();
    if (!ref) return null;
    try {
        const docRef = ref.doc();
        const title = String(firstMessage || 'New Chat').replace(/\s+/g, ' ').slice(0, 40).trim() || 'New Chat';
        await docRef.set({
            title,
            lastMessage: String(firstMessage || '').slice(0, 100),
            messageCount: 0,
            messages: [],
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        _setCurrentConvId(docRef.id);
        return docRef.id;
    } catch (err) {
        console.warn('Create conversation failed:', err.message);
        return null;
    }
}

/* Firestore docs are limited to 1 MB → store only a small thumbnail of sent photos */
function compressImage(dataUrl, maxDim = 480, quality = 0.6) {
    return new Promise(resolve => {
        if (!dataUrl || String(dataUrl).indexOf('data:image') !== 0) return resolve(null);
        const img = new Image();
        img.onload = () => {
            try {
                const scale = Math.min(1, maxDim / Math.max(img.width, img.height));
                const canvas = document.createElement('canvas');
                canvas.width = Math.max(1, Math.round(img.width * scale));
                canvas.height = Math.max(1, Math.round(img.height * scale));
                canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
                const out = canvas.toDataURL('image/jpeg', quality);
                resolve(out.length < 180000 ? out : null);
            } catch (_) { resolve(null); }
        };
        img.onerror = () => resolve(null);
        img.src = dataUrl;
    });
}

async function persistMessage(role, content, imageBase64) {
    if (!currentConvId) {
        const id = await createConversation(content);
        if (!id) return;
    }
    const ref = _convRef();
    if (!ref || !currentConvId) return;

    try {
        const thumb = imageBase64 ? await compressImage(imageBase64) : null;
        const msg = {
            role,
            content: String(content || ''),
            image: thumb,
            timestamp: Date.now()
        };
        await ref.doc(currentConvId).update({
            messages: firebase.firestore.FieldValue.arrayUnion(msg),
            updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
            lastMessage: String(content || (thumb ? '📷' : '')).slice(0, 100),
            messageCount: firebase.firestore.FieldValue.increment(1)
        });
    } catch (err) {
        console.warn('Persist message failed:', err.message);
    }
}

window.createConversation = createConversation;
window.persistMessage = persistMessage;
// ai.js calls these exact names
window.dvCreateConversation = createConversation;
window.dvPersistMessage = persistMessage;

/* ============================================================
   SWITCH CONVERSATION
   ============================================================ */
async function switchConversation(convId) {
    if (!convId) return;
    if (convId === currentConvId) { closeSidebar(); return; }

    const ref = _convRef();
    if (!ref) return;

    try {
        const doc = await ref.doc(convId).get();
        if (!doc.exists) {
            alert('Conversation not found');
            return;
        }

        const messages = Array.isArray(doc.data().messages) ? doc.data().messages : [];
        _setCurrentConvId(convId);

        if (typeof window.stopSpeaking === 'function') window.stopSpeaking();
        if (typeof window.hideLocationRequest === 'function') window.hideLocationRequest();
        if (typeof window.hideNearbyVets === 'function') window.hideNearbyVets();
        if (window._resetConversationHistory) window._resetConversationHistory();

        const container = _el('chatMessages');
        if (container) container.innerHTML = '';

        if (!messages.length) {
            showWelcomeMessage();
        } else {
            messages.forEach(m => window._restoreMessage && window._restoreMessage(m.role, m.content, m.image, m.timestamp));
            const chips = _el('suggestionChips');
            if (chips) chips.style.display = 'none';
        }

        if (window._restoreConversationHistory) {
            window._restoreConversationHistory(
                messages
                    .filter(m => m.role === 'user' || m.role === 'assistant')
                    .map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content }))
            );
        }

        if (container) container.scrollTop = container.scrollHeight;
        closeSidebar();
        renderConversations();
    } catch (err) {
        console.warn('Switch conversation failed:', err.message);
        alert('Could not load conversation.');
    }
}
window.switchConversation = switchConversation;

/* ============================================================
   DELETE
   ============================================================ */
async function deleteConversation(convId, title) {
    if (!convId) return;
    if (!confirm(`🗑️ Delete "${title || 'this conversation'}"?\n\nThis cannot be undone.`)) return;
    const ref = _convRef();
    if (!ref) return;
    try {
        await ref.doc(convId).delete();
        if (convId === currentConvId) {
            _setCurrentConvId(null);
            clearChatUI();
            if (window._resetConversationHistory) window._resetConversationHistory();
        }
    } catch (err) {
        console.warn('Delete conversation failed:', err.message);
        alert('Failed to delete conversation.');
    }
}
window.deleteConversation = deleteConversation;

async function deleteCurrentConversation() {
    const menu = _el('menuDropdown');
    if (menu) menu.style.display = 'none';
    if (!currentConvId) {
        alert('No active conversation to delete.');
        return;
    }
    const conv = allConversations.find(c => c.id === currentConvId);
    await deleteConversation(currentConvId, conv?.title);
}
window.deleteCurrentConversation = deleteCurrentConversation;

/* ============================================================
   NEW CHAT
   ============================================================ */
function startNewChat() {
    _setCurrentConvId(null);
    if (typeof window.stopSpeaking === 'function') window.stopSpeaking();
    if (typeof window.hideLocationRequest === 'function') window.hideLocationRequest();
    if (typeof window.hideNearbyVets === 'function') window.hideNearbyVets();
    clearChatUI();
    if (window._resetConversationHistory) window._resetConversationHistory();
    closeSidebar();
    renderConversations();
    _el('chatInput')?.focus();
}
window.startNewChat = startNewChat;

/* ============================================================
   UI HELPERS
   ============================================================ */
function clearChatUI() {
    const container = _el('chatMessages');
    if (!container) return;
    container.innerHTML = '';
    showWelcomeMessage();
    const chips = _el('suggestionChips');
    if (chips) chips.style.display = 'flex';
}

function showWelcomeMessage() {
    const container = _el('chatMessages');
    if (!container) return;
    const div = document.createElement('div');
    div.className = 'message ai-message';
    div.innerHTML = `
        <div class="avatar ai-avatar-small"><img src="assets/dailyvetlogo.jpeg" alt="AI" /></div>
        <div class="bubble">
            <p class="bubble-title">${'Hello! 🐾'}</p>
            <p>${"Describe your animal's problem or send a photo."}</p>
        </div>`;
    container.appendChild(div);
}

/* ============================================================
   LOGOUT
   ============================================================ */
async function logoutUser() {
    if (!confirm('Do you want to log out?')) return;

    try { if (unsubscribeConversations) unsubscribeConversations(); } catch (_) {}
    try { if (unsubscribeUser) unsubscribeUser(); } catch (_) {}
    try { if ('speechSynthesis' in window) speechSynthesis.cancel(); } catch (_) {}
    try { await firebase.auth().signOut(); } catch (_) {}

    try {
        sessionStorage.clear();
        Object.keys(localStorage).forEach(k => {
            if (/^(user|dvUser|dv_user|userProfile)/i.test(k)) localStorage.removeItem(k);
        });
    } catch (_) {}

    window.location.replace('login.html');
}
window.logoutUser = logoutUser;

/* ============================================================
   INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
    if (!getMyPhone()) return;   // ai.js redirects to login

    // Sidebar visibility: desktop always open, mobile closed
    const sync = () => {
        if (isDesktop()) {
            _el('chatSidebar')?.classList.add('open');
            _el('sidebarOverlay')?.classList.remove('show');
            sidebarOpen = true;
        } else if (sidebarOpen && !_el('sidebarOverlay')?.classList.contains('show')) {
            // came from desktop → collapse drawer
            _el('chatSidebar')?.classList.remove('open');
            sidebarOpen = false;
        }
    };
    sync();
    window.addEventListener('resize', sync);

    _el('convSearchInput')?.addEventListener('input', renderConversations);
    document.addEventListener('keydown', e => {
        if (e.key === 'Escape' && sidebarOpen) closeSidebar();
    });

    const start = () => {
        startUserListener();
        loadConversations();
    };
    if (window.firebase && firebase.apps && firebase.apps.length) start();
    else setTimeout(start, 300);
});

})();