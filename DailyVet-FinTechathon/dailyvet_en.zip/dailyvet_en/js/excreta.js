/* ============================================================
   DailyVet — Dung & Urine AI Scanner v1.5 (English only)
   ✅ AI output guaranteed English via DVLangGuard
   ✅ 5 Gemini keys + rotation + model failover
   ✅ Hard timeout 5.5s — guaranteed reply
   ✅ Strict-English retry pass if first attempt returns Bengali
   ============================================================ */

let bdSelectedImage = null;
let bdCurrentPhone = null;
let bdSelectedAnimal = 'cow';
let bdSelectedType = 'dung';
let animalDropdownOpen = false;
let typeDropdownOpen = false;

const BD_GEMINI_KEYS = [
  'AQ.Ab8RN6JURo6GM-erOA_GzQTIrix34mRH_wwh7Mi3McjquuWf0g',
  'AQ.Ab8RN6K_FYnOKLOtYQ_me-ikqMro19izQCEQ91p50uqCjhc9Vw',
  'AQ.Ab8RN6LOnEJNNw1ZnudbaWtiTwlMxIIL2YzmjQchRbotREe1Bw',
  'AQ.Ab8RN6Lw1hLrmOpHhxXcrbItIvQPqrjhXij-NQ4DWAfsrQaBOQ',
  'AQ.Ab8RN6IfcISj48ZUdezZBtrefHQ6lAXxQ_vtZxXFIJItAhAyUQ'
];

const BD_VISION_MODELS = [
  'gemini-3.5-flash-lite',
  'gemini-3.1-flash-lite',
  'gemini-2.5-flash-lite',
  'gemini-3.5-flash',
  'gemini-2.5-flash'
];

const BD_GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
const BD_PER_CALL_TIMEOUT_MS = 4200;
const BD_OVERALL_TIMEOUT_MS = 5500;
const BD_MAX_IMAGE_MB = 25;

const _bdKeyStatus = BD_GEMINI_KEYS.map(() => ({ blockedUntil: 0, failCount: 0 }));
let _bdBestKeyIndex = 0;
const _bdModelStatus = BD_VISION_MODELS.map(() => ({ blockedUntil: 0 }));

const BD_BLOCK_MS = {
  rate_limit: 25 * 1000, invalid: 20 * 60 * 1000, network: 5 * 1000,
  timeout: 4 * 1000, server: 8 * 1000, model_gone: 90 * 60 * 1000,
  badOutput: 15 * 1000
};

/* ============================================================
   1. Data
   ============================================================ */
const BD_ANIMALS = [
  { id: 'cow', emoji: '🐄', name: 'Cow' },
  { id: 'buffalo', emoji: '🐃', name: 'Buffalo' },
  { id: 'goat', emoji: '🐐', name: 'Goat' },
  { id: 'sheep', emoji: '🐑', name: 'Sheep' },
  { id: 'chicken', emoji: '🐔', name: 'Chicken' },
  { id: 'duck', emoji: '🦆', name: 'Duck' },
  { id: 'pigeon', emoji: '🕊️', name: 'Pigeon' },
  { id: 'dog', emoji: '🐕', name: 'Dog' },
  { id: 'cat', emoji: '🐈', name: 'Cat' },
  { id: 'rabbit', emoji: '🐇', name: 'Rabbit' }
];

const BD_TYPES = [
  { id: 'dung', emoji: '🌱', name: 'Dung / Droppings' },
  { id: 'urine', emoji: '💧', name: 'Urine' }
];

/* ============================================================
   2. Prompts — English only (species + type)
   ============================================================ */
const BD_ENGLISH_RULE = `STRICT: Reply ONLY in clean English. Do NOT use Bengali, Hindi, or any non-English script in any field. Return ONLY valid JSON. No markdown.`;

const BD_EXCRETA_PROMPTS = {
  cow: {
    dung: `You are a veterinary AI analyzing COW DUNG.
Checklist: color, texture, blood presence (fresh red / dark tarry), mucus, visible worms, undigested feed, odor.
Likely conditions: loose/watery → diarrhea; bloody/mucus → black quarter or bacterial infection; worms → parasite; undigested feed → liver/metabolic; black tarry → internal bleeding; green watery → grass overload/infectious.
Return ONLY valid JSON with fields: status, species, speciesEnglish, analysisType, analysisTypeEnglish, aiVisualFindings { detectedColor, detectedTexture, bloodPresent, mucusPresent, wormsVisible, undigestedFeed }, suspectedDisease { nameEnglish, confidencePercentage }, riskLevel, verdict, immediateActions, homeCare, medicineSuggestion, dietAdvice, prevention, diyPhysicalVerificationGuide.
${BD_ENGLISH_RULE}`,
    urine: `You are a veterinary AI analyzing COW URINE.
Checklist: color (pale yellow normal, red/coffee emergency, dark yellow, cloudy, brown), clarity, blood, sediment/pus.
Likely conditions: red/coffee → babesiosis (tick fever, emergency); dark yellow → jaundice/liver/dehydration; cloudy/milky → UTI/kidney; brown → myoglobinuria.
Return ONLY valid JSON with the same fields as dung (analysisTypeEnglish = "Urine").
${BD_ENGLISH_RULE}`
  },
  goat: {
    dung: `You are a veterinary AI analyzing GOAT DROPPINGS. Conditions: PPR, parasites, enterotoxaemia, coccidiosis. Return ONLY valid JSON with species=goat, speciesEnglish="Goat". ${BD_ENGLISH_RULE}`,
    urine: `You are a veterinary AI analyzing GOAT URINE. Red→infection/stones, dark yellow→dehydration/liver, cloudy→UTI. Return ONLY valid JSON with species=goat, speciesEnglish="Goat". ${BD_ENGLISH_RULE}`
  },
  buffalo: {
    dung: `You are a veterinary AI analyzing BUFFALO DUNG. Conditions: HS, FMD-related diarrhea, parasites, black quarter. Return ONLY valid JSON with species=buffalo, speciesEnglish="Buffalo". ${BD_ENGLISH_RULE}`,
    urine: `You are a veterinary AI analyzing BUFFALO URINE. Red/coffee = babesiosis emergency. Return ONLY valid JSON with species=buffalo, speciesEnglish="Buffalo". ${BD_ENGLISH_RULE}`
  },
  sheep: {
    dung: `You are a veterinary AI analyzing SHEEP DROPPINGS. Conditions: PPR, parasites, enterotoxaemia, coccidiosis. Return ONLY valid JSON with species=sheep, speciesEnglish="Sheep". ${BD_ENGLISH_RULE}`,
    urine: `You are a veterinary AI analyzing SHEEP URINE. Return ONLY valid JSON with species=sheep, speciesEnglish="Sheep". ${BD_ENGLISH_RULE}`
  },
  dog: {
    dung: `You are a veterinary AI analyzing DOG FECES. CRITICAL: black tarry → GI bleeding / parvo suspect; fresh red → parvo or parasite; loose + vomiting → emergency; white string/rice grain → tapeworm/roundworm. Return ONLY valid JSON with species=dog, speciesEnglish="Dog". ${BD_ENGLISH_RULE}`,
    urine: `You are a veterinary AI analyzing DOG URINE. Red/pink→UTI/stones, dark yellow→dehydration/liver, cloudy→UTI, brown→myoglobinuria. Return ONLY valid JSON with species=dog, speciesEnglish="Dog". ${BD_ENGLISH_RULE}`
  },
  cat: {
    dung: `You are a veterinary AI analyzing CAT FECES. Black→GI bleeding; fresh red→parasite/colitis; loose→IBD/parasite; worms→tapeworm/roundworm; hard→constipation. Return ONLY valid JSON with species=cat, speciesEnglish="Cat". ${BD_ENGLISH_RULE}`,
    urine: `You are a veterinary AI analyzing CAT URINE. CRITICAL FLUTD: pink/red→UTI/FLUTD (life-threatening)/stones; dark yellow→jaundice; cloudy→infection. Return ONLY valid JSON with species=cat, speciesEnglish="Cat". ${BD_ENGLISH_RULE}`
  },
  chicken: {
    dung: `You are a POULTRY expert analyzing CHICKEN DROPPINGS. OUTBREAK ALERT: green/chalky white→Newcastle/Avian Influenza (critical outbreak); bloody/red→coccidiosis; yellow frothy→fowl cholera/salmonella; watery/clear→heat stroke/gumboro. Emergency: isolate, disinfect (KMnO4), vaccinate healthy, electrolytes, bury dead, report DLS if AI suspected. Return ONLY valid JSON with species=chicken, speciesEnglish="Chicken". ${BD_ENGLISH_RULE}`,
    urine: `You are a POULTRY expert. Birds excrete uric acid (white paste) with droppings. Yellow urates→liver; green urates→liver infection; white chalky→normal/dehydration; bloody→serious infection. Return ONLY valid JSON with species=chicken, speciesEnglish="Chicken". ${BD_ENGLISH_RULE}`
  },
  duck: {
    dung: `You are a POULTRY expert analyzing DUCK DROPPINGS. Green/chalky→duck plague; bloody→coccidiosis; watery→duck viral hepatitis; yellow→salmonella. Return ONLY valid JSON with species=duck, speciesEnglish="Duck". ${BD_ENGLISH_RULE}`,
    urine: `You are a POULTRY expert analyzing DUCK URATE. Return ONLY valid JSON with species=duck, speciesEnglish="Duck". ${BD_ENGLISH_RULE}`
  },
  pigeon: {
    dung: `You are a BIRD expert analyzing PIGEON DROPPINGS. Green watery→salmonella; bloody→coccidiosis; yellow→liver; white chalky→normal/dehydration. Return ONLY valid JSON with species=pigeon, speciesEnglish="Pigeon". ${BD_ENGLISH_RULE}`,
    urine: `You are a BIRD expert analyzing PIGEON URATE. Return ONLY valid JSON with species=pigeon, speciesEnglish="Pigeon". ${BD_ENGLISH_RULE}`
  },
  rabbit: {
    dung: `You are a veterinary AI analyzing RABBIT DROPPINGS. Loose→GI stasis/enteritis/coccidiosis; no droppings→GI STASIS (emergency); small→GI stasis; mucus→enteritis. Return ONLY valid JSON with species=rabbit, speciesEnglish="Rabbit". ${BD_ENGLISH_RULE}`,
    urine: `You are a veterinary AI analyzing RABBIT URINE. Rabbit urine can be naturally red/orange (porphyrins). Milky white→normal; red-orange→normal/check; cloudy thick→sludge/UTI; bloody→UTI/stones. Return ONLY valid JSON with species=rabbit, speciesEnglish="Rabbit". ${BD_ENGLISH_RULE}`
  }
};

function getExcretaPrompt(animal, type) {
  const p = BD_EXCRETA_PROMPTS[animal];
  return p ? (p[type] || p.dung) : null;
}

/* ============================================================
   3. Helpers
   ============================================================ */
const _elBD = id => document.getElementById(id);
const _fsBD = () => firebase.firestore();
const _bdSleep = ms => new Promise(r => setTimeout(r, ms));

function escapeHtmlBD(text) {
  const div = document.createElement('div');
  div.textContent = String(text);
  return div.innerHTML;
}

function parseGeminiJSON(rawText) {
  let parsed;
  try { parsed = JSON.parse(rawText); }
  catch {
    const match = rawText.match(/\{[\s\S]*\}/);
    if (match) parsed = JSON.parse(match[0]);
    else throw new Error('Could not parse AI response');
  }

  /* Final safety net — strip any foreign script */
  if (window.DVLangGuard && parsed && typeof parsed === 'object') {
    const clean = obj => {
      if (typeof obj === 'string') return window.DVLangGuard.stripForeign(obj);
      if (Array.isArray(obj)) return obj.map(clean);
      if (obj && typeof obj === 'object') {
        const out = {};
        for (const k of Object.keys(obj)) out[k] = clean(obj[k]);
        return out;
      }
      return obj;
    };
    parsed = clean(parsed);
  }
  return parsed;
}

function _bdMarkKeyFailed(index, errorType) {
  const st = _bdKeyStatus[index];
  const base = BD_BLOCK_MS[errorType] || 8 * 1000;
  st.blockedUntil = Date.now() + base * Math.min(1 + st.failCount * 0.3, 2.5);
  st.failCount += 1;
}
function _bdMarkKeySuccess(index) {
  _bdBestKeyIndex = index;
  Object.assign(_bdKeyStatus[index], { failCount: 0, blockedUntil: 0 });
}
function _bdMarkModelGone(idx) {
  _bdModelStatus[idx].blockedUntil = Date.now() + BD_BLOCK_MS.model_gone;
}
function _bdGetLiveKeys() {
  const now = Date.now();
  const order = Array.from({ length: BD_GEMINI_KEYS.length }, (_, i) =>
    (_bdBestKeyIndex + i) % BD_GEMINI_KEYS.length);
  let live = order.filter(i => _bdKeyStatus[i].blockedUntil <= now);
  if (!live.length) live = order.slice(0, 3);
  return live;
}
function _bdGetLiveModels() {
  const now = Date.now();
  const live = BD_VISION_MODELS
    .map((m, i) => ({ m, i }))
    .filter(x => _bdModelStatus[x.i].blockedUntil <= now)
    .map(x => x.m);
  return live.length ? live : BD_VISION_MODELS.slice();
}

/* ============================================================
   4. Image compression
   ============================================================ */
function openBDCamera() { _elBD('bdCameraInput')?.click(); }
function openBDGallery() { _elBD('bdGalleryInput')?.click(); }
window.openBDCamera = openBDCamera;
window.openBDGallery = openBDGallery;

const BD_COMPRESS_CONFIG = {
  hardMaxInputMB: 25,
  targetMaxBytes: 1.5 * 1024 * 1024,
  hardMaxBytes: 2.0 * 1024 * 1024,
  maxDimension: 1024,
  minDimension: 640,
  initialQuality: 0.85,
  minQuality: 0.45,
  qualityStep: 0.12,
  maxIterations: 5
};

async function compressBDImage(file) {
  if (file.size > BD_COMPRESS_CONFIG.hardMaxInputMB * 1024 * 1024)
    throw new Error(`Image too large (${(file.size / 1024 / 1024).toFixed(1)}MB). Max ${BD_COMPRESS_CONFIG.hardMaxInputMB}MB.`);
  if (!file.type || !file.type.startsWith('image/')) throw new Error('File is not an image.');

  const dataURL = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = e => resolve(e.target.result);
    reader.onerror = () => reject(new Error('File read failed'));
    reader.readAsDataURL(file);
  });

  const img = await new Promise((resolve, reject) => {
    const im = new Image();
    const timer = setTimeout(() => reject(new Error('Image load timeout')), 15000);
    im.onload = () => { clearTimeout(timer); resolve(im); };
    im.onerror = () => { clearTimeout(timer); reject(new Error('Image decode failed')); };
    im.src = dataURL;
  });

  const origW = img.naturalWidth || img.width;
  const origH = img.naturalHeight || img.height;
  if (!origW || !origH) { img.src = ''; throw new Error('Image has no dimensions'); }

  const sizeMB = file.size / 1024 / 1024;
  const { maxDimension, targetMaxBytes, hardMaxBytes } = BD_COMPRESS_CONFIG;
  let workingMaxDim = maxDimension;
  if (sizeMB > 8 || origW * origH > 12_000_000) workingMaxDim = 900;
  if (sizeMB > 15 || origW * origH > 20_000_000) workingMaxDim = 768;

  const initialScale = Math.min(1, workingMaxDim / Math.max(origW, origH));
  let width = Math.round(origW * initialScale);
  let height = Math.round(origH * initialScale);
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d', { alpha: false });
  let quality = BD_COMPRESS_CONFIG.initialQuality;
  let best = null;

  for (let iter = 0; iter < BD_COMPRESS_CONFIG.maxIterations; iter++) {
    canvas.width = width; canvas.height = height;
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = '#ffffff'; ctx.fillRect(0, 0, width, height);
    ctx.drawImage(img, 0, 0, width, height);
    const result = canvas.toDataURL('image/jpeg', quality);
    const bytes = Math.round(result.length * 0.75);
    if (!best || bytes < best.bytes) best = { data: result, bytes, quality, width, height };
    if (bytes <= targetMaxBytes) break;
    if (quality > BD_COMPRESS_CONFIG.minQuality) {
      quality = Math.max(BD_COMPRESS_CONFIG.minQuality, quality - BD_COMPRESS_CONFIG.qualityStep);
      continue;
    }
    if (width > BD_COMPRESS_CONFIG.minDimension || height > BD_COMPRESS_CONFIG.minDimension) {
      width = Math.max(BD_COMPRESS_CONFIG.minDimension, Math.round(width * 0.82));
      height = Math.max(BD_COMPRESS_CONFIG.minDimension, Math.round(height * 0.82));
      quality = BD_COMPRESS_CONFIG.initialQuality;
      continue;
    }
    break;
  }

  img.src = ''; canvas.width = 0; canvas.height = 0;
  if (!best || !best.data) throw new Error('Compression failed');
  if (best.bytes > hardMaxBytes)
    throw new Error(`Still too large (${(best.bytes / 1024 / 1024).toFixed(1)}MB). Try a smaller image.`);
  return best.data;
}

async function handleBDImage(file) {
  if (!file || !file.type.startsWith('image/')) return;
  try {
    bdSelectedImage = await compressBDImage(file);
    showBDPreview(bdSelectedImage);
  } catch (err) { alert('Failed to load image: ' + err.message); }
}

function handleBDImageSelect(event) {
  const file = event.target.files?.[0];
  if (file) handleBDImage(file);
  event.target.value = '';
}

function showBDPreview(dataURL) {
  _elBD('bdImageField')?.classList.add('hidden');
  const preview = _elBD('bdPreview');
  const img = _elBD('bdPreviewImg');
  if (preview && img) { img.src = dataURL; preview.style.display = 'flex'; }
  const result = _elBD('bdResult');
  if (result) result.style.display = 'none';
  const loading = _elBD('bdLoading');
  if (loading) loading.style.display = 'none';
  preview?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function removeBDPreview() {
  bdSelectedImage = null;
  _elBD('bdPreview').style.display = 'none';
  _elBD('bdImageField')?.classList.remove('hidden');
  _elBD('bdResult').style.display = 'none';
  _elBD('bdLoading').style.display = 'none';
  ['bdCameraInput', 'bdGalleryInput'].forEach(id => {
    const el = _elBD(id);
    if (el) el.value = '';
  });
}
window.removeBDPreview = removeBDPreview;

/* ============================================================
   5. Dropdowns
   ============================================================ */
function toggleAnimalDropdown() {
  const panel = _elBD('animalPanel');
  const trigger = _elBD('animalTrigger');
  if (!panel || !trigger) return;
  if (animalDropdownOpen) { closeAnimalDropdown(); return; }
  closeTypeDropdown();
  renderAnimalList('');
  panel.classList.add('open');
  trigger.classList.add('open');
  animalDropdownOpen = true;
  const search = _elBD('animalSearch');
  if (search) { search.value = ''; setTimeout(() => search.focus(), 100); }
}
function closeAnimalDropdown() {
  _elBD('animalPanel')?.classList.remove('open');
  _elBD('animalTrigger')?.classList.remove('open');
  animalDropdownOpen = false;
}
function renderAnimalList(filter) {
  const list = _elBD('animalList');
  if (!list) return;
  const q = (filter || '').toLowerCase().trim();
  const filtered = BD_ANIMALS.filter(a =>
    !q || a.name.toLowerCase().includes(q) || a.id.includes(q));
  if (!filtered.length) { list.innerHTML = `<div class="ex-empty">No animal found</div>`; return; }
  list.innerHTML = filtered.map(a => `
    <button type="button" class="ex-option ${a.id === bdSelectedAnimal ? 'active' : ''}"
            data-id="${a.id}" onclick="selectAnimalFromList('${a.id}')">
      <span class="ex-option-emoji">${a.emoji}</span>
      <span class="ex-option-text"><span>${a.name}</span></span>
      <i class="fas fa-check ex-check"></i>
    </button>`).join('');
}
function selectAnimalFromList(id) {
  const animal = BD_ANIMALS.find(a => a.id === id);
  if (!animal) return;
  bdSelectedAnimal = animal.id;
  const emoji = _elBD('animalEmoji'), name = _elBD('animalName');
  if (emoji) emoji.textContent = animal.emoji;
  if (name) name.textContent = animal.name;
  closeAnimalDropdown();
}
function toggleTypeDropdown() {
  const panel = _elBD('typePanel');
  const trigger = _elBD('typeTrigger');
  if (!panel || !trigger) return;
  if (typeDropdownOpen) { closeTypeDropdown(); return; }
  closeAnimalDropdown();
  renderTypeList();
  panel.classList.add('open');
  trigger.classList.add('open');
  typeDropdownOpen = true;
}
function closeTypeDropdown() {
  _elBD('typePanel')?.classList.remove('open');
  _elBD('typeTrigger')?.classList.remove('open');
  typeDropdownOpen = false;
}
function renderTypeList() {
  const list = _elBD('typeList');
  if (!list) return;
  list.innerHTML = BD_TYPES.map(t => `
    <button type="button" class="ex-option ${t.id === bdSelectedType ? 'active' : ''}"
            data-id="${t.id}" onclick="selectTypeFromList('${t.id}')">
      <span class="ex-option-emoji">${t.emoji}</span>
      <span class="ex-option-text"><span>${t.name}</span></span>
      <i class="fas fa-check ex-check"></i>
    </button>`).join('');
}
function selectTypeFromList(id) {
  const type = BD_TYPES.find(t => t.id === id);
  if (!type) return;
  bdSelectedType = type.id;
  const emoji = _elBD('typeEmoji'), name = _elBD('typeName');
  if (emoji) emoji.textContent = type.emoji;
  if (name) name.textContent = type.name;
  closeTypeDropdown();
}

/* ============================================================
   6. Vision call — English-only enforced
   ============================================================ */
async function _bdCallOne(apiKey, keyIndex, model, imageBase64, prompt, strictEnglish) {
  const url = `${BD_GEMINI_API_URL}/${model}:generateContent?key=${apiKey}`;
  const imageData = imageBase64.includes(',') ? imageBase64.split(',')[1] : imageBase64;
  const mimeType = imageBase64.includes('data:') ? imageBase64.split(';')[0].split(':')[1] : 'image/jpeg';

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), BD_PER_CALL_TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          role: 'user',
          parts: [
            { inline_data: { mime_type: mimeType, data: imageData } },
            { text: prompt }
          ]
        }],
        generationConfig: {
          temperature: 0.15, maxOutputTokens: 1500, topP: 0.95,
          responseMimeType: 'application/json'
        }
      }),
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (!response.ok) {
      const status = response.status;
      const errBody = await response.text().catch(() => '');
      const errorType = status === 429 ? 'rate_limit'
        : (status === 401 || status === 403) ? 'invalid'
        : status === 404 ? 'model_gone'
        : (status === 400 && /api[_ ]key (?:not valid|invalid|expired)|API_KEY_INVALID/i.test(errBody)) ? 'invalid'
        : status >= 500 ? 'server' : 'network';
      return { success: false, errorType, status, keyIndex };
    }

    const data = await response.json();
    const rawText = (data.candidates?.[0]?.content?.parts || [])
      .filter(pt => pt && pt.text && !pt.thought).map(pt => pt.text).join('');
    if (!rawText) return { success: false, errorType: 'empty', keyIndex };

    if (window.DVLangGuard && !window.DVLangGuard.isEnglishEnough(rawText)) {
      if (!strictEnglish) return { success: false, errorType: 'badOutput', keyIndex };
      /* retry pass: strip foreign scripts and continue */
    }

    const parsed = parseGeminiJSON(rawText);
    return { success: true, data: parsed, keyIndex };
  } catch (err) {
    clearTimeout(timeoutId);
    const errorType = err?.name === 'AbortError' ? 'timeout' : 'network';
    return { success: false, errorType, keyIndex };
  }
}

function _bdFallbackResult() {
  const animal = BD_ANIMALS.find(a => a.id === bdSelectedAnimal) || BD_ANIMALS[0];
  const type = BD_TYPES.find(t => t.id === bdSelectedType) || BD_TYPES[0];
  return {
    status: "success",
    species: bdSelectedAnimal,
    speciesEnglish: animal.name,
    analysisType: bdSelectedType,
    analysisTypeEnglish: type.name,
    aiVisualFindings: {
      detectedColor: "Unknown", detectedTexture: "Unknown",
      bloodPresent: false, mucusPresent: false, wormsVisible: false, undigestedFeed: false
    },
    suspectedDisease: { nameEnglish: "Unable to analyze", confidencePercentage: 20 },
    riskLevel: "Medium",
    verdict: "Sample analysis could not be completed due to network/API issues. Please try again or take a clearer photo. In an emergency, contact your nearest veterinarian.",
    immediateActions: [
      "Contact your nearest veterinarian",
      "Provide adequate water to the animal",
      "Isolate if other animals are present"
    ],
    homeCare: ["Take a clearer photo and scan again"],
    medicineSuggestion: ["Do not give medicine without veterinary advice"],
    dietAdvice: ["Continue normal feed and monitor"],
    prevention: ["Maintain a clean environment"],
    diyPhysicalVerificationGuide: [
      "Check the sample color, texture and smell yourself",
      "If you see blood or worms, call a vet immediately"
    ],
    _fallback: true
  };
}

async function callExcretaGemini(imageBase64, prompt) {
  const liveKeys = _bdGetLiveKeys();
  let liveModels = _bdGetLiveModels();
  if (!liveModels.length) liveModels = BD_VISION_MODELS.slice();
  const start = Date.now();

  for (let round = 1; round <= 3; round++) {
    const strictEnglish = round === 3;
    const remaining = BD_OVERALL_TIMEOUT_MS - (Date.now() - start);
    if (remaining < 800) break;

    /* Round 1 & 2: parallel race; Round 3: strict English single attempt */
    if (round < 3) {
      const racePromises = [];
      const used = new Set();
      for (let k = 0; k < Math.min(2, liveKeys.length); k++) {
        const keyIdx = liveKeys[k];
        for (let m = 0; m < Math.min(2, liveModels.length); m++) {
          const model = liveModels[m];
          const id = `${keyIdx}-${model}`;
          if (used.has(id)) continue;
          used.add(id);
          racePromises.push(
            _bdCallOne(BD_GEMINI_KEYS[keyIdx], keyIdx, model, imageBase64, prompt, false)
              .then(r => ({ ...r, model }))
          );
        }
      }
      const timeoutPromise = new Promise(resolve => {
        setTimeout(() => resolve({ success: false, errorType: 'overall_timeout' }), remaining);
      });
      const firstResult = await Promise.race([
        Promise.any(racePromises.map(p => p.then(r => { if (r.success) return r; throw r; })))
          .catch(() => ({ success: false, errorType: 'all_race_failed' })),
        timeoutPromise
      ]);
      if (firstResult && firstResult.success) {
        _bdMarkKeySuccess(firstResult.keyIndex);
        return firstResult.data;
      }

      /* Sequential retry in round 2 */
      if (round === 2) {
        for (const keyIdx of liveKeys) {
          for (const model of liveModels) {
            if (Date.now() - start > BD_OVERALL_TIMEOUT_MS - 800) break;
            const result = await _bdCallOne(BD_GEMINI_KEYS[keyIdx], keyIdx, model, imageBase64, prompt, false);
            if (result.success) { _bdMarkKeySuccess(keyIdx); return result.data; }
            if (result.errorType === 'model_gone') {
              const mi = BD_VISION_MODELS.indexOf(model);
              if (mi >= 0) _bdMarkModelGone(mi);
              continue;
            }
            if (['rate_limit', 'invalid', 'timeout', 'network', 'badOutput'].includes(result.errorType)) {
              _bdMarkKeyFailed(keyIdx, result.errorType);
              break;
            }
          }
        }
      } else if (round === 1) {
        await _bdSleep(500);
      }
    } else {
      /* Round 3 = strict English retry, still on live keys */
      for (const keyIdx of liveKeys) {
        if (Date.now() - start > BD_OVERALL_TIMEOUT_MS - 500) break;
        const result = await _bdCallOne(BD_GEMINI_KEYS[keyIdx], keyIdx, liveModels[0], imageBase64, prompt, true);
        if (result.success) { _bdMarkKeySuccess(keyIdx); return result.data; }
      }
    }
  }
  return _bdFallbackResult();
}

/* ============================================================
   7. Render — English only
   ============================================================ */
const BD_TRAIT_LABELS = {
  detectedColor: '🎨 Color', detectedTexture: '📏 Texture', detectedClarity: '🔍 Clarity',
  bloodPresent: '🩸 Blood', mucusPresent: '💧 Mucus', wormsVisible: '🪱 Worms',
  undigestedFeed: '🌾 Undigested', sedimentVisible: '⚗️ Sediment',
  tarryStool: '⚫ Tarry Stool', frothy: '🫧 Frothy', outbreakAlert: '🚨 Outbreak Sign'
};

function _buildRiskBanner(riskLevel) {
  if (riskLevel === 'critical')
    return `<div class="bd-risk-banner"><i class="fas fa-triangle-exclamation"></i><div><strong>🚨 CRITICAL EMERGENCY</strong><p>Contact a veterinarian immediately</p></div></div>`;
  if (riskLevel === 'high')
    return `<div class="bd-risk-banner"><i class="fas fa-triangle-exclamation"></i><div><strong>⚠️ HIGH RISK</strong><p>Urgent treatment needed</p></div></div>`;
  if (riskLevel === 'medium')
    return `<div class="bd-caution-banner"><i class="fas fa-info-circle"></i><div><strong>⚡ MODERATE RISK</strong><p>Monitor closely</p></div></div>`;
  return `<div class="bd-safe-banner"><i class="fas fa-circle-check"></i><div><strong>✅ NORMAL</strong><p>Healthy appearance</p></div></div>`;
}

function _buildListSection(title, items, listClass = 'bd-diy-list', ordered = false) {
  if (!Array.isArray(items) || !items.length) return '';
  const tag = ordered ? 'ol' : 'ul';
  return `<div class="bd-section">
    <div class="bd-section-label">${title}</div>
    <${tag} class="${listClass}">${items.map(i => `<li>${escapeHtmlBD(i)}</li>`).join('')}</${tag}>
  </div>`;
}

function renderExcretaResult(data) {
  const resultEl = _elBD('bdResult');
  if (!resultEl) return;

  const userImageHTML = bdSelectedImage
    ? `<div class="bd-result-image"><img src="${bdSelectedImage}" alt="Analyzed Sample" /></div>` : '';

  if (data.status === 'error' || data.error) {
    resultEl.innerHTML = `
      ${userImageHTML}
      <div class="bd-result-error">
        <i class="fas fa-exclamation-triangle"></i>
        <h3>Could Not Analyze</h3>
        <p>${escapeHtmlBD(data.error || data.verdict || 'Please try a clearer photo.')}</p>
      </div>`;
    resultEl.style.display = 'flex';
    return;
  }

  const findings = data.aiVisualFindings || {};
  const disease = data.suspectedDisease || {};
  const riskLevel = (data.riskLevel || 'Low').toLowerCase();

  const riskColor = (riskLevel === 'critical' || riskLevel === 'high') ? '#dc2626'
    : riskLevel === 'medium' ? '#d97706' : '#10b981';
  const riskBg = (riskLevel === 'critical' || riskLevel === 'high') ? '#fef2f2'
    : riskLevel === 'medium' ? '#fef9e7' : '#f0fdf4';
  const riskBorder = (riskLevel === 'critical' || riskLevel === 'high') ? '#fecaca'
    : riskLevel === 'medium' ? '#fcd34d' : '#86efac';

  const confidence = disease.confidencePercentage || 0;
  const confColor = confidence >= 80 ? '#10b981' : confidence >= 60 ? '#d97706' : '#dc2626';
  const riskBanner = _buildRiskBanner(riskLevel);

  const findingsHTML = Object.entries(findings).map(([k, v]) => {
    const label = BD_TRAIT_LABELS[k] || k;
    const value = typeof v === 'boolean' ? (v ? '✅ Yes' : '❌ No') : escapeHtmlBD(v);
    return `<div class="bd-trait-row"><span class="bd-trait-label">${label}</span><span class="bd-trait-value">${value}</span></div>`;
  }).join('');

  const actionsHTML = _buildListSection('🚨 Immediate Actions', data.immediateActions, 'bd-red-flags');
  const homeCareHTML = _buildListSection('🏠 Home Care', data.homeCare);
  const medicineHTML = _buildListSection('💊 Medicine (Vet-supervised)', data.medicineSuggestion);
  const dietHTML = _buildListSection('🥗 Diet Advice', data.dietAdvice);
  const preventionHTML = _buildListSection('🛡️ Prevention', data.prevention);
  const diyHTML = _buildListSection('🔍 Verify Yourself (DIY)', data.diyPhysicalVerificationGuide, 'bd-diy-list', true);

  const speciesEn = data.speciesEnglish || 'Animal';
  const analysisTypeEn = data.analysisTypeEnglish || (bdSelectedType === 'urine' ? 'Urine' : 'Dung');

  const fallbackNotice = data._fallback
    ? `<div style="margin:12px 0;padding:12px;background:#fef3c7;border-radius:12px;font-size:13px;color:#92400e;border:1px solid #fcd34d;">
        ⚠️ Analysis incomplete due to API issues. Please try again or take a clearer photo.
       </div>` : '';

  resultEl.innerHTML = `
    ${riskBanner}
    ${userImageHTML}
    ${fallbackNotice}

    <div class="bd-result-header">
      <i class="fas fa-check-circle" style="color:${confColor};"></i>
      <h3>${data._fallback ? 'Scan Incomplete' : 'Analysis Complete'}</h3>
    </div>

    <div class="bd-section bd-breed-section">
      <div class="bd-section-label">🐾 Subject</div>
      <div class="bd-species-name">${escapeHtmlBD(speciesEn)} — ${escapeHtmlBD(analysisTypeEn)}</div>
      ${disease.nameEnglish ? `
        <div class="bd-breed-name">🩺 ${escapeHtmlBD(disease.nameEnglish)}</div>` : ''}
      <div class="bd-confidence">
        <span>Confidence</span>
        <div class="bd-confidence-bar">
          <div class="bd-confidence-fill" style="width:${confidence}%;background:${confColor};"></div>
        </div>
        <strong style="color:${confColor};">${confidence}%</strong>
      </div>
    </div>

    ${findingsHTML ? `
      <div class="bd-section">
        <div class="bd-section-label">📊 AI Visual Findings</div>
        <div class="bd-traits">${findingsHTML}</div>
      </div>` : ''}

    <div class="bd-section bd-health-section" style="background:${riskBg};border-color:${riskBorder};">
      <div class="bd-section-label" style="color:${riskColor};">🩺 Risk Assessment</div>
      <div class="bd-health-status">
        <span>Risk Level:</span>
        <strong style="color:${riskColor};">${escapeHtmlBD(data.riskLevel || 'Low').toUpperCase()}</strong>
      </div>
    </div>

    ${actionsHTML}
    ${data.verdict ? `
      <div class="bd-section bd-verdict-section">
        <div class="bd-section-label">Summary</div>
        <div class="bd-verdict-text">${escapeHtmlBD(data.verdict)}</div>
      </div>` : ''}
    ${homeCareHTML}
    ${medicineHTML}
    ${dietHTML}
    ${preventionHTML}
    ${diyHTML}

    <div class="bd-result-actions">
      <button type="button" class="bd-rescan-btn" onclick="rescanExcreta()">
        <i class="fas fa-redo"></i> Scan Again
      </button>
    </div>`;
  resultEl.style.display = 'flex';
  resultEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ============================================================
   8. Firestore
   ============================================================ */
async function saveExcretaScan(scanData) {
  if (!bdCurrentPhone || scanData._fallback) return;
  try {
    await _fsBD().collection('users').doc(bdCurrentPhone)
      .collection('excreta_history').add({
        ...scanData, user_phone: bdCurrentPhone,
        animal: bdSelectedAnimal, type: bdSelectedType,
        scanned_at: firebase.firestore.FieldValue.serverTimestamp(),
        scanned_at_ms: Date.now()
      });
  } catch (err) { console.warn('Save failed:', err.message); }
}

/* ============================================================
   9. Scan flow
   ============================================================ */
async function startExcretaScan() {
  if (!bdSelectedImage) return alert('Please select or take a photo first.');
  if (!bdCurrentPhone) {
    alert('Please login first.');
    window.location.href = 'login.html';
    return;
  }
  const prompt = getExcretaPrompt(bdSelectedAnimal, bdSelectedType);
  if (!prompt) return alert('Analysis prompt not found. Please try again.');

  const scanBtn = _elBD('bdScanBtn');
  const preview = _elBD('bdPreview');
  const loading = _elBD('bdLoading');
  const result = _elBD('bdResult');

  scanBtn.disabled = true;
  preview.style.display = 'none';
  result.style.display = 'none';
  loading.style.display = 'flex';

  try {
    const scanData = await callExcretaGemini(bdSelectedImage, prompt);
    loading.style.display = 'none';
    renderExcretaResult(scanData);
    if (scanData.status !== 'error' && !scanData._fallback) saveExcretaScan(scanData);
  } catch (err) {
    console.error('Scan error:', err);
    loading.style.display = 'none';
    renderExcretaResult(_bdFallbackResult());
  } finally {
    scanBtn.disabled = false;
  }
}
window.startExcretaScan = startExcretaScan;

function rescanExcreta() {
  if (!bdSelectedImage) return;
  showBDPreview(bdSelectedImage);
}
window.rescanExcreta = rescanExcreta;

/* ============================================================
   10. Init
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  bdCurrentPhone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
  if (!bdCurrentPhone) { window.location.href = 'login.html'; return; }

  const cow = BD_ANIMALS.find(a => a.id === 'cow');
  const dung = BD_TYPES.find(t => t.id === 'dung');
  if (_elBD('animalEmoji')) _elBD('animalEmoji').textContent = cow.emoji;
  if (_elBD('animalName')) _elBD('animalName').textContent = cow.name;
  if (_elBD('typeEmoji')) _elBD('typeEmoji').textContent = dung.emoji;
  if (_elBD('typeName')) _elBD('typeName').textContent = dung.name;

  ['bdCameraInput', 'bdGalleryInput'].forEach(id => {
    _elBD(id)?.addEventListener('change', handleBDImageSelect);
  });

  const animalSearch = _elBD('animalSearch');
  if (animalSearch) animalSearch.addEventListener('input', (e) => renderAnimalList(e.target.value));

  const imageField = _elBD('bdImageField');
  if (imageField) {
    imageField.addEventListener('click', openBDGallery);
    imageField.addEventListener('dragover', (e) => {
      e.preventDefault(); e.stopPropagation();
      imageField.classList.add('bd-dragover');
    });
    imageField.addEventListener('dragleave', (e) => {
      e.preventDefault(); e.stopPropagation();
      imageField.classList.remove('bd-dragover');
    });
    imageField.addEventListener('drop', (e) => {
      e.preventDefault(); e.stopPropagation();
      imageField.classList.remove('bd-dragover');
      const imgFile = Array.from(e.dataTransfer?.files || []).find(f => f.type.startsWith('image/'));
      if (imgFile) handleBDImage(imgFile);
    });
  }

  document.addEventListener('paste', (e) => {
    const imageItem = Array.from(e.clipboardData?.items || []).find(i => i.type.indexOf('image') !== -1);
    if (!imageItem) return;
    const file = imageItem.getAsFile();
    if (!file) return;
    e.preventDefault();
    handleBDImage(file);
  });

  document.addEventListener('click', (e) => {
    const animalWrap = _elBD('animalTrigger')?.parentElement;
    const typeWrap = _elBD('typeTrigger')?.parentElement;
    if (animalWrap && !animalWrap.contains(e.target)) closeAnimalDropdown();
    if (typeWrap && !typeWrap.contains(e.target)) closeTypeDropdown();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { closeAnimalDropdown(); closeTypeDropdown(); }
  });

  console.log('✅ Dung & Urine Scanner v1.5 ready (English only)');
});

window.toggleAnimalDropdown = toggleAnimalDropdown;
window.toggleTypeDropdown = toggleTypeDropdown;
window.selectAnimalFromList = selectAnimalFromList;
window.selectTypeFromList = selectTypeFromList;

window.DUDebug = {
  status() {
    console.table(_bdKeyStatus.map((s, i) => ({
      key: '#' + (i + 1),
      blockedFor_s: Math.max(0, Math.round((s.blockedUntil - Date.now()) / 1000)),
      failCount: s.failCount,
      best: i === _bdBestKeyIndex ? '⭐' : ''
    })));
  },
  reset() {
    _bdKeyStatus.forEach(s => Object.assign(s, { blockedUntil: 0, failCount: 0 }));
    _bdModelStatus.forEach(s => s.blockedUntil = 0);
    console.log('♻️ DU reset');
  }
};