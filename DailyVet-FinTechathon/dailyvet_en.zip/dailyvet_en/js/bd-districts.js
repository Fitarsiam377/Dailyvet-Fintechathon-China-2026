/* ============================================================
   DailyVet — Bangladesh 64 Districts Data (English Only)
   Source: BBS (Bangladesh Bureau of Statistics) + GADM 4.1
   Purpose: dropdown, GPS auto-detect, per-district NASA calls
   ============================================================ */
(function () {
'use strict';

/* ------------------------------------------------------------
   64 DISTRICTS
   Structure: { name, lat, lng, division }
   ------------------------------------------------------------ */
window.BD_DISTRICTS_LIST = {

    /* ===== DHAKA DIVISION (13 districts) ===== */
    dhaka:        { name: 'Dhaka',         lat: 23.8103, lng: 90.4125, division: 'Dhaka' },
    gazipur:      { name: 'Gazipur',       lat: 24.0023, lng: 90.4264, division: 'Dhaka' },
    narayanganj:  { name: 'Narayanganj',   lat: 23.6238, lng: 90.4999, division: 'Dhaka' },
    tangail:      { name: 'Tangail',       lat: 24.2513, lng: 89.9167, division: 'Dhaka' },
    kishoreganj:  { name: 'Kishoreganj',   lat: 24.4449, lng: 90.7766, division: 'Dhaka' },
    manikganj:    { name: 'Manikganj',     lat: 23.8617, lng: 90.0003, division: 'Dhaka' },
    munshiganj:   { name: 'Munshiganj',    lat: 23.5422, lng: 90.5305, division: 'Dhaka' },
    narsingdi:    { name: 'Narsingdi',     lat: 23.9322, lng: 90.7151, division: 'Dhaka' },
    faridpur:     { name: 'Faridpur',      lat: 23.6070, lng: 89.8429, division: 'Dhaka' },
    gopalganj:    { name: 'Gopalganj',     lat: 23.0051, lng: 89.8266, division: 'Dhaka' },
    madaripur:    { name: 'Madaripur',     lat: 23.1641, lng: 90.1896, division: 'Dhaka' },
    rajbari:      { name: 'Rajbari',       lat: 23.7574, lng: 89.6445, division: 'Dhaka' },
    shariatpur:   { name: 'Shariatpur',    lat: 23.2423, lng: 90.4348, division: 'Dhaka' },

    /* ===== CHITTAGONG DIVISION (11 districts) ===== */
    chittagong:   { name: 'Chittagong',    lat: 22.3569, lng: 91.7832, division: 'Chittagong' },
    coxsbazar:    { name: "Cox's Bazar",   lat: 21.4272, lng: 92.0058, division: 'Chittagong' },
    bandarban:    { name: 'Bandarban',     lat: 22.1953, lng: 92.2184, division: 'Chittagong' },
    khagrachari:  { name: 'Khagrachari',   lat: 23.1193, lng: 91.9847, division: 'Chittagong' },
    rangamati:    { name: 'Rangamati',     lat: 22.6533, lng: 92.1735, division: 'Chittagong' },
    noakhali:     { name: 'Noakhali',      lat: 22.8696, lng: 91.0995, division: 'Chittagong' },
    feni:         { name: 'Feni',          lat: 23.0159, lng: 91.3976, division: 'Chittagong' },
    lakshmipur:   { name: 'Lakshmipur',    lat: 22.9447, lng: 90.8283, division: 'Chittagong' },
    comilla:      { name: 'Comilla',       lat: 23.4607, lng: 91.1809, division: 'Chittagong' },
    brahmanbaria: { name: 'Brahmanbaria',  lat: 23.9571, lng: 91.1119, division: 'Chittagong' },
    chandpur:     { name: 'Chandpur',      lat: 23.2333, lng: 90.6711, division: 'Chittagong' },

    /* ===== RAJSHAHI DIVISION (8 districts) ===== */
    rajshahi:     { name: 'Rajshahi',      lat: 24.3745, lng: 88.6042, division: 'Rajshahi' },
    bogura:       { name: 'Bogura',        lat: 24.8465, lng: 89.3773, division: 'Rajshahi' },
    pabna:        { name: 'Pabna',         lat: 24.0064, lng: 89.2372, division: 'Rajshahi' },
    sirajganj:    { name: 'Sirajganj',     lat: 24.4533, lng: 89.7009, division: 'Rajshahi' },
    natore:       { name: 'Natore',        lat: 24.4206, lng: 89.0003, division: 'Rajshahi' },
    naogaon:      { name: 'Naogaon',       lat: 24.7936, lng: 88.9318, division: 'Rajshahi' },
    chapainawabganj: { name: 'Chapainawabganj', lat: 24.5965, lng: 88.2775, division: 'Rajshahi' },
    joypurhat:    { name: 'Joypurhat',     lat: 25.0968, lng: 89.0227, division: 'Rajshahi' },

    /* ===== KHULNA DIVISION (10 districts) ===== */
    khulna:       { name: 'Khulna',        lat: 22.8456, lng: 89.5403, division: 'Khulna' },
    jessore:      { name: 'Jessore',       lat: 23.1664, lng: 89.2081, division: 'Khulna' },
    satkhira:     { name: 'Satkhira',      lat: 22.7185, lng: 89.0705, division: 'Khulna' },
    bagerhat:     { name: 'Bagerhat',      lat: 22.6516, lng: 89.7859, division: 'Khulna' },
    kushtia:      { name: 'Kushtia',       lat: 23.9013, lng: 89.1206, division: 'Khulna' },
    jhenaidah:    { name: 'Jhenaidah',     lat: 23.5448, lng: 89.1539, division: 'Khulna' },
    magura:       { name: 'Magura',        lat: 23.4855, lng: 89.4198, division: 'Khulna' },
    narail:       { name: 'Narail',        lat: 23.1725, lng: 89.5127, division: 'Khulna' },
    chuadanga:    { name: 'Chuadanga',     lat: 23.6402, lng: 88.8418, division: 'Khulna' },
    meherpur:     { name: 'Meherpur',      lat: 23.7622, lng: 88.6318, division: 'Khulna' },

    /* ===== BARISAL DIVISION (6 districts) ===== */
    barisal:      { name: 'Barisal',       lat: 22.7010, lng: 90.3535, division: 'Barisal' },
    barguna:      { name: 'Barguna',       lat: 22.1592, lng: 90.1260, division: 'Barisal' },
    bhola:        { name: 'Bhola',         lat: 22.6859, lng: 90.6482, division: 'Barisal' },
    jhalokati:    { name: 'Jhalokati',     lat: 22.6406, lng: 90.1987, division: 'Barisal' },
    patuakhali:   { name: 'Patuakhali',    lat: 22.3596, lng: 90.3298, division: 'Barisal' },
    pirojpur:     { name: 'Pirojpur',      lat: 22.5841, lng: 89.9720, division: 'Barisal' },

    /* ===== SYLHET DIVISION (4 districts) ===== */
    sylhet:       { name: 'Sylhet',        lat: 24.8949, lng: 91.8687, division: 'Sylhet' },
    habiganj:     { name: 'Habiganj',      lat: 24.3745, lng: 91.4155, division: 'Sylhet' },
    moulvibazar:  { name: 'Moulvibazar',   lat: 24.4829, lng: 91.7774, division: 'Sylhet' },
    sunamganj:    { name: 'Sunamganj',     lat: 25.0658, lng: 91.3950, division: 'Sylhet' },

    /* ===== RANGPUR DIVISION (8 districts) ===== */
    rangpur:      { name: 'Rangpur',       lat: 25.7439, lng: 89.2752, division: 'Rangpur' },
    dinajpur:     { name: 'Dinajpur',      lat: 25.6217, lng: 88.6354, division: 'Rangpur' },
    gaibandha:    { name: 'Gaibandha',     lat: 25.3288, lng: 89.5286, division: 'Rangpur' },
    kurigram:     { name: 'Kurigram',      lat: 25.8072, lng: 89.6295, division: 'Rangpur' },
    lalmonirhat:  { name: 'Lalmonirhat',   lat: 25.9923, lng: 89.2847, division: 'Rangpur' },
    nilphamari:   { name: 'Nilphamari',    lat: 25.9317, lng: 88.8560, division: 'Rangpur' },
    panchagarh:   { name: 'Panchagarh',    lat: 26.3335, lng: 88.5518, division: 'Rangpur' },
    thakurgaon:   { name: 'Thakurgaon',    lat: 26.0337, lng: 88.4616, division: 'Rangpur' },

    /* ===== MYMENSINGH DIVISION (4 districts) ===== */
    mymensingh:   { name: 'Mymensingh',    lat: 24.7471, lng: 90.4203, division: 'Mymensingh' },
    jamalpur:     { name: 'Jamalpur',      lat: 24.9375, lng: 89.9372, division: 'Mymensingh' },
    netrokona:    { name: 'Netrokona',     lat: 24.8103, lng: 90.7279, division: 'Mymensingh' },
    sherpur:      { name: 'Sherpur',       lat: 25.0205, lng: 90.0153, division: 'Mymensingh' }

};

/* ------------------------------------------------------------
   HELPER — Find nearest district from GPS (Haversine)
   ------------------------------------------------------------ */
window.findNearestDistrict = function (lat, lng) {
    let best = null;
    let minDist = Infinity;

    Object.entries(window.BD_DISTRICTS_LIST).forEach(([key, d]) => {
        const dist = _haversineKm(lat, lng, d.lat, d.lng);
        if (dist < minDist) {
            minDist = dist;
            best = key;
        }
    });

    return best;
};

/* ------------------------------------------------------------
   HELPER — District key from a district name
   ------------------------------------------------------------ */
window.getDistrictKeyByName = function (name) {
    if (!name) return null;
    const target = String(name).toLowerCase().trim();
    for (const [key, d] of Object.entries(window.BD_DISTRICTS_LIST)) {
        if (d.name.toLowerCase() === target || key === target) return key;
    }
    return null;
};

/* ------------------------------------------------------------
   HELPER — Group all districts by division
   ------------------------------------------------------------ */
window.getDistrictsByDivision = function () {
    const groups = {};
    Object.entries(window.BD_DISTRICTS_LIST).forEach(([key, d]) => {
        if (!groups[d.division]) groups[d.division] = [];
        groups[d.division].push({ key, ...d });
    });
    return groups;
};

/* ------------------------------------------------------------
   HELPER — Populate any <select> element with 64 districts
   ------------------------------------------------------------ */
window.populateDistrictSelect = function (selectEl, options) {
    if (!selectEl) return;
    const opts = options || {};
    const placeholder = opts.placeholder || '-- Select District --';
    const grouped = opts.grouped !== false;   // default: grouped by division
    const selectedKey = opts.selected || '';

    if (!grouped) {
        selectEl.innerHTML = `<option value="">${placeholder}</option>` +
            Object.entries(window.BD_DISTRICTS_LIST)
                .sort((a, b) => a[1].name.localeCompare(b[1].name))
                .map(([key, d]) => `<option value="${key}"${key === selectedKey ? ' selected' : ''}>${d.name}</option>`)
                .join('');
        return;
    }

    const groups = window.getDistrictsByDivision();
    const divisionOrder = ['Dhaka', 'Chittagong', 'Rajshahi', 'Khulna', 'Barisal', 'Sylhet', 'Rangpur', 'Mymensingh'];

    let html = `<option value="">${placeholder}</option>`;
    divisionOrder.forEach(div => {
        const list = groups[div] || [];
        if (!list.length) return;
        html += `<optgroup label="${div} Division">`;
        list.sort((a, b) => a.name.localeCompare(b.name));
        list.forEach(d => {
            html += `<option value="${d.key}"${d.key === selectedKey ? ' selected' : ''}>${d.name}</option>`;
        });
        html += `</optgroup>`;
    });
    selectEl.innerHTML = html;
};

/* ------------------------------------------------------------
   HELPER — Haversine distance
   ------------------------------------------------------------ */
function _haversineKm(lat1, lng1, lat2, lng2) {
    const R = 6371;
    const toRad = d => d * Math.PI / 180;
    const dLat = toRad(lat2 - lat1);
    const dLng = toRad(lng2 - lng1);
    const a = Math.sin(dLat / 2) ** 2 +
              Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
              Math.sin(dLng / 2) ** 2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/* ------------------------------------------------------------
   HELPER — Check if coordinates are inside Bangladesh
   ------------------------------------------------------------ */
window.isInBangladesh = function (lat, lng) {
    return lat >= 20.0 && lat <= 27.0 && lng >= 87.5 && lng <= 93.5;
};

console.log('✅ bd-districts.js loaded — ' + Object.keys(window.BD_DISTRICTS_LIST).length + ' districts');

})();