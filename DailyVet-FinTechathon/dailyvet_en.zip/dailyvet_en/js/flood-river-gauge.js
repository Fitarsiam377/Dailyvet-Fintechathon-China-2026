/* ============================================================
 DailyVet — FFWC River Gauge Integration
 ------------------------------------------------------------
 Reads river water level from Firestore `river_gauges`
 collection and adds it to the flood risk score.
 ============================================================ */
(function () {
'use strict';

const _fs = () => firebase.firestore();
const COLLECTION = 'river_gauges';
const CACHE_TTL_MS = 5 * 60 * 1000; /* 5 min */

let _cachedRiver = null;
let _cacheTime = 0;
let _cacheKey = '';

/* ============================================================
 FETCH river data for a district
 ============================================================ */
async function fetchRiverGauge(district) {
 if (!district) return null;

 /* Cache hit */
 if (_cachedRiver && _cacheKey === district &&
 Date.now() - _cacheTime < CACHE_TTL_MS) {
 return _cachedRiver;
 }

 try {
 const snap = await _fs()
 .collection(COLLECTION)
 .where('district', '==', district)
 .limit(1)
 .get();

 if (snap.empty) {
 console.log(`[River] No gauge found for: ${district}`);
 return null;
 }

 const doc = snap.docs[0];
 const d = doc.data();

 const data = {
 id: doc.id,
 riverName: d.riverName || '—',
 riverNameEn: d.riverNameEn || '—',
 stationName: d.stationName || '—',
 stationNameEn: d.stationNameEn || '—',
 district: d.district,
 dangerLevel: Number(d.dangerLevel) || 0,
 currentLevel: Number(d.currentLevel) || 0,
 trend: d.trend || 'stable',
 note: d.note || '',
 lastUpdated: d.lastUpdated || null,
 lastUpdatedMs: d.lastUpdatedMs || null,
 updatedBy: d.updatedBy || null
 };

 /* Derived */
 data.gap = +(data.dangerLevel - data.currentLevel).toFixed(2);
 data.percentOfDanger = data.dangerLevel > 0
 ? Math.min(150, Math.round((data.currentLevel / data.dangerLevel) * 100))
 : 0;
 data.status = data.gap <= 0 ? 'overflow'
 : data.gap <= 0.5 ? 'critical'
 : data.gap <= 1.5 ? 'alert'
 : data.gap <= 3 ? 'watch'
 : 'safe';

 _cachedRiver = data;
 _cacheTime = Date.now();
 _cacheKey = district;

 return data;

 } catch (err) {
 console.warn('[River] Fetch failed:', err.message);
 return null;
 }
}

/* ============================================================
 Status → Bangla label + color
 ============================================================ */
function classifyRiverStatus(status) {
 const MAP = {
 overflow: { labelBn: 'Overflow', labelEn: 'Overflow', color: '#dc2626', bg: '#fef2f2', border: '#fecaca', icon: '🚨' },
 critical: { labelBn: 'Critical', labelEn: 'Critical', color: '#dc2626', bg: '#fef2f2', border: '#fecaca', icon: '🚨' },
 alert: { labelBn: 'Alert', labelEn: 'Alert', color: '#ea580c', bg: '#fff7ed', border: '#fdba74', icon: '⚠️' },
 watch: { labelBn: 'Watch', labelEn: 'Watch', color: '#d97706', bg: '#fef9e7', border: '#fcd34d', icon: '👀' },
 safe: { labelBn: 'Safe', labelEn: 'Safe', color: '#059669', bg: '#ecfdf5', border: '#86efac', icon: '✅' },
 unknown: { labelBn: 'Unknown', labelEn: 'Unknown', color: '#94a3b8', bg: '#f1f5f9', border: '#e2e8f0', icon: '⚪' }
 };
 return MAP[status] || MAP.unknown;
}

/* ============================================================
 River data → river score (0-30 points)
 ============================================================ */
function calcRiverScore(river) {
 if (!river || !river.dangerLevel) {
 return { score: 0, reasonBn: 'No river data', available: false };
 }

 const pct = river.percentOfDanger;
 let score = 0;
 let reasonBn = '';

 if (pct >= 100) {
 score = 30;
 reasonBn = '🚨 River has exceeded danger level! Move animals now.';
 } else if (pct >= 95) {
 score = 25;
 reasonBn = '⚠️ Within 5% of danger level. May overflow anytime.';
 } else if (pct >= 90) {
 score = 18;
 reasonBn = 'Within 10% of danger level — increase monitoring.';
 } else if (pct >= 80) {
 score = 10;
 reasonBn = 'Water rising — prepare.';
 } else if (pct >= 70) {
 score = 5;
 reasonBn = 'Slightly above normal.';
 } else {
 score = 0;
 reasonBn = 'River at normal level.';
 }

 if (river.trend === 'rising' && score > 0) {
 score = Math.min(30, Math.round(score * 1.15));
 reasonBn += ' 📈 Water is rising.';
 }

 return {
 score,
 reasonBn,
 available: true,
 percentOfDanger: pct,
 gap: river.gap,
 trend: river.trend
 };
}

/* ============================================================
 Public API
 ============================================================ */
window.NasaFloodRiver = {
 fetchRiverGauge,
 classifyRiverStatus,
 calcRiverScore,
 clearCache: () => { _cachedRiver = null; _cacheTime = 0; _cacheKey = ''; }
};

console.log('✅ flood-river-gauge.js loaded');

})();