/* ============================================================
   DailyVet — AI Agent Dashboard Logic v2.0
   ============================================================ */
(function () {
'use strict';

const _fs = () => firebase.firestore();
const _el = id => document.getElementById(id);

let _phone = null;
let _district = 'dhaka';
let _risk = null;
let _assets = [];
let _safeLoanLimit = 0;

document.addEventListener('DOMContentLoaded', async () => {
    _phone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
    if (!_phone) return window.location.href = 'login.html';

    renderMarketTrends(); // Load AI Market Trends
    await loadDashboardData();
});

async function loadDashboardData() {
    try {
        /* 1. Fetch User Profile */
        const userDoc = await _fs().collection('users').doc(_phone).get();
        if (userDoc.exists) {
            const data = userDoc.data();
            const d = data.district || data.city;
            if (d && window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[String(d).toLowerCase()]) {
                _district = String(d).toLowerCase();
            }
        }

        /* 2. Fetch Wealth Assets */
        const assetsSnap = await _fs().collection('users').doc(_phone).collection('wealth_assets').get();
        let netWorth = 0;
        _assets = [];
        assetsSnap.forEach(doc => {
            const d = doc.data();
            netWorth += Number(d.value) || 0;
            _assets.push({ id: doc.id, ...d });
        });
        if (_el('totalNetWorth')) _el('totalNetWorth').textContent = '৳ ' + netWorth.toLocaleString('en-IN');

        /* 3. Fetch Credit Readiness */
        if (window.DVCreditReadiness) {
            const creditData = await window.DVCreditReadiness.compute(_phone);
            if (creditData.ok && !creditData.empty) {
                if (_el('creditScore')) _el('creditScore').textContent = creditData.score;
                _safeLoanLimit = creditData.safeLoan ? creditData.safeLoan.limit : 0;
            }
        }

        /* 4. Fetch Live Risk */
        if (typeof window.fetchLiveRiskData === 'function') {
            _risk = await window.fetchLiveRiskData(_district);
            renderRiskStatus(_risk);
        }

        /* 5. Generate AI Actions */
        generateActions(_risk, _safeLoanLimit);

        /* 6. Load History */
        loadHistory();

    } catch (err) {
        console.error('Dashboard load failed:', err);
        if (_el('actionsContainer')) {
            _el('actionsContainer').innerHTML = '<div style="color:#dc2626;text-align:center;padding:1rem;">Failed to load AI data. Please refresh.</div>';
        }
    }
}

/* ============================================================
   🆕 AI MARKET TRENDS (Dynamic Simulation)
   ============================================================ */
function renderMarketTrends() {
    const container = _el('marketTrendContainer');
    if (!container) return;

    // Simulated AI Market Insights based on Bangladesh Market
    const trends = [
        { 
            animal: '🐄 Beef Cattle', 
            trend: 'up', 
            text: 'High demand in Dhaka and Chittagong. Prices are expected to rise by 8% before Eid.', 
            color: '#059669' 
        },
        { 
            animal: '🐐 Black Bengal Goat', 
            trend: 'up', 
            text: 'Export demand is increasing. Rajshahi and Jessore markets are showing strong buyer interest.', 
            color: '#059669' 
        },
        { 
            animal: '🐔 Sonali Chicken', 
            trend: 'down', 
            text: 'Poultry feed prices have increased by 3% this week. Profit margins might be slightly tighter.', 
            color: '#dc2626' 
        },
        { 
            animal: '🐃 Murrah Buffalo', 
            trend: 'stable', 
            text: 'Dairy farmers are holding onto high-yield buffaloes. Market supply is stable.', 
            color: '#d97706' 
        }
    ];

    container.innerHTML = trends.map(t => `
        <div style="display:flex; gap:12px; padding:12px; background:#f8fafc; border-radius:10px; border:1px solid #e2e8f0; border-left:4px solid ${t.color}; margin-bottom:10px;">
            <div style="font-size:1.25rem; font-weight:bold; color:${t.color}; display:flex; align-items:center; justify-content:center;">
                <i class="fas fa-arrow-trend-${t.trend === 'stable' ? 'up' : t.trend}"></i>
            </div>
            <div>
                <div style="font-weight:800; color:#0f172a; font-size:0.8125rem; margin-bottom:2px;">${t.animal}</div>
                <div style="font-size:0.75rem; color:#475569; line-height:1.4;">${t.text}</div>
            </div>
        </div>
    `).join('');
}

/* ============================================================
   RENDER RISK STATUS
   ============================================================ */
function renderRiskStatus(risk) {
    const box = _el('riskStatusContainer');
    if (!box || !risk) return;

    const flood = risk.flood?.score || 0;
    const heat = risk.heat?.level || 'normal';

    let cls = 'risk-safe';
    let text = 'Low Risk';
    if (flood > 70 || heat === 'severe') { cls = 'risk-danger'; text = 'High Risk'; }
    else if (flood > 40 || heat === 'moderate') { cls = 'risk-warning'; text = 'Moderate Risk'; }

    box.innerHTML = `
        <div class="risk-badge ${cls}">${text}</div>
        <div style="font-size:0.75rem; color:#475569; margin-top:4px;">
            Flood: <b>${flood}%</b> | Heat: <b>${heat}</b>
        </div>
    `;
}

/* ============================================================
   GENERATE AI ACTIONS
   ============================================================ */
function generateActions(risk, safeLimit) {
    const container = _el('actionsContainer');
    if (!container) return;

    const actions = [];
    const flood = risk?.flood?.score || 0;
    const heat = risk?.heat?.level || 'normal';

    // 1. Insurance Claim Action
    if (flood > 60 || heat === 'severe') {
        actions.push({
            id: 'claim',
            type: 'danger',
            icon: 'fa-shield-virus',
            title: 'File Parametric Claim',
            desc: `Extreme weather detected in your area (Flood: ${flood}%, Heat: ${heat}). You are eligible for an automatic payout.`,
            btn: 'File Claim',
            action: () => window.location.href = 'insurance-claim.html'
        });
    }

    // 2. Loan Simulation Action
    if (safeLimit > 0) {
        actions.push({
            id: 'loan',
            type: 'success',
            icon: 'fa-hand-holding-dollar',
            title: 'Safe Loan Limit Available',
            desc: `Based on your cashflow and weather risk, AI recommends you can safely borrow up to ৳${safeLimit.toLocaleString('en-IN')}.`,
            btn: 'Simulate Loan',
            action: () => window.location.href = 'finance-copilot.html'
        });
    }

    // 3. Portfolio Rebalancing
    if (_assets.length > 1) {
        actions.push({
            id: 'rebalance',
            type: 'warning',
            icon: 'fa-chart-pie',
            title: 'Portfolio Rebalancing',
            desc: `You have ${_assets.length} assets. AI suggests selling older non-productive animals and reinvesting in high-yield breeds.`,
            btn: 'Open Wealth Agent',
            action: () => window.location.href = 'wealth-agent.html'
        });
    }

    if (!actions.length) {
        container.innerHTML = `<div style="text-align:center;padding:2rem;color:#64748b;"><i class="fas fa-check-circle" style="color:#10b981;font-size:2rem;margin-bottom:1rem;"></i><div>All systems normal. No immediate actions required.</div></div>`;
        return;
    }

    container.innerHTML = actions.map(a => `
        <div class="action-card action-${a.type}">
            <div class="action-content">
                <h4><i class="fas ${a.icon}"></i> ${a.title}</h4>
                <p>${a.desc}</p>
            </div>
            <button class="action-btn" onclick="window.__agentAction_${a.id}()">${a.btn}</button>
        </div>
    `).join('');

    actions.forEach(a => { window[`__agentAction_${a.id}`] = a.action; });
}

/* ============================================================
   LOAD HISTORY
   ============================================================ */
async function loadHistory() {
    const container = _el('recentActionsContainer');
    if (!container) return;

    try {
        const snap = await _fs().collection('users').doc(_phone)
            .collection('ai_action_plans')
            .orderBy('createdAtMs', 'desc')
            .limit(5)
            .get();

        if (snap.empty) {
            container.innerHTML = '<div style="color:#64748b;font-size:0.8125rem;text-align:center;padding:1rem;">No recent actions executed.</div>';
            return;
        }

        container.innerHTML = snap.docs.map(doc => {
            const d = doc.data();
            const statusCls = d.status === 'executed' ? 'status-executed' : 'status-pending';
            const dateStr = new Date(d.createdAtMs).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
            
            // Determine title based on action type
            let title = 'Financial Action';
            if (d.action === 'micro_investment') title = 'Micro-Investment';
            else if (d.action === 'carbon_credit') title = 'Carbon Credit Earned';
            else if (d.action === 'roi_claim') title = 'ROI Claimed';
            else if (d.sell) title = `Sold ${d.sell.animalType} -> Bought ${d.buy?.animalType}`;

            return `
                <div class="history-item">
                    <div class="history-item-left">
                        <div class="history-item-title">${title}</div>
                        <div class="history-item-date">${dateStr} • ${d.summary || ''}</div>
                    </div>
                    <span class="history-status ${statusCls}">${(d.status || 'DONE').toUpperCase()}</span>
                </div>
            `;
        }).join('');

    } catch (err) {
        console.warn('History load failed:', err);
        container.innerHTML = '<div style="color:#64748b;font-size:0.8125rem;text-align:center;padding:1rem;">Could not load history.</div>';
    }
}

})();