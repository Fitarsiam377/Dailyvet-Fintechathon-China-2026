(function () {
'use strict';

const DISTRICT_COORDS = {
    dhaka:      { lat: 23.8103, lng: 90.4125, name: 'Dhaka' },
    kurigram:   { lat: 25.8072, lng: 89.6295, name: 'Kurigram' },
    gaibandha:  { lat: 25.3288, lng: 89.5286, name: 'Gaibandha' },
    lalmonirhat:{ lat: 25.9923, lng: 89.2847, name: 'Lalmonirhat' },
    sirajganj:  { lat: 24.4533, lng: 89.7009, name: 'Sirajganj' },
    jamalpur:   { lat: 24.9375, lng: 89.9372, name: 'Jamalpur' },
    sunamganj:  { lat: 25.0658, lng: 91.3950, name: 'Sunamganj' },
    sylhet:     { lat: 24.8949, lng: 91.8687, name: 'Sylhet' },
    kishoreganj:{ lat: 24.4449, lng: 90.7766, name: 'Kishoreganj' },
    chandpur:   { lat: 23.2333, lng: 90.6711, name: 'Chandpur' },
    shariatpur: { lat: 23.2423, lng: 90.4348, name: 'Shariatpur' },
    munshiganj: { lat: 23.5422, lng: 90.5305, name: 'Munshiganj' },
    bogura:     { lat: 24.8465, lng: 89.3773, name: 'Bogura' },
    pabna:      { lat: 24.0064, lng: 89.2372, name: 'Pabna' },
    faridpur:   { lat: 23.6070, lng: 89.8429, name: 'Faridpur' },
    rangpur:    { lat: 25.7439, lng: 89.2752, name: 'Rangpur' },
    chittagong: { lat: 22.3569, lng: 91.7832, name: 'Chittagong' },
    khulna:     { lat: 22.8456, lng: 89.5403, name: 'Khulna' },
    barisal:    { lat: 22.7010, lng: 90.3535, name: 'Barisal' },
    rajshahi:   { lat: 24.3745, lng: 88.6042, name: 'Rajshahi' },
    mymensingh: { lat: 24.7471, lng: 90.4203, name: 'Mymensingh' }
};

const _el = id => document.getElementById(id);
const _ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const escapeHtml = t => String(t == null ? '' : t).replace(/[&<>"']/g, c => _ESC[c]);
const fmt = n => Number(n || 0).toLocaleString('en-IN');

function formatDate(yyyymmdd) {
    if (!yyyymmdd) return '';
    const s = String(yyyymmdd);
    if (s.length !== 8) return '';
    const d = new Date(Date.UTC(+s.slice(0,4), +s.slice(4,6)-1, +s.slice(6,8)));
    return isNaN(d) ? '' : d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
}

let currentDistrict = 'sirajganj';
let loadToken = 0;

async function fetchAllFloodData(districtKey) {
    const coords = DISTRICT_COORDS[districtKey];
    if (!coords) return null;

    const [parameter, rainForecast, sedac, riverGauge] = await Promise.all([
        NasaPower.getPowerData(coords.lat, coords.lng, 7).catch(() => null),
        OpenMeteo.getRainfallCumulative(coords.lat, coords.lng, 72).catch(() => null),
        NasaSedac.fetchSedacData(districtKey).catch(() => null),
        (window.NasaFloodRiver && typeof NasaFloodRiver.fetchRiverGauge === 'function')
            ? NasaFloodRiver.fetchRiverGauge(districtKey).catch(() => null)
            : Promise.resolve(null)
    ]);

    return { coords, parameter, rainForecast, sedac, riverGauge };
}

function renderFloodDashboard(body, districtKey, data) {
    const { coords, parameter, rainForecast, sedac, riverGauge } = data;

    const rainSeries = parameter ? NasaPower.getSeries(parameter, 'PRECTOTCORR') : [];
    const soilRootLatest = parameter ? NasaPower.getLatest(parameter, 'GWETROOT') : null;
    const soilTopLatest = parameter ? NasaPower.getLatest(parameter, 'GWETTOP') : null;

    const rain7dayMm = rainSeries.reduce((s, d) => s + (d.value > 0 ? d.value : 0), 0);
    const daysOfRain = rainSeries.filter(d => d.value > 5).length;

    const rain48h = rainForecast?.rain48hMm || 0;
    const rain72h = rainForecast?.rain72hMm || 0;
    const peakHourly = rainForecast?.peakHourlyMm || 0;

    const risk = NasaFlood.calculateFloodRisk({
        rain7dayMm,
        soilRoot: soilRootLatest ? soilRootLatest.value : 0,
        soilTop: soilTopLatest ? soilTopLatest.value : 0,
        rain48hForecast: rain48h,
        rain72hForecast: rain72h,
        district: districtKey,
        daysOfRain
    });

    let riverBonus = 0;
    let riverScoreData = null;

    if (riverGauge && window.NasaFloodRiver && typeof NasaFloodRiver.calcRiverScore === 'function') {
        riverScoreData = NasaFloodRiver.calcRiverScore(riverGauge);
        if (riverScoreData.available) {
            riverBonus = Math.round(riverScoreData.score * 0.5);
        }
    }

    if (riverBonus > 0) {
        const newScore = Math.min(100, risk.score + riverBonus);
        const newLevel = NasaFlood.FLOOD_LEVELS.find(l => newScore >= l.min);

        risk.score = newScore;
        if (newLevel) Object.assign(risk, newLevel);

        risk.breakdown = risk.breakdown || [];
        risk.breakdown.push({
            icon: '🌊',
            label: 'River Water Level (FFWC)',
            value: `${riverGauge.currentLevel}m / Danger ${riverGauge.dangerLevel}m`,
            score: riverBonus,
            max: 15,
            reason: riverScoreData.reason
        });
    }

    const livestockCounts = sedac?.livestock || { cattle: 100000, goat: 50000, poultry: 500000, sheep: 10000 };
    const totalAnimals = (livestockCounts.cattle || 0) + (livestockCounts.goat || 0) +
                         (livestockCounts.sheep || 0) + (livestockCounts.poultry || 0);
    const animalsAtRisk = Math.round(totalAnimals * (risk.score / 100));
    const marginalFarmers = sedac?.marginalFarmers || 0;
    const farmersAtRisk = Math.round(marginalFarmers * (risk.score / 100));

    const speciesList = ['Cow', 'Goat', 'Sheep', 'Chicken', 'Duck'];
    const relocationPlan = NasaFlood.getRelocationPriority(risk.level, speciesList);

    const shelters = NasaFlood.getSafeShelterAdvice(risk.level, districtKey);

    const feedPlan = NasaFlood.getEmergencyFeedPlan(risk.level, ['Cow', 'Goat', 'Chicken']);

    const breakdownHtml = risk.breakdown.map(b => `
        <div style="margin-bottom:14px;">
            <div style="display:flex;justify-content:space-between;font-size:12.5px;font-weight:700;margin-bottom:5px;gap:10px;flex-wrap:wrap;">
                <span>${b.icon} ${escapeHtml(b.label)} <span style="color:#64748b;font-weight:600;">(${escapeHtml(b.value)})</span></span>
                <span style="color:${risk.color};font-weight:800;">+${b.score} / ${b.max}</span>
            </div>
            <div style="height:6px;background:#e2e8f0;border-radius:999px;overflow:hidden;">
                <div style="width:${Math.min(100, (b.score/b.max)*100)}%;background:${risk.color};height:100%;border-radius:999px;transition:width 0.5s;"></div>
            </div>
            <div style="font-size:11px;color:#64748b;margin-top:4px;">${escapeHtml(b.reason)}</div>
        </div>
    `).join('');

    const relocationHtml = relocationPlan.map((r, i) => `
        <div style="display:flex;align-items:flex-start;gap:12px;padding:12px 14px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:14px;margin-bottom:8px;">
            <div style="width:32px;height:32px;border-radius:50%;background:${i === 0 ? '#dc2626' : i === 1 ? '#f59e0b' : '#0891b2'};color:#fff;font-weight:900;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0;">${i + 1}</div>
            <div>
                <div style="font-size:14px;font-weight:800;color:#0f172a;">${escapeHtml(r.species)}</div>
                <div style="font-size:12px;color:#475569;line-height:1.5;margin-top:2px;">${escapeHtml(r.reason)}</div>
            </div>
        </div>
    `).join('');

    const shelterHtml = shelters.map(s => `
        <div style="display:flex;align-items:flex-start;gap:10px;padding:10px 12px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:12px;margin-bottom:6px;">
            <span style="font-size:20px;flex-shrink:0;">${s.icon}</span>
            <div>
                <div style="font-size:13px;font-weight:800;color:#1e40af;">${escapeHtml(s.title)}</div>
                <div style="font-size:11.5px;color:#475569;margin-top:1px;">${escapeHtml(s.note)}</div>
            </div>
        </div>
    `).join('');

    const feedHtml = feedPlan.plan.map(p => `
        <div class="cl-feed-card-premium">
            <div class="cl-feed-header">
                <div class="cl-feed-title">
                    <span style="font-size:18px;">🐾</span> ${escapeHtml(p.species)}
                </div>
                <div class="cl-feed-badge">${p.days} Days Plan</div>
            </div>
            
            <div class="cl-feed-grid">
                <div class="cl-feed-item">
                    <div class="cl-feed-item-lbl"><i class="fas fa-wheat-awn"></i> Dry Hay</div>
                    <div class="cl-feed-item-val">${p.hayKg}<span class="cl-feed-item-unit">kg</span></div>
                </div>
                <div class="cl-feed-item">
                    <div class="cl-feed-item-lbl"><i class="fas fa-seedling"></i> Grain/Bran</div>
                    <div class="cl-feed-item-val">${p.concentrateKg}<span class="cl-feed-item-unit">kg</span></div>
                </div>
                <div class="cl-feed-item">
                    <div class="cl-feed-item-lbl"><i class="fas fa-droplet"></i> Water</div>
                    <div class="cl-feed-item-val">${p.waterLt}<span class="cl-feed-item-unit">L</span></div>
                </div>
            </div>
            
            <div class="cl-feed-note">
                <i class="fas fa-circle-info" style="color:#d97706;"></i> ${escapeHtml(p.note)}
            </div>
        </div>
    `).join('');

    const feedTips = feedPlan.tips.map(t => `<li>${escapeHtml(t)}</li>`).join('');

    let riverSectionHtml = '';
    if (riverGauge && window.NasaFloodRiver && typeof NasaFloodRiver.classifyRiverStatus === 'function') {
        const riverStatus = NasaFloodRiver.classifyRiverStatus(riverGauge.status);
        const rsData = riverScoreData || NasaFloodRiver.calcRiverScore(riverGauge);
        const lastUpdatedText = riverGauge.lastUpdatedMs
            ? new Date(riverGauge.lastUpdatedMs).toLocaleString('en-GB', {
                day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'
            })
            : '—';

        riverSectionHtml = `
            <div class="dva-card" style="border:2px solid ${riverStatus.color}30;">
                <div class="dva-card-title">
                    <span><i class="fas fa-water" style="color:${riverStatus.color};"></i> River Water Level — ${escapeHtml(riverGauge.riverName)}</span>
                    <span class="dva-hero-status-pill" style="background:${riverStatus.bg};color:${riverStatus.color};border:1px solid ${riverStatus.border};font-size:11px;">
                        ${riverStatus.icon} ${escapeHtml(riverStatus.label)}
                    </span>
                </div>

                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;">
                    <div style="padding:14px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:14px;text-align:center;">
                        <div style="font-size:11px;font-weight:800;color:#64748b;text-transform:uppercase;">Current Water Level</div>
                        <div style="font-size:24px;font-weight:900;color:${riverStatus.color};margin-top:4px;">${riverGauge.currentLevel} <span style="font-size:13px;">m</span></div>
                    </div>
                    <div style="padding:14px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:14px;text-align:center;">
                        <div style="font-size:11px;font-weight:800;color:#64748b;text-transform:uppercase;">Danger Level</div>
                        <div style="font-size:24px;font-weight:900;color:#0f172a;margin-top:4px;">${riverGauge.dangerLevel} <span style="font-size:13px;">m</span></div>
                    </div>
                    <div style="padding:14px;background:${riverStatus.bg};border:1px solid ${riverStatus.border};border-radius:14px;text-align:center;">
                        <div style="font-size:11px;font-weight:800;color:${riverStatus.color};text-transform:uppercase;">
                            ${riverGauge.gap >= 0 ? 'Remaining' : 'Exceeded'}
                        </div>
                        <div style="font-size:24px;font-weight:900;color:${riverStatus.color};margin-top:4px;">
                            ${Math.abs(riverGauge.gap)} <span style="font-size:13px;">m</span>
                        </div>
                    </div>
                </div>

                <div style="margin-top:6px;">
                    <div style="display:flex;justify-content:space-between;font-size:11px;font-weight:700;color:#64748b;margin-bottom:5px;">
                        <span>% of danger level — ${riverGauge.percentOfDanger}%</span>
                        <span>${riverGauge.trend === 'rising' ? '📈 Rising' : riverGauge.trend === 'falling' ? '📉 Falling' : '➡️ Stable'}</span>
                    </div>
                    <div style="height:10px;background:#e2e8f0;border-radius:999px;overflow:hidden;">
                        <div style="width:${Math.min(100, riverGauge.percentOfDanger)}%;height:100%;background:${riverStatus.color};border-radius:999px;transition:width 0.6s;"></div>
                    </div>
                    <div style="font-size:11.5px;color:${riverStatus.color};font-weight:700;margin-top:6px;">
                        💡 ${escapeHtml(rsData.reason)}
                    </div>
                </div>

                <div style="display:flex;justify-content:space-between;align-items:center;font-size:11px;color:#94a3b8;padding-top:8px;border-top:1px dashed #e2e8f0;margin-top:6px;flex-wrap:wrap;gap:6px;">
                    <span><i class="fas fa-clock"></i> Last Updated: ${lastUpdatedText}</span>
                    <span><i class="fas fa-map-marker-alt"></i> ${escapeHtml(riverGauge.stationName)}</span>
                </div>
            </div>
        `;
    }

    body.innerHTML = `
        <div class="dva-box">
            <div class="dva-hero-card" style="border-color:${risk.color};background:${risk.bg};">
                <div class="dva-hero-top">
                    <span class="dva-hero-title" style="color:${risk.color};font-size:15px;">
                        <i class="fas fa-water"></i>
                        Flood Risk Score — ${escapeHtml(coords.name)}
                    </span>
                    <span class="dva-hero-status-pill" style="background:#fff;color:${risk.color};border:1.5px solid ${risk.color};">
                        ${risk.icon} ${escapeHtml(risk.label)}
                    </span>
                </div>
                <div class="dva-hero-val-row">
                    <div>
                        <span class="dva-hero-num" style="color:${risk.color};">${risk.score}</span>
                        <span class="dva-hero-unit">%</span>
                    </div>
                    <div style="text-align:right;">
                        <div style="font-size:13.5px;font-weight:800;color:${risk.color};">${escapeHtml(risk.action)}</div>
                    </div>
                </div>
                <div class="dva-meter-track">
                    <div class="dva-meter-fill" style="width:${risk.score}%;background:${risk.color};"></div>
                </div>
                <div class="dva-meter-labels">
                    <span style="color:#059669;">✅ 0-35%</span>
                    <span style="color:#d97706;">👀 35-55%</span>
                    <span style="color:#c2410c;">⚠️ 55-75%</span>
                    <span style="color:#dc2626;">🚨 75-100%</span>
                </div>
            </div>

            ${risk.level !== 'safe' ? `
                <div style="padding:16px 20px;background:#fef2f2;border:2px solid ${risk.color};border-radius:18px;display:flex;align-items:flex-start;gap:14px;">
                    <span style="font-size:28px;flex-shrink:0;">${risk.icon}</span>
                    <div>
                        <div style="font-size:16px;font-weight:900;color:${risk.color};margin-bottom:4px;">
                            ${escapeHtml(risk.label)} — Take Action Now
                        </div>
                        <div style="font-size:13px;color:#334155;line-height:1.55;">
                            Flood risk in ${escapeHtml(coords.name)} over the next 48-72 hours is <b>${risk.score}%</b>. 
                            ${totalAnimals > 0 ? `<b>${fmt(animalsAtRisk)}</b> livestock and <b>${fmt(farmersAtRisk)}</b> farmers are at risk.` : ''}
                        </div>
                    </div>
                </div>
            ` : ''}

            ${riverSectionHtml}

            <div class="dva-card">
                <div class="dva-card-title">
                    <span><i class="fas fa-chart-simple text-blue-600"></i> Potential Impact (Population at Risk)</span>
                    <span style="font-size:11.5px;font-weight:700;color:#64748b;">NASA SEDAC + DLS</span>
                </div>
                <div class="dva-pollutant-grid" style="grid-template-columns:repeat(auto-fit,minmax(140px,1fr));">
                    <div class="dva-pollutant-card">
                        <div class="dva-pollutant-top"><span class="dva-pollutant-icon">🐾</span></div>
                        <div class="dva-pollutant-val">${fmt(animalsAtRisk)}</div>
                        <div class="dva-pollutant-lbl">Livestock at risk</div>
                    </div>
                    <div class="dva-pollutant-card">
                        <div class="dva-pollutant-top"><span class="dva-pollutant-icon">🧑‍🌾</span></div>
                        <div class="dva-pollutant-val">${fmt(farmersAtRisk)}</div>
                        <div class="dva-pollutant-lbl">Farmer households</div>
                    </div>
                    <div class="dva-pollutant-card">
                        <div class="dva-pollutant-top"><span class="dva-pollutant-icon">🌧️</span></div>
                        <div class="dva-pollutant-val">${Math.round(rain72h)}<span style="font-size:12px;"> mm</span></div>
                        <div class="dva-pollutant-lbl">72h forecast rain</div>
                    </div>
                    <div class="dva-pollutant-card">
                        <div class="dva-pollutant-top"><span class="dva-pollutant-icon">💧</span></div>
                        <div class="dva-pollutant-val">${Math.round((soilRootLatest?.value || 0) * 100)}<span style="font-size:12px;"> %</span></div>
                        <div class="dva-pollutant-lbl">Soil moisture</div>
                    </div>
                </div>
            </div>

            <div class="dva-card">
                <div class="dva-card-title">
                    <span><i class="fas fa-calculator text-blue-600"></i> Why ${risk.score}% flood risk?</span>
                    <span style="font-size:11.5px;font-weight:700;color:#64748b;">All factors</span>
                </div>
                ${breakdownHtml}
            </div>

            <div class="dva-card">
                <div class="dva-card-title">
                    <span><i class="fas fa-truck-ramp-box text-rose-600"></i> Livestock Relocation Priority</span>
                    <span style="font-size:11.5px;font-weight:700;color:#dc2626;background:#fef2f2;padding:3px 10px;border-radius:8px;border:1px solid #fecaca;">
                        ${risk.level === 'critical' ? '🚨 Now' : risk.level === 'alert' ? '⚠️ Within 48 Hours' : '👀 Be Prepared'}
                    </span>
                </div>
                ${relocationHtml}
            </div>

            <div class="dva-card">
                <div class="dva-card-title">
                    <span><i class="fas fa-house-chimney text-emerald-600"></i> Safe Shelter Advice</span>
                    <span style="font-size:11.5px;font-weight:700;color:#047857;background:#ecfdf5;padding:3px 10px;border-radius:8px;border:1px solid #a7f3d0;">
                        ${escapeHtml(risk.vulnerability?.type?.toUpperCase() || 'GENERAL')} ZONE
                    </span>
                </div>
                ${shelterHtml}
            </div>

            <div class="dva-card">
                <div class="dva-card-title">
                    <span><i class="fas fa-wheat-awn text-amber-600"></i> ${feedPlan.days}-Day Emergency Feed Plan</span>
                    <span style="font-size:11.5px;font-weight:700;color:#92400e;background:#fffbeb;padding:3px 10px;border-radius:8px;border:1px solid #fde68a;">
                        Per Animal
                    </span>
                </div>
                ${feedHtml}
                
                <div class="cl-feed-tips-container">
                    <div class="cl-feed-tips-title">
                        <i class="fas fa-lightbulb"></i> Feed Storage Tips
                    </div>
                    <ul class="cl-feed-tips-list">
                        ${feedTips}
                    </ul>
                </div>
            </div>

            ${rainForecast && Array.isArray(rainForecast.hourly) && rainForecast.hourly.length > 0 ? `
                <div class="dva-card">
                    <div class="dva-card-title">
                        <span><i class="fas fa-clock text-indigo-600"></i> Next 72 Hours Rainfall (hourly)</span>
                        <span style="font-size:11.5px;font-weight:700;color:#64748b;">Open-Meteo</span>
                    </div>
                    <div style="display:flex;align-items:flex-end;gap:2px;height:80px;padding:8px 0;overflow-x:auto;position:relative;">
                        ${peakHourly === 0 || rainForecast.hourly.every(p => Number(p.mm) === 0) ? `
                            <div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:#f8fafc;border-radius:8px;border:1px dashed #cbd5e1;z-index:10;">
                                <span style="font-size:12px;font-weight:600;color:#64748b;"><i class="fas fa-cloud-sun" style="margin-right:6px;"></i>No rainfall expected in the next 72 hours</span>
                            </div>
                        ` : ''}
                        ${rainForecast.hourly.slice(0, 72).map((p, i) => {
                            const mm = Number(p.mm) || 0;
                            const h = Math.min(70, mm * 3);
                            const c = mm > 15 ? '#dc2626' : mm > 8 ? '#ea580c' : mm > 3 ? '#d97706' : '#0891b2';
                            
                            if (mm === 0) {
                                return `<div title="Hour ${i}: 0 mm" style="width:6px;height:2px;background:#cbd5e1;border-radius:2px;flex-shrink:0;margin-top:auto;"></div>`;
                            }
                            
                            return `<div title="Hour ${i}: ${mm.toFixed(1)} mm" style="width:6px;height:${h}px;background:${c};border-radius:2px;flex-shrink:0;min-height:3px;"></div>`;
                        }).join('')}
                    </div>
                    <div style="font-size:11px;color:#64748b;text-align:center;margin-top:4px;">
                        First 72 hours &bull; Peak hourly ${peakHourly} mm
                    </div>
                </div>
            ` : ''}

            <div class="dvf-card-footer">
                <i class="fas fa-info-circle text-slate-400"></i>
                <span>Sources: NASA GPM IMERG rainfall radar + NASA SMAP soil moisture satellite + NASA POWER 7-day rainfall + Open-Meteo 48-72h forecast${riverGauge ? ' + FFWC river water level (manual input)' : ''}. Flood forecast is a planning aid model — not a substitute for official warnings.</span>
            </div>

        </div>
    `;
}

async function loadFloodData() {
    const body = _el('floodAppRoot');
    if (!body) return;

    const token = ++loadToken;
    body.innerHTML = `
        <div class="climate-empty">
            <i class="fas fa-spinner fa-spin text-blue-600" style="font-size:32px;"></i>
            <span class="font-extrabold text-slate-800">Analyzing flood telemetry...</span>
            <span class="text-xs text-slate-500">NASA GPM + SMAP + Open-Meteo + FFWC</span>
        </div>`;

    try {
        const data = await fetchAllFloodData(currentDistrict);
        if (token !== loadToken) return;

        if (!data || !data.parameter) {
            throw new Error('NASA data not available');
        }

        renderFloodDashboard(body, currentDistrict, data);

        if (window.DVNotifications && typeof window.DVNotifications.createNotification === 'function') {
            const risk = NasaFlood.calculateFloodRisk({
                rain7dayMm: (data.parameter ? NasaPower.getSeries(data.parameter, 'PRECTOTCORR').reduce((s, d) => s + (d.value || 0), 0) : 0),
                soilRoot: (NasaPower.getLatest(data.parameter, 'GWETROOT')?.value || 0),
                soilTop: (NasaPower.getLatest(data.parameter, 'GWETTOP')?.value || 0),
                rain48hForecast: data.rainForecast?.rain48hMm || 0,
                rain72hForecast: data.rainForecast?.rain72hMm || 0,
                district: currentDistrict
            });

            if (risk.level === 'critical' || risk.level === 'alert') {
                window.DVNotifications.createNotification({
                    title: `${risk.icon} Flood Warning — ${DISTRICT_COORDS[currentDistrict].name}`,
                    body: `${risk.score}% flood risk over 48-72 hours. Move livestock to higher ground, stockpile feed.`,
                    icon: risk.icon,
                    type: 'flood_alert',
                    priority: 'high',
                    actionUrl: 'climate-flood.html',
                    scheduledFor: Date.now(),
                    maxReminds: 2,
                    meta: {
                        district: currentDistrict,
                        level: risk.level,
                        score: risk.score,
                        kind: 'flood_warning'
                    }
                });
            }
        }
    } catch (err) {
        if (token !== loadToken) return;
        console.error('[Flood] Load failed:', err);
        body.innerHTML = `
            <div class="climate-empty">
                <i class="fas fa-exclamation-triangle" style="color:#dc2626;font-size:32px;"></i>
                <span class="font-extrabold text-slate-800">Could not load flood data</span>
                <span class="text-xs text-slate-500">${escapeHtml(err.message)}</span>
            </div>`;
    }
}

function init() {
    const select = _el('climateDistrict');
    if (select) {
        select.value = currentDistrict;
        select.addEventListener('change', e => {
            if (!DISTRICT_COORDS[e.target.value]) return;
            currentDistrict = e.target.value;
            loadFloodData();
        });
    }
    loadFloodData();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
} else {
    init();
}

})();