/* ============================================================
   DailyVet — AI Breed Detection v3.5 (English only)
   ✅ AI output guaranteed English via DVLangGuard
   ✅ Strict-English retry if first pass returns Bengali
   ✅ speciesBengali / sexBengali now English species terms
      (Bull/Cow, Buck/Doe, Rooster/Hen, etc.)
   ✅ Hard timeout 8s — guaranteed reply
   ✅ 5 Gemini + 3 Groq + 2 OpenRouter keys (rotation + fallback)
   ============================================================ */

let bdSelectedImage = null;
let bdCurrentPhone = null;

const BD_GEMINI_KEYS = [
  _dvDec('QVEuQWI4Uk42S1ZieGwxZTBaSjRqUU9rR1oyeXFkRnh4MnU1SmwxeU42QW5DVzRtM2pwSVE='),
  _dvDec('QVEuQWI4Uk42TENMSDBLdjctZEVYNjFMcWhlWnlUM2VXWFpuOXZsamhFd2Fsb2xOcnc1bGc='),
  _dvDec('QVEuQWI4Uk42S3JmTjF2dmUwQTRvOURiUnJLbEp3ZHVJNl9GdkJrQ0Q0Q0dMZVFjR0FveFE='),
  _dvDec('QVEuQWI4Uk42SUgzMFlLWkVPVndWZF8yOFhlc3Y2akh1bk1WRndjN0JucXlldkR3WTV2U3c='),
  _dvDec('QVEuQWI4Uk42TDJ1Y2RzVk1DT0JkaFpHU1llTF9LenZjVUtWbEpaOVI4T3Y4RnV4WG5KWnc=')
];

const BD_VISION_MODELS = [
    'gemini-3.5-flash-lite',
    'gemini-3.1-flash-lite',
    'gemini-2.5-flash-lite',
    'gemini-3.8-flash',
    'gemini-3.6-flash',
    'gemini-2.5-flash'
];

const BD_GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
const BD_PER_CALL_TIMEOUT_MS = 4200;
const BD_OVERALL_TIMEOUT_MS = 8000;
const BD_MAX_IMAGE_MB = 10;

const _bdKeyStatus = BD_GEMINI_KEYS.map(() => ({ blockedUntil: 0, failCount: 0 }));
let _bdBestKeyIndex = 0;

const BD_BLOCK_MS = {
  rate_limit: 25 * 1000, invalid: 20 * 60 * 1000, network: 5 * 1000,
  timeout: 4 * 1000, server: 8 * 1000, model_gone: 90 * 60 * 1000,
  badOutput: 15 * 1000
};

/* ============================================================
   Groq + OpenRouter vision fallback (rotation) — models identical to ai.js
   Gemini runs first; if every Gemini slot fails, these take over.
   ============================================================ */
const BD_GROQ_KEYS = [
  _dvDec('Z3NrX21WVXRJQThxTHdXUGNIZkFvNHNkV0dkeWIzRllkUk1rTlppMUxYT2gxb1RITVlIM0w3WXI='),
  _dvDec('Z3NrX3o4QkRyYldCbXlhS2l6M3BiVnZRV0dkeWIzRlk1R25haDNrQVptQm1xRUF2a2ZLMTZmd1M='),
  _dvDec('Z3NrX0ExSHo5VDQ3aTA5UndrM1h4UGlaV0dkeWIzRllxT0YxOHdDc0JRV0lUaVlOQjRaM3RheDQ=')
];
const BD_OPENROUTER_KEYS = [
  _dvDec('c2stb3ItdjEtODg4MDE5MDk4Njc2MjllYWQ5ZGQyMjQ2MTc5YWVlZjE0Y2VkZTFiMGZkOGI2YmQxM2VkNDA2NTU3NWVhZWY3OQ=='),
  _dvDec('c2stb3ItdjEtNGQwZmE1MzM5YWI1YTA3NDlkM2I4ZTEyZTU1NGM3ZWI2MjFjYzNjMmI1YjgwYzk0MjA5YjM0YjhmMzZjZTFlNg==')
];
const BD_ALT_KEYS = { groq: BD_GROQ_KEYS, openrouter: BD_OPENROUTER_KEYS };
const BD_ALT_MODELS = {
  groq: ['qwen/qwen3.8-27b'],
  openrouter: ['qwen/qwen2.5-vl-72b-instruct:free']
};
const BD_ALT_URLS = {
  groq: 'https://api.groq.com/openai/v1/chat/completions',
  openrouter: 'https://openrouter.ai/api/v1/chat/completions'
};
const _bdAltStatus = {
  groq: BD_GROQ_KEYS.map(() => ({ blockedUntil: 0, failCount: 0 })),
  openrouter: BD_OPENROUTER_KEYS.map(() => ({ blockedUntil: 0, failCount: 0 }))
};
const _bdAltBest = { groq: 0, openrouter: 0 };

function _bdAltLiveKeys(provider) {
  const n = BD_ALT_KEYS[provider].length;
  if (!n) return [];
  const now = Date.now();
  const order = Array.from({ length: n }, (_, i) => (_bdAltBest[provider] + i) % n);
  const live = order.filter(i => _bdAltStatus[provider][i].blockedUntil <= now);
  return live.length ? live : order.slice(0, 2);
}
function _bdAltMarkFailed(provider, index, errorType) {
  const st = _bdAltStatus[provider]?.[index];
  if (!st) return;
  const base = BD_BLOCK_MS[errorType] || 8 * 1000;
  st.blockedUntil = Date.now() + base * Math.min(1 + st.failCount * 0.3, 2.5);
  st.failCount += 1;
}
function _bdAltMarkSuccess(provider, index) {
  _bdAltBest[provider] = index;
  const st = _bdAltStatus[provider]?.[index];
  if (st) Object.assign(st, { failCount: 0, blockedUntil: 0 });
}

async function _bdCallChat(provider, keyIdx, model, imageBase64, prompt) {
  const apiKey = BD_ALT_KEYS[provider][keyIdx];
  const imageData = imageBase64.includes(',') ? imageBase64.split(',')[1] : imageBase64;
  const mimeType = imageBase64.includes('data:') ? imageBase64.split(';')[0].split(':')[1] : 'image/jpeg';
  const dataUrl = `data:${mimeType};base64,${imageData}`;

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), BD_PER_CALL_TIMEOUT_MS);
  try {
    const body = {
      model, temperature: 0.15, max_tokens: 1500,
      messages: [{
        role: 'user',
        content: [
          { type: 'text', text: prompt },
          { type: 'image_url', image_url: { url: dataUrl } }
        ]
      }]
    };
    if (provider === 'groq') body.response_format = { type: 'json_object' };
    const headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` };
    if (provider === 'openrouter') {
      headers['HTTP-Referer'] = (typeof location !== 'undefined' && location.origin) || 'https://dailyvet.app';
      headers['X-Title'] = 'DailyVet';
    }
    const response = await fetch(BD_ALT_URLS[provider], {
      method: 'POST', headers, body: JSON.stringify(body), signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (!response.ok) {
      const status = response.status;
      const errorType = status === 429 ? 'rate_limit'
        : (status === 401 || status === 402 || status === 403) ? 'invalid'
        : status === 404 ? 'model_gone'
        : status >= 500 ? 'server' : 'network';
      return { success: false, errorType, status, provider, keyIndex: keyIdx };
    }
    const data = await response.json();
    const rawText = String(data.choices?.[0]?.message?.content || '')
      .replace(/<think>[\s\S]*?<\/think>/gi, '').trim();
    if (!rawText) return { success: false, errorType: 'empty', provider, keyIndex: keyIdx };
    let parsed;
    try { parsed = parseGeminiJSON(rawText); }
    catch (_) { return { success: false, errorType: 'badOutput', provider, keyIndex: keyIdx }; }
    return { success: true, data: parsed, provider, keyIndex: keyIdx };
  } catch (err) {
    clearTimeout(timeoutId);
    const errorType = err?.name === 'AbortError' ? 'timeout' : 'network';
    return { success: false, errorType, provider, keyIndex: keyIdx };
  }
}

/* Staggered race: Groq starts at once, OpenRouter hedges in a bit later. */
async function _bdAltFallback(imageBase64, prompt, deadlineMs) {
  const jobs = [];
  ['groq', 'openrouter'].forEach((provider, pi) => {
    _bdAltLiveKeys(provider).slice(0, 2).forEach((keyIdx, ki) => {
      BD_ALT_MODELS[provider].forEach(model =>
        jobs.push({ provider, keyIdx, model, delay: pi * 900 + ki * 400 }));
    });
  });
  if (!jobs.length) return null;
  const run = job => _bdSleep(job.delay)
    .then(() => _bdCallChat(job.provider, job.keyIdx, job.model, imageBase64, prompt))
    .then(r => {
      if (r.success) { _bdAltMarkSuccess(r.provider, r.keyIndex); return r; }
      _bdAltMarkFailed(r.provider, r.keyIndex, r.errorType);
      throw r;
    });
  const timeout = new Promise(res => setTimeout(() => res(null), Math.max(1500, deadlineMs)));
  const winner = await Promise.race([Promise.any(jobs.map(run)).catch(() => null), timeout]);
  return winner && winner.success ? winner.data : null;
}

/* ============================================================
   Helpers
   ============================================================ */
const _elBD = id => document.getElementById(id);
const _fsBD = () => firebase.firestore();
const _bdSleep = ms => new Promise(r => setTimeout(r, ms));

function escapeHtmlBD(text) {
  const div = document.createElement('div');
  div.textContent = String(text);
  return div.innerHTML;
}

function _bdMarkKeyFailed(index, errorType) {
  const st = _bdKeyStatus[index];
  const base = BD_BLOCK_MS[errorType] || 8 * 1000;
  st.blockedUntil = Date.now() + base * Math.min(1 + st.failCount * 0.3, 2.5);
  st.failCount += 1;
}
function _bdMarkKeySuccess(index) {
  _bdBestKeyIndex = index;
  Object.assign(_bdKeyStatus[index], { failCount: 0, blockedUntil: 0 });
}
function _bdGetLiveKeys() {
  const now = Date.now();
  const order = Array.from({ length: BD_GEMINI_KEYS.length }, (_, i) =>
    (_bdBestKeyIndex + i) % BD_GEMINI_KEYS.length);
  let live = order.filter(i => _bdKeyStatus[i].blockedUntil <= now);
  if (!live.length) live = order.slice(0, 3);
  return live;
}

function compressBDImage(file, maxDim = 1400, quality = 0.85) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          const scale = maxDim / Math.max(width, height);
          width = Math.round(width * scale);
          height = Math.round(height * scale);
        }
        const canvas = document.createElement('canvas');
        canvas.width = width; canvas.height = height;
        canvas.getContext('2d').drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = () => reject(new Error('Image decode failed'));
      img.src = e.target.result;
    };
    reader.onerror = () => reject(new Error('File read failed'));
    reader.readAsDataURL(file);
  });
}

async function handleBDImage(file) {
  if (!file || !file.type.startsWith('image/')) return;
  if (file.size > BD_MAX_IMAGE_MB * 1024 * 1024) {
    alert(`Image too large. Please choose under ${BD_MAX_IMAGE_MB}MB.`);
    return;
  }
  try {
    bdSelectedImage = await compressBDImage(file);
    showBDPreview(bdSelectedImage);
  } catch (err) { alert('Failed to read image: ' + err.message); }
}

function handleBDImageSelect(event) {
  const file = event.target.files?.[0];
  if (file) handleBDImage(file);
  event.target.value = '';
}

function openBDCamera() { _elBD('bdCameraInput')?.click(); }
function openBDGallery() { _elBD('bdGalleryInput')?.click(); }
window.openBDCamera = openBDCamera;
window.openBDGallery = openBDGallery;

function showBDPreview(dataURL) {
  const preview = _elBD('bdPreview');
  const img = _elBD('bdPreviewImg');
  const imageField = _elBD('bdImageField');
  imageField?.classList.add('hidden');
  if (preview && img) { img.src = dataURL; preview.style.display = 'flex'; }
  const result = _elBD('bdResult');
  if (result) result.style.display = 'none';
  const loading = _elBD('bdLoading');
  if (loading) loading.style.display = 'none';
  preview?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function removeBDPreview() {
  bdSelectedImage = null;
  _elBD('bdPreview').style.display = 'none';
  _elBD('bdImageField')?.classList.remove('hidden');
  _elBD('bdResult').style.display = 'none';
  _elBD('bdLoading').style.display = 'none';
  ['bdCameraInput', 'bdGalleryInput'].forEach(id => {
    const el = _elBD(id);
    if (el) el.value = '';
  });
}
window.removeBDPreview = removeBDPreview;

function parseGeminiJSON(rawText) {
  let parsed;
  try { parsed = JSON.parse(rawText); }
  catch {
    const match = rawText.match(/\{[\s\S]*\}/);
    if (match) parsed = JSON.parse(match[0]);
    else throw new Error('Could not parse AI response');
  }
  if (window.DVLangGuard && parsed && typeof parsed === 'object') {
    const clean = obj => {
      if (typeof obj === 'string') return window.DVLangGuard.stripForeign(obj);
      if (Array.isArray(obj)) return obj.map(clean);
      if (obj && typeof obj === 'object') {
        const out = {};
        for (const k of Object.keys(obj)) out[k] = clean(obj[k]);
        return out;
      }
      return obj;
    };
    parsed = clean(parsed);
  }
  return parsed;
}

/* ============================================================
   Prompt — English only
   ============================================================ */
const BD_BREED_PROMPT = `You are an expert livestock & pet breed identification AI for DailyVet (Bangladesh).

STRICT: Reply ONLY in clean English. Do NOT use Bengali, Hindi, or any non-English script in any field. Return ONLY valid JSON. No markdown.

Analyze the attached image and identify the animal species, breed, origin, sex/gender, and health integrity.

Supported animals: Cattle (Cow/Bull/Ox/Calf), Buffalo, Goat (Black Bengal, Jamunapari, Boer, Sirohi, Crossbreed), Sheep, Chicken (Local Deshi, Broiler, Layer, Sonali), Duck, Pigeon, Horse, Dog, Cat, Rabbit.

STEP 1 — Species (GOAT vs COW critical):
- GOAT = smaller body, may have beard, straight/back-curving horns, short tail, narrow face
- COW = larger body, may have hump, larger horns, long tail with tuft, broad face
- NEVER default to "cow". Identify the actual species.

STEP 1B — Sex / Gender:
- Cattle → Bull (male) / Cow (female) / unknown
- Goat → Buck / Doe / unknown
- Buffalo → Male Buffalo / Female Buffalo / unknown
- Sheep → Ram / Ewe / unknown
- Dog → Male Dog / Female Dog / unknown
- Cat → Male Cat / Female Cat / unknown
- Chicken → Rooster / Hen / unknown
- Duck → Drake / Duck / unknown
- Pigeon → Male / Female / unknown
If sex cannot be determined → "unknown".

STEP 2 — Cattle breed rules (Cow/Bull/Ox):
- NEVER call a foreign or crossbreed cattle "Deshi"
- Black & white patches → Holstein Friesian → NOT Deshi
- Reddish-brown + big dewlap → Sahiwal → NOT Deshi
- Very large frame (>300 kg) → NOT pure Deshi
- "Deshi" requires: prominent hump + large dewlap + medium body + visible horns + solid coat
- When uncertain → "Crossbreed (Foreign X Local)" or "Uncertain"

STEP 3–10 — Goat / Buffalo / Sheep / Dog / Cat / Chicken / Duck / Pigeon: identify breed + origin (Local Deshi / Crossbreed / Foreign).

HEALTH INTEGRITY (ALL ANIMALS) — detect artificial fattening (steroids/hormones):
- Abnormal skin tautness and glossiness
- Severe water retention in thighs/muscles
- Dull eyes, lethargic posture
- Unnatural fat distribution

BUYING RECOMMENDATION:
- Healthy → shouldBuy: true
- Medium risk → shouldBuy: "caution"
- High risk → shouldBuy: false

Output JSON (RETURN ONLY VALID JSON):
{
  "status": "success",
  "timestamp": "2026-01-01T00:00:00Z",
  "species": "goat",
  "speciesEnglish": "Goat",
  "sex": "female",
  "sexEnglish": "Doe",
  "breedAnalysis": {
    "detectedBreed": "Black Bengal Goat",
    "originType": "Local Deshi",
    "confidenceScorePercentage": 92,
    "physicalTraitsObserved": {
      "bodyStructure": "Small compact body",
      "coatPattern": "Black coat with short hair",
      "hornShape": "Short backward-curved horns",
      "earType": "Short upright ears"
    }
  },
  "healthIntegrity": {
    "isArtificiallyFattened": false,
    "riskLevel": "Low",
    "detectedRedFlags": []
  },
  "buyingRecommendation": {
    "shouldBuy": true,
    "recommendation": "The animal appears normal and healthy. No signs of artificial fattening detected."
  },
  "verdict": "Animal identified: Local Deshi goat (Black Bengal), female (Doe). ...",
  "diyPhysicalVerificationGuide": ["...", "..."]
}

STRICT OUTPUT:
- "species" MUST be one of: cow, buffalo, goat, sheep, chicken, duck, pigeon, horse, dog, cat, rabbit, bird, unknown- "speciesEnglish" MUST be the English species name (e.g. "Goat")
- "sex" MUST be: male / female / unknown
- "sexEnglish" MUST be the species-specific English term (Bull/Cow, Buck/Doe, Rooster/Hen, etc.)
- ALL text fields MUST be in English.
- If NOT an animal: {"status": "error", "error": "Not an animal", "verdict": "No animal or bird detected in the image."}
- NEVER default to cow. Identify the actual species and sex.`;

/* ============================================================
   Vision call — English enforced
   ============================================================ */
async function _bdCallOne(apiKey, keyIndex, model, imageBase64, strictEnglish) {
  const url = `${BD_GEMINI_API_URL}/${model}:generateContent?key=${apiKey}`;
  const imageData = imageBase64.includes(',') ? imageBase64.split(',')[1] : imageBase64;
  const mimeType = imageBase64.includes('data:') ? imageBase64.split(';')[0].split(':')[1] : 'image/jpeg';

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), BD_PER_CALL_TIMEOUT_MS);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{
          role: 'user',
          parts: [
            { inline_data: { mime_type: mimeType, data: imageData } },
            { text: BD_BREED_PROMPT }
          ]
        }],
        generationConfig: {
          temperature: 0.15, maxOutputTokens: 1500, topP: 0.95,
          responseMimeType: 'application/json'
        }
      }),
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (!response.ok) {
      const status = response.status;
      const errBody = await response.text().catch(() => '');
      const errorType = status === 429 ? 'rate_limit'
        : (status === 401 || status === 403) ? 'invalid'
        : status === 404 ? 'model_gone'
        : (status === 400 && /api[_ ]key (?:not valid|invalid|expired)|API_KEY_INVALID/i.test(errBody)) ? 'invalid'
        : status >= 500 ? 'server' : 'network';
      return { success: false, errorType, status, keyIndex };
    }

    const data = await response.json();
    const rawText = (data.candidates?.[0]?.content?.parts || [])
      .filter(pt => pt && pt.text && !pt.thought).map(pt => pt.text).join('');
    if (!rawText) return { success: false, errorType: 'empty', keyIndex };

    if (window.DVLangGuard && !window.DVLangGuard.isEnglishEnough(rawText)) {
      if (!strictEnglish) return { success: false, errorType: 'badOutput', keyIndex };
    }

    const parsed = parseGeminiJSON(rawText);
    return { success: true, data: parsed, keyIndex };
  } catch (err) {
    clearTimeout(timeoutId);
    const errorType = err?.name === 'AbortError' ? 'timeout' : 'network';
    return { success: false, errorType, keyIndex };
  }
}

function _bdFallbackResult() {
  return {
    status: "success",
    species: "unknown",
    speciesEnglish: "Unknown",
    sex: "unknown",
    sexEnglish: "Unknown",
    breedAnalysis: {
      detectedBreed: "Unable to analyze", originType: "Unknown",
      confidenceScorePercentage: 15, physicalTraitsObserved: {}
    },
    healthIntegrity: { isArtificiallyFattened: false, riskLevel: "Medium", detectedRedFlags: [] },
    buyingRecommendation: {
      shouldBuy: "caution",
      recommendation: "Analysis incomplete due to network/API issues. Please try again or use a clearer photo."
    },
    verdict: "Animal identification incomplete due to network/API issues. Please try again.",
    diyPhysicalVerificationGuide: [
      "Take a clearer photo and scan again",
      "Make sure the full body of the animal is in the photo"
    ],
    _fallback: true
  };
}

async function callBreedGemini(imageBase64) {
  const liveKeys = _bdGetLiveKeys();
  const start = Date.now();

  for (let round = 1; round <= 3; round++) {
    const strictEnglish = round === 3;
    const remaining = BD_OVERALL_TIMEOUT_MS - (Date.now() - start);
    if (remaining < 800) break;

    if (round < 3) {
      const racePromises = [];
      const used = new Set();
      for (let k = 0; k < Math.min(2, liveKeys.length); k++) {
        const keyIdx = liveKeys[k];
        for (let m = 0; m < Math.min(2, BD_VISION_MODELS.length); m++) {
          const model = BD_VISION_MODELS[m];
          const id = `${keyIdx}-${model}`;
          if (used.has(id)) continue;
          used.add(id);
          racePromises.push(_bdCallOne(BD_GEMINI_KEYS[keyIdx], keyIdx, model, imageBase64, false).then(r => ({ ...r, model })));
        }
      }
      const timeoutPromise = new Promise(resolve => setTimeout(() => resolve({ success: false, errorType: 'overall_timeout' }), remaining));
      const firstResult = await Promise.race([
        Promise.any(racePromises.map(p => p.then(r => { if (r.success) return r; throw r; })))
          .catch(() => ({ success: false, errorType: 'all_race_failed' })),
        timeoutPromise
      ]);
      if (firstResult && firstResult.success) {
        _bdMarkKeySuccess(firstResult.keyIndex);
        return firstResult.data;
      }
      /* Gemini failed in round 1 -> Groq / OpenRouter fallback right away */
      if (round === 1) {
        const alt = await _bdAltFallback(imageBase64, BD_BREED_PROMPT, BD_OVERALL_TIMEOUT_MS - (Date.now() - start));
        if (alt) return alt;
      }
      if (round === 2) {
        for (const keyIdx of liveKeys) {
          for (const model of BD_VISION_MODELS) {
            if (Date.now() - start > BD_OVERALL_TIMEOUT_MS - 800) break;
            const result = await _bdCallOne(BD_GEMINI_KEYS[keyIdx], keyIdx, model, imageBase64, false);
            if (result.success) { _bdMarkKeySuccess(keyIdx); return result.data; }
            if (result.errorType === 'model_gone') continue;
            if (['rate_limit', 'invalid', 'timeout', 'network', 'badOutput'].includes(result.errorType)) {
              _bdMarkKeyFailed(keyIdx, result.errorType);
              break;
            }
          }
        }
      } else {
        await _bdSleep(500);
      }
    } else {
      for (const keyIdx of liveKeys) {
        if (Date.now() - start > BD_OVERALL_TIMEOUT_MS - 500) break;
        const result = await _bdCallOne(BD_GEMINI_KEYS[keyIdx], keyIdx, BD_VISION_MODELS[0], imageBase64, true);
        if (result.success) { _bdMarkKeySuccess(keyIdx); return result.data; }
      }
    }
  }
  return _bdFallbackResult();
}

/* ============================================================
   Species English map
   ============================================================ */
const SPECIES_EN = {
  cow: 'Cow', buffalo: 'Buffalo', goat: 'Goat', sheep: 'Sheep',
  chicken: 'Chicken', duck: 'Duck', pigeon: 'Pigeon', horse: 'Horse',
  dog: 'Dog', cat: 'Cat', rabbit: 'Rabbit', bird: 'Bird',
  fish: 'Fish', unknown: 'Unknown'
};

const TRAIT_LABELS = {
  humpSize: '🐂 Hump', dewlapStatus: '🦴 Dewlap', bodyStructure: '📐 Body',
  coatPattern: '🎨 Coat', hornShape: '🦄 Horns', earType: '👂 Ears'
};

/* ============================================================
   Render
   ============================================================ */
function renderBreedResult(data) {
  const resultEl = _elBD('bdResult');
  if (!resultEl) return;
  const userImageHTML = bdSelectedImage
    ? `<div class="bd-result-image"><img src="${bdSelectedImage}" alt="Analyzed Animal" /></div>` : '';

  if (data.status === 'error' || data.error) {
    resultEl.innerHTML = `
      ${userImageHTML}
      <div class="bd-result-error">
        <i class="fas fa-exclamation-triangle"></i>
        <h3>Could Not Detect</h3>
        <p>${escapeHtmlBD(data.error || data.verdict || 'Please try a clearer photo.')}</p>
      </div>`;
    resultEl.style.display = 'flex';
    return;
  }

  const ba = data.breedAnalysis || {};
  const hi = data.healthIntegrity || {};
  const buying = data.buyingRecommendation || {};
  const traits = ba.physicalTraitsObserved || {};
  const species = (data.species || 'unknown').toLowerCase();
  const speciesEn = data.speciesEnglish || SPECIES_EN[species] || 'Unknown';
  const sex = (data.sex || 'unknown').toLowerCase();
  const sexEn = data.sexEnglish || (sex === 'male' ? 'Male' : sex === 'female' ? 'Female' : 'Unknown');
  const sexIcon = sex === 'male' ? '♂️' : sex === 'female' ? '♀️' : '❔';

  const riskLevel = (hi.riskLevel || 'Low').toLowerCase();
  const riskColor = riskLevel === 'high' ? '#dc2626' : riskLevel === 'medium' ? '#d97706' : '#10b981';
  const riskBg = riskLevel === 'high' ? '#fef2f2' : riskLevel === 'medium' ? '#fef9e7' : '#f0fdf4';
  const riskBorder = riskLevel === 'high' ? '#fecaca' : riskLevel === 'medium' ? '#fcd34d' : '#86efac';

  const confidence = ba.confidenceScorePercentage || 0;
  const confColor = confidence >= 80 ? '#10b981' : confidence >= 60 ? '#d97706' : '#dc2626';

  const originText = (ba.originType || '').toLowerCase();
  const originBadgeClass = originText.includes('foreign') ? 'bd-origin-foreign'
    : originText.includes('cross') ? 'bd-origin-cross' : 'bd-origin-local';

  const shouldBuy = buying.shouldBuy;
  let riskBanner = '';
  if (shouldBuy === true) {
    riskBanner = `<div class="bd-safe-banner"><i class="fas fa-circle-check"></i><div><strong>✅ Suitable to buy</strong><p>${escapeHtmlBD(buying.recommendation || 'The animal appears normal and healthy.')}</p></div></div>`;
  } else if (shouldBuy === 'caution' || riskLevel === 'medium') {
    riskBanner = `<div class="bd-caution-banner"><i class="fas fa-triangle-exclamation"></i><div><strong>⚠️ Can be bought with caution</strong><p>${escapeHtmlBD(buying.recommendation || 'Some caution signs present. Consult a veterinarian before buying.')}</p></div></div>`;
  } else if (shouldBuy === false || hi.isArtificiallyFattened || riskLevel === 'high') {
    riskBanner = `<div class="bd-risk-banner"><i class="fas fa-triangle-exclamation"></i><div><strong>🚨 HIGH RISK — Not recommended to buy</strong><p>${escapeHtmlBD(buying.recommendation || 'Suspected artificial fattening. Consult a veterinarian.')}</p></div></div>`;
  }

  const traitsHTML = Object.entries(traits)
    .filter(([val]) => val)
    .map(([key, val]) => `<div class="bd-trait-row"><span class="bd-trait-label">${TRAIT_LABELS[key] || '•'}</span><span class="bd-trait-value">${escapeHtmlBD(val)}</span></div>`)
    .join('');

  const redFlagsHTML = Array.isArray(hi.detectedRedFlags) && hi.detectedRedFlags.length
    ? `<div class="bd-section bd-red-flags-section"><div class="bd-section-label">🚩 Detected Red Flags</div><ul class="bd-red-flags">${hi.detectedRedFlags.map(f => `<li>${escapeHtmlBD(f)}</li>`).join('')}</ul></div>` : '';

  const diyHTML = Array.isArray(data.diyPhysicalVerificationGuide) && data.diyPhysicalVerificationGuide.length
    ? `<div class="bd-section bd-diy-section"><div class="bd-section-label">🔍 DIY Verification Guide</div><ol class="bd-diy-list">${data.diyPhysicalVerificationGuide.map(step => `<li>${escapeHtmlBD(step)}</li>`).join('')}</ol></div>` : '';

  const healthStatusText = hi.isArtificiallyFattened ? '⚠️ YES (Detected)' : '✅ NO (Natural & Healthy)';
  const fallbackNotice = data._fallback
    ? `<div style="margin:12px 0;padding:12px;background:#fef3c7;border-radius:12px;font-size:13px;color:#92400e;border:1px solid #fcd34d;">⚠️ Analysis incomplete due to API issues. Please try again or use a clearer photo.</div>` : '';

  resultEl.innerHTML = `
    ${riskBanner}
    ${userImageHTML}
    ${fallbackNotice}

    <div class="bd-result-header">
      <i class="fas fa-check-circle" style="color:${confColor};"></i>
      <h3>${data._fallback ? 'Scan Incomplete' : 'Analysis Complete'}</h3>
    </div>

    <div class="bd-section bd-breed-section">
      <div class="bd-section-label">🐾 Identified Animal</div>
      <div class="bd-species-name">${escapeHtmlBD(speciesEn)}</div>
      <div class="bd-sex-badge" style="margin:6px 0 8px;font-size:15px;font-weight:600;">${sexIcon} Sex: ${escapeHtmlBD(sexEn)}</div>
      <div class="bd-breed-name">${escapeHtmlBD(ba.detectedBreed || 'Unknown')}</div>
      <div class="bd-origin-badge ${originBadgeClass}"><i class="fas fa-location-dot"></i> ${escapeHtmlBD(ba.originType || 'Unknown Origin')}</div>
      <div class="bd-confidence">
        <span>Confidence</span>
        <div class="bd-confidence-bar"><div class="bd-confidence-fill" style="width:${confidence}%;background:${confColor};"></div></div>
        <strong style="color:${confColor};">${confidence}%</strong>
      </div>
    </div>

    ${traitsHTML ? `<div class="bd-section"><div class="bd-section-label">📊 Physical Traits Observed</div><div class="bd-traits">${traitsHTML}</div></div>` : ''}

    <div class="bd-section bd-health-section" style="background:${riskBg};border-color:${riskBorder};">
      <div class="bd-section-label" style="color:${riskColor};">🩺 Health Integrity Check</div>
      <div class="bd-health-status"><span>Artificial fattening:</span><strong style="color:${riskColor};">${healthStatusText}</strong></div>
      <div class="bd-health-status"><span>Risk Level:</span><strong style="color:${riskColor};">${escapeHtmlBD(hi.riskLevel || 'Low').toUpperCase()}</strong></div>
    </div>

    ${redFlagsHTML}

    ${data.verdict ? `<div class="bd-section bd-verdict-section"><div class="bd-section-label">📋 Summary</div><div class="bd-verdict-text">${escapeHtmlBD(data.verdict)}</div></div>` : ''}

    ${diyHTML}

    <div class="bd-result-actions">
      <button type="button" class="bd-rescan-btn" onclick="rescanBreed()">
        <i class="fas fa-redo"></i> Scan Again
      </button>
    </div>`;
  resultEl.style.display = 'flex';
  resultEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function saveBreedScan(scanData) {
  if (!bdCurrentPhone || scanData._fallback) return;
  try {
    await _fsBD().collection('users').doc(bdCurrentPhone).collection('breed_history').add({
      ...scanData, user_phone: bdCurrentPhone,
      scanned_at: firebase.firestore.FieldValue.serverTimestamp(),
      scanned_at_ms: Date.now()
    });
  } catch (err) { console.warn('Breed save failed:', err.message); }
}

async function startBreedScan() {
  if (!bdSelectedImage) return alert('Please select or take a photo first.');
  if (!bdCurrentPhone) { alert('Please login first.'); window.location.href = 'login.html'; return; }

  const scanBtn = _elBD('bdScanBtn');
  const preview = _elBD('bdPreview');
  const loading = _elBD('bdLoading');
  const result = _elBD('bdResult');

  scanBtn.disabled = true;
  preview.style.display = 'none';
  result.style.display = 'none';
  loading.style.display = 'flex';

  try {
    const scanData = await callBreedGemini(bdSelectedImage);
    loading.style.display = 'none';
    renderBreedResult(scanData);
    if (scanData.status !== 'error' && !scanData._fallback) saveBreedScan(scanData);
  } catch (err) {
    console.error('Scan error:', err);
    loading.style.display = 'none';
    renderBreedResult(_bdFallbackResult());
  } finally {
    scanBtn.disabled = false;
  }
}
window.startBreedScan = startBreedScan;

function rescanBreed() {
  if (!bdSelectedImage) return;
  showBDPreview(bdSelectedImage);
}
window.rescanBreed = rescanBreed;

/* Init */
document.addEventListener('DOMContentLoaded', () => {
  bdCurrentPhone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
  if (!bdCurrentPhone) { window.location.href = 'login.html'; return; }

  ['bdCameraInput', 'bdGalleryInput'].forEach(id => {
    _elBD(id)?.addEventListener('change', handleBDImageSelect);
  });

  const imageField = _elBD('bdImageField');
  if (imageField) {
    imageField.addEventListener('click', openBDGallery);
    imageField.addEventListener('dragover', (e) => {
      e.preventDefault(); e.stopPropagation();
      imageField.classList.add('bd-dragover');
    });
    imageField.addEventListener('dragleave', (e) => {
      e.preventDefault(); e.stopPropagation();
      imageField.classList.remove('bd-dragover');
    });
    imageField.addEventListener('drop', (e) => {
      e.preventDefault(); e.stopPropagation();
      imageField.classList.remove('bd-dragover');
      const imgFile = Array.from(e.dataTransfer?.files || []).find(f => f.type.startsWith('image/'));
      if (imgFile) handleBDImage(imgFile);
    });
  }

  document.addEventListener('paste', (e) => {
    const imageItem = Array.from(e.clipboardData?.items || []).find(i => i.type.indexOf('image') !== -1);
    if (!imageItem) return;
    const file = imageItem.getAsFile();
    if (!file) return;
    e.preventDefault();
    handleBDImage(file);
  });

  console.log('✅ Breed Detection v3.5 ready (English only)');
});

window.BDDebug = {
  status() {
    console.table(_bdKeyStatus.map((s, i) => ({
      key: '#' + (i + 1),
      blockedFor_s: Math.max(0, Math.round((s.blockedUntil - Date.now()) / 1000)),
      failCount: s.failCount,
      best: i === _bdBestKeyIndex ? '⭐' : ''
    })));
  },
  reset() {
    _bdKeyStatus.forEach(s => Object.assign(s, { blockedUntil: 0, failCount: 0 }));
    console.log('♻️ BD keys reset');
  }
};