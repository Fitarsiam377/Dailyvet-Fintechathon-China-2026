/* ============================================================
   DailyVet — Parametric Claim Verification v4.2 (Real-time AI + Fast Fallback)
   ✅ AI Vision verifies the image (animal + sick condition)
   ✅ Real-time AI Chat (Groq + Gemini Hedged Fallback)
   ✅ Guaranteed reply in 2-4 seconds (Hard Timeout)
   ✅ Handles Conversational Assistant
   ============================================================ */

let selectedClaimImage = null;
let currentPolicy = null;
let fetchedTriggers = [];
let isDataReady = false;
let isImageVerified = false;
let activeMapRiskData = null;
let chatBusy = false;

// 🆕 Chat History for AI Context
let chatHistory = [];

const _elClaim = id => document.getElementById(id);

/* ============================================================
   AI VISION & CHAT CONFIG
   ============================================================ */
const CLAIM_GEMINI_KEYS = [
  _dvDec('QVEuQWI4Uk42SlVSbzZHTS1lck9BX0d6UVRJcml4MzRtUkhfd3doN01pM01janF1dVdmMGc='),
  _dvDec('QVEuQWI4Uk42S19GWW5PS0xPdFlRX21lLWlrcU1ybzE5aXpRQ0VROTFwNTB1cUNqaGM5Vnc='),
  _dvDec('QVEuQWI4Uk42TE9uRUpOTncxWm51ZGJhV3RpVHdsTXhJSUwyWXptalFjaFJib3RSRWUxQnc=')
];
const CLAIM_GROQ_KEYS = [_dvDec('Z3NrX3o4QkRyYldCbXlhS2l6M3BiVnZRV0dkeWIzRlk1R25haDNrQVptQm1xRUF2a2ZLMTZmd1M=')];

// 🆕 Your requested models list
const CLAIM_VISION_MODELS = [
    'gemini-3.5-flash-lite',
    'gemini-3.1-flash-lite',
    'gemini-2.5-flash-lite',
    'gemini-3.8-flash',
    'gemini-3.6-flash',
    'gemini-2.5-flash'
];

const CLAIM_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
const CLAIM_GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions';

document.addEventListener('DOMContentLoaded', async () => {
    const phone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
    if (!phone) return window.location.href = 'login.html';

    initChatAssistant();

    try {
        const policies = await loadActivePolicies();
        if (policies && policies.length > 0) {
            currentPolicy = policies[0];
            const dName = currentPolicy.districtName || currentPolicy.district || 'dhaka';
            const distEl = _elClaim('verifyDistrict');
            if (distEl) distEl.textContent = ((currentPolicy.area ? currentPolicy.area + ', ' : '') + String(dName).toUpperCase());
            preFetchTriggerData(currentPolicy);
        } else {
            alert('No active policy found. Please buy a policy first.');
            window.location.href = 'insurance-policy.html';
        }
    } catch (err) {
        console.error('Policy load failed:', err);
    }
});

/* ============================================================
   FRAUD DETECTION: AI VISION (With Fast Parallel Race)
   ============================================================ */
async function analyzeClaimImage(base64) {
    const zone = _elClaim('uploadZone');
    const resBox = _elClaim('aiVisionResult');
    
    zone.classList.add('analyzing');
    resBox.style.display = 'none';
    isImageVerified = false;
    checkReadyToSubmit();

    _chatAppend('assistant', "⏳ Please wait, I'm analyzing your photo to verify if it's a real livestock animal in distress...");

    const prompt = `You are an insurance fraud detection AI. Analyze this claim photo.
RULES:
1. Must be a livestock animal (cow, goat, sheep, buffalo, chicken, duck).
2. Must show signs of distress (sick, lying down, injured, in floodwater, heat stress).
3. If it's a human, object, or a perfectly healthy animal in a clean shed, reject it.
Return ONLY JSON: {"valid": true/false, "reason": "Short explanation", "condition": "sick/flooded/healthy/fake"}`;

    let success = false;
    let errorMsg = 'AI service unavailable. Manual review needed.';

    try {
        // Fire the top 3 models simultaneously to get the fastest reply
        const promises = CLAIM_VISION_MODELS.slice(0, 3).map(model => 
            fetch(`${CLAIM_API_URL}/${model}:generateContent?key=${CLAIM_GEMINI_KEYS[0]}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{
                        role: 'user',
                        parts: [{ inline_data: { mime_type: 'image/jpeg', data: base64.split(',')[1] } }, { text: prompt }]
                    }],
                    generationConfig: { temperature: 0.1, responseMimeType: 'application/json' }
                })
            }).then(async res => {
                if (!res.ok) throw new Error('API Error');
                const data = await res.json();
                const raw = (data.candidates?.[0]?.content?.parts || []).find(p => p.text)?.text;
                if (!raw) throw new Error('No text');
                return JSON.parse(raw.replace(/```json/gi, '').replace(/```/g, '').trim());
            })
        );

        // Wait for the FIRST successful response
        const parsed = await Promise.any(promises);

        if (parsed.valid === true) {
            isImageVerified = true;
            resBox.style.display = 'block';
            resBox.style.background = '#ECFDF5';
            resBox.style.color = '#047857';
            resBox.style.border = '1px solid #86efac';
            resBox.innerHTML = `<i class="fas fa-check-circle"></i> AI Verified: ${parsed.reason}`;
            _chatAppend('assistant', `✅ **Image Verified:** ${parsed.reason}. The claim process can continue.`);
        } else {
            isImageVerified = false;
            resBox.style.display = 'block';
            resBox.style.background = '#FEF2F2';
            resBox.style.color = '#B91C1C';
            resBox.style.border = '1px solid #fecaca';
            resBox.innerHTML = `<i class="fas fa-times-circle"></i> Fraud Detected: ${parsed.reason}`;
            _chatAppend('assistant', `❌ **Verification Failed:** ${parsed.reason}. Please upload a valid photo of your distressed animal.`);
        }
        success = true;
    } catch (e) {
        console.warn('AI vision race failed:', e);
    }

    if (!success) {
        resBox.style.display = 'block';
        resBox.style.background = '#FFFBEB';
        resBox.style.color = '#B45309';
        resBox.style.border = '1px solid #fde68a';
        resBox.innerHTML = `<i class="fas fa-triangle-exclamation"></i> ${errorMsg}`;
        _chatAppend('assistant', "⚠️ I couldn't verify the image right now due to a connection issue. Moving to manual review.");
        isImageVerified = true; 
    }

    zone.classList.remove('analyzing');
    checkReadyToSubmit();
}

/* ============================================================
   IMAGE HANDLING
   ============================================================ */
function handleClaimImage(event) {
    const file = event.target.files[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
        alert('Image is too large. Max 5MB.');
        event.target.value = '';
        return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
        selectedClaimImage = e.target.result;
        const zone = _elClaim('uploadZone');
        const img = _elClaim('claimPreviewImg');
        const removeBtn = _elClaim('removeImgBtn');
        
        zone.classList.add('has-image');
        img.src = selectedClaimImage;
        img.style.display = 'block';
        removeBtn.style.display = 'block';
        zone.querySelector('.ic-upload-icon').style.display = 'none';
        zone.querySelector('.ic-upload-text').style.display = 'none';
        zone.querySelector('.ic-upload-sub').style.display = 'none';

        await analyzeClaimImage(selectedClaimImage);
        _chatAutoAdvanceOnPhoto();
    };
    reader.readAsDataURL(file);
}

function removeClaimImage(e) {
    if (e) e.stopPropagation();
    selectedClaimImage = null;
    isImageVerified = false;
    checkReadyToSubmit();

    const zone = _elClaim('uploadZone');
    const img = _elClaim('claimPreviewImg');
    const removeBtn = _elClaim('removeImgBtn');
    const input = _elClaim('claimImageInput');
    const resBox = _elClaim('aiVisionResult');

    zone.classList.remove('has-image');
    img.src = '';
    img.style.display = 'none';
    removeBtn.style.display = 'none';
    resBox.style.display = 'none';
    
    zone.querySelector('.ic-upload-icon').style.display = 'block';
    zone.querySelector('.ic-upload-text').style.display = 'block';
    zone.querySelector('.ic-upload-sub').style.display = 'block';
    if (input) input.value = '';
}

/* ============================================================
   VERIFICATION & CLAIM
   ============================================================ */
async function preFetchTriggerData(policy) {
    const district = policy.district || 'dhaka';
    const animal = policy.animalType || 'cow';
    const badge = _elClaim('verifyStatusBadge');
    badge.textContent = 'Checking...';

    try {
        const result = await detectTriggers(district, animal, policy.lat, policy.lng);
        fetchedTriggers = Array.isArray(result?.triggers) ? result.triggers : [];
        isDataReady = true;

        const count = fetchedTriggers.length;
        badge.textContent = count > 0 ? `${count} Trigger(s)` : 'No Trigger';
        badge.style.background = count > 0 ? '#FEE2E2' : '#F1F5F9';
        badge.style.color = count > 0 ? '#DC2626' : '#64748B';

        const riskData = await fetchLiveRiskData(district, policy.lat, policy.lng);
        _elClaim('verifyThi').textContent = `THI ${riskData.heat?.thi || 0}`;
        _elClaim('verifyFlood').textContent = `${riskData.flood?.score || 0}%`;
        
        checkReadyToSubmit();
        _chatAutoAdvanceOnTrigger();
    } catch (err) { console.error(err); }
}

function checkReadyToSubmit() {
    const btn = _elClaim('btnSubmitClaim');
    if (btn) btn.disabled = !(selectedClaimImage && isImageVerified && isDataReady);
}

async function processClaim() {
    if (!selectedClaimImage || !currentPolicy || !isImageVerified) return alert('Please upload a valid image.');
    
    const btn = _elClaim('btnSubmitClaim');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Processing...';
    btn.disabled = true;

    _chatAppend('assistant', "⏳ Processing your claim in the database...");

    try {
        if (fetchedTriggers.length === 0) throw new Error('No weather trigger detected.');
        const topTrigger = [...fetchedTriggers].sort((a, b) => b.payout - a.payout)[0];
        const claimResult = await fileClaim(currentPolicy.id, topTrigger);
        if (!claimResult) throw new Error('Database error');
        
        showInvoice(topTrigger, claimResult);
        _chatAppend('assistant', `🎉 **Claim Approved!** You have received ৳${topTrigger.payout.toLocaleString('en-IN')} for ${topTrigger.label}. Please check the invoice.`);
    } catch (err) {
        alert('❌ ' + err.message);
        _chatAppend('assistant', `❌ **Failed:** ${err.message}`);
        btn.innerHTML = '<i class="fas fa-check-circle"></i> Verify & Process Claim';
        btn.disabled = false;
    }
}

function showInvoice(trigger, claim) {
    _elClaim('uploadCard').style.display = 'none';
    document.querySelectorAll('.ic-card')[1].style.display = 'none';
    _elClaim('invoicePayoutAmount').textContent = `৳ ${trigger.payout.toLocaleString('en-IN')}`;
    _elClaim('invoiceTotal').textContent = `৳ ${trigger.payout.toLocaleString('en-IN')}`;
    _elClaim('invoiceNo').textContent = 'INV-' + Date.now().toString().slice(-6);
    _elClaim('invoiceDate').textContent = new Date().toLocaleDateString('en-GB');
    _elClaim('invoiceTrigger').textContent = trigger.label;
    _elClaim('invoiceEvidence').textContent = trigger.evidence;
    _elClaim('invoiceSection').style.display = 'block';
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function forceDemoClaim() {
    if (!selectedClaimImage) return alert('Upload an image first.');
    const topTrigger = { label: 'Flood (Simulated)', payout: 1200, evidence: 'Demo trigger' };
    const claimResult = await fileClaim(currentPolicy.id, topTrigger);
    showInvoice(topTrigger, claimResult);
}

/* ============================================================
   CHAT & MAP (Real-time AI + Hedged Fallback)
   ============================================================ */
window.onClaimLocationChange = async function (payload) {
    if (!payload || !payload.districtKey) return;
    _elClaim('verifyDistrict').textContent = ((payload.area ? payload.area + ', ' : '') + payload.districtName).toUpperCase();
    
    try {
        const result = await detectTriggers(payload.districtKey, 'cow', payload.hasArea ? payload.lat : undefined, payload.hasArea ? payload.lng : undefined);
        const tempTriggers = Array.isArray(result?.triggers) ? result.triggers : [];
        const badge = _elClaim('verifyStatusBadge');
        badge.textContent = tempTriggers.length > 0 ? `${tempTriggers.length} Trigger(s)` : 'No Trigger';
        badge.style.background = tempTriggers.length > 0 ? '#FEE2E2' : '#F1F5F9';
        badge.style.color = tempTriggers.length > 0 ? '#DC2626' : '#64748B';
    } catch(e){}
};

function initChatAssistant() {
    _elClaim('claimChatForm').addEventListener('submit', (e) => {
        e.preventDefault();
        const input = _elClaim('claimChatInput');
        if (input.value.trim()) { handleChatMessage(input.value.trim()); input.value = ''; }
    });
    _elClaim('claimChatQuick').addEventListener('click', (e) => {
        const btn = e.target.closest('[data-msg]');
        if (btn) handleChatMessage(btn.dataset.msg);
    });
    _chatAppend('assistant', "Hello! I'm your AI Claim Assistant. If your animal is sick or affected by weather, upload a proof photo on the right and I'll help you process the claim.");
}

function _chatAppend(role, text) {
    const log = _elClaim('claimChatLog');
    const wrapper = document.createElement('div');
    wrapper.className = `ic-chat-msg ${role}`;
    
    // Convert markdown-style bold (**text**) to HTML
    const formattedText = text.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

    wrapper.innerHTML = `
        <div class="ic-chat-avatar"><i class="fas ${role === 'user' ? 'fa-user' : 'fa-robot'}"></i></div>
        <div class="ic-chat-bubble">${formattedText}</div>`;
    log.appendChild(wrapper); 
    log.scrollTop = log.scrollHeight;
}

// 🆕 FAST REAL-TIME AI WITH HEDGED FALLBACK & TIMEOUT
async function handleChatMessage(text) {
    if (chatBusy) return;
    _chatAppend('user', text);
    
    chatHistory.push({ role: 'user', content: text });
    if (chatHistory.length > 6) chatHistory.shift();

    _elClaim('claimChatTyping').style.display = 'flex';
    chatBusy = true;

    const systemPrompt = `You are the DailyVet Parametric Insurance Claim Assistant. 
Your goal is to help farmers file claims for their livestock (cow, goat, chicken, etc.) when weather triggers (Flood, Heat Stress, Drought) occur.
Current policy status: ${currentPolicy ? 'Active for ' + currentPolicy.animalType + ' in ' + (currentPolicy.district || 'Dhaka') : 'No active policy'}.
If the user says their animal is sick or affected by weather, tell them to click "Upload Proof Photo" on the right side.
Be empathetic, concise, and reply in English. Do not provide medical advice, only claim guidance.`;

    let reply = "";
    let isDone = false;

    // HARD TIMEOUT: Guarantee a reply in 4 seconds max
    const timeoutTimer = setTimeout(() => {
        if (!isDone) {
            isDone = true;
            _elClaim('claimChatTyping').style.display = 'none';
            _chatAppend('assistant', "I am experiencing a slight delay with the network. Please go ahead and **Upload a Proof Photo** on the right. Once uploaded, my vision system will verify it instantly.");
            chatBusy = false;
        }
    }, 4000); // 4 seconds hard limit

    // Helper function to fetch from Gemini
    const fetchGemini = async (modelIndex) => {
        if (modelIndex >= CLAIM_VISION_MODELS.length) throw new Error('All models failed');
        const model = CLAIM_VISION_MODELS[modelIndex];
        const key = CLAIM_GEMINI_KEYS[0];
        
        const res = await fetch(`${CLAIM_API_URL}/${model}:generateContent?key=${key}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                contents: [{ role: 'user', parts: [{ text: systemPrompt + "\n\nUser: " + text }] }],
                generationConfig: { temperature: 0.5, maxOutputTokens: 250 }
            })
        });
        
        if (!res.ok) throw new Error('API Error');
        const data = await res.json();
        const txt = data.candidates?.[0]?.content?.parts?.[0]?.text;
        if (!txt) throw new Error('No text');
        return txt;
    };

    try {
        // We fire Groq AND Gemini at the same time. Whichever replies first wins!
        const groqPromise = fetch(CLAIM_GROQ_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${CLAIM_GROQ_KEYS[0]}` },
            body: JSON.stringify({
                model: 'llama-3.3-70b-versatile',
                messages: [{ role: 'system', content: systemPrompt }, ...chatHistory],
                temperature: 0.5,
                max_tokens: 200
            })
        }).then(async res => {
            if (!res.ok) throw new Error('Groq Error');
            const data = await res.json();
            return data.choices[0].message.content;
        });

        // Gemini try 1
        const geminiPromise = fetchGemini(0);

        // Promise.any waits for the FIRST successful promise
        reply = await Promise.any([groqPromise, geminiPromise]);

    } catch (err) {
        // If both the first Groq and first Gemini fail, try the 2nd Gemini model
        try {
            reply = await fetchGemini(1);
        } catch (e2) {
            reply = "I couldn't reach the AI right now. Please upload a photo to continue.";
        }
    }

    if (!isDone) {
        isDone = true;
        clearTimeout(timeoutTimer);
        _elClaim('claimChatTyping').style.display = 'none';
        _chatAppend('assistant', reply);
        chatHistory.push({ role: 'assistant', content: reply });
        chatBusy = false;
    }
}

function _chatAutoAdvanceOnPhoto() {
    if (isImageVerified && fetchedTriggers.length > 0) {
        _chatAppend('assistant', "✅ Image is valid and weather triggers are detected. You can now click the **Verify & Process Claim** button to get your payout.");
    }
}

function _chatAutoAdvanceOnTrigger() {
    // Optional: You can add an automatic message here when triggers load
}
