/* DailyVet — NASA Outbreak & Vector Risk Engine v3.0
   Inputs (NASA POWER): PRECTOTCORR (rain mm/day), RH2M (%), T2M (°C),
                        GWETTOP/GWETROOT (soil moisture), + rain7dayMm
   Overall score (0–100): rain max +40, humidity max +25, temperature max +20
   Levels: >=70 critical | >=50 alert | >=30 watch | <30 safe
   Disease data: Bangladesh DLS + FAO EMPRES-i patterns + BD field studies

   v3.0 additions:
   • calculateDiseaseRisks() now accepts rain7dayMm & soilMoisture
   • DISTRICT_PRIORS — Bangladesh-specific disease baseline per district
   • FMD rain lag logic (7-14 days after flood)
   • Anthrax soil moisture trigger (saturated soil + warm temp)
   • Newcastle (Ranikhet) seasonal boost (rainy season OR=3.9 per BD study)
   • LSD climate correlation aligned with BD 2020-2023 study [citation:15]
*/
(function () {
'use strict';

/* ===== START: DISEASE LIBRARY ===== */
const DISEASE_LIBRARY = {
    lsd: {
        nameEn: 'Lumpy Skin Disease (LSD)',
        nameBn: 'Lumpy Skin Disease', abbr: 'LSD',
        animals: ['Cow', 'Buffalo'],
        vector: 'mosquito', vectorBn: 'Mosquito & Fly',
        tempRange: [25, 32], rainThreshold: 30, humidityMin: 70,
        riskBoost: 15,
        adviceBn: 'Keep livestock under mosquito nets. Clear standing water around the farm.',
        economicImpactPerHead: 80000,
        /* Bangladesh 2020-2023 study: positive correlation with rainfall, humidity, min temp.
           Monsoon (May-Nov) peak [citation:15] */
        rain7dayBonus: 5,
        humidityBonus: 8
    },
    fmd: {
        nameEn: 'Foot & Mouth Disease (FMD)',
        nameBn: 'Foot & Mouth Disease', abbr: 'FMD',
        animals: ['Cow', 'Goat', 'Buffalo', 'Sheep'],
        vector: 'water', vectorBn: 'Contaminated Water & Mud',
        tempRange: [20, 30], rainThreshold: 50, humidityMin: 75,
        riskBoost: 12,
        adviceBn: 'Keep hooves dry. Wash hooves with 1% potassium permanganate.',
        economicImpactPerHead: 60000,
        /* FMD risk peaks 7-14 days AFTER a flood event (contaminated water/mud).
           Direct rain alone does not raise risk immediately. */
        rainLagDays: 10,
        rainLagBonus: 12,
        soilMoistureThreshold: 0.65
    },
    ppr: {
        nameEn: 'PPR (Peste des Petits Ruminants)',
        nameBn: 'PPR', abbr: 'PPR',
        animals: ['Goat', 'Sheep'],
        vector: 'contact', vectorBn: 'Direct Contact',
        tempRange: [22, 32], rainThreshold: 40, humidityMin: 70,
        riskBoost: 10,
        adviceBn: 'Isolate infected goats. Vaccinate healthy goats with PPR vaccine.',
        economicImpactPerHead: 12000
    },
    ranikhet: {
        nameEn: 'Ranikhet (Newcastle Disease)',
        nameBn: 'Ranikhet', abbr: 'Ranikhet',
        animals: ['Chicken', 'Duck', 'Pigeon'],
        vector: 'air', vectorBn: 'Air & Contaminated Feed',
        tempRange: [20, 35], rainThreshold: 35, humidityMin: 65,
        riskBoost: 15,
        adviceBn: 'Keep poultry sheds dry. Vaccinate healthy birds with BCRDV.',
        economicImpactPerHead: 400,
        /* Bangladesh Sonali study: rainy season OR=3.9 vs winter, humid OR=2.6 [citation:4] */
        rainySeasonBonus: 10,
        highHumidityBonus: 6
    },
    coccidiosis: {
        nameEn: 'Coccidiosis',
        nameBn: 'Coccidiosis', abbr: 'Coccidiosis',
        animals: ['Chicken', 'Duck', 'Goat', 'Rabbit'],
        vector: 'water', vectorBn: 'Wet Litter & Contaminated Water',
        tempRange: [22, 30], rainThreshold: 30, humidityMin: 75,
        riskBoost: 18,
        adviceBn: 'Keep poultry litter dry. Use anticoccidial medicine as advised by a vet.',
        economicImpactPerHead: 400
    },
    mastitis: {
        nameEn: 'Mastitis',
        nameBn: 'Mastitis', abbr: 'Mastitis',
        animals: ['Cow', 'Buffalo', 'Goat'],
        vector: 'environment', vectorBn: 'Wet & Dirty Environment',
        tempRange: [15, 32], rainThreshold: 40, humidityMin: 80,
        riskBoost: 10,
        adviceBn: 'Clean udders before and after milking. Keep cattle sheds dry.',
        economicImpactPerHead: 45000
    },
    anthrax: {
        nameEn: 'Anthrax',
        nameBn: 'Anthrax', abbr: 'Anthrax',
        animals: ['Cow', 'Goat', 'Sheep', 'Buffalo'],
        vector: 'environment', vectorBn: 'Soil & Contaminated Feed',
        tempRange: [25, 37], rainThreshold: 25, humidityMin: 60,
        riskBoost: 8,
        adviceBn: 'Do not open carcass. Vaccinate annually. Avoid grazing in known outbreak areas.',
        economicImpactPerHead: 70000,
        /* Bangladesh study: saturated soil + warm temp (May-Nov) trigger spore activation.
           High Ca content soil also favorable [citation:19][citation:28] */
        soilMoistureThreshold: 0.60,
        soilMoistureBonus: 15,
        minTempThreshold: 25
    }
};
/* ===== END: DISEASE LIBRARY ===== */

/* ===== START: DISTRICT PRIORS (v3.0 — NEW) =====
   Bangladesh-specific disease baseline per district.
   Sources:
   - Anthrax: Sirajganj, Bogra, Kushtia, Tangail, Mymensingh (historically endemic) [citation:19]
   - LSD: Chattogram, Cox's Bazar (southeast) → Rajshahi, Rangpur (northwest) shifting hotspots [citation:15]
   - PPR: goat-dense districts (Rajshahi, Rangpur divisions)
   
   Values are relative multipliers (1.0 = national average).
   Only applied when districtKey matches; otherwise 1.0.
*/
const DISTRICT_PRIORS = {
    // Anthrax endemic (Bangladesh studies)
    sirajganj:   { anthrax: 1.8, fmd: 1.3, lsd: 1.2 },
    bogura:      { anthrax: 1.6, fmd: 1.2, lsd: 1.1 },
    kushtia:     { anthrax: 1.5, fmd: 1.1 },
    tangail:     { anthrax: 1.4, fmd: 1.1 },
    mymensingh:  { anthrax: 1.4, fmd: 1.2, lsd: 1.1 },
    // LSD hotspots (2020-2023 shifting pattern)
    chattogram:  { lsd: 1.5, fmd: 1.1 },
    coxsbazar:   { lsd: 1.6 },
    rajshahi:    { lsd: 1.3, ppr: 1.4 },
    rangpur:     { lsd: 1.4, ppr: 1.5 },
    // PPR goat-dense
    jamalpur:    { ppr: 1.3 },
    // Poultry belt
    kishoreganj: { ranikhet: 1.3, coccidiosis: 1.2 },
    gazipur:     { ranikhet: 1.2, coccidiosis: 1.2 }
};
/* ===== END: DISTRICT PRIORS ===== */

/* ===== START: HELPERS + RISK LEVEL TABLE ===== */
const GENERIC_DISEASES_BN = 'Mosquito-borne & water-borne diseases';
const _isNum = v => v !== null && v !== undefined && v !== '' && Number.isFinite(Number(v));

const RISK_LEVELS = [
    { min: 70, level: 'critical', label: 'Very High', labelBn: 'Very High',
      color: '#dc2626', bg: '#fef2f2', border: '#fecaca', icon: '🚨' },
    { min: 50, level: 'alert',    label: 'High',      labelBn: 'High',
      color: '#c2410c', bg: '#fff7ed', border: '#fdba74', icon: '⚠️' },
    { min: 30, level: 'watch',    label: 'Medium',    labelBn: 'Medium',
      color: '#92400e', bg: '#fef9e7', border: '#fcd34d', icon: '👀' },
    { min: 0,  level: 'safe',     label: 'Low',       labelBn: 'Low',
      color: '#047857', bg: '#ecfdf5', border: '#86efac', icon: '✅' }
];
/* ===== END: HELPERS + RISK LEVEL TABLE ===== */

/* ===== START: DETAILED RAINFALL RISK with breakdown ===== */
function calculateRainfallRiskDetailed(rainMm, humidity, temp) {
    if (!_isNum(rainMm)) {
        return {
            level: 'unknown', score: 0, color: '#8ab8be',
            label: 'Unknown', labelBn: 'Unknown',
            bg: '#f1f5f9', border: '#e2e8f0', icon: '⚪',
            breakdown: [],
            totalRawScore: 0
        };
    }

    const rain = Number(rainMm);
    const rhOk = _isNum(humidity), tOk = _isNum(temp);
    const rh = rhOk ? Number(humidity) : 0;
    const t = tOk ? Number(temp) : NaN;
    const breakdown = [];
    let score = 0;

    /* ===== RAINFALL ===== */
    let rainScore = 0, rainReason = '', rainReasonBn = '';
    if (rain > 100) { rainScore = 40; rainReason = '>100mm → severe flood'; rainReasonBn = '>100mm → severe flood risk'; }
    else if (rain > 50) { rainScore = 30; rainReason = '>50mm → mosquito peak'; rainReasonBn = '>50mm → mosquito breeding peaks'; }
    else if (rain > 20) { rainScore = 20; rainReason = '>20mm → moderate vector'; rainReasonBn = '>20mm → moderate vector growth'; }
    else if (rain > 5) { rainScore = 10; rainReason = '>5mm → light vector'; rainReasonBn = '>5mm → light vector growth'; }
    else { rainReason = '<5mm → minimal'; rainReasonBn = '<5mm → minimal effect'; }
    score += rainScore;
    breakdown.push({
        icon: '🌧️', label: 'Rainfall', labelEn: 'Rainfall',
        value: `${Math.round(rain)}mm/24h`,
        score: rainScore, max: 40, reason: rainReason,
        reasonBn: rainReasonBn
    });

    /* ===== HUMIDITY ===== */
    let humScore = 0, humReason = '', humReasonBn = '';
    if (!rhOk) { humReason = 'no data'; humReasonBn = 'No humidity data'; }
    else if (rh > 85) { humScore = 25; humReason = '>85% → vector survival high'; humReasonBn = '>85% → high vector survival'; }
    else if (rh > 75) { humScore = 15; humReason = '>75% → moderate survival'; humReasonBn = '>75% → moderate vector survival'; }
    else if (rh > 65) { humScore = 8; humReason = '>65% → low survival'; humReasonBn = '>65% → low vector survival'; }
    else { humReason = '<65% → minimal'; humReasonBn = '<65% → minimal effect'; }
    score += humScore;
    breakdown.push({
        icon: '💧', label: 'Humidity', labelEn: 'Humidity',
        value: rhOk ? `${rh.toFixed(0)}%` : 'N/A',
        score: humScore, max: 25, reason: humReason,
        reasonBn: humReasonBn
    });

    /* ===== TEMPERATURE ===== */
    let tempScore = 0, tempReason = '', tempReasonBn = '';
    if (!tOk) { tempReason = 'no data'; tempReasonBn = 'No temperature data'; }
    else if (t >= 25 && t <= 32) { tempScore = 20; tempReason = '25-32°C → optimal for virus'; tempReasonBn = '25-32°C → optimal for pathogens & vectors'; }
    else if (t >= 20 && t < 35) { tempScore = 10; tempReason = '20-35°C → moderate'; tempReasonBn = '20-35°C → moderately favorable'; }
    else { tempReason = 'outside 20-35°C → low'; tempReasonBn = 'Outside 20-35°C → less favorable'; }
    score += tempScore;
    breakdown.push({
        icon: '🌡️', label: 'Temperature', labelEn: 'Temperature',
        value: tOk ? `${Math.round(t)}°C` : 'N/A',
        score: tempScore, max: 20, reason: tempReason,
        reasonBn: tempReasonBn
    });

    /* ===== VECTOR BASELINE ===== */
    const vectorBaseline = 10;
    score += vectorBaseline;
    breakdown.push({
        icon: '🦟', label: 'Vector baseline', labelEn: 'Vector baseline',
        value: 'Endemic',
        score: vectorBaseline, max: 10, reason: 'Bangladesh endemic baseline',
        reasonBn: 'Bangladesh endemic baseline'
    });

    const totalRaw = score;
    const finalScore = Math.min(100, score);

    const levelDef = RISK_LEVELS.find(l => finalScore >= l.min);
    const { min, ...result } = levelDef;

    return {
        ...result,
        score: finalScore,
        totalRawScore: totalRaw,
        capped: totalRaw > 100,
        breakdown,
        inputs: { rain, humidity: rhOk ? rh : null, temp: tOk ? t : null }
    };
}

function calculateRainfallRisk(rainMm, humidity, temp) {
    return calculateRainfallRiskDetailed(rainMm, humidity, temp);
}
/* ===== END: DETAILED RAINFALL RISK ===== */

/* ===== START: DISEASE RISK with district priors + lag logic (v3.0) ===== */
/**
 * Calculate per-disease risk scores.
 * @param {Object} params
 * @param {number} params.rainMm       - Today's rainfall (mm)
 * @param {number} params.humidity     - Relative humidity (%)
 * @param {number} params.temp         - Temperature (°C)
 * @param {number} [params.rain7dayMm] - Cumulative 7-day rainfall (mm) — used for FMD lag
 * @param {number} [params.soilMoisture] - Surface soil moisture (0-1) — used for Anthrax
 * @param {string} [params.district]   - District key (e.g. 'sirajganj') — applies DISTRICT_PRIORS
 * @returns {Array} Sorted list of disease risk objects (top 3)
 */
function calculateDiseaseRisks(params) {
    const { rainMm, humidity, temp, rain7dayMm, soilMoisture, district } = params || {};
    if (!_isNum(rainMm) || !_isNum(humidity) || !_isNum(temp)) return [];

    const rain = Number(rainMm);
    const rh = Number(humidity);
    const t = Number(temp);
    const rain7 = _isNum(rain7dayMm) ? Number(rain7dayMm) : 0;
    const soil = _isNum(soilMoisture) ? Number(soilMoisture) : 0;
    const distKey = String(district || '').toLowerCase().trim();
    const priors = DISTRICT_PRIORS[distKey] || {};
    const risks = [];

    for (const [key, d] of Object.entries(DISEASE_LIBRARY)) {
        let score = 0;

        // ===== BASE FACTORS =====
        // Rain factor (today)
        if (rain >= d.rainThreshold) score += 35;
        else if (rain >= d.rainThreshold * 0.6) score += 20;
        else if (rain >= d.rainThreshold * 0.3) score += 10;

        // Humidity factor
        if (rh >= d.humidityMin) score += 25;
        else if (rh >= d.humidityMin - 10) score += 12;

        // Temp factor
        if (t >= d.tempRange[0] && t <= d.tempRange[1]) score += 25;
        else if (t >= d.tempRange[0] - 3 && t <= d.tempRange[1] + 3) score += 12;

        // Endemic baseline
        score += d.riskBoost * 0.5;

        // ===== v3.0: DISEASE-SPECIFIC BONUSES =====

        // FMD: rain lag (7-14 days after flood → contaminated water/mud)
        if (key === 'fmd' && rain7 >= 100) {
            score += d.rainLagBonus || 10;
        }
        // FMD: saturated soil
        if (key === 'fmd' && soil >= (d.soilMoistureThreshold || 0.65)) {
            score += 8;
        }

        // Anthrax: saturated soil + warm temp (spore activation)
        if (key === 'anthrax') {
            if (soil >= (d.soilMoistureThreshold || 0.60) && t >= (d.minTempThreshold || 25)) {
                score += d.soilMoistureBonus || 15;
            }
            // Anthrax is endemic in specific districts (prior boost)
        }

        // Ranikhet: rainy season + high humidity (BD Sonali study)
        if (key === 'ranikhet') {
            if (rain7 >= 50) score += d.rainySeasonBonus || 8;
            if (rh >= 80) score += d.highHumidityBonus || 5;
        }

        // LSD: cumulative rain + humidity (BD 2020-2023 study)
        if (key === 'lsd') {
            if (rain7 >= 80) score += d.rain7dayBonus || 5;
            if (rh >= 80) score += d.humidityBonus || 8;
        }

        // ===== v3.0: DISTRICT PRIOR BOOST =====
        const priorMultiplier = priors[key];
        if (priorMultiplier && priorMultiplier > 1) {
            // Add a bonus proportional to the multiplier (e.g., 1.8 → +8 points)
            score += Math.round((priorMultiplier - 1) * 10);
        }

        const rounded = Math.min(100, Math.round(score));
        if (rounded >= 30) {
            risks.push({
                key,
                ...d,
                score: rounded,
                economicPerHead: d.economicImpactPerHead,
                districtBoost: priorMultiplier ? Math.round((priorMultiplier - 1) * 10) : 0
            });
        }
    }

    return risks.sort((a, b) => b.score - a.score).slice(0, 3);
}
/* ===== END: DISEASE RISK ===== */

/* ===== START: ENGLISH ALERT with numbers ===== */
function generateAlertBanner(district, riskLevel, diseases, rainMm) {
    const level = riskLevel && riskLevel.level;
    const list = Array.isArray(diseases) ? diseases : [];
    const rain = Number(rainMm) || 0;

    if (level === 'safe') {
        return {
            type: 'safe', icon: '✅',
            titleBn: 'Normal Condition',
            messageBn: `Low risk of mosquito-borne or water-borne diseases in ${district} at present.`,
            title: 'Normal condition',
            message: `Low risk of vector-borne diseases in ${district}.`
        };
    }

    if (level === 'watch') {
        return {
            type: 'watch', icon: '👀',
            titleBn: 'Stay Alert',
            messageBn: `${rain.toFixed(0)} mm of rain in ${district} in the last 24h. Mosquito and fly breeding may increase. Clear standing water.`,
            title: 'Stay alert',
            message: `${rain.toFixed(0)}mm rain in ${district} in last 24h. Vector breeding may increase.`
        };
    }

    if (level === 'alert') {
        const names = list.slice(0, 2).map(d => d.nameBn).join(' and ') || GENERIC_DISEASES_BN;
        const topDisease = list[0];
        return {
            type: 'alert', icon: '⚠️',
            titleBn: 'High Disease Risk',
            messageBn: `${rain.toFixed(0)} mm rainfall in ${district} has increased the risk of ${names}${topDisease ? ` (${topDisease.score}%)` : ''}. Keep animals under mosquito nets and keep the farm dry.`,
            title: 'High disease risk',
            message: `${rain.toFixed(0)}mm rainfall increased risk of ${names} in ${district}.`
        };
    }

    if (level === 'critical') {
        const names = list.slice(0, 3).map(d => d.nameBn).join(', ') || GENERIC_DISEASES_BN;
        const topDisease = list[0];
        return {
            type: 'critical', icon: '🚨',
            titleBn: 'Emergency Alert',
            messageBn: `Severe rainfall (${rain.toFixed(0)} mm) and high humidity in ${district}. Very high probability of a ${names} outbreak${topDisease ? ` (${topDisease.score}%)` : ''}. Take preventive measures now and contact your veterinarian.`,
            title: 'Emergency alert',
            message: `Severe rainfall (${rain.toFixed(0)}mm) + high humidity. Very high risk of ${names} in ${district}.`
        };
    }

    return {
        type: 'unknown', icon: '⚪',
        titleBn: 'No Data',
        messageBn: `Weather data for ${district} not available.`,
        title: 'No data',
        message: `No weather data for ${district}.`
    };
}
/* ===== END: ENGLISH ALERT ===== */

/* ===== START: ECONOMIC IMPACT (double-count fixed) ===== */
function estimateEconomicImpact(diseases, livestockCounts) {
    if (!Array.isArray(diseases) || !livestockCounts) {
        return {
            total: 0, totalCrore: '0.00', currency: '৳',
            breakdown: [], overlap: false,
            assumption: 'No disease or livestock data'
        };
    }

    const resolveCount = (speciesName) => {
        const key = String(speciesName || '').toLowerCase();
        if (livestockCounts[key] !== undefined) return Number(livestockCounts[key]) || 0;
        if (livestockCounts[key + 's'] !== undefined) return Number(livestockCounts[key + 's']) || 0;
        return 0;
    };

    const claimedSpecies = new Set();
    const breakdown = [];
    let total = 0;
    let hadOverlap = false;

    diseases.forEach(d => {
        const animals = Array.isArray(d.animals) ? d.animals : [];
        let affectedHeads = 0;
        let lostSpecies = 0;

        animals.forEach(a => {
            const speciesKey = String(a).toLowerCase();
            if (claimedSpecies.has(speciesKey)) {
                hadOverlap = true;
                return;
            }
            claimedSpecies.add(speciesKey);
            lostSpecies++;
            affectedHeads += resolveCount(a) * 0.1;
        });

        const loss = affectedHeads * (d.economicPerHead || 0);
        total += loss;

        breakdown.push({
            key: d.key,
            vector: d.vector,
            disease: d.nameBn,
            abbr: d.abbr || d.nameBn,
            diseaseEn: d.nameEn,
            affectedHeads: Math.round(affectedHeads),
            perHead: d.economicPerHead || 0,
            loss: Math.round(loss),
            lossCrore: (loss / 10000000).toFixed(2),
            speciesCounted: lostSpecies
        });
    });

    return {
        total: Math.round(total),
        totalCrore: (total / 10000000).toFixed(2),
        currency: '৳',
        overlap: hadOverlap,
        assumption: hadOverlap
            ? 'The same animal is not counted in multiple diseases — only the highest-risk disease is counted (infection rate: 10%)'
            : 'Infection rate: 10% of at-risk animals',
        breakdown
    };
}

function livestockFromSedac(sedac) {
    const l = sedac && sedac.livestock;
    if (!l) return null;
    const n = v => Math.max(0, Number(v) || 0);
    const cattle = n(l.cattle), poultry = n(l.poultry);
    const has = k => l[k] !== undefined && l[k] !== null;
    return {
        cow:     has('cow')     ? n(l.cow)     : Math.round(cattle * (has('buffalo') ? 1 : 0.9)),
        buffalo: has('buffalo') ? n(l.buffalo) : Math.round(cattle * 0.1),
        goat:    n(l.goat),
        sheep:   n(l.sheep),
        chicken: has('chicken') ? n(l.chicken) : Math.round(poultry * (has('duck') ? 1 : 0.87)),
        duck:    has('duck')    ? n(l.duck)    : Math.round(poultry * 0.13)
    };
}
/* ===== END: ECONOMIC IMPACT ===== */

/* ===== START: VECTOR ACTIVITY ===== */
const VECTOR_ACTIVITY = {
    safe:     { label: 'Low',       labelBn: 'Low',       icon: '🟢' },
    watch:    { label: 'Medium',    labelBn: 'Medium',    icon: '🟡' },
    alert:    { label: 'High',      labelBn: 'High',      icon: '🟠' },
    critical: { label: 'Very High', labelBn: 'Very High', icon: '🔴' },
    unknown:  { label: 'Unknown',   labelBn: 'Unknown',   icon: '⚪' }
};

function getVectorActivity(riskLevel) {
    return VECTOR_ACTIVITY[riskLevel] || VECTOR_ACTIVITY.unknown;
}
/* ===== END: VECTOR ACTIVITY ===== */

/* ===== START: PUBLIC API ===== */
window.NasaOutbreak = {
    calculateRainfallRisk,
    calculateRainfallRiskDetailed,
    calculateDiseaseRisks,
    generateAlertBanner,
    getVectorActivity,
    estimateEconomicImpact,
    livestockFromSedac,
    DISEASE_LIBRARY,
    DISTRICT_PRIORS
};
/* ===== END: PUBLIC API ===== */

})();
