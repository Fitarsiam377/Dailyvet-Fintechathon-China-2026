/* DailyVet — NASA Climate Engine v3.0
   THI (NRC 1971):  THI = (1.8×T + 32) − (0.55 − 0.0055×RH) × (1.8×T − 26)
   Inputs (NASA POWER): T2M, RH2M, GWETTOP

   Heat-stress thresholds — Bangladesh-specific (v3.0)
   Based on recent Bangladesh research (Savar CCBDF 2024, Islam et al. 2023):
     Cow/Buffalo: <72 normal | 72–79 mild | 79–89 moderate | ≥89 severe
     Goat/Sheep:  <75 normal | 75–82 mild | 82–88 moderate | ≥88 severe
     Poultry:     <70 normal | 70–76 mild | 76–83 moderate | ≥83 severe
     Dog:         <72 normal | 72–78 mild | 78–85 moderate | ≥85 severe
     Cat:         <72 normal | 72–78 mild | 78–85 moderate | ≥85 severe

   v3.0 additions:
   • estimateMilkDrop(thi, species) — predicted milk yield loss (%)
   • predictTHITrend(last7Days, species) — 3-day THI trend + risk forecast
   • Thresholds adjusted to Bangladesh research (see comments)
*/
(function () {
'use strict';

/* ===== START: THI CALCULATION - NRC 1971 formula (NASA: T2M, RH2M) ===== */
const _num = v => (v === null || v === undefined || v === '') ? NaN : Number(v);

function calculateTHI(tempC, rh) {
    const T = _num(tempC);
    const R = _num(rh);
    if (!Number.isFinite(T) || !Number.isFinite(R)) return null;
    return (1.8 * T + 32) - (0.55 - 0.0055 * R) * (1.8 * T - 26);
}
/* ===== END: THI CALCULATION ===== */

/* ===== START: SPECIES-SPECIFIC THI THRESHOLDS =====
   Bangladesh-specific thresholds based on:
   - Savar CCBDF study (2024): THI categories T0 ≤75, T1 75-80, T2 ≥80 for HF crossbreds
   - Islam et al. 2023 (Ann. Bangladesh Agric.): Armstrong scale (72/79/89) for ruminants in BD
   - BLRI/CIMMYT Agvisely decision tree (species-specific biological thresholds)

   Cow/Buffalo: mild at 72 (universal dairy threshold), moderate at 79
                (Bangladesh summer avg 77-81), severe at 89 (severe heat wave)
   Poultry:     more sensitive, mild at 70 (industry standard), severe at 83
   Goat/Sheep:  slightly more tolerant than cattle, mild at 75
*/
const THI_THRESHOLDS = {
    cow:      { mild: 72, moderate: 79, severe: 89, label: '🐄 Cow' },
    buffalo:  { mild: 72, moderate: 79, severe: 89, label: '🐃 Buffalo' },
    goat:     { mild: 75, moderate: 82, severe: 88, label: '🐐 Goat' },
    sheep:    { mild: 75, moderate: 82, severe: 88, label: '🐑 Sheep' },
    poultry:  { mild: 70, moderate: 76, severe: 83, label: '🐔 Poultry' },
    chicken:  { mild: 70, moderate: 76, severe: 83, label: '🐔 Chicken' },
    duck:     { mild: 70, moderate: 76, severe: 83, label: '🦆 Duck' },
    dog:      { mild: 72, moderate: 78, severe: 85, label: '🐕 Dog' },
    cat:      { mild: 72, moderate: 78, severe: 85, label: '🐈 Cat' },
    default:  { mild: 72, moderate: 79, severe: 89, label: '🐾 Animal' }
};

const THI_LEVEL_DEFS = {
    normal: {
        level: 'normal', label: 'Normal', labelBn: 'Normal',
        color: '#047857', bg: '#ecfdf5', border: '#86efac',
        advice: 'Heat-stress risk is low. Maintain normal care.',
        adviceBn: 'Heat-stress risk is low. Maintain normal care.',
        actionBn: 'Maintain normal care',
        action: 'Maintain normal care'
    },
    mild: {
        level: 'mild', label: 'Mild', labelBn: 'Mild',
        color: '#92400e', bg: '#fef9e7', border: '#fcd34d',
        advice: 'Mild heat-stress. Provide shade and cool water.',
        adviceBn: 'Mild heat-stress. Provide shade and cool water.',
        actionBn: 'Provide shade, water ×1.5',
        action: 'Provide shade, water ×1.5'
    },
    moderate: {
        level: 'moderate', label: 'Moderate', labelBn: 'Moderate',
        color: '#c2410c', bg: '#fff7ed', border: '#fdba74',
        advice: 'Moderate heat-stress. Reduce activity, use fans, add electrolytes.',
        adviceBn: 'Moderate heat-stress. Reduce activity, use fans, add electrolytes.',
        actionBn: 'Keep in shade at noon, water ×2, add electrolytes',
        action: 'Keep in shade at noon, water ×2, add electrolytes'
    },
    severe: {
        level: 'severe', label: 'Severe', labelBn: 'Severe',
        color: '#991b1b', bg: '#fef2f2', border: '#fecaca',
        advice: 'SEVERE heat-stress! Immediate action needed. Spray water, provide shade, call vet.',
        adviceBn: 'SEVERE heat-stress! Immediate action needed. Spray water, provide shade, call vet.',
        actionBn: 'Spray water NOW, move to cool area, call vet',
        action: 'Spray water NOW, move to cool area, call vet'
    },
    unknown: {
        level: 'unknown', label: 'Unknown', labelBn: 'Unknown',
        color: '#8ab8be', bg: '#f1f5f9', border: '#e2e8f0',
        advice: 'Data not available', adviceBn: 'Data not available',
        actionBn: 'Data not available', action: 'Data not available'
    }
};

function classifyTHI(thi, species) {
    if (!Number.isFinite(thi)) return { ...THI_LEVEL_DEFS.unknown };

    const sp = (species || 'default').toLowerCase();
    const thresholds = THI_THRESHOLDS[sp] || THI_THRESHOLDS.default;

    let level;
    if (thi < thresholds.mild) level = 'normal';
    else if (thi < thresholds.moderate) level = 'mild';
    else if (thi < thresholds.severe) level = 'moderate';
    else level = 'severe';

    return {
        ...THI_LEVEL_DEFS[level],
        species: sp,
        speciesLabel: thresholds.label,
        thresholds,
        thiValue: thi
    };
}
/* ===== END: SPECIES-SPECIFIC THI THRESHOLDS ===== */

/* ===== START: MILK DROP ESTIMATION (v3.0 — NEW) =====
   Estimates percentage of milk yield loss at a given THI for dairy species.
   Based on research findings:
   - Milk yield declines start at THI ≥ 72 for dairy cattle [Yan et al. 2021]
   - Rate of decline ~2.13% per unit THI increase (tropical crossbred study) [FAO AGRIS 2021]
   - Severe heat (THI > 85) can cause 30-50% drop in high-yielding cows

   Returns:
     { dropPct: number, level: 'none'|'mild'|'moderate'|'severe', description: string }
     or null if species not dairy / THI invalid.

   Species supported: cow, buffalo (dairy). Goat milk drop not well studied, returns null.
*/
const _MILK_DROP_RATES = {
    // Per unit THI above threshold
    cow:     { perUnit: 2.13, maxDrop: 45 },
    buffalo: { perUnit: 1.80, maxDrop: 40 }  // Buffalo slightly more tolerant
};

function estimateMilkDrop(thi, species) {
    if (!Number.isFinite(thi)) return null;
    const sp = (species || 'cow').toLowerCase();

    const rate = _MILK_DROP_RATES[sp];
    if (!rate) return null;  // species not dairy (chicken, duck, dog, cat, goat, sheep)

    const thr = THI_THRESHOLDS[sp] || THI_THRESHOLDS.cow;

    if (thi < thr.mild) {
        return {
            dropPct: 0,
            level: 'none',
            description: 'No heat-related milk loss expected.'
        };
    }

    // Linear decline from mild threshold upward, capped
    const excess = thi - thr.mild;
    const rawDrop = excess * rate.perUnit;
    const dropPct = Math.min(rate.maxDrop, Math.round(rawDrop * 10) / 10);

    let level, description;
    if (dropPct < 5) {
        level = 'mild';
        description = `Mild milk drop (~${dropPct}%) expected. Provide shade and extra water.`;
    } else if (dropPct < 15) {
        level = 'moderate';
        description = `Moderate milk drop (~${dropPct}%) expected. Use fans, electrolytes, and shift feeding to cooler hours.`;
    } else {
        level = 'severe';
        description = `Severe milk drop (~${dropPct}%) expected. Immediate cooling required — spray water, ventilate shed, contact vet.`;
    }

    return { dropPct, level, description };
}
/* ===== END: MILK DROP ESTIMATION ===== */

/* ===== START: THI TREND PREDICTION (v3.0 — NEW) =====
   Takes the last N days of THI values and predicts tomorrow's direction.
   Uses simple linear regression on the last 3-7 days.
   
   Input: last7Days = [{ date, thi }, ...] (oldest → newest)
   Output: {
     trend: 'rising' | 'falling' | 'stable',
     slope: number,           // THI change per day
     tomorrowPrediction: number,
     riskTomorrow: 'normal'|'mild'|'moderate'|'severe',
     alert: string|null       // human-readable warning
   }
*/
function predictTHITrend(last7Days, species) {
    const sp = (species || 'cow').toLowerCase();
    const thr = THI_THRESHOLDS[sp] || THI_THRESHOLDS.cow;
    const days = (Array.isArray(last7Days) ? last7Days : [])
        .filter(d => Number.isFinite(d && d.thi))
        .slice(-7);

    if (days.length < 3) {
        return {
            trend: 'unknown',
            slope: 0,
            tomorrowPrediction: null,
            riskTomorrow: 'unknown',
            alert: 'Not enough data to predict trend (need at least 3 days).'
        };
    }

    // Simple linear regression: y = a + b*x
    const n = days.length;
    let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
    days.forEach((d, i) => {
        sumX += i;
        sumY += d.thi;
        sumXY += i * d.thi;
        sumX2 += i * i;
    });
    const denom = (n * sumX2 - sumX * sumX);
    const slope = denom === 0 ? 0 : (n * sumXY - sumX * sumY) / denom;

    const lastThi = days[days.length - 1].thi;
    const tomorrowPrediction = lastThi + slope;

    let trend;
    if (slope > 0.5) trend = 'rising';
    else if (slope < -0.5) trend = 'falling';
    else trend = 'stable';

    const riskTomorrow = classifyTHI(tomorrowPrediction, sp).level;

    let alert = null;
    if (riskTomorrow === 'severe' && trend !== 'falling') {
        alert = `⚠️ THI may reach ${tomorrowPrediction.toFixed(0)} tomorrow — SEVERE heat stress expected. Prepare cooling now.`;
    } else if (riskTomorrow === 'moderate' && trend === 'rising') {
        alert = `THI rising toward ${tomorrowPrediction.toFixed(0)} — moderate heat stress likely. Ensure shade and water.`;
    } else if (trend === 'falling' && lastThi >= thr.mild) {
        alert = `Relief expected — THI falling from ${lastThi.toFixed(0)} to ~${tomorrowPrediction.toFixed(0)}.`;
    }

    return {
        trend,
        slope: Math.round(slope * 100) / 100,
        tomorrowPrediction: Math.round(tomorrowPrediction * 10) / 10,
        riskTomorrow,
        alert
    };
}
/* ===== END: THI TREND PREDICTION ===== */

/* ===== START: THI COMPARISON - Before/After ===== */
function generateTHIComparison(current, yesterday, tomorrow, species, lang) {
    if (!Number.isFinite(current)) {
        return {
            available: false,
            headlineBn: 'Data not available',
            headline: 'Data not available'
        };
    }

    const currentCls = classifyTHI(current, species);
    const yesterdayCls = Number.isFinite(yesterday) ? classifyTHI(yesterday, species) : null;
    const tomorrowCls = Number.isFinite(tomorrow) ? classifyTHI(tomorrow, species) : null;

    const delta = Number.isFinite(yesterday) ? current - yesterday : null;
    let trend = '➡️ Stable';
    let trendEn = 'Stable';

    if (delta !== null) {
        if (delta > 2) { trend = '⬆️ Rising'; trendEn = 'Rising'; }
        else if (delta < -2) { trend = '⬇️ Falling'; trendEn = 'Falling'; }
    }

    const deltaText = delta !== null
        ? `${Math.abs(delta).toFixed(1)} points ${delta > 0 ? 'higher' : 'lower'} than yesterday`
        : '';

    const headlineBn = currentCls.level === 'normal'
        ? `Your ${currentCls.speciesLabel} is in normal condition now`
        : `Your ${currentCls.speciesLabel} is currently at ${currentCls.labelBn} risk`;
    const headline = headlineBn;

    const tomorrowText = tomorrowCls
        ? `Tomorrow (estimate): ${tomorrow.toFixed(1)} THI (${tomorrowCls.labelBn})`
        : '';

    const yesterdayText = yesterdayCls
        ? `Yesterday: ${yesterday.toFixed(1)} THI (${yesterdayCls.labelBn})`
        : '';

    return {
        available: true,
        current: current.toFixed(1),
        yesterday: yesterdayCls ? yesterday.toFixed(1) : null,
        tomorrow: tomorrowCls ? tomorrow.toFixed(1) : null,
        delta: delta !== null ? delta.toFixed(1) : null,
        trend,
        trendEn,
        deltaText,
        headline,
        headlineBn,
        yesterdayText,
        tomorrowText,
        currentLevel: currentCls.level,
        currentLevelBn: currentCls.labelBn,
        color: currentCls.color,
        bg: currentCls.bg,
        border: currentCls.border,
        actionBn: currentCls.actionBn,
        action: currentCls.action,
        adviceBn: currentCls.adviceBn,
        advice: currentCls.advice
    };
}
/* ===== END: THI COMPARISON ===== */

/* ===== START: SOIL LEVELS + FORAGE LIBRARY ===== */
const SOIL_LEVELS = [
    { max: 0.15, level: 'drought', label: 'Drought Risk', labelBn: 'Drought Risk', color: '#dc2626',
      advice: 'Very dry soil. Choose drought-tolerant grass.',
      adviceBn: 'Very dry soil. Choose drought-tolerant grass.' },
    { max: 0.30, level: 'dry', label: 'Dry', labelBn: 'Dry', color: '#d97706',
      advice: 'Dry soil. Irrigation may be needed.',
      adviceBn: 'Dry soil. Irrigation may be needed.' },
    { max: 0.65, level: 'optimal', label: 'Optimal', labelBn: 'Optimal', color: '#059669',
      advice: 'Soil moisture is optimal for forage growth.',
      adviceBn: 'Soil moisture is optimal for forage growth.' },
    { max: Infinity, level: 'wet', label: 'Waterlogged', labelBn: 'Waterlogged', color: '#2563eb',
      advice: 'Soil is very wet. Risk of root rot and foot diseases.',
      adviceBn: 'Soil is very wet. Risk of root rot and foot diseases.' }
];

const FORAGE_DETAILS = {
    napier: {
        name: 'Napier Grass', en: 'Napier Grass', emoji: '🌾',
        why: 'Drought-tolerant, high yield',
        whyEn: 'Drought-tolerant, high yield',
        waterNeed: 'Low', waterNeedEn: 'Low',
        harvestDays: 70,
        yieldPerHectare: '40-60 tons',
        droughtTolerance: 'High',
        suitableMonths: [1,2,3,4,5,6,10,11,12],
        avoidReason: 'Not suitable for current soil conditions'
    },
    german: {
        name: 'German Grass', en: 'German Grass', emoji: '🌱',
        why: 'Grows well in wet soil',
        whyEn: 'Grows well in wet soil',
        waterNeed: 'High', waterNeedEn: 'High',
        harvestDays: 55,
        yieldPerHectare: '35-50 tons',
        droughtTolerance: 'Low',
        suitableMonths: [7,8,9,10],
        avoidReason: 'Requires too much water'
    },
    para: {
        name: 'Para Grass', en: 'Para Grass', emoji: '🍃',
        why: 'Flood-tolerant, ideal for lowland',
        whyEn: 'Flood-tolerant, ideal for lowland',
        waterNeed: 'High', waterNeedEn: 'High',
        harvestDays: 60,
        yieldPerHectare: '30-40 tons',
        droughtTolerance: 'Low',
        suitableMonths: [7,8,9,10],
        avoidReason: 'Requires waterlogged soil'
    },
    jumbo: {
        name: 'Jumbo Grass', en: 'Jumbo Grass', emoji: '🌿',
        why: 'Highest yield in good conditions',
        whyEn: 'Highest yield in good conditions',
        waterNeed: 'Medium', waterNeedEn: 'Medium',
        harvestDays: 65,
        yieldPerHectare: '50-70 tons',
        droughtTolerance: 'Medium',
        suitableMonths: [3,4,5,6,7,8,9],
        avoidReason: 'Needs medium water — not suitable for dry soil'
    },
    fodderMaize: {
        name: 'Fodder Maize', en: 'Fodder Maize', emoji: '🌽',
        why: 'Nutritious, ideal for dairy cattle',
        whyEn: 'Nutritious, ideal for dairy cattle',
        waterNeed: 'Medium', waterNeedEn: 'Medium',
        harvestDays: 85,
        yieldPerHectare: '35-50 tons',
        droughtTolerance: 'Medium',
        suitableMonths: [1,2,3,4,5,10,11,12],
        avoidReason: 'Not suitable for current soil conditions'
    }
};

const FORAGE_BY_SOIL = {
    drought: ['napier', 'fodderMaize', 'jumbo'],
    dry:     ['napier', 'fodderMaize'],
    optimal: ['jumbo', 'fodderMaize', 'napier'],
    wet:     ['german', 'para']
};

const REGION_PROFILE = {
    rajshahi:   { type: 'drought', regionBn: 'Barind / North-West Region',
                  noteBn: 'This region has high drought risk — prioritize drought-tolerant grasses, mulching and water-saving methods.' },
    rangpur:    { type: 'drought', regionBn: 'North-West Region',
                  noteBn: 'This region has high drought risk in the dry season — prioritize drought-tolerant grasses.' },
    dhaka:      { type: 'flood', regionBn: 'Central Bangladesh',
                  noteBn: 'Waterlogging risk in monsoon — keep drainage channels clear, plant grasses on higher ground.' },
    mymensingh: { type: 'flood', regionBn: 'North-Central Region',
                  noteBn: 'Flood risk in monsoon — choose flood-tolerant grasses and higher ground.' },
    sylhet:     { type: 'flood', regionBn: 'North-East Haor Region',
                  noteBn: 'High risk of flash floods — stock up silage/hay before monsoon.' },
    khulna:     { type: 'flood', regionBn: 'South-West Coastal Region',
                  noteBn: 'Waterlogging and salinity risk — consider drainage and salt-tolerant grasses.' },
    barisal:    { type: 'flood', regionBn: 'South Coastal Region',
                  noteBn: 'Waterlogging and tidal risk — keep drainage clear.' },
    chittagong: { type: 'flood', regionBn: 'South-East Coastal Region',
                  noteBn: 'Heavy rain and hill-slope flood risk — prevent soil erosion on slopes.' }
};

function getRegionProfile(districtKey) {
    return REGION_PROFILE[String(districtKey || '').toLowerCase()] || null;
}

function _nextSuitableMonth(g, fromMonth) {
    for (let i = 0; i < 12; i++) {
        const m = ((fromMonth - 1 + i) % 12) + 1;
        if (g.suitableMonths.includes(m)) return m;
    }
    return g.suitableMonths[0];
}

function classifySoilTrend(series) {
    const vals = (Array.isArray(series) ? series : [])
        .map(x => _num(x && x.value)).filter(Number.isFinite);
    if (vals.length < 3) return { trend: 'unknown', trendBn: '', delta: null };
    const half = Math.floor(vals.length / 2);
    const avg = a => a.reduce((s, v) => s + v, 0) / a.length;
    const delta = avg(vals.slice(-half)) - avg(vals.slice(0, half));
    if (delta > 0.05)  return { trend: 'wetting', trendBn: '⬆️ Soil is getting wetter', delta };
    if (delta < -0.05) return { trend: 'drying',  trendBn: '⬇️ Soil is drying', delta };
    return { trend: 'stable', trendBn: '➡️ Soil moisture is stable', delta };
}

function classifySoilMoisture(gwettop) {
    const v = _num(gwettop);
    if (!Number.isFinite(v)) {
        return {
            level: 'unknown', label: 'Unknown', labelBn: 'Unknown', color: '#8ab8be',
            advice: 'Soil data not available', adviceBn: 'Soil data not available'
        };
    }
    const found = SOIL_LEVELS.find(l => v < l.max);
    const { max, ...result } = found;
    return result;
}

function recommendForageDetailed(soilLevel, currentMonth, gwettop, districtKey) {
    const month = Number.isInteger(currentMonth) && currentMonth >= 1 && currentMonth <= 12
        ? currentMonth : (new Date().getMonth() + 1);
    currentMonth = month;
    const region = getRegionProfile(districtKey);

    let grassKeys = (FORAGE_BY_SOIL[soilLevel] || ['napier']).slice();

    if (region && soilLevel === 'optimal') {
        if (region.type === 'drought') grassKeys = ['napier', 'jumbo', 'fodderMaize'];
        else if (currentMonth >= 6 && currentMonth <= 10) grassKeys = ['jumbo', 'para', 'napier'];
    }
    if (region && region.type === 'drought' && soilLevel === 'dry') {
        grassKeys = ['napier', 'fodderMaize'];
    }

    grassKeys = grassKeys
        .map((k, i) => ({ k, i, ok: FORAGE_DETAILS[k].suitableMonths.includes(currentMonth) }))
        .sort((a, b) => (b.ok - a.ok) || (a.i - b.i))
        .map(x => x.k);
    const monthNames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const monthFull = ['January','February','March','April','May','June','July','August','September','October','November','December'];

    const recommended = grassKeys.map(k => {
        const g = FORAGE_DETAILS[k];
        const monthSuitable = g.suitableMonths.includes(currentMonth);
        return {
            ...g,
            key: k,
            monthSuitable,
            reason: monthSuitable
                ? `✅ Suitable for planting in ${monthFull[currentMonth-1]}`
                : `⚠️ Not ideal this month — plant in ${monthFull[_nextSuitableMonth(g, currentMonth)-1]}`,
            reasonEn: monthSuitable
                ? `Suitable for planting in ${monthNames[currentMonth-1]}`
                : `⚠️ Not ideal this month — plant in ${monthNames[_nextSuitableMonth(g, currentMonth)-1]}`
        };
    });

    const avoid = Object.entries(FORAGE_DETAILS)
        .filter(([k]) => !grassKeys.includes(k))
        .slice(0, 2)
        .map(([k, g]) => ({
            name: g.name,
            nameEn: g.en,
            reason: g.avoidReason || 'Not suitable for current soil conditions',
            reasonEn: g.waterNeedEn === 'High'
                ? 'Needs too much water right now'
                : 'Not suitable for current soil'
        }));

    const calendar = [];
    for (let i = 0; i < 3; i++) {
        const m = ((currentMonth + i - 1) % 12) + 1;
        let picks = grassKeys.filter(k => FORAGE_DETAILS[k].suitableMonths.includes(m));
        if (!picks.length) {
            picks = Object.keys(FORAGE_DETAILS).filter(k => FORAGE_DETAILS[k].suitableMonths.includes(m));
        }
        calendar.push({
            month: monthNames[m-1],
            grasses: picks.slice(0, 2).map(k => FORAGE_DETAILS[k].name),
            grass: picks.slice(0, 2).map(k => FORAGE_DETAILS[k].name).join(', ') || '—'
        });
    }

    const wet = soilLevel === 'wet';
    return {
        recommended,
        avoid,
        calendar,
        region: region ? { type: region.type, regionBn: region.regionBn, noteBn: region.noteBn } : null,
        soilMoisture: gwettop !== undefined && gwettop !== null
            ? (gwettop * 100).toFixed(0)
            : null,
        irrigation: {
            frequency: soilLevel === 'drought' ? 'Once every 2 days'
                     : soilLevel === 'dry' ? 'Once every 3 days'
                     : soilLevel === 'wet' ? 'No irrigation needed'
                     : 'Twice a week',
            frequencyEn: soilLevel === 'drought' ? 'Every 2 days'
                       : soilLevel === 'dry' ? 'Every 3 days'
                       : soilLevel === 'wet' ? 'No irrigation needed'
                       : 'Twice a week',
            timing: wet ? 'Keep drainage channels clear' : 'Early morning (6-8 AM)',
            timingEn: wet ? 'Keep drainage channels clear' : 'Early morning (6-8 AM)',
            amountPerHectare: wet ? '0 L' : '30,000 L',
            amountPerHectareEn: wet ? '0 L' : '30,000 L',
            mulchingBenefit: wet ? 'Not applicable on waterlogged soil' : '40% water savings',
            mulchingBenefitEn: wet ? 'Not applicable on waterlogged soil' : '40% water savings'
        }
    };
}
/* ===== END: SOIL LEVELS + FORAGE LIBRARY ===== */

/* ===== START: FORAGE COMPARISON - Why this grass ===== */
function compareForageOptions(soilLevel) {
    const allKeys = Object.keys(FORAGE_DETAILS);
    const recommended = FORAGE_BY_SOIL[soilLevel] || ['napier'];

    return allKeys.map(k => {
        const g = FORAGE_DETAILS[k];
        const isRecommended = recommended.includes(k);
        const score = isRecommended ? 100 - recommended.indexOf(k) * 15 : 30;

        return {
            ...g,
            key: k,
            isRecommended,
            score,
            verdictBn: isRecommended
                ? `✅ Preference #${recommended.indexOf(k) + 1}`
                : '❌ Not suitable now',
            verdictEn: isRecommended
                ? `✅ Rank #${recommended.indexOf(k) + 1}`
                : '❌ Not suitable now'
        };
    }).sort((a, b) => b.score - a.score);
}
/* ===== END: FORAGE COMPARISON ===== */

/* ===== START: PUBLIC API ===== */
window.NasaClimate = {
    calculateTHI,
    classifyTHI,
    generateTHIComparison,
    classifySoilMoisture,
    recommendForageDetailed,
    recommendForage: (soilLevel) => {
        const keys = FORAGE_BY_SOIL[soilLevel] || ['napier'];
        return keys.map(k => FORAGE_DETAILS[k]);
    },
    compareForageOptions,
    classifySoilTrend,
    getRegionProfile,
    FORAGE_LIBRARY: FORAGE_DETAILS,
    FORAGE_DETAILS,
    REGION_PROFILE,
    THI_THRESHOLDS,

    /* v3.0 additions */
    estimateMilkDrop,
    predictTHITrend
};
/* ===== END: PUBLIC API ===== */

})();
