/* ============================================================
   DailyVet — Animal Body Weight Estimator v4.1 (English only)
   ✅ AI output guaranteed English via DVLangGuard
   ✅ Strict-English retry pass if first pass returns Bengali
   ✅ Multi-provider cascade: Gemini → Groq → OpenRouter
   ✅ Tape Measure (Schaeffer Formula) tab
   ============================================================ */
(function () {
const _dvDec = (s) => { try { return atob(s); } catch (e) { return ''; } };

'use strict';

let wsSelectedImage = null;
let wsCurrentPhone = null;
let wsPendingWeight = null;
let wsPendingFromAI = false;
let wsScanning = false;

/* ============================================================
   Keys — rotate before launch
   ============================================================ */
const WS_KEYS = {
  gemini: [
    _dvDec('QVEuQWI4Uk42S0RlT3dsV0NLR1BqdHJTWjJ4QnVfZV9BcTBjb1kxbnpTSnFaaVhXYWFxcGc='),
    _dvDec('QVEuQWI4Uk42SWNpaEFtbVF5aTZIWTBwQU5HNkFGLVpYRGZwSUdZZmFfNjhHb0NpQ2VqTFE='),
    _dvDec('QVEuQWI4Uk42SzJyWmx1MF81UTVEUzd6YkJ2azNmNEQwYVdxUlZCUENjaF83OF9xd25rU3c='),
    _dvDec('QVEuQWI4Uk42SUgzMFlLWkVPVndWZF8yOFhlc3Y2akh1bk1WRndjN0JucXlldkR3WTV2U3c='),
    _dvDec('QVEuQWI4Uk42S3JYOTg4UThFWFdORzlpRjlDYnNtcUxJbEw3aEtpQWFYUkNhMWFHZ01vU0E=')
  ],
  groq: [
    _dvDec('Z3NrX21WVXRJQThxTHdXUGNIZkFvNHNkV0dkeWIzRllkUk1rTlppMUxYT2gxb1RITVlIM0w3WXI='),
    _dvDec('Z3NrX3o4QkRyYldCbXlhS2l6M3BiVnZRV0dkeWIzRlk1R25haDNrQVptQm1xRUF2a2ZLMTZmd1M='),
    _dvDec('Z3NrX0ExSHo5VDQ3aTA5UndrM1h4UGlaV0dkeWIzRllxT0YxOHdDc0JRV0lUaVlOQjRaM3RheDQ=')
  ],
  openrouter: [
    _dvDec('c2stb3ItdjEtODg4MDE5MDk4Njc2MjllYWQ5ZGQyMjQ2MTc5YWVlZjE0Y2VkZTFiMGZkOGI2YmQxM2VkNDA2NTU3NWVhZWY3OQ=='),
    _dvDec('c2stb3ItdjEtNGQwZmE1MzM5YWI1YTA3NDlkM2I4ZTEyZTU1NGM3ZWI2MjFjYzNjMmI1YjgwYzk0MjA5YjM0YjhmMzZjZTFlNg==')
  ]
};
const WS_PROVIDER_ORDER = ['gemini', 'groq', 'openrouter'];

const WS_MODELS = {
  gemini: [
    'gemini-3.5-flash-lite',
    'gemini-3.1-flash-lite',
    'gemini-2.5-flash-lite',
    'gemini-3.8-flash',
    'gemini-3.6-flash',
    'gemini-2.5-flash'
  ],
  groq: ['qwen/qwen3.8-27b'],
  openrouter: ['qwen/qwen2.5-vl-72b-instruct:free']
};
const WS_ENDPOINTS = {
  gemini: 'https://generativelanguage.googleapis.com/v1beta/models',
  groq: 'https://api.groq.com/openai/v1/chat/completions',
  openrouter: 'https://openrouter.ai/api/v1/chat/completions'
};

const WS_TIMING = { total: 9000, perCall: 6000, hedge: 500, parallel: 2 };
const WS_WATCHDOG_EXTRA_MS = 1500;

const WS_COOLDOWN = {
  rateLimit: 20e3, rateLimitMax: 12 * 60e3, server: 15e3, timeout: 12e3,
  badRequest: 60e3, badOutput: 15e3, authKey: 6 * 3600e3,
  modelGone: 24 * 3600e3, quotaZero: 6 * 3600e3, perDay: 3 * 3600e3
};

const WS_GEMINI_SAFETY = ['HARM_CATEGORY_HARASSMENT', 'HARM_CATEGORY_HATE_SPEECH', 'HARM_CATEGORY_SEXUALLY_EXPLICIT', 'HARM_CATEGORY_DANGEROUS_CONTENT']
  .map(category => ({ category, threshold: 'BLOCK_ONLY_HIGH' }));

const WS_MAX_IMAGE_MB = 25;
const WS_TARGET_MAX_BYTES = 1.5 * 1024 * 1024;
const WS_MAX_SANE_KG = 1500;
const WS_CACHE_TTL_MS = 60 * 60 * 1000;
const WS_CACHE_MAX = 20;

const _el = id => document.getElementById(id);
const _wsLsGet = k => { try { return localStorage.getItem(k); } catch (_) { return null; } };
const _wsLsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (_) {} };

/* ============================================================
   System prompt — English only
   ============================================================ */
const WS_WEIGHT_PROMPT = `You are an expert livestock weight estimation AI for DailyVet (Bangladesh).

STRICT: Reply ONLY in clean English. Do NOT use Bengali, Hindi, or any non-English script in any field. Return ONLY valid JSON. No markdown.

Analyze the attached image of a farm animal (cow, buffalo, goat, sheep) and estimate its weight.

Your task:
1. Identify the animal species and breed (if possible)
2. Estimate the weight in kilograms based on body proportions
3. Assess the animal's body condition

CRITICAL RULES:
- ONLY estimate weight for cattle, buffalo, goat, sheep
- If image shows dog, cat, bird, chicken, duck, pigeon → return error: "birds_pets_not_supported"
- Look for a reference object if present (person, fence, bucket) to calibrate size

Return ONLY a valid JSON object with this exact structure:
{
  "status": "success",
  "species": "cow",
  "speciesEnglish": "Cow",
  "estimated_weight_kg": 320,
  "weight_range_kg": { "min": 290, "max": 360 },
  "confidence_percentage": 78,
  "body_condition": "Good",
  "observations": "The animal has normal height and body proportions. No signs of artificial fattening.",
  "notes": "This weight is an estimate — use a weighing scale for exact weight."
}

If the image is NOT a cattle/goat/sheep/buffalo:
{
  "status": "error",
  "error": "birds_pets_not_supported",
  "errorEnglish": "This measurement is only for livestock. Please upload a cow, buffalo, goat, or sheep."
}

IMPORTANT:
- Return ONLY the JSON. No markdown.
- All text fields MUST be in English.
- Weight estimation is approximate.`;

const WS_USER_NUDGE = 'Estimate the body weight of the animal in this image. Reply with the JSON object only, in English.';

/* ============================================================
   Helpers
   ============================================================ */
function escapeHtmlWS(text) {
  const div = document.createElement('div');
  div.textContent = String(text ?? '');
  return div.innerHTML;
}

function _wsParseJSON(raw) {
  if (!raw || typeof raw !== 'string') return null;
  const t = raw.replace(/<think>[\s\S]*?<\/think>/gi, '').replace(/```(?:json)?/gi, '').trim();
  let parsed;
  try { parsed = JSON.parse(t); }
  catch (_) {
    const m = t.match(/\{[\s\S]*\}/);
    if (m) { try { parsed = JSON.parse(m[0]); } catch (_) {} }
  }
  if (!parsed) return null;
  /* last-resort foreign-script strip */
  if (window.DVLangGuard) {
    const clean = obj => {
      if (typeof obj === 'string') return window.DVLangGuard.stripForeign(obj);
      if (Array.isArray(obj)) return obj.map(clean);
      if (obj && typeof obj === 'object') {
        const out = {};
        for (const k of Object.keys(obj)) out[k] = clean(obj[k]);
        return out;
      }
      return obj;
    };
    parsed = clean(parsed);
  }
  return parsed;
}

const WS_SPECIES_EN = { cow: 'Cow', cattle: 'Cow', buffalo: 'Buffalo', goat: 'Goat', sheep: 'Sheep' };

function _wsNormalize(d) {
  if (!d || typeof d !== 'object') return null;

  if (d.status === 'error') {
    return {
      status: 'error',
      error: String(d.error || 'not_supported'),
      errorEnglish: String(d.errorEnglish || 'This measurement is only for livestock.')
    };
  }

  const w = Number(d.estimated_weight_kg);
  if (!isFinite(w) || w < 1 || w > WS_MAX_SANE_KG) return null;
  const weight = Math.round(w * 10) / 10;

  let min = Number(d.weight_range_kg?.min), max = Number(d.weight_range_kg?.max);
  if (!isFinite(min) || !isFinite(max) || min <= 0 || min > weight || max < weight) {
    min = Math.round(weight * 0.88);
    max = Math.round(weight * 1.12);
  }

  let conf = Number(d.confidence_percentage);
  if (!isFinite(conf)) conf = 60;
  conf = Math.max(0, Math.min(100, Math.round(conf)));

  const species = String(d.species || '').toLowerCase();
  return {
    status: 'success',
    species: d.species || 'animal',
    speciesEnglish: d.speciesEnglish || WS_SPECIES_EN[species] || 'Animal',
    estimated_weight_kg: weight,
    weight_range_kg: { min, max },
    confidence_percentage: conf,
    body_condition: d.body_condition || '',
    observations: d.observations || '',
    notes: d.notes || 'This weight is an estimate — use a weighing scale for exact weight.'
  };
}

function _wsParseImage(img) {
  const m = /^data:([^;]+);base64,(.*)$/.exec(img || '');
  return m ? { mime: m[1], data: m[2] } : { mime: 'image/jpeg', data: img };
}

/* ============================================================
   Block registry
   ============================================================ */
const WS_BLOCK_STORE = 'dvWsBlocks';
const _wsBlocks = new Map();
const _wsStrikes = new Map();
const _wsRot = { gemini: 0, groq: 0, openrouter: 0 };

(function _wsLoadBlocks() {
  try {
    Object.entries(JSON.parse(_wsLsGet(WS_BLOCK_STORE) || '{}')).forEach(([id, until]) => {
      if (until > Date.now()) _wsBlocks.set(id, until);
    });
  } catch (_) {}
})();

const _wsTail = k => k.slice(-8);
const _wsKeyId = s => `k:${s.provider}:${_wsTail(s.key)}`;
const _wsModelId = s => `m:${s.provider}:${s.model}`;
const _wsIsBlocked = id => (_wsBlocks.get(id) || 0) > Date.now();
const _wsSlotBlocked = s => _wsIsBlocked(s.id) || _wsIsBlocked(_wsKeyId(s)) || _wsIsBlocked(_wsModelId(s));

function _wsBlock(id, ms) {
  _wsBlocks.set(id, Date.now() + ms);
  const live = {};
  _wsBlocks.forEach((until, k) => { if (until > Date.now()) live[k] = until; });
  _wsLsSet(WS_BLOCK_STORE, JSON.stringify(live));
}

function _wsInterleave(lists) {
  const out = [];
  const idx = lists.map(() => 0);
  let added = true;
  while (added) {
    added = false;
    lists.forEach((list, i) => {
      if (idx[i] < list.length) { out.push(list[idx[i]++]); added = true; }
    });
  }
  return out;
}

function _wsBuildSlots() {
  const perProvider = WS_PROVIDER_ORDER.map(provider => {
    const keys = (WS_KEYS[provider] || []).filter(Boolean);
    if (!keys.length) return [];
    const shift = _wsRot[provider] % keys.length;
    const rotated = keys.slice(shift).concat(keys.slice(0, shift));
    const seen = new Set();
    const out = [];
    for (const model of WS_MODELS[provider]) {
      for (const key of rotated) {
        const id = `s:${provider}:${model}:${_wsTail(key)}`;
        if (seen.has(id)) continue;
        seen.add(id);
        out.push({ provider, model, key, id });
      }
    }
    return out;
  });
  const live = _wsInterleave(perProvider.map(list => list.filter(s => !_wsSlotBlocked(s))));
  if (live.length) return live;
  return _wsInterleave(perProvider.map(list => list.filter(s =>
    !_wsIsBlocked(_wsKeyId(s)) && !_wsIsBlocked(_wsModelId(s))
  ))).slice(0, 4);
}

/* ============================================================
   Image compression
   ============================================================ */
function compressWSImage(file, maxDim = 1400, quality = 0.85) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          const scale = maxDim / Math.max(width, height);
          width = Math.round(width * scale);
          height = Math.round(height * scale);
        }
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        canvas.getContext('2d').drawImage(img, 0, 0, width, height);
        let q = quality;
        let dataUrl = canvas.toDataURL('image/jpeg', q);
        for (let i = 0; i < 5 && dataUrl.length * 0.75 > WS_TARGET_MAX_BYTES && q > 0.4; i++) {
          q -= 0.12;
          dataUrl = canvas.toDataURL('image/jpeg', q);
        }
        resolve(dataUrl);
      };
      img.onerror = () => reject(new Error('Image decode failed'));
      img.src = e.target.result;
    };
    reader.onerror = () => reject(new Error('File read failed'));
    reader.readAsDataURL(file);
  });
}

/* ============================================================
   Modal
   ============================================================ */
window.openWeightScale = function () {
  const modal = _el('weightScaleModal');
  if (!modal) return;
  modal.classList.remove('hidden');
  modal.style.display = 'block';
  document.body.style.overflow = 'hidden';

  wsSelectedImage = null;
  wsPendingWeight = null;
  wsPendingFromAI = false;
  const applyBtn = _el('wsApplyBtn');
  if (applyBtn) applyBtn.disabled = true;
  const aiResult = _el('wsAiResult');
  if (aiResult) { aiResult.style.display = 'none'; aiResult.innerHTML = ''; }
  const preview = _el('wsAiPreview');
  if (preview) { preview.style.display = 'none'; preview.classList.add('hidden'); }
  const imageField = _el('wsImageField');
  if (imageField) imageField.style.display = 'flex';
  const girth = _el('wsGirth'), length = _el('wsLength'), tapeWeight = _el('wsTapeWeight');
  if (girth) girth.value = '';
  if (length) length.value = '';
  if (tapeWeight) tapeWeight.textContent = '0';

  switchWsTab('ai');
};

window.closeWeightScale = function () {
  const modal = _el('weightScaleModal');
  if (!modal) return;
  modal.classList.add('hidden');
  modal.style.display = 'none';
  document.body.style.overflow = '';
};

window.switchWsTab = function (tab) {
  const tabTape = _el('wsTabTape'), tabAI = _el('wsTabAI');
  const contentTape = _el('wsContentTape'), contentAI = _el('wsContentAI');
  if (!tabTape || !tabAI || !contentTape || !contentAI) return;
  const activeCls = ['bg-white', 'text-deep', 'shadow-xs'];
  const inactiveCls = ['bg-transparent', 'text-mute'];
  const setActive = (el) => { el.classList.add(...activeCls); el.classList.remove(...inactiveCls); };
  const setInactive = (el) => { el.classList.remove(...activeCls); el.classList.add(...inactiveCls); };
  if (tab === 'tape') {
    setActive(tabTape); setInactive(tabAI);
    contentTape.classList.remove('hidden'); contentTape.style.display = 'flex';
    contentAI.classList.add('hidden'); contentAI.style.display = 'none';
  } else {
    setActive(tabAI); setInactive(tabTape);
    contentAI.classList.remove('hidden'); contentAI.style.display = 'flex';
    contentTape.classList.add('hidden'); contentTape.style.display = 'none';
  }
};

window.calculateTapeWeight = function () {
  const girthIn = parseFloat(_el('wsGirth')?.value) || 0;
  const lengthIn = parseFloat(_el('wsLength')?.value) || 0;
  const weightEl = _el('wsTapeWeight');
  const applyBtn = _el('wsApplyBtn');
  if (girthIn > 0 && lengthIn > 0) {
    const weightKg = (girthIn * girthIn * lengthIn) / 660;
    const rounded = Math.round(weightKg * 10) / 10;
    if (weightEl) weightEl.textContent = rounded.toFixed(1);
    wsPendingWeight = rounded;
    wsPendingFromAI = false;
    if (applyBtn) applyBtn.disabled = false;
  } else {
    if (weightEl) weightEl.textContent = '0';
    wsPendingWeight = null;
    wsPendingFromAI = false;
    if (applyBtn) applyBtn.disabled = true;
  }
};

/* ============================================================
   Image handling
   ============================================================ */
async function handleWsImage(event) {
  const file = event.target.files?.[0];
  if (file) await processWSImageFile(file);
  event.target.value = '';
}
window.handleWsImage = handleWsImage;

async function processWSImageFile(file) {
  if (!file || !file.type.startsWith('image/')) return;
  if (file.size > WS_MAX_IMAGE_MB * 1024 * 1024) {
    alert(`Image too large. Please choose under ${WS_MAX_IMAGE_MB}MB.`);
    return;
  }
  try {
    wsSelectedImage = await compressWSImage(file);
    showWSPreview(wsSelectedImage);
  } catch (err) {
    alert('Failed to read image: ' + err.message);
  }
}

function showWSPreview(dataURL) {
  const imageField = _el('wsImageField');
  const preview = _el('wsAiPreview');
  const img = _el('wsPreviewImg');
  if (imageField) imageField.style.display = 'none';
  if (preview && img) { img.src = dataURL; preview.classList.remove('hidden'); preview.style.display = 'flex'; }
  const result = _el('wsAiResult');
  if (result) { result.classList.add('hidden'); result.style.display = 'none'; }
  const loading = _el('wsAiLoading');
  if (loading) { loading.classList.add('hidden'); loading.style.display = 'none'; }
}

window.removeWSPreview = function () {
  wsSelectedImage = null;
  const preview = _el('wsAiPreview');
  if (preview) { preview.style.display = 'none'; preview.classList.add('hidden'); }
  const imageField = _el('wsImageField');
  if (imageField) imageField.style.display = 'flex';
  const result = _el('wsAiResult');
  if (result) { result.classList.add('hidden'); result.style.display = 'none'; result.innerHTML = ''; }
  const loading = _el('wsAiLoading');
  if (loading) { loading.classList.add('hidden'); loading.style.display = 'none'; }
  ['wsCameraInput', 'wsGalleryInput'].forEach(id => { const el = _el(id); if (el) el.value = ''; });
  const applyBtn = _el('wsApplyBtn');
  if (applyBtn) applyBtn.disabled = true;
  wsPendingWeight = null;
  wsPendingFromAI = false;
};

/* ============================================================
   Provider calls — English-only enforced
   ============================================================ */
function _wsGeminiRequest(slot, img) {
  const { mime, data } = _wsParseImage(img);
  const generationConfig = {
    temperature: 0.15, maxOutputTokens: 1200, topP: 0.95,
    responseMimeType: 'application/json'
  };
  if (slot.model.includes('2.5')) generationConfig.thinkingConfig = { thinkingBudget: 0 };
  return {
    url: `${WS_ENDPOINTS.gemini}/${slot.model}:generateContent?key=${slot.key}`,
    headers: { 'Content-Type': 'application/json' },
    body: {
      contents: [{
        role: 'user',
        parts: [
          { inline_data: { mime_type: mime, data } },
          { text: WS_WEIGHT_PROMPT }
        ]
      }],
      generationConfig,
      safetySettings: WS_GEMINI_SAFETY
    }
  };
}

function _wsChatRequest(slot, img) {
  const url = img.startsWith('data:') ? img : `data:image/jpeg;base64,${img}`;
  const headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${slot.key}` };
  if (slot.provider === 'openrouter') {
    headers['HTTP-Referer'] = location.origin || 'https://dailyvet.app';
    headers['X-Title'] = 'DailyVet Weight';
  }
  return {
    url: WS_ENDPOINTS[slot.provider],
    headers,
    body: {
      model: slot.model,
      messages: [
        { role: 'system', content: WS_WEIGHT_PROMPT },
        {
          role: 'user',
          content: [
            { type: 'text', text: WS_USER_NUDGE },
            { type: 'image_url', image_url: { url } }
          ]
        }
      ],
      temperature: 0.15,
      max_tokens: 1200
    }
  };
}

function _wsOnHttpError(slot, status, retryAfter, bodyText) {
  const body = String(bodyText || '').slice(0, 500);
  if (status === 429) {
    const n = (_wsStrikes.get(slot.id) || 0) + 1;
    _wsStrikes.set(slot.id, n);
    const hinted = (parseInt(retryAfter, 10) || 0) * 1000;
    let ms = Math.min(Math.max(hinted, WS_COOLDOWN.rateLimit * 2 ** (n - 1)), WS_COOLDOWN.rateLimitMax);
    if (/limit:\s*0/i.test(body)) ms = WS_COOLDOWN.quotaZero;
    else if (/PerDay|per\s*day/i.test(body)) ms = WS_COOLDOWN.perDay;
    _wsBlock(slot.id, ms);
  } else if (status === 400) {
    if (/api[_ ]key (?:not valid|invalid|expired)|API_KEY_INVALID|key expired/i.test(body)) _wsBlock(_wsKeyId(slot), WS_COOLDOWN.authKey);
    else _wsBlock(slot.id, WS_COOLDOWN.badRequest);
  } else if (status === 401 || status === 403) {
    _wsBlock(_wsKeyId(slot), WS_COOLDOWN.authKey);
  } else if (status === 404) {
    _wsBlock(_wsModelId(slot), WS_COOLDOWN.modelGone);
  } else if (status >= 500 || status === 408) {
    _wsBlock(slot.id, WS_COOLDOWN.server);
  }
}

async function _wsCallSlot(slot, img, ctrl, timeoutMs, strictEnglish) {
  let timedOut = false;
  const timer = setTimeout(() => { timedOut = true; ctrl.abort(); }, timeoutMs);
  try {
    const req = slot.provider === 'gemini' ? _wsGeminiRequest(slot, img) : _wsChatRequest(slot, img);
    const res = await fetch(req.url, {
      method: 'POST',
      headers: req.headers,
      body: JSON.stringify(req.body),
      signal: ctrl.signal
    });
    if (!res.ok) {
      const errBody = await res.text().catch(() => '');
      _wsOnHttpError(slot, res.status, res.headers.get('retry-after'), errBody);
      return null;
    }
    const data = await res.json();
    let raw;
    if (slot.provider === 'gemini') {
      raw = (data.candidates?.[0]?.content?.parts || [])
        .filter(p => p && p.text && !p.thought).map(p => p.text).join('');
    } else {
      raw = data.choices?.[0]?.message?.content;
    }

    /* ── English-only hard check ── */
    if (window.DVLangGuard && raw && !window.DVLangGuard.isEnglishEnough(raw)) {
      if (!strictEnglish) { _wsBlock(slot.id, WS_COOLDOWN.badOutput); return null; }
      // retry pass: strip and continue
    }

    const parsed = _wsNormalize(_wsParseJSON(raw));
    if (!parsed) { _wsBlock(slot.id, WS_COOLDOWN.badOutput); return null; }

    _wsStrikes.delete(slot.id);
    const keys = (WS_KEYS[slot.provider] || []).filter(Boolean);
    _wsRot[slot.provider] = keys.indexOf(slot.key) + 1;
    return parsed;
  } catch (err) {
    if (timedOut) _wsBlock(slot.id, WS_COOLDOWN.timeout);
    else if (!ctrl.signal.aborted) _wsBlock(slot.id, WS_COOLDOWN.server);
    return null;
  } finally {
    clearTimeout(timer);
  }
}

function _wsCascade(slots, img, cfg, strictEnglish) {
  return new Promise(resolve => {
    let next = 0, inflight = 0, done = false;
    let deadline = null, hedgeTimer = null;
    const ctrls = new Set();
    const preBlocked = new Set(slots.filter(_wsSlotBlocked).map(s => s.id));
    const skipSlot = s => _wsSlotBlocked(s) && !preBlocked.has(s.id);

    const finish = result => {
      if (done) return;
      done = true;
      clearTimeout(deadline); clearTimeout(hedgeTimer);
      ctrls.forEach(c => { try { c.abort(); } catch (_) {} });
      resolve(result);
    };

    const launch = () => {
      if (done || inflight >= cfg.parallel) return;
      while (next < slots.length && skipSlot(slots[next])) next++;
      if (next >= slots.length) { if (!inflight) finish(null); return; }
      const slot = slots[next++];
      const ctrl = new AbortController();
      ctrls.add(ctrl);
      inflight++;
      _wsCallSlot(slot, img, ctrl, cfg.perCall, strictEnglish).then(res => {
        ctrls.delete(ctrl);
        inflight--;
        if (res) finish({ provider: slot.provider, model: slot.model, data: res });
        else launch();
      }).catch(() => {
        ctrls.delete(ctrl);
        inflight--;
        launch();
      });
    };

    deadline = setTimeout(() => finish(null), cfg.total);
    launch();
    hedgeTimer = setTimeout(launch, cfg.hedge);
  });
}

/* ============================================================
   Cache
   ============================================================ */
const _wsCache = new Map();
function _wsImgKey(img) {
  let h = 2166136261 >>> 0;
  const step = Math.max(1, Math.floor(img.length / 4000));
  for (let i = 0; i < img.length; i += step) {
    h ^= img.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return `${img.length}:${h}`;
}
function _wsCacheGet(key) {
  const e = _wsCache.get(key);
  if (!e) return null;
  if (Date.now() - e.t > WS_CACHE_TTL_MS) { _wsCache.delete(key); return null; }
  return e;
}
function _wsCacheSet(key, data, provider, model) {
  _wsCache.set(key, { data, provider, model, t: Date.now() });
  if (_wsCache.size > WS_CACHE_MAX) _wsCache.delete(_wsCache.keys().next().value);
}

async function wsEstimateWeight(img) {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    return { unavailable: true, reason: 'offline' };
  }
  const cacheKey = _wsImgKey(img);
  const hit = _wsCacheGet(cacheKey);
  if (hit) return { data: hit.data, provider: hit.provider, model: hit.model, cached: true };

  const slots = _wsBuildSlots();
  if (!slots.length) return { unavailable: true, reason: 'no_keys' };

  for (let round = 1; round <= 3; round++) {
    const strictEnglish = round === 3;
    let res = null;
    try { res = await _wsCascade(slots, img, WS_TIMING, strictEnglish); }
    catch (_) { res = null; }
    if (res && res.data) {
      _wsCacheSet(cacheKey, res.data, res.provider, res.model);
      return { data: res.data, provider: res.provider, model: res.model, cached: false };
    }
  }
  return { unavailable: true, reason: 'busy' };
}

/* ============================================================
   Scan flow
   ============================================================ */
window.runAiWeightScan = async function () {
  if (wsScanning) return;
  if (!wsSelectedImage) { alert('Please select or take a photo first.'); return; }
  wsScanning = true;

  const scanBtn = _el('wsScanBtn');
  const preview = _el('wsAiPreview');
  const loading = _el('wsAiLoading');
  const result = _el('wsAiResult');
  const applyBtn = _el('wsApplyBtn');

  if (wsPendingFromAI) {
    wsPendingWeight = null;
    wsPendingFromAI = false;
    if (applyBtn) applyBtn.disabled = true;
  }

  if (scanBtn) scanBtn.disabled = true;
  if (preview) preview.style.display = 'none';
  if (result) { result.classList.add('hidden'); result.style.display = 'none'; }
  if (loading) { loading.classList.remove('hidden'); loading.style.display = 'flex'; }

  const hideLoading = () => { if (loading) { loading.classList.add('hidden'); loading.style.display = 'none'; } };

  try {
    const out = await Promise.race([
      wsEstimateWeight(wsSelectedImage),
      new Promise(r => setTimeout(() => r({ unavailable: true, reason: 'busy' }), WS_TIMING.total + WS_WATCHDOG_EXTRA_MS))
    ]);
    hideLoading();
    if (out && out.data) renderWSResult(out.data);
    else renderWSUnavailable(out && out.reason);
  } catch (err) {
    console.error('WS scan error:', err);
    hideLoading();
    renderWSUnavailable('busy');
  } finally {
    wsScanning = false;
    if (scanBtn) scanBtn.disabled = false;
  }
};

/* ============================================================
   Render
   ============================================================ */
function renderWSUnavailable(reason) {
  const resultEl = _el('wsAiResult');
  if (!resultEl) return;
  const msg = reason === 'offline'
    ? 'No internet connection. Try again when online, or use Tape Measure now.'
    : 'AI service is busy, so weight could not be estimated. Try again shortly, or use Tape Measure.';
  const btn = 'border:0;border-radius:10px;padding:8px 14px;font-weight:600;font-size:13px;cursor:pointer;';
  resultEl.innerHTML = `
    <div class="ws-error-box">
      <div class="ws-error-icon"><i class="fas fa-triangle-exclamation"></i></div>
      <div class="ws-error-title">AI is busy</div>
      <div class="ws-error-msg">${escapeHtmlWS(msg)}</div>
      <div style="display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:12px;">
        <button type="button" style="${btn}background:#088F8F;color:#fff;" onclick="runAiWeightScan()">Try again</button>
        <button type="button" style="${btn}background:#e0f0f2;color:#035D69;" onclick="switchWsTab('tape')">Tape Measure</button>
      </div>
    </div>`;
  resultEl.classList.remove('hidden');
  resultEl.style.display = 'flex';
}

function renderWSResult(data) {
  const resultEl = _el('wsAiResult');
  if (!resultEl) return;

  if (!data || data.status === 'error') {
    const errMsg = data?.errorEnglish || data?.error || 'Could not analyze this image.';
    resultEl.innerHTML = `
      <div class="ws-error-box">
        <div class="ws-error-icon"><i class="fas fa-triangle-exclamation"></i></div>
        <div class="ws-error-title">Not Supported</div>
        <div class="ws-error-msg">${escapeHtmlWS(errMsg)}</div>
      </div>`;
    resultEl.classList.remove('hidden');
    resultEl.style.display = 'flex';
    return;
  }

  const weight = data.estimated_weight_kg || 0;
  const range = data.weight_range_kg || {};
  const confidence = data.confidence_percentage || 0;

  if (weight > 0) {
    wsPendingWeight = weight;
    wsPendingFromAI = true;
    const applyBtn = _el('wsApplyBtn');
    if (applyBtn) applyBtn.disabled = false;
  }

  const userImageHTML = wsSelectedImage
    ? `<div class="ws-user-image-wrap"><img src="${wsSelectedImage}" alt="Analyzed Animal" /></div>` : '';

  const row = (label, value, isHighlight = false) => `
    <div class="ws-detail-row">
      <span class="ws-detail-label">${label}</span>
      <span class="ws-detail-value ${isHighlight ? 'highlight' : ''}">${value}</span>
    </div>`;

  resultEl.innerHTML = `
    <div class="ws-result-header">
      <div class="ws-result-header-left">
        <div class="ws-result-icon"><i class="fas fa-check-circle"></i></div>
        <span class="ws-result-title">AI Analysis Complete</span>
      </div>
      <span class="ws-result-badge">${confidence}% confidence</span>
    </div>

    ${userImageHTML}

    <div class="ws-details-card">
      ${row('🐾 Animal', escapeHtmlWS(data.speciesEnglish || '—'))}
      ${row('⚖️ Estimated Weight', `${weight} kg`, true)}
      ${range.min && range.max ? row('📊 Range', `${range.min}–${range.max} kg`) : ''}
      ${data.body_condition ? row('💪 Body Condition', escapeHtmlWS(data.body_condition)) : ''}
    </div>

    ${data.observations ? `
      <div class="ws-observations">
        <div class="ws-observations-inner">
          <i class="fas fa-eye"></i>
          <div><strong>AI Observations</strong><span>${escapeHtmlWS(data.observations)}</span></div>
        </div>
      </div>` : ''}

    ${data.notes ? `
      <div class="ws-notes">
        <div class="ws-notes-inner">
          <i class="fas fa-info-circle"></i>
          <span>${escapeHtmlWS(data.notes)}</span>
        </div>
      </div>` : ''}`;

  resultEl.classList.remove('hidden');
  resultEl.style.display = 'flex';
  resultEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

window.applyEstimatedWeight = function () {
  if (!wsPendingWeight || wsPendingWeight <= 0) return;
  const weightInput = document.getElementById('petWeight');
  if (weightInput) {
    weightInput.value = Number(wsPendingWeight).toFixed(1);
    weightInput.dispatchEvent(new Event('input', { bubbles: true }));
    weightInput.dispatchEvent(new Event('change', { bubbles: true }));
  }
  closeWeightScale();
};

/* ============================================================
   Init
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
  wsCurrentPhone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');

  ['wsCameraInput', 'wsGalleryInput'].forEach(id => {
    const el = _el(id);
    if (el) el.addEventListener('change', handleWsImage);
  });

  const imageField = _el('wsImageField');
  if (imageField) {
    imageField.addEventListener('click', (e) => {
      if (e.target.closest('button')) return;
      const input = _el('wsGalleryInput');
      if (input) input.click();
    });
    imageField.addEventListener('dragover', (e) => {
      e.preventDefault(); e.stopPropagation();
      imageField.classList.add('border-teal', 'bg-teal/5');
    });
    imageField.addEventListener('dragleave', (e) => {
      e.preventDefault(); e.stopPropagation();
      imageField.classList.remove('border-teal', 'bg-teal/5');
    });
    imageField.addEventListener('drop', (e) => {
      e.preventDefault(); e.stopPropagation();
      imageField.classList.remove('border-teal', 'bg-teal/5');
      const imgFile = Array.from(e.dataTransfer?.files || []).find(f => f.type.startsWith('image/'));
      if (imgFile) processWSImageFile(imgFile);
    });
  }

  document.addEventListener('paste', (e) => {
    const modal = _el('weightScaleModal');
    if (!modal || modal.classList.contains('hidden')) return;
    const imageItem = Array.from(e.clipboardData?.items || []).find(i => i.type.indexOf('image') !== -1);
    if (!imageItem) return;
    const file = imageItem.getAsFile();
    if (!file) return;
    e.preventDefault();
    processWSImageFile(file);
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const modal = _el('weightScaleModal');
      if (modal && !modal.classList.contains('hidden')) closeWeightScale();
    }
  });

  console.log('✅ Weight Estimator v4.1 ready (English only)');
});

window.WSDebug = {
  status() {
    const now = Date.now();
    console.table([..._wsBlocks].filter(([until]) => until > now)
      .map(([id, until]) => ({ id, secsLeft: Math.round((until - now) / 1000) })));
    console.log('Usable slots:', _wsBuildSlots().length);
  },
  reset() {
    _wsBlocks.clear(); _wsStrikes.clear();
    _wsLsSet(WS_BLOCK_STORE, '{}');
    console.log('✅ WS block clear');
  },
  clearCache() { _wsCache.clear(); console.log('✅ WS cache cleared'); },
  estimate: wsEstimateWeight
};

})();