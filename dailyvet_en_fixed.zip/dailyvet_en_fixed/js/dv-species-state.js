/* DailyVet — Centralized Species State v1.0
   Resolves duplicate __changeSpecies in climate-dashboard.js + climate-feature.js.

   Usage:
     1. Include this file BEFORE any climate-*.js script.
     2. All modules should call window.DVSpecies.set(id) instead of
        mutating their own local variable.
     3. Subscribe via:
          document.addEventListener('dv:species-changed', e => {
              console.log('Species is now:', e.detail.species);
          });
     4. Legacy `window.__changeSpecies(id)` is aliased for backward compat.
*/
(function () {
'use strict';

const STORAGE_KEY = 'dvClimateSpecies';
const VALID_SPECIES = ['cow', 'buffalo', 'goat', 'sheep', 'chicken', 'duck', 'dog', 'cat'];

function _readStored() {
    try {
        const v = localStorage.getItem(STORAGE_KEY);
        return VALID_SPECIES.includes(v) ? v : null;
    } catch (_) { return null; }
}

let currentSpecies = _readStored() || 'cow';

const DVSpecies = {
    all() { return VALID_SPECIES.slice(); },

    get() { return currentSpecies; },

    set(id) {
        const next = String(id || '').toLowerCase();
        if (!VALID_SPECIES.includes(next)) return false;
        if (next === currentSpecies) return true;
        currentSpecies = next;
        try { localStorage.setItem(STORAGE_KEY, next); } catch (_) {}
        try {
            document.dispatchEvent(new CustomEvent('dv:species-changed', {
                detail: { species: next, previous: currentSpecies }
            }));
        } catch (_) {}
        return true;
    },

    isValid(id) { return VALID_SPECIES.includes(String(id || '').toLowerCase()); },

    KEY: STORAGE_KEY,
    VALID: VALID_SPECIES
};

window.DVSpecies = DVSpecies;

/* Legacy alias — some pages still call window.__changeSpecies(id) */
window.__changeSpecies = function (id) {
    return DVSpecies.set(id);
};

/* Broadcast initial state once DOM is ready, so any module that missed
   the first event can read from DVSpecies.get() */
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        document.dispatchEvent(new CustomEvent('dv:species-changed', {
            detail: { species: currentSpecies, previous: null, initial: true }
        }));
    });
} else {
    document.dispatchEvent(new CustomEvent('dv:species-changed', {
        detail: { species: currentSpecies, previous: null, initial: true }
    }));
}

})();
