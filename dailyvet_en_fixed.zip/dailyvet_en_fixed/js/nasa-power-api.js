/* DailyVet — NASA POWER API Client
   Source: https://power.larc.nasa.gov/docs/services/api/
   Flow:   memory cache -> Firestore cache (24h) -> live NASA POWER call

   v2.0 additions:
   • New parameters: TSOIL (soil temp), T2M_MIN (min temp), ALLSKY_SFC_SW_DWN (solar radiation)
   • getDataFreshness() — per-parameter freshness indicator (fresh / acceptable / stale)
   • Per-parameter cache TTL (soil & solar update slower than air temp)
*/
(function () {
'use strict';

/* ===== START: CONFIG (NASA endpoint, parameters, cache, timeout) ===== */
const POWER_BASE_URL   = 'https://power.larc.nasa.gov/api/temporal/daily/point';
/* T2M/T2M_MAX/T2M_MIN/RH2M -> THI | GWETTOP/GWETROOT/TSOIL -> forage |
   PRECTOTCORR -> disease risk & flood | ALLSKY_SFC_SW_DWN -> solar radiation */
const POWER_PARAMS     = [
    'T2M', 'T2M_MAX', 'T2M_MIN', 'RH2M',
    'GWETTOP', 'GWETROOT', 'TSOIL1',   /* NASA has no plain "TSOIL" -> 422. TSOIL1 = 0-10cm soil temp */
    'PRECTOTCORR', 'ALLSKY_SFC_SW_DWN'
].join(',');

const CACHE_TTL_MS     = 24 * 60 * 60 * 1000; // global default (24h)
const MEM_TTL_MS       = 30 * 60 * 1000;      // in-memory (30 min)
const CACHE_COLLECTION = 'nasa_cache';
const API_TIMEOUT_MS   = 15000;
const RETRY_DELAY_MS   = 800;
const MISSING_VALUE    = -999;

/* ===== START: PER-PARAMETER CACHE TTL =====
   Different NASA POWER parameters update at different rates.
   A single 24h TTL wastes calls for slow-changing soil/solar data,
   and is too slow for fast-changing air temperature. */
const PARAM_TTL_MS = {
    // Air / weather: refreshes daily, keep 12h so users see latest
    T2M:                12 * 60 * 60 * 1000,
    T2M_MAX:            12 * 60 * 60 * 1000,
    T2M_MIN:            12 * 60 * 60 * 1000,
    RH2M:               12 * 60 * 60 * 1000,
    // Precipitation: changes more often during monsoon
    PRECTOTCORR:        6  * 60 * 60 * 1000,
    // Soil moisture/temp: slower changes, 24h is fine
    GWETTOP:            24 * 60 * 60 * 1000,
    GWETROOT:           24 * 60 * 60 * 1000,
    TSOIL:              24 * 60 * 60 * 1000,
    // Solar radiation: reanalysis, 24h is fine
    ALLSKY_SFC_SW_DWN:  24 * 60 * 60 * 1000
};

/* Effective TTL for the whole payload = shortest of the requested params.
   Since we always request all params, this becomes PRECTOTCORR's 6h. */
function _effectiveTTL() {
    let min = Infinity;
    for (const k of Object.keys(PARAM_TTL_MS)) {
        if (PARAM_TTL_MS[k] < min) min = PARAM_TTL_MS[k];
    }
    return min;
}
/* ===== END: PER-PARAMETER CACHE TTL ===== */

const _fs  = () => firebase.firestore();
const _mem = new Map();
/* Where each parameter object came from: 'live' | 'firestore-cache' | 'stale-cache' */
const _meta = new WeakMap();
const _tag = (obj, source) => { if (obj && typeof obj === 'object') _meta.set(obj, source); return obj; };
/* ===== END: CONFIG (NASA endpoint, parameters, cache, timeout) ===== */

/* ===== START: HELPERS (date, cache key, -999 validation, retry check) ===== */
const _sleep = ms => new Promise(r => setTimeout(r, ms));

/** Date -> YYYYMMDD */
function _dateStr(d) {
    return `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
}

/** Coordinates rounded to 2 decimals (~1km) to maximise cache hits. */
function _cacheKey(lat, lng, start, end) {
    return `${Number(lat).toFixed(2)}_${Number(lng).toFixed(2)}_${start}_${end}`;
}

/** NASA uses -999 as the "missing data" sentinel. */
function _isValidValue(v) {
    return typeof v === 'number' && Number.isFinite(v) && v !== MISSING_VALUE;
}

/** Last-good snapshot per location (used as offline fallback). */
function _latestKey(lat, lng) {
    return `latest_${Number(lat).toFixed(2)}_${Number(lng).toFixed(2)}`;
}

/** Age of a YYYYMMDD date in whole days (UTC) -> number | null */
function ageDays(yyyymmdd) {
    if (!yyyymmdd || String(yyyymmdd).length !== 8) return null;
    const s = String(yyyymmdd);
    const t = Date.UTC(+s.slice(0, 4), +s.slice(4, 6) - 1, +s.slice(6, 8));
    if (!Number.isFinite(t)) return null;
    return Math.max(0, Math.floor((Date.now() - t) / 86400000));
}

function _isRetryable(err) {
    return err.name === 'TypeError' || err.retryable === true ||
           err.status === 429 || err.status >= 500;
}
/* ===== END: HELPERS (date, cache key, -999 validation, retry check) ===== */

/* ===== START: NASA POWER API CALL - single request with timeout ===== */
async function _fetchOnce(url) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), API_TIMEOUT_MS);
    try {
        const res = await fetch(url, { signal: controller.signal });
        if (!res.ok) {
            let detail = '';
            try { const j = await res.json(); detail = (j.messages || j.errors || j.message || '').toString(); } catch (_) {}
            const e = new Error(`NASA POWER HTTP ${res.status}` + (detail ? ' - ' + detail : ''));
            e.status = res.status;
            throw e;
        }
        const json = await res.json();
        if (!json || !json.properties || !json.properties.parameter) {
            throw new Error('NASA POWER: unexpected response format');
        }
        const param = json.properties.parameter;
        if (param.TSOIL1 && !param.TSOIL) param.TSOIL = param.TSOIL1; /* keep old key for other files */
        return param;
    } catch (err) {
        if (err.name === 'AbortError') {
            const e = new Error('NASA POWER request timed out');
            e.retryable = true;
            throw e;
        }
        throw err;
    } finally {
        clearTimeout(timer);
    }
}
/* ===== END: NASA POWER API CALL - single request with timeout ===== */

/* ===== START: NASA POWER API CALL - live fetch + one retry ===== */
/**
 * Live NASA POWER call (retries once on timeout / network / 429 / 5xx).
 * @returns {Promise<Object>} { T2M: { "20251001": 28.5, ... }, ... }
 */
async function fetchFromPowerAPI(lat, lng, startDate, endDate) {
    const la = Number(lat);
    const lo = Number(lng);
    if (!Number.isFinite(la) || !Number.isFinite(lo)) {
        throw new Error('NASA POWER: invalid coordinates');
    }

    /* ===== START: BUILD NASA URL ===== */
    const url = `${POWER_BASE_URL}?parameters=${POWER_PARAMS}&community=AG` +
                `&longitude=${lo}&latitude=${la}&start=${startDate}&end=${endDate}&format=JSON`;
    /* ===== END: BUILD NASA URL ===== */

    try {
        return await _fetchOnce(url);
    } catch (err) {
        /* 422 = bad date range (NASA lags real time by days) -> retry once with older window */
        if (err.status === 422) {
            const toD = v => { const t = String(v); return new Date(+t.slice(0,4), +t.slice(4,6) - 1, +t.slice(6,8)); };
            const e2 = toD(endDate); e2.setDate(e2.getDate() - 5);
            const s2 = toD(startDate); s2.setDate(s2.getDate() - 5);
            const url2 = `${POWER_BASE_URL}?parameters=${POWER_PARAMS}&community=AG` +
                         `&longitude=${lo}&latitude=${la}&start=${_dateStr(s2)}&end=${_dateStr(e2)}&format=JSON`;
            return _fetchOnce(url2);
        }
        if (!_isRetryable(err)) throw err;
        await _sleep(RETRY_DELAY_MS);
        return _fetchOnce(url);
    }
}
/* ===== END: NASA POWER API CALL - live fetch + one retry ===== */

/* ===== START: FIRESTORE CACHE - READ (per-parameter TTL) ===== */
async function readCache(cacheKey, allowStale) {
    try {
        const doc = await _fs().collection(CACHE_COLLECTION).doc(cacheKey).get();
        if (!doc.exists) return null;
        const data = doc.data();
        if (!data || !data.cachedAtMs) return null;
        if (!allowStale) {
            const age = Date.now() - data.cachedAtMs;
            const ttl = _effectiveTTL();
            if (age > ttl) return null;
        }
        return data.parameter || null;
    } catch (err) {
        console.warn('[NASA] Cache read failed:', err.message);
        return null;
    }
}
/* ===== END: FIRESTORE CACHE - READ (per-parameter TTL) ===== */

/* ===== START: FIRESTORE CACHE - WRITE ===== */
async function writeCache(cacheKey, parameter) {
    try {
        await _fs().collection(CACHE_COLLECTION).doc(cacheKey).set({
            parameter,
            cachedAtMs: Date.now(),
            cachedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (err) {
        console.warn('[NASA] Cache write failed:', err.message);
    }
}
/* ===== END: FIRESTORE CACHE - WRITE ===== */

/* ===== START: LOAD DATA (Firestore cache first, then NASA API) ===== */
async function _load(lat, lng, startStr, endStr, cacheKey) {
    /* ===== 1. FRESH FIRESTORE CACHE ===== */
    const cached = await readCache(cacheKey);
    if (cached) return _tag(cached, 'firestore-cache');

    try {
        /* ===== 2. LIVE NASA POWER CALL ===== */
        const parameter = await fetchFromPowerAPI(lat, lng, startStr, endStr);

        /* ===== 3. SAVE (never cache an empty response) ===== */
        if (getLatest(parameter, 'T2M')) {
            writeCache(cacheKey, parameter);
            writeCache(_latestKey(lat, lng), parameter);
        }
        return _tag(parameter, 'live');
    } catch (err) {
        /* ===== 4. OFFLINE FALLBACK: last good snapshot for this location ===== */
        const stale = await readCache(_latestKey(lat, lng), true);
        if (stale && getLatest(stale, 'T2M')) {
            console.warn('[NASA] Live call failed, using last saved snapshot:', err.message);
            return _tag(stale, 'stale-cache');
        }
        throw err;
    }
}
/* ===== END: LOAD DATA (Firestore cache first, then NASA API) ===== */

/* ===== START: MAIN GETTER - getPowerData (memory cache + shared request) ===== */
/**
 * Get NASA POWER data for coordinates (last N days).
 * Concurrent / repeated calls for the same key share one request.
 */
function getPowerData(lat, lng, daysBack) {
    daysBack = daysBack || 7;

    /* ===== START: DATE RANGE (last N days) ===== */
    const end = new Date();
    const start = new Date();
    start.setDate(end.getDate() - daysBack);

    const startStr = _dateStr(start);
    const endStr = _dateStr(end);
    const key = _cacheKey(lat, lng, startStr, endStr);
    /* ===== END: DATE RANGE (last N days) ===== */

    /* ===== START: MEMORY CACHE CHECK ===== */
    const hit = _mem.get(key);
    if (hit && Date.now() - hit.at < MEM_TTL_MS) return hit.promise;
    /* ===== END: MEMORY CACHE CHECK ===== */

    /* ===== START: START REQUEST + SHARE WITH CONCURRENT CALLERS ===== */
    const promise = _load(lat, lng, startStr, endStr, key);
    _mem.set(key, { at: Date.now(), promise });
    promise.catch(() => {
        const cur = _mem.get(key);
        if (cur && cur.promise === promise) _mem.delete(key);
    });
    return promise;
    /* ===== END: START REQUEST + SHARE WITH CONCURRENT CALLERS ===== */
}
/* ===== END: MAIN GETTER - getPowerData (memory cache + shared request) ===== */

/* ===== START: DATA PARSERS - getLatest / getSeries ===== */
/** Latest valid value of a parameter -> { value, date } | null */
function getLatest(parameter, key) {
    if (!parameter || !parameter[key]) return null;
    const series = parameter[key];
    const dates = Object.keys(series).sort();
    for (let i = dates.length - 1; i >= 0; i--) {
        if (_isValidValue(series[dates[i]])) {
            return { value: series[dates[i]], date: dates[i] };
        }
    }
    return null;
}

/** Valid time-series of a parameter -> [{ date, value }] */
function getSeries(parameter, key) {
    if (!parameter || !parameter[key]) return [];
    const series = parameter[key];
    return Object.keys(series)
        .sort()
        .map(d => ({ date: d, value: series[d] }))
        .filter(item => _isValidValue(item.value));
}
/* ===== END: DATA PARSERS - getLatest / getSeries ===== */

/* ===== START: DATA FRESHNESS (v2.0 — NEW) =====
   NASA POWER reanalysis data typically lags real time by 2-7 days
   (satellite + model processing delay). Users need to know if they
   are looking at fresh or old data.

   Returns:
     {
       status:   'fresh' | 'acceptable' | 'stale' | 'no-data',
       ageDays:  number|null,       // days since latest T2M date
       dataDate: 'YYYYMMDD'|null,   // latest valid date
       warning:  string|null,       // human-readable warning (if any)
       perParam: { [key]: {date, ageDays, status} }  // per-parameter view
     }
   Callers should use this to show a banner like:
     "⚠️ This data is 5 days old (NASA satellite delay)"
*/
const _FRESHNESS_THRESHOLDS = {
    fresh:      2,   // <= 2 days: OK
    acceptable: 7    // <= 7 days: acceptable but flag it
                     // > 7 days: stale
};

function getDataFreshness(parameter) {
    if (!parameter) {
        return {
            status: 'no-data',
            ageDays: null,
            dataDate: null,
            warning: 'No NASA data available',
            perParam: {}
        };
    }

    // Consider the "reference" parameter T2M for overall freshness,
    // but also report each parameter's own age.
    const paramKeys = Object.keys(PARAM_TTL_MS);
    const perParam = {};
    let oldestAge = 0;
    let refDate = null;

    paramKeys.forEach(k => {
        const latest = getLatest(parameter, k);
        if (!latest) {
            perParam[k] = { date: null, ageDays: null, status: 'no-data' };
            return;
        }
        const age = ageDays(latest.date);
        const ageNum = age == null ? 0 : age;
        let status;
        if (ageNum <= _FRESHNESS_THRESHOLDS.fresh) status = 'fresh';
        else if (ageNum <= _FRESHNESS_THRESHOLDS.acceptable) status = 'acceptable';
        else status = 'stale';

        perParam[k] = { date: latest.date, ageDays: age, status };
        if (ageNum > oldestAge) oldestAge = ageNum;
    });

    // Overall status driven by T2M (the "reference" weather parameter)
    const ref = perParam.T2M;
    let status = 'no-data';
    let warning = null;
    if (ref && ref.date) {
        refDate = ref.date;
        if (ref.ageDays <= _FRESHNESS_THRESHOLDS.fresh) {
            status = 'fresh';
        } else if (ref.ageDays <= _FRESHNESS_THRESHOLDS.acceptable) {
            status = 'acceptable';
            warning = `NASA data is ${ref.ageDays} day${ref.ageDays === 1 ? '' : 's'} old (satellite processing delay)`;
        } else {
            status = 'stale';
            warning = `⚠️ NASA data is ${ref.ageDays} days old — treat as reference only`;
        }
    } else {
        warning = 'No valid temperature data';
    }

    return {
        status,
        ageDays: ref ? ref.ageDays : null,
        dataDate: refDate,
        warning,
        oldestAge,
        perParam
    };
}

/** Short human label for UI chips / badges. */
function freshnessLabel(status) {
    switch (status) {
        case 'fresh':      return 'Live';
        case 'acceptable': return 'Recent';
        case 'stale':      return 'Old';
        case 'no-data':    return 'No data';
        default:           return 'Unknown';
    }
}

/** Suggested CSS color per status (safe for existing theme). */
function freshnessColor(status) {
    switch (status) {
        case 'fresh':      return '#059669'; // green
        case 'acceptable': return '#d97706'; // amber
        case 'stale':      return '#dc2626'; // red
        default:           return '#94a3b8'; // slate
    }
}
/* ===== END: DATA FRESHNESS ===== */

/* ===== START: PUBLIC API - window.NasaPower ===== */
window.NasaPower = {
    getPowerData,
    getLatest,
    getSeries,
    fetchFromPowerAPI,
    getSource: parameter => (parameter && _meta.get(parameter)) || 'unknown',
    ageDays,

    /* v2.0 additions */
    getDataFreshness,
    freshnessLabel,
    freshnessColor,
    PARAM_TTL_MS,
    _effectiveTTL,

    PARAMETERS: POWER_PARAMS.split(',')
};
/* ===== END: PUBLIC API - window.NasaPower ===== */

})();