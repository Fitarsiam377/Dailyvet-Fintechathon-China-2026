/* ============================================================
   DailyVet — Shared GPS Animator v3.0
   Flow:  tap "My Location" -> GPS -> smooth ZOOM-IN animation
          to the user's location -> toast: "Location detected (Name)"
   Works on every page:
     • Leaflet map pages  -> real map.flyTo() zoom-in
     • Non-map pages      -> full-screen zoom-in (rings + pin) overlay
   Usage:
     DVGpsAnimator.locate({
        buttonId | button,     // the My Location button (optional)
        accentColor,           // '#0891b2'
        map,                   // Leaflet map (optional)
        zoom,                  // target zoom for map (default 11)
        findClosest(lat,lng),  // -> { key, nameBn, ... }
        onSuccess(closest, {lat,lng})
     });
   Add BEFORE the page js:  <script src="js/dv-gps-animator.js"></script>
   ============================================================ */
(function () {
'use strict';

const BD = { minLat: 20.0, maxLat: 27.0, minLng: 87.5, maxLng: 93.0 };
let _busy = false;

/* ===== STYLES (injected once) ===== */
function injectStyles() {
    if (document.getElementById('dvGpsAnimStyles')) return;
    const css = `
    @keyframes dvgpsGrid   { 0%{transform:scale(4.2);opacity:0} 25%{opacity:.9} 100%{transform:scale(1);opacity:.55} }
    @keyframes dvgpsRing   { 0%{transform:scale(7);opacity:0} 30%{opacity:.85} 100%{transform:scale(1);opacity:0} }
    @keyframes dvgpsPin    { 0%{transform:translateY(-70px) scale(.4);opacity:0} 60%{transform:translateY(6px) scale(1.1);opacity:1} 100%{transform:translateY(0) scale(1);opacity:1} }
    @keyframes dvgpsDot    { 0%,100%{transform:scale(1);opacity:.5} 50%{transform:scale(2.4);opacity:0} }
    @keyframes dvgpsToastIn{ 0%{transform:translate(-50%,-30px);opacity:0} 100%{transform:translate(-50%,0);opacity:1} }
    @keyframes dvgpsToastOut{0%{opacity:1} 100%{transform:translate(-50%,-20px);opacity:0}}
    @keyframes dvgpsBar    { 0%{width:100%} 100%{width:0} }
    .dvgps-overlay{position:fixed;inset:0;z-index:99998;display:flex;align-items:center;justify-content:center;
        background:radial-gradient(circle at center,rgba(15,23,42,.35),rgba(15,23,42,.82));
        backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px);overflow:hidden;transition:opacity .45s ease}
    .dvgps-overlay.out{opacity:0}
    .dvgps-grid{position:absolute;inset:-20%;opacity:0;animation:dvgpsGrid 1.7s cubic-bezier(.2,.8,.2,1) forwards;
        background-image:linear-gradient(rgba(255,255,255,.18) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.18) 1px,transparent 1px);
        background-size:46px 46px}
    .dvgps-center{position:relative;width:120px;height:120px;display:flex;align-items:center;justify-content:center}
    .dvgps-ring{position:absolute;inset:0;border-radius:50%;border:3px solid var(--dvgps-c,#2563eb);opacity:0;
        animation:dvgpsRing 1.7s cubic-bezier(.2,.8,.2,1) forwards}
    .dvgps-ring:nth-child(2){animation-delay:.18s}
    .dvgps-ring:nth-child(3){animation-delay:.36s}
    .dvgps-pulse{position:absolute;width:18px;height:18px;border-radius:50%;background:var(--dvgps-c,#2563eb);
        animation:dvgpsDot 1.2s ease-in-out 1.0s infinite}
    .dvgps-pin{position:relative;z-index:2;opacity:0;animation:dvgpsPin .7s cubic-bezier(.3,1.4,.5,1) .85s forwards;
        filter:drop-shadow(0 6px 10px rgba(0,0,0,.45))}
    .dvgps-label{position:absolute;bottom:18%;left:0;right:0;text-align:center;color:#fff;font:700 14px/1.3 system-ui,sans-serif;
        letter-spacing:.3px;text-shadow:0 2px 8px rgba(0,0,0,.5)}
    .dvgps-toast-wrap{position:fixed;top:14px;left:50%;transform:translateX(-50%);z-index:100000;pointer-events:none;
        width:min(92vw,380px)}
    .dvgps-toast{position:absolute;top:0;left:50%;width:100%;transform:translate(-50%,0);pointer-events:auto;
        background:#fff;border-radius:14px;box-shadow:0 12px 32px rgba(15,23,42,.25);overflow:hidden;
        display:flex;align-items:center;gap:12px;padding:12px 14px;border-left:5px solid var(--dvgps-c,#059669);
        font-family:system-ui,-apple-system,'Segoe UI',sans-serif;animation:dvgpsToastIn .45s cubic-bezier(.2,.9,.3,1.2) both}
    .dvgps-toast.out{animation:dvgpsToastOut .35s ease forwards}
    .dvgps-toast-ic{flex:0 0 38px;height:38px;border-radius:50%;background:var(--dvgps-c,#059669);color:#fff;
        display:flex;align-items:center;justify-content:center}
    .dvgps-toast-t{font-weight:800;font-size:14px;color:#0f172a;line-height:1.25}
    .dvgps-toast-t span{color:var(--dvgps-c,#059669)}
    .dvgps-toast-s{font-size:11.5px;color:#64748b;margin-top:2px}
    .dvgps-toast-bar{position:absolute;left:0;bottom:0;height:3px;background:var(--dvgps-c,#059669);opacity:.55;
        animation:dvgpsBar 4s linear forwards}
    @media (prefers-reduced-motion: reduce){
        .dvgps-grid,.dvgps-ring,.dvgps-pin,.dvgps-pulse{animation-duration:.01s;animation-delay:0s}
    }`;
    const el = document.createElement('style');
    el.id = 'dvGpsAnimStyles';
    el.textContent = css;
    document.head.appendChild(el);
}

const PIN_SVG = c => `<svg width="46" height="58" viewBox="0 0 24 30" xmlns="http://www.w3.org/2000/svg"><path d="M12 0C5.9 0 1 4.9 1 11c0 8 11 19 11 19s11-11 11-19C23 4.9 18.1 0 12 0z" fill="${c}"/><circle cx="12" cy="11" r="4.6" fill="#fff"/></svg>`;
const CHECK_SVG = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7"/></svg>`;
const WARN_SVG  = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.6" stroke-linecap="round"><path d="M12 7v6M12 17h.01"/></svg>`;

const _esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
const _sleep = ms => new Promise(r => setTimeout(r, ms));
const _reduced = () => window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ===== TOAST: "Location detected (Name)" ===== */
function toast(opts) {
    injectStyles();
    const o = opts || {};
    const color = o.color || '#059669';
    let wrap = document.getElementById('dvGpsToastWrap');
    if (!wrap) {
        wrap = document.createElement('div');
        wrap.id = 'dvGpsToastWrap';
        wrap.className = 'dvgps-toast-wrap';
        document.body.appendChild(wrap);
    }
    wrap.innerHTML = '';
    const t = document.createElement('div');
    t.className = 'dvgps-toast';
    t.style.setProperty('--dvgps-c', color);
    t.innerHTML = `
        <div class="dvgps-toast-ic">${o.error ? WARN_SVG : CHECK_SVG}</div>
        <div style="min-width:0">
            <div class="dvgps-toast-t">${_esc(o.title)}${o.name ? ` <span>(${_esc(o.name)})</span>` : ''}</div>
            ${o.sub ? `<div class="dvgps-toast-s">${_esc(o.sub)}</div>` : ''}
        </div>
        <div class="dvgps-toast-bar"></div>`;
    wrap.appendChild(t);
    const life = o.duration || 4000;
    setTimeout(() => {
        t.classList.add('out');
        setTimeout(() => { if (t.parentNode) t.parentNode.removeChild(t); }, 380);
    }, life);
}

/* ===== ZOOM-IN: full-screen overlay (non-map pages) ===== */
async function playOverlayZoom(color, label) {
    injectStyles();
    const ov = document.createElement('div');
    ov.className = 'dvgps-overlay';
    ov.style.setProperty('--dvgps-c', color);
    ov.innerHTML = `
        <div class="dvgps-grid"></div>
        <div class="dvgps-center">
            <div class="dvgps-ring"></div><div class="dvgps-ring"></div><div class="dvgps-ring"></div>
            <div class="dvgps-pulse"></div>
            <div class="dvgps-pin">${PIN_SVG(color)}</div>
        </div>
        <div class="dvgps-label">${_esc(label || 'Zooming to your location...')}</div>`;
    document.body.appendChild(ov);
    await _sleep(_reduced() ? 250 : 2000);
    ov.classList.add('out');
    await _sleep(420);
    if (ov.parentNode) ov.parentNode.removeChild(ov);
}

/* ===== ZOOM-IN: real Leaflet flyTo (map pages) ===== */
function flyMap(map, lat, lng, zoom) {
    return new Promise(resolve => {
        let done = false;
        const fin = () => { if (!done) { done = true; resolve(); } };
        try {
            map.once('moveend', fin);
            map.flyTo([lat, lng], zoom, { duration: _reduced() ? 0.1 : 2.2, easeLinearity: 0.25 });
        } catch (_) { fin(); }
        setTimeout(fin, 3400);
    });
}

/* ===== MAIN ===== */
function locate(opts) {
    const o = opts || {};
    const color = o.accentColor || '#2563eb';
    const btn = o.button || (o.buttonId ? document.getElementById(o.buttonId) : null);
    if (_busy) return;

    const origHtml = btn ? btn.innerHTML : '';
    function setLoading() {
        if (!btn) return;
        btn.classList.add('loading');
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>Locating...</span>';
        btn.style.opacity = '0.7';
        btn.style.pointerEvents = 'none';
    }
    function resetBtn(html) {
        if (!btn) return;
        btn.classList.remove('loading');
        btn.innerHTML = html || origHtml || '<i class="fas fa-crosshairs"></i> <span>My Location</span>';
        btn.style.opacity = '1';
        btn.style.pointerEvents = 'auto';
    }
    function fail(msg) {
        _busy = false;
        resetBtn();
        toast({ error: true, color: '#dc2626', title: msg });
        if (typeof o.onError === 'function') { try { o.onError(msg); } catch (_) {} }
    }

    if (!navigator.geolocation) { fail('Your browser does not support geolocation.'); return; }

    _busy = true;
    injectStyles();
    setLoading();

    navigator.geolocation.getCurrentPosition(
        async pos => {
            const lat = pos.coords.latitude;
            const lng = pos.coords.longitude;

            if (!(lat >= BD.minLat && lat <= BD.maxLat && lng >= BD.minLng && lng <= BD.maxLng)) {
                fail('Your location (' + lat.toFixed(2) + ', ' + lng.toFixed(2) + ') is outside Bangladesh.');
                return;
            }

            let closest = null;
            try { closest = typeof o.findClosest === 'function' ? await o.findClosest(lat, lng) : null; }
            catch (err) { console.warn('[GPS] findClosest failed:', err && err.message); }
            const name = (closest && (closest.nameBn || closest.name)) || 'My Location';

            /* ===== ZOOM-IN ===== */
            try {
                if (o.map && typeof o.map.flyTo === 'function') await flyMap(o.map, lat, lng, o.zoom || 11);
                else await playOverlayZoom(color, 'Zooming to your location...');
            } catch (err) { console.warn('[GPS] animation failed:', err && err.message); }

            /* ===== NOTIFICATION: Location detected (Name) ===== */
            toast({ title: 'Location detected', name: name, sub: 'GPS: ' + lat.toFixed(3) + ', ' + lng.toFixed(3), color: color });

            resetBtn('<i class="fas fa-location-dot"></i> <span>' + _esc(String(name).split(' ')[0]) + '</span>');
            _busy = false;

            if (typeof o.onSuccess === 'function') {
                try { await o.onSuccess(closest || { key: null, nameBn: name }, { lat: lat, lng: lng }); }
                catch (err) { console.warn('[GPS] onSuccess failed:', err && err.message); }
            }
        },
        err => {
            let msg = 'Location could not be found.';
            if (err.code === 1) msg = 'Location permission denied. Please allow location access.';
            else if (err.code === 2) msg = 'GPS signal not available.';
            else if (err.code === 3) msg = 'Location request timed out. Please try again.';
            fail(msg);
        },
        { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
}

window.DVGpsAnimator = { locate: locate, toast: toast, playOverlayZoom: playOverlayZoom };

})();
