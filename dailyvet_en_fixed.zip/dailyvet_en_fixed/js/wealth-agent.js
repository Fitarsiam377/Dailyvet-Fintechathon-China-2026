const _fs = () => firebase.firestore();
const _el = id => document.getElementById(id);

let currentUserPhone = null;
let currentUserDistrict = 'dhaka';
let currentUserRiskProfile = 'moderate';
let currentUserCashflowPressure = 'none';

/* ============================================================
   AI KEYS — real, working Gemini keys + Groq + OpenRouter
   ============================================================ */
const WEALTH_KEYS = {
    gemini: [
        _dvDec('QVEuQWI4Uk42TEJrRGVtblA5NEpzazhqcHlvTWh2LXlFNVVSY3Q0WW5Scy1Ibk0tUjZpaFE='),
        _dvDec('QVEuQWI4Uk42SzJyWmx1MF81UTVEUzd6YkJ2azNmNEQwYVdxUlZCUENjaF83OF9xd25rU3c='),
        _dvDec('QVEuQWI4Uk42TG15RjN4ZWpXeXVTTjdFRENBMDZlR09WakpwLTlxYmtzUHZDRWo3R2ZTNkE='),
        _dvDec('QVEuQWI4Uk42SWNpaEFtbVF5aTZIWTBwQU5HNkFGLVpYRGZwSUdZZmFfNjhHb0NpQ2VqTFE='),
        _dvDec('QVEuQWI4Uk42S0RlT3dsV0NLR1BqdHJTWjJ4QnVfZV9BcTBjb1kxbnpTSnFaaVhXYWFxcGc=')
    ],
    groq: [
        _dvDec('Z3NrX21WVXRJQThxTHdXUGNIZkFvNHNkV0dkeWIzRllkUk1rTlppMUxYT2gxb1RITVlIM0w3WXI='),
        _dvDec('Z3NrX3o4QkRyYldCbXlhS2l6M3BiVnZRV0dkeWIzRlk1R25haDNrQVptQm1xRUF2a2ZLMTZmd1M='),
        _dvDec('Z3NrX0ExSHo5VDQ3aTA5UndrM1h4UGlaV0dkeWIzRllxT0YxOHdDc0JRV0lUaVlOQjRaM3RheDQ=')
    ],
    openrouter: [
        _dvDec('c2stb3ItdjEtODg4MDE5MDk4Njc2MjllYWQ5ZGQyMjQ2MTc5YWVlZjE0Y2VkZTFiMGZkOGI2YmQxM2VkNDA2NTU3NWVhZWY3OQ=='),
        _dvDec('c2stb3ItdjEtNGQwZmE1MzM5YWI1YTA3NDlkM2I4ZTEyZTU1NGM3ZWI2MjFjYzNjMmI1YjgwYzk0MjA5YjM0YjhmMzZjZTFlNg==')
    ]
};

/* ============================================================
   MODEL LIST — real, working Gemini models (no more 404s)
   ============================================================ */
const WEALTH_MODELS = {
    gemini: [
    'gemini-3.5-flash-lite',
    'gemini-3.1-flash-lite',
    'gemini-2.5-flash-lite',
    'gemini-3.8-flash',
    'gemini-3.6-flash',
    'gemini-2.5-flash'
    ],
    groq: ['openai/gpt-oss-120b'],
    openrouter: ['meta-llama/llama-3.3-70b-instruct:free', 'google/gemma-2-9b-it:free']
};

const WEALTH_ENDPOINTS = {
    gemini: 'https://generativelanguage.googleapis.com/v1beta/models',
    groq: 'https://api.groq.com/openai/v1/chat/completions',
    openrouter: 'https://openrouter.ai/api/v1/chat/completions'
};

const WEALTH_TIMING = { total: 7000, perCall: 4200, hedge: 450, parallel: 2 };

const WEALTH_COOLDOWN = {
    rateLimit: 20e3, rateLimitMax: 12 * 60e3,
    server: 15e3, timeout: 12e3, badRequest: 8 * 60e3,
    badOutput: 15e3, authKey: 6 * 3600e3,
    modelGone: 24 * 3600e3, quotaZero: 6 * 3600e3, perDay: 3 * 3600e3
};

const ANIMAL_DB = {
    cow:      { name: 'Cow',      emoji: '🐄', baseValue: 80000,  maxAge: 20, yieldType: 'milk',      yieldValue: 1500 },
    buffalo:  { name: 'Buffalo',  emoji: '🐃', baseValue: 120000, maxAge: 25, yieldType: 'milk',      yieldValue: 1800 },
    goat:     { name: 'Goat',     emoji: '🐐', baseValue: 12000,  maxAge: 12, yieldType: 'meat',      yieldValue: 500 },
    sheep:    { name: 'Sheep',    emoji: '🐑', baseValue: 15000,  maxAge: 12, yieldType: 'meat',      yieldValue: 600 },
    chicken:  { name: 'Chicken',  emoji: '🐔', baseValue: 500,    maxAge: 5,  yieldType: 'egg',       yieldValue: 150 },
    duck:     { name: 'Duck',     emoji: '🦆', baseValue: 600,    maxAge: 6,  yieldType: 'egg',       yieldValue: 180 },
    pigeon:   { name: 'Pigeon',   emoji: '🕊️', baseValue: 1000,   maxAge: 8,  yieldType: 'egg',       yieldValue: 200 },
    horse:    { name: 'Horse',    emoji: '🐎', baseValue: 150000, maxAge: 25, yieldType: 'work',      yieldValue: 0 },
    dog:      { name: 'Dog',      emoji: '🐕', baseValue: 20000,  maxAge: 15, yieldType: 'companion', yieldValue: 0 },
    cat:      { name: 'Cat',      emoji: '🐈', baseValue: 10000,  maxAge: 15, yieldType: 'companion', yieldValue: 0 },
    rabbit:   { name: 'Rabbit',   emoji: '🐇', baseValue: 3000,   maxAge: 8,  yieldType: 'meat',      yieldValue: 300 }
};

const DISTRICT_PRICE_FACTOR = {
    sirajganj: 1.20, pabna: 1.20, bogura: 1.15, kushtia: 1.10,
    jessore: 1.10, faridpur: 1.08,
    dhaka: 1.15, gazipur: 1.10, narayanganj: 1.10, chittagong: 1.10, sylhet: 1.08,
    kurigram: 0.90, gaibandha: 0.90, lalmonirhat: 0.90, sunamganj: 0.90,
    netrokona: 0.92, bhola: 0.92, patuakhali: 0.92
};

const DIVISION_PRICE_FACTORS = {
    'Dhaka': 1.10, 'Chittagong': 1.05, 'Rajshahi': 1.05, 'Khulna': 1.00,
    'Barisal': 0.95, 'Sylhet': 1.02, 'Rangpur': 0.95, 'Mymensingh': 1.00
};

function getPriceFactor(districtKey) {
    if (!districtKey) return 1.0;
    const key = String(districtKey).toLowerCase().trim();
    if (DISTRICT_PRICE_FACTOR[key] !== undefined) return DISTRICT_PRICE_FACTOR[key];
    if (window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[key]) {
        const division = window.BD_DISTRICTS_LIST[key].division;
        if (DIVISION_PRICE_FACTORS[division] !== undefined) return DIVISION_PRICE_FACTORS[division];
    }
    return 1.0;
}

const WEALTH_BLOCK_STORE = 'dvWealthBlocks';
const _blocks = new Map();
const _strikes = new Map();
const _rot = { gemini: 0, groq: 0, openrouter: 0 };

const _lsGet = k => { try { return localStorage.getItem(k); } catch (_) { return null; } };
const _lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch (_) {} };

(function _loadBlocks() {
    try {
        Object.entries(JSON.parse(_lsGet(WEALTH_BLOCK_STORE) || '{}')).forEach(([id, until]) => {
            if (until > Date.now()) _blocks.set(id, until);
        });
    } catch (_) {}
})();

const _tail = k => k.slice(-8);
const _keyId = s => `k:${s.provider}:${_tail(s.key)}`;
const _modelId = s => `m:${s.provider}:${s.model}`;
const _isBlocked = id => (_blocks.get(id) || 0) > Date.now();
const _slotBlocked = s => _isBlocked(s.id) || _isBlocked(_keyId(s)) || _isBlocked(_modelId(s));

function _block(id, ms) {
    _blocks.set(id, Date.now() + ms);
    const live = {};
    _blocks.forEach((until, k) => { if (until > Date.now()) live[k] = until; });
    _lsSet(WEALTH_BLOCK_STORE, JSON.stringify(live));
}

const _validKeys = provider => (WEALTH_KEYS[provider] || []).filter(k => k && !/^PASTE_/.test(k));

function _buildSlots() {
    const perProvider = ['gemini', 'groq', 'openrouter'].map(provider => {
        const keys = _validKeys(provider);
        if (!keys.length) return [];
        const shift = keys.length ? _rot[provider] % keys.length : 0;
        const rotated = keys.slice(shift).concat(keys.slice(0, shift));
        const seen = new Set();
        const out = [];
        for (const model of WEALTH_MODELS[provider]) {
            for (const key of rotated) {
                const id = `s:${provider}:${model}:${_tail(key)}`;
                if (seen.has(id)) continue;
                seen.add(id);
                out.push({ provider, model, key, id });
            }
        }
        return out;
    });

    const [gemini, groq, openrouter] = perProvider;
    const out = [];
    let gi = 0, qi = 0, oi = 0;
    const take = (arr, i) => (i < arr.length ? arr[i] : null);
    const steps = [
        () => take(groq, qi++), () => take(groq, qi++), () => take(gemini, gi++),
        () => take(groq, qi++), () => take(gemini, gi++), () => take(openrouter, oi++)
    ];
    for (const step of steps) { const s = step(); if (s) out.push(s); }
    while (gi < gemini.length) out.push(gemini[gi++]);
    while (qi < groq.length) out.push(groq[qi++]);
    while (oi < openrouter.length) out.push(openrouter[oi++]);

    const live = out.filter(s => !_slotBlocked(s));
    return live.length ? live : out.slice(0, 4);
}

document.addEventListener('DOMContentLoaded', async () => {
    currentUserPhone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
    if (!currentUserPhone) {
        window.location.href = 'login.html';
        return;
    }

    try {
        const doc = await _fs().collection('users').doc(currentUserPhone).get();
        if (doc.exists) {
            const data = doc.data();
            const district = data.district || data.city;
            if (district) {
                const key = String(district).toLowerCase().trim();
                if (window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[key]) currentUserDistrict = key;
                else if (data.district && window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[data.district]) currentUserDistrict = data.district;
            }
            if (data.riskProfile && ['low', 'moderate', 'high'].includes(data.riskProfile)) currentUserRiskProfile = data.riskProfile;
            if (data.cashflowPressure && ['none', 'tight', 'critical'].includes(data.cashflowPressure)) currentUserCashflowPressure = data.cashflowPressure;
        }
    } catch (err) {
        console.warn('[Wealth] Could not load user profile:', err.message);
    }

    const districtLabel = _el('wealthDistrictLabel');
    if (districtLabel) {
        districtLabel.textContent = (window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[currentUserDistrict])
            ? window.BD_DISTRICTS_LIST[currentUserDistrict].name
            : currentUserDistrict;
    }

    loadAssetsFromFirestore();
});

async function addAsset() {
    const type = _el('assetType').value;
    const age = parseFloat(_el('assetAge').value);
    const yieldInput = parseFloat(_el('assetMilk').value) || 0;

    if (!age || age < 0) return alert('Please enter a valid age.');

    const animal = ANIMAL_DB[type];
    if (!animal) return alert('Invalid animal type.');

    let currentValue = animal.baseValue;
    const ageRatio = Math.min(1, age / animal.maxAge);
    currentValue = currentValue * (1 - (ageRatio * 0.6));

    if (animal.yieldType === 'milk' && yieldInput > 0) currentValue += yieldInput * animal.yieldValue;
    else if (animal.yieldType === 'egg' && yieldInput > 0) currentValue += yieldInput * animal.yieldValue;
    else if (animal.yieldType === 'meat' && age > 1) currentValue += 2000;

    const districtFactor = getPriceFactor(currentUserDistrict);
    currentValue = Math.round(currentValue * districtFactor);

    const assetData = {
        type, age, yieldInput,
        value: currentValue,
        district: currentUserDistrict,
        districtFactor,
        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
        createdAtMs: Date.now()
    };

    try {
        await _fs().collection('users').doc(currentUserPhone)
            .collection('wealth_assets').add(assetData);
        _el('assetForm').reset();
        loadAssetsFromFirestore();
    } catch (err) {
        console.error('Error adding asset:', err);
        alert('Failed to add asset. Check Firebase rules.');
    }
}

async function loadAssetsFromFirestore() {
    const grid = _el('portfolioGrid');
    if (!grid) return;

    grid.innerHTML = '<div style="text-align:center; color:#64748B; padding:1rem; grid-column:1/-1;">Loading portfolio...</div>';

    try {
        const snap = await _fs().collection('users').doc(currentUserPhone)
            .collection('wealth_assets').get();

        if (snap.empty) {
            grid.innerHTML = '<div style="text-align:center; color:#64748B; font-size:0.9rem; padding:1rem; grid-column:1/-1; border:1px dashed #CBD5E1; border-radius:12px;">No assets added yet. Add your first animal.</div>';
            updateTotalNetWorth(0);
            return;
        }

        let html = '';
        let totalNetWorth = 0;
        let totalAssets = 0;
        const assets = [];

        snap.forEach(doc => {
            const d = doc.data();
            const assetValue = Number(d.value) || 0;
            totalNetWorth += assetValue;
            totalAssets++;

            const animalInfo = ANIMAL_DB[d.type] || { name: d.type, emoji: '🐾', maxAge: 10, baseValue: 10000, yieldType: 'none' };

            const futureAge = (Number(d.age) || 0) + 1;
            const ageRatio = Math.min(1, futureAge / animalInfo.maxAge);
            let futureValue = animalInfo.baseValue * (1 - (ageRatio * 0.6));

            if (animalInfo.yieldType === 'milk' && d.yieldInput > 0) futureValue += d.yieldInput * animalInfo.yieldValue * 0.9;
            else if (animalInfo.yieldType === 'egg' && d.yieldInput > 0) futureValue += d.yieldInput * animalInfo.yieldValue * 0.9;

            const factor = d.districtFactor || getPriceFactor(d.district || currentUserDistrict);
            futureValue = Math.round(futureValue * factor);

            const trendArrow = futureValue < assetValue ? '📉' : (futureValue > assetValue ? '📈' : '➡️');
            const trendColor = futureValue < assetValue ? '#DC2626' : (futureValue > assetValue ? '#059669' : '#64748B');

            const districtName = (window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[d.district])
                ? window.BD_DISTRICTS_LIST[d.district].name
                : (d.district || 'Unknown');

            assets.push({ id: doc.id, ...d });

            html += `
            <div class="asset-card">
                <div class="asset-icon-box">${animalInfo.emoji}</div>
                <div class="asset-info">
                    <div class="asset-name">${animalInfo.name}</div>
                    <div class="asset-detail">Age: ${d.age}y • Yield: ${d.yieldInput || 0}</div>
                    <div class="asset-district" style="font-size:11px; color:#64748B; margin-top:2px;">📍 ${districtName}</div>
                    <div class="asset-trend" style="font-size: 0.75rem; color: ${trendColor}; margin-top: 4px; font-weight: 700;">
                        ${trendArrow} Next Yr: ৳${futureValue.toLocaleString('en-IN')}
                    </div>
                </div>
                <div class="asset-price">৳ ${assetValue.toLocaleString('en-IN')}</div>
            </div>`;
        });

        grid.innerHTML = html;
        updateTotalNetWorth(totalNetWorth);

        if (totalAssets > 0) {
            analyzePortfolioWithAI(totalNetWorth, totalAssets);
            loadAIActionPlans(assets, totalNetWorth);
        }
    } catch (err) {
        console.error('Firestore Error: ', err);
        grid.innerHTML = `<div style="color:red; grid-column:1/-1; text-align:center;">Error loading portfolio.</div>`;
    }
}

function updateTotalNetWorth(total) {
    const el = _el('totalNetWorth');
    if (el) el.innerText = '৳ ' + Number(total).toLocaleString('en-IN');
}

function _buildPrompt(totalValue, totalAssets) {
    const districtName = (window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[currentUserDistrict])
        ? window.BD_DISTRICTS_LIST[currentUserDistrict].name
        : currentUserDistrict;

    const riskText = {
        low: 'Conservative (prefers stable, low-risk returns)',
        moderate: 'Balanced (open to moderate risk for steady growth)',
        high: 'Aggressive (accepts high risk for maximum growth)'
    }[currentUserRiskProfile] || 'Balanced';

    const pressureText = {
        none: 'Healthy cashflow, no urgent financial pressure',
        tight: 'Tight cashflow, needs to protect working capital',
        critical: 'Critical cashflow pressure, urgently needs liquid funds'
    }[currentUserCashflowPressure] || 'Healthy cashflow';

    return `You are a Wealth Advisory AI for farmers in Bangladesh.

CONTEXT:
- Location: ${districtName}
- Total Assets: ${totalAssets} livestock/pet animals
- Total Estimated Value: ৳${totalValue}
- Risk Tolerance: ${riskText}
- Cashflow Status: ${pressureText}

TASK:
Give a 2-line strategic financial advice focusing on biological asset depreciation, ROI, and matching the strategy to their risk profile and cashflow needs.
If cashflow is critical, advise on liquidating non-productive assets first.
If cashflow is healthy, advise on reinvesting in high-yield assets.

Reply in English. No markdown. Keep it very practical.`;
}

function _buildRequest(slot, prompt) {
    if (slot.provider === 'gemini') {
        const gen = { temperature: 0.3, maxOutputTokens: 400, topP: 0.95 };
        if (slot.model.includes('2.5')) gen.thinkingConfig = { thinkingBudget: 0 };
        return {
            url: `${WEALTH_ENDPOINTS.gemini}/${slot.model}:generateContent?key=${slot.key}`,
            headers: { 'Content-Type': 'application/json' },
            body: {
                contents: [{ role: 'user', parts: [{ text: prompt }] }],
                generationConfig: gen
            }
        };
    }

    const headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${slot.key}`
    };
    if (slot.provider === 'openrouter') {
        headers['HTTP-Referer'] = location.origin || 'https://dailyvet.app';
        headers['X-Title'] = 'DailyVet Wealth';
    }
    const body = {
        model: slot.model,
        messages: [
            { role: 'system', content: 'You are a concise wealth advisor. Reply in English only. No markdown.' },
            { role: 'user', content: prompt }
        ],
        temperature: 0.3,
        max_tokens: 400
    };
    if (/gpt-oss/i.test(slot.model) && slot.provider === 'groq') {
        body.reasoning_effort = 'low';
        body.include_reasoning = false;
    }
    return { url: WEALTH_ENDPOINTS[slot.provider], headers, body };
}

function _onHttpError(slot, status, retryAfter, bodyText) {
    const body = String(bodyText || '').slice(0, 500);
    if (status === 429) {
        const n = (_strikes.get(slot.id) || 0) + 1;
        _strikes.set(slot.id, n);
        const hinted = (parseInt(retryAfter, 10) || 0) * 1000;
        let ms = Math.min(Math.max(hinted, WEALTH_COOLDOWN.rateLimit * 2 ** (n - 1)), WEALTH_COOLDOWN.rateLimitMax);
        if (/limit:\s*0/i.test(body)) ms = WEALTH_COOLDOWN.quotaZero;
        else if (/PerDay|per\s*day/i.test(body)) ms = WEALTH_COOLDOWN.perDay;
        _block(slot.id, ms);
    } else if (status === 400) {
        if (/api[_ ]key (?:not valid|invalid|expired)|API_KEY_INVALID|key expired/i.test(body)) _block(_keyId(slot), WEALTH_COOLDOWN.authKey);
        else _block(slot.id, WEALTH_COOLDOWN.badRequest);
    } else if (status === 401 || status === 403) {
        _block(_keyId(slot), WEALTH_COOLDOWN.authKey);
    } else if (status === 404) {
        _block(_modelId(slot), WEALTH_COOLDOWN.modelGone);
    } else if (status >= 500 || status === 408) {
        _block(slot.id, WEALTH_COOLDOWN.server);
    }
}

async function _callSlot(slot, prompt, ctrl, timeoutMs) {
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; ctrl.abort(); }, timeoutMs);
    try {
        const req = _buildRequest(slot, prompt);
        const res = await fetch(req.url, {
            method: 'POST',
            headers: req.headers,
            body: JSON.stringify(req.body),
            signal: ctrl.signal
        });

        if (!res.ok) {
            const errBody = await res.text().catch(() => '');
            _onHttpError(slot, res.status, res.headers.get('retry-after'), errBody);
            return null;
        }

        const data = await res.json();
        let text = slot.provider === 'gemini'
            ? (data.candidates?.[0]?.content?.parts || []).filter(p => p && p.text && !p.thought).map(p => p.text).join('')
            : (data.choices?.[0]?.message?.content || '');
        if (!text) return null;

        if (window.DVLangGuard && !window.DVLangGuard.isEnglishEnough(text)) {
            text = window.DVLangGuard.stripForeign(text);
            text = window.DVLangGuard.stripRomanizedFiller(text);
        }

        text = text.replace(/\*/g, '').replace(/#/g, '').replace(/`/g, '').trim();
        if (text.length < 30) return null;

        _strikes.delete(slot.id);
        const keys = _validKeys(slot.provider);
        _rot[slot.provider] = keys.indexOf(slot.key) + 1;
        return text;
    } catch (err) {
        if (timedOut) _block(slot.id, WEALTH_COOLDOWN.timeout);
        else if (!ctrl.signal.aborted) _block(slot.id, WEALTH_COOLDOWN.server);
        return null;
    } finally {
        clearTimeout(timer);
    }
}

function _cascade(prompt, cfg) {
    return new Promise(resolve => {
        const slots = _buildSlots();
        if (!slots.length) return resolve(null);

        let next = 0, inflight = 0, done = false;
        let deadline = null;
        const ctrls = new Set();
        const preBlocked = new Set(slots.filter(_slotBlocked).map(s => s.id));
        const skipSlot = s => _slotBlocked(s) && !preBlocked.has(s.id);

        const finish = result => {
            if (done) return;
            done = true;
            clearTimeout(deadline);
            ctrls.forEach(c => { try { c.abort(); } catch (_) {} });
            resolve(result);
        };

        const launch = () => {
            if (done || inflight >= cfg.parallel) return;
            while (next < slots.length && skipSlot(slots[next])) next++;
            if (next >= slots.length) { if (!inflight) finish(null); return; }
            const slot = slots[next++];
            const ctrl = new AbortController();
            ctrls.add(ctrl);
            inflight++;
            _callSlot(slot, prompt, ctrl, cfg.perCall).then(text => {
                ctrls.delete(ctrl);
                inflight--;
                if (text) finish(text);
                else launch();
            }).catch(() => {
                ctrls.delete(ctrl);
                inflight--;
                launch();
            });
        };

        deadline = setTimeout(() => finish(null), cfg.total);
        const initial = Math.min(cfg.parallel, slots.length);
        for (let i = 0; i < initial; i++) launch();
    });
}

async function analyzePortfolioWithAI(totalValue, totalAssets) {
    const box = _el('aiSummaryBox');
    const text = _el('aiSummaryText');
    if (!box || !text) return;

    box.style.display = 'block';
    text.innerHTML = '<i class="fas fa-spinner fa-spin"></i> AI Agent is analyzing your portfolio...';

    const prompt = _buildPrompt(totalValue, totalAssets);

    let aiText = null;
    try { aiText = await _cascade(prompt, WEALTH_TIMING); }
    catch (err) { console.warn('[Wealth] Cascade failed:', err?.message || err); }

    if (aiText) { text.innerText = aiText; return; }

    let fallbackText = `Your total portfolio is ৳${totalValue.toLocaleString('en-IN')} across ${totalAssets} assets. `;
    if (currentUserCashflowPressure === 'critical') fallbackText += `Given your critical cashflow needs, consider culling older non-productive animals to raise immediate liquid funds before market prices drop further.`;
    else if (currentUserRiskProfile === 'low') fallbackText += `To combat biological depreciation safely, reinvest milk revenues into low-risk, high-yield dairy or pregnant goats to ensure steady, stable ROI.`;
    else fallbackText += `To maximize ROI, reinvest in high-yield dairy cows or pregnant goats. Cull older non-productive animals to optimize your biological asset base.`;

    text.innerText = fallbackText;
}

const ACTION_PLAN_PROMPT = `You are a livestock wealth advisor AI for Bangladesh.

PORTFOLIO (JSON):
{ASSETS}

LOCATION: {DISTRICT}
TOTAL VALUE: ৳{TOTAL}
RISK PROFILE: {RISK}
CASHFLOW: {CASHFLOW}

TASK:
Propose a concrete portfolio rebalancing plan with 1 SELL action and 1 BUY action.

RULES:
- SELL: pick the asset with the worst ROI (oldest age OR zero yield).
- BUY: pick an animal type that:
    * Fits the risk profile: low -> goat/sheep, moderate -> goat/cow, high -> cow/buffalo
    * Improves portfolio diversification if possible
- The BUY price must not exceed the SELL price + 20% buffer.
- Return ONLY valid JSON, in English. No markdown.

OUTPUT SCHEMA:
{
  "sell": {
    "assetId": "<exact id from the input JSON>",
    "animalType": "cow",
    "reason": "Age 8y, milk yield 0 — no longer productive",
    "salePrice": 45000
  },
  "buy": {
    "animalType": "goat",
    "age": 1.5,
    "yieldInput": 0,
    "purchasePrice": 15000,
    "reason": "Pregnant Black Bengal goat — high ROI in 6 months"
  },
  "summary": "Sell the 8-year-old non-productive cow for ৳45k and reinvest ৳15k in a pregnant goat via NAGAD; keep ৳30k as cashflow buffer."
}`;

function _buildActionPlanPrompt(assets, totalValue) {
    const districtName = (window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[currentUserDistrict])
        ? window.BD_DISTRICTS_LIST[currentUserDistrict].name
        : currentUserDistrict;

    const slim = assets.map(a => ({
        id: a.id, type: a.type, age: a.age,
        yieldInput: a.yieldInput || 0, value: a.value
    }));

    return ACTION_PLAN_PROMPT
        .replace('{ASSETS}', JSON.stringify(slim))
        .replace('{DISTRICT}', districtName)
        .replace('{TOTAL}', totalValue)
        .replace('{RISK}', currentUserRiskProfile)
        .replace('{CASHFLOW}', currentUserCashflowPressure);
}

function _parseActionPlan(text) {
    try {
        const clean = text.replace(/```json/gi, '').replace(/```/g, '').trim();
        const match = clean.match(/\{[\s\S]*\}/);
        if (!match) return null;
        return JSON.parse(match[0]);
    } catch (_) { return null; }
}

async function loadAIActionPlans(assets, totalValue) {
    const host = _el('aiActionPlanBox');
    if (!host) return;

    let history = [];
    try {
        const snap = await _fs().collection('users').doc(currentUserPhone)
            .collection('ai_action_plans')
            .orderBy('createdAtMs', 'desc')
            .limit(5)
            .get();
        snap.forEach(d => history.push({ id: d.id, ...d.data() }));
    } catch (err) {
        console.warn('[ActionPlan] History load failed:', err.message);
    }

    _renderActionPlanHistory(host, history);

    if (!assets.length) return;

    const existingBox = _el('aiActionPlanNew');
    if (existingBox) existingBox.remove();

    const wrapper = document.createElement('div');
    wrapper.id = 'aiActionPlanNew';
    wrapper.style.cssText = 'margin-top:12px;padding:16px;border:1.5px dashed #a78bfa;border-radius:14px;background:#faf5ff;';
    wrapper.innerHTML = '<div style="text-align:center;color:#6d28d9;font-size:13px;font-weight:700;"><i class="fas fa-spinner fa-spin"></i> AI is generating a portfolio action plan...</div>';
    host.appendChild(wrapper);

    const prompt = _buildActionPlanPrompt(assets, totalValue);
    let aiText = null;
    try { aiText = await _cascade(prompt, WEALTH_TIMING); }
    catch (err) { console.warn('[ActionPlan] Cascade failed:', err?.message || err); }

    if (!aiText) {
        wrapper.innerHTML = '<div style="color:#92400e;font-size:12.5px;text-align:center;">AI is busy. Please try again later.</div>';
        return;
    }

    const plan = _parseActionPlan(aiText);
    if (!plan || !plan.sell || !plan.buy) {
        wrapper.innerHTML = '<div style="color:#92400e;font-size:12.5px;text-align:center;">AI could not produce a valid plan. Try again.</div>';
        return;
    }

    _renderActionPlanProposal(wrapper, plan, assets);
}

function _renderActionPlanProposal(container, plan, assets) {
    const soldAsset = assets.find(a => a.id === plan.sell.assetId);
    if (!soldAsset) {
        container.innerHTML = '<div style="color:#92400e;font-size:12.5px;text-align:center;">AI referenced an asset that is no longer in your portfolio.</div>';
        return;
    }

    const animalSold = ANIMAL_DB[soldAsset.type] || { name: soldAsset.type, emoji: '🐾' };
    const animalBuy = ANIMAL_DB[plan.buy.animalType] || { name: plan.buy.animalType, emoji: '🐾' };

    container.innerHTML = `
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;">
            <i class="fas fa-lightbulb" style="color:#7c3aed;font-size:14px;"></i>
            <span style="font-size:13px;font-weight:900;color:#6d28d9;">AI Portfolio Action Plan</span>
            <span style="font-size:10px;font-weight:800;padding:2px 8px;border-radius:999px;background:#ede9fe;color:#6d28d9;border:1px solid #ddd6fe;">AI PROPOSED</span>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px;">
            <div style="padding:12px;border:1px solid #fecaca;border-radius:12px;background:#fef2f2;">
                <div style="font-size:11px;font-weight:800;color:#b91c1c;text-transform:uppercase;letter-spacing:.04em;">🔴 Sell</div>
                <div style="font-size:14px;font-weight:900;color:#0f172a;margin-top:4px;">${animalSold.emoji} ${animalSold.name}</div>
                <div style="font-size:11.5px;color:#7f1d1d;margin-top:2px;">Age ${soldAsset.age}y • ৳${(plan.sell.salePrice || soldAsset.value).toLocaleString('en-IN')}</div>
                <div style="font-size:11px;color:#475569;margin-top:6px;line-height:1.5;">${_esc(plan.sell.reason)}</div>
            </div>
            <div style="padding:12px;border:1px solid #86efac;border-radius:12px;background:#ecfdf5;">
                <div style="font-size:11px;font-weight:800;color:#047857;text-transform:uppercase;letter-spacing:.04em;">🟢 Buy</div>
                <div style="font-size:14px;font-weight:900;color:#0f172a;margin-top:4px;">${animalBuy.emoji} ${animalBuy.name}</div>
                <div style="font-size:11.5px;color:#065f46;margin-top:2px;">Age ${plan.buy.age}y • ৳${(plan.buy.purchasePrice || 0).toLocaleString('en-IN')}</div>
                <div style="font-size:11px;color:#475569;margin-top:6px;line-height:1.5;">${_esc(plan.buy.reason)}</div>
            </div>
        </div>

        <div style="font-size:12px;line-height:1.6;margin-bottom:12px;">
            <b style="color:#6d28d9;">AI Summary:</b><br>
            <span style="${_paymentLineStyle(plan.summary)} white-space:normal; margin-top:4px;">${_esc(plan.summary || '')}</span>
        </div>

        <div style="display:flex;gap:8px;">
            <button type="button" id="apAcceptBtn" style="flex:1;padding:10px;background:#7c3aed;color:#fff;border:none;border-radius:10px;font-weight:800;font-size:13px;cursor:pointer;">
                <i class="fas fa-check"></i> Accept & Execute
            </button>
            <button type="button" id="apRejectBtn" style="flex:1;padding:10px;background:#f1f5f9;color:#475569;border:1px solid #e2e8f0;border-radius:10px;font-weight:800;font-size:13px;cursor:pointer;">
                <i class="fas fa-xmark"></i> Reject
            </button>
        </div>`;

    _el('apAcceptBtn').onclick = () => _executeActionPlan(plan, soldAsset);
    _el('apRejectBtn').onclick = () => _rejectActionPlan(plan, container);
}

function _esc(s) {
    const d = document.createElement('div');
    d.textContent = String(s || '');
    return d.innerHTML;
}

async function _executeActionPlan(plan, soldAsset) {
    const btn = _el('apAcceptBtn');
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Executing...'; }

    try {
        const batch = _fs().batch();
        const userRef = _fs().collection('users').doc(currentUserPhone);

        batch.delete(userRef.collection('wealth_assets').doc(plan.sell.assetId));

        const animalBuy = ANIMAL_DB[plan.buy.animalType] || ANIMAL_DB.goat;
        const factor = getPriceFactor(currentUserDistrict);
        const newAssetValue = Math.round(Number(plan.buy.purchasePrice || animalBuy.baseValue) * factor);
        const newAssetRef = userRef.collection('wealth_assets').doc();
        batch.set(newAssetRef, {
            type: plan.buy.animalType,
            age: Number(plan.buy.age) || 1,
            yieldInput: Number(plan.buy.yieldInput) || 0,
            value: newAssetValue,
            district: currentUserDistrict,
            districtFactor: factor,
            source: 'ai_action_plan',
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            createdAtMs: Date.now()
        });

        const logRef = userRef.collection('ai_action_plans').doc();
        batch.set(logRef, {
            sell: plan.sell,
            buy: plan.buy,
            summary: plan.summary || '',
            soldAssetSnapshot: { type: soldAsset.type, age: soldAsset.age, value: soldAsset.value },
            newAssetId: newAssetRef.id,
            status: 'executed',
            executedAt: firebase.firestore.FieldValue.serverTimestamp(),
            createdAtMs: Date.now()
        });

        await batch.commit();

        const newBox = _el('aiActionPlanNew');
        if (newBox) newBox.remove();

        alert('✅ Action plan executed!\n\nYour portfolio has been updated.');
        loadAssetsFromFirestore();
    } catch (err) {
        console.error('[ActionPlan] Execute failed:', err);
        alert('❌ Failed to execute: ' + (err.message || 'Try again.'));
        if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-check"></i> Accept & Execute'; }
    }
}

async function _rejectActionPlan(plan, container) {
    try {
        await _fs().collection('users').doc(currentUserPhone)
            .collection('ai_action_plans').add({
                sell: plan.sell,
                buy: plan.buy,
                summary: plan.summary || '',
                status: 'rejected',
                createdAtMs: Date.now(),
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });
    } catch (err) {
        console.warn('[ActionPlan] Reject log failed:', err.message);
    }
    container.innerHTML = '<div style="text-align:center;color:#64748b;font-size:12.5px;">Plan rejected. AI will propose a new plan next time.</div>';
    setTimeout(() => container.remove(), 2500);
}

// ───── Payment line theme (bKash / Nagad / Rocket) ─────
function _getPaymentTheme(text) {
    if (!text) return null;
    const t = String(text).toUpperCase();
    if (t.includes('BKASH'))  return { bg: '#E2136E', color: '#000000' };
    if (t.includes('NAGAD'))  return { bg: '#F6921E', color: '#000000' };
    if (t.includes('ROCKET')) return { bg: '#8B1B89', color: '#FFFFFF' };
    return null;
}

function _paymentLineStyle(text) {
    const th = _getPaymentTheme(text);
    return th
        ? `display:inline-block; background:${th.bg}; color:${th.color}; padding:3px 10px; border-radius:6px; font-weight:700;`
        : 'color:#64748B;';
}

const _PAY_WORDS = '(?:bkash|nagad|rocket|upay|cash|bank|card)';

function _cleanProductName(raw) {
    if (!raw) return null;
    let s = String(raw)
        .replace(new RegExp(`\\s+(?:via|using|with|by|through|thru)\\s+${_PAY_WORDS}.*$`, 'i'), '')
        .replace(/\s+(?:via|using|through)\s+.*$/i, '')
        .replace(/\s+(?:for|at|on|worth)\s+[৳$]?\s?[\d,.]+.*$/i, '')
        .replace(/[\s.,;:!]+$/g, '')
        .trim();
    if (!s || s.length > 60) return null;
    return s;
}

function _extractProductName(summary) {
    if (!summary) return null;
    const s = String(summary).replace(/\s+/g, ' ').trim();
    const patterns = [
        /\b(?:invested|investing|investment)\b.*?\bin\s+(.+)$/i,
        /\b(?:claimed|collected|received|withdrew|withdrawn)\b.*?\bfrom\s+(.+)$/i,
        /\b(?:bought|purchased|buy|sold|sell|sale of)\s+(?:an?\s+|the\s+)?(.+)$/i,
        /\bin\s+(.+)$/i,
        /\bfrom\s+(.+)$/i,
        /\bof\s+(.+)$/i
    ];
    for (const re of patterns) {
        const m = s.match(re);
        if (m) {
            const name = _cleanProductName(m[1]);
            if (name) return name;
        }
    }
    return null;
}

function _historyTitle(h) {
    const structured = h.productName || h.product || h.assetName || h.itemName;
    if (structured) return String(structured);

    if (h.sell?.animalType && h.buy?.animalType) {
        const s = ANIMAL_DB[h.sell.animalType]?.name || h.sell.animalType;
        const b = ANIMAL_DB[h.buy.animalType]?.name || h.buy.animalType;
        return `${s} ➔ ${b}`;
    }

    return _extractProductName(h.summary) || 'Portfolio rebalancing';
}

function _renderActionPlanHistory(host, history) {
    const old = _el('aiActionPlanHistory');
    if (old) old.remove();
    if (!history.length) return;

    const wrap = document.createElement('div');
    wrap.id = 'aiActionPlanHistory';

    wrap.innerHTML = `
        <div style="display:flex; align-items:center; gap:8px; font-size:12px; font-weight:900; color:#6d28d9; text-transform:uppercase; letter-spacing:.05em; margin-bottom:12px; margin-top:16px;">
            <i class="fas fa-clock-rotate-left"></i> Recent AI Action Plans
        </div>

        <div class="ap-history-container">
            ${history.map(h => {
                const animalBuy = ANIMAL_DB[h.buy?.animalType] || { emoji: '🐾', name: h.buy?.animalType || '—' };
                const animalSell = ANIMAL_DB[h.sell?.animalType] || { emoji: '🐾', name: h.sell?.animalType || '—' };

                const isExecuted = h.status === 'executed';
                const statusColor = isExecuted ? '#047857' : h.status === 'rejected' ? '#DC2626' : '#64748B';
                const statusBg = isExecuted ? '#ECFDF5' : h.status === 'rejected' ? '#FEF2F2' : '#F1F5F9';
                const statusIcon = isExecuted ? 'fa-check-circle' : 'fa-times-circle';
                const statusText = isExecuted ? 'Executed' : h.status === 'rejected' ? 'Rejected' : 'Pending';

                const dateStr = h.createdAtMs ? new Date(h.createdAtMs).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' }) : '';

                const sellAge = h.soldAssetSnapshot?.age ? `Age ${h.soldAssetSnapshot.age}y` : '';
                const sellPrice = h.sell?.salePrice ? `৳${h.sell.salePrice.toLocaleString('en-IN')}` : '';
                const buyAge = h.buy?.age ? `Age ${h.buy.age}y` : '';
                const buyPrice = h.buy?.purchasePrice ? `৳${h.buy.purchasePrice.toLocaleString('en-IN')}` : '';

                return `
                <div class="ap-history-item">
                    <div class="ap-history-left">
                        <div class="ap-history-icons">
                            <div style="background:#FEF2F2; padding:6px 10px; border-radius:8px; border:1px solid #FECACA; text-align:center; min-width:65px;">
                                <div style="font-size:16px; line-height:1;">${animalSell.emoji}</div>
                                <div style="font-size:10px; font-weight:800; color:#991B1B; margin-top:4px;">SELL</div>
                                <div style="font-size:9px; color:#7F1D1D;">${sellAge} ${sellPrice}</div>
                            </div>

                            <i class="fas fa-arrow-right" style="font-size:12px; color:#94A3B8;"></i>

                            <div style="background:#ECFDF5; padding:6px 10px; border-radius:8px; border:1px solid #A7F3D0; text-align:center; min-width:65px;">
                                <div style="font-size:16px; line-height:1;">${animalBuy.emoji}</div>
                                <div style="font-size:10px; font-weight:800; color:#065F46; margin-top:4px;">BUY</div>
                                <div style="font-size:9px; color:#047857;">${buyAge} ${buyPrice}</div>
                            </div>
                        </div>
                        <div class="ap-history-text" style="margin-left:4px; flex:1; min-width:0;">
                            <div style="font-weight:800; color:#0F172A; font-size:13px;">${_esc(_historyTitle(h))}</div>
                            <div style="font-size:11px; margin-top:4px; white-space:normal; word-break:break-word; line-height:1.5; max-width:100%; ${_paymentLineStyle(h.summary)}">
                                ${h.summary ? _esc(h.summary) : 'Portfolio rebalancing'}
                            </div>
                        </div>
                    </div>

                    <div class="ap-history-right">
                        <span style="font-size:11px; color:#94A3B8; font-weight:600; margin-right:8px;">${dateStr}</span>
                        <span class="ap-history-badge" style="background:${statusBg}; color:${statusColor}; border:1px solid ${statusColor}30;">
                            <i class="fas ${statusIcon}"></i> ${statusText}
                        </span>
                    </div>
                </div>`;
            }).join('')}
        </div>
    `;
    host.appendChild(wrap);
}

window.WealthDebug = {
    status() {
        const now = Date.now();
        console.table([..._blocks].filter(([until]) => until > now)
            .map(([id, until]) => ({ id, secsLeft: Math.round((until - now) / 1000) })));
        console.log('Usable slots:', _buildSlots().length);
        console.log('Valid keys:', {
            gemini: _validKeys('gemini').length,
            groq: _validKeys('groq').length,
            openrouter: _validKeys('openrouter').length
        });
        console.log('Current district:', currentUserDistrict, '| Price factor:', getPriceFactor(currentUserDistrict));
        console.log('Risk Profile:', currentUserRiskProfile, '| Cashflow:', currentUserCashflowPressure);
    },
    reset() {
        _blocks.clear();
        _strikes.clear();
        _lsSet(WEALTH_BLOCK_STORE, '{}');
        console.log('✅ Wealth blocks cleared');
    },
    test: () => _cascade('Say hello in one short sentence.', WEALTH_TIMING),
    prices(district) {
        console.log('District:', district, '| Factor:', getPriceFactor(district));
        Object.keys(ANIMAL_DB).forEach(k => {
            const a = ANIMAL_DB[k];
            const adjusted = Math.round(a.baseValue * getPriceFactor(district));
            console.log(`${a.emoji} ${a.name}: ৳${a.baseValue} → ৳${adjusted}`);
        });
    }
};

window.addAsset = addAsset;