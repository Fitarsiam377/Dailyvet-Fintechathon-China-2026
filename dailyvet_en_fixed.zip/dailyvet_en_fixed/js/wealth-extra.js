/* ============================================================
   DailyVet — Wealth Extra (Live Data, ROI, Carbon Selling & AI) v7.2
   ✅ Fixed VISION_MODEL syntax error (was comma-list, now array)
   ✅ 5 Gemini + 3 Groq + 2 OpenRouter, hedged rotation + fallback (ai.js style)
   ✅ Cleaned duplicates, removed dead code
   ✅ v7.2: Dates always shown in English (e.g. 20 Oct 2026), even for old transactions
   ============================================================ */

let currentUserPhone = null;
let currentUserRiskProfile = 'moderate';
let totalCarbonCredits = 0;
let currentCarbonSource = '';
let carbonImageBase64 = null;

// Payment State
let currentAssetName = '';
let currentTargetValue = 0;
let currentMinInvestment = 5000;
let currentPaymentMethod = 'bkash';

const _fs = () => firebase.firestore();

/* Date helper: always English (en-GB), e.g. "20 Oct 2026" */
const _fmtDate = (ms) => new Date(ms || Date.now()).toLocaleDateString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric'
});

/* AI Keys: 5 Gemini + 3 Groq + 2 OpenRouter (rotation + fallback) */
const GEMINI_KEYS = [
    _dvDec('QVEuQWI4Uk42SlVSbzZHTS1lck9BX0d6UVRJcml4MzRtUkhfd3doN01pM01janF1dVdmMGc='),
    _dvDec('QVEuQWI4Uk42S19GWW5PS0xPdFlRX21lLWlrcU1ybzE5aXpRQ0VROTFwNTB1cUNqaGM5Vnc='),
    _dvDec('QVEuQWI4Uk42TE9uRUpOTncxWm51ZGJhV3RpVHdsTXhJSUwyWXptalFjaFJib3RSRWUxQnc='),
    _dvDec('QVEuQWI4Uk42TG15RjN4ZWpXeXVTTjdFRENBMDZlR09WakpwLTlxYmtzUHZDRWo3R2ZTNkE='),
    _dvDec('QVEuQWI4Uk42SWNpaEFtbVF5aTZIWTBwQU5HNkFGLVpYRGZwSUdZZmFfNjhHb0NpQ2VqTFE=')
  ];
const GROQ_KEYS = [
    _dvDec('Z3NrX21WVXRJQThxTHdXUGNIZkFvNHNkV0dkeWIzRllkUk1rTlppMUxYT2gxb1RITVlIM0w3WXI='),
    _dvDec('Z3NrX3o4QkRyYldCbXlhS2l6M3BiVnZRV0dkeWIzRlk1R25haDNrQVptQm1xRUF2a2ZLMTZmd1M='),
    _dvDec('Z3NrX0ExSHo5VDQ3aTA5UndrM1h4UGlaV0dkeWIzRllxT0YxOHdDc0JRV0lUaVlOQjRaM3RheDQ=')
  ];
const OPENROUTER_KEYS = [
    _dvDec('c2stb3ItdjEtODg4MDE5MDk4Njc2MjllYWQ5ZGQyMjQ2MTc5YWVlZjE0Y2VkZTFiMGZkOGI2YmQxM2VkNDA2NTU3NWVhZWY3OQ=='),
    _dvDec('c2stb3ItdjEtNGQwZmE1MzM5YWI1YTA3NDlkM2I4ZTEyZTU1NGM3ZWI2MjFjYzNjMmI1YjgwYzk0MjA5YjM0YjhmMzZjZTFlNg==')
  ];

/* Models identical to ai.js (vision) */
const VISION_MODELS = [
    'gemini-3.5-flash-lite',
    'gemini-3.1-flash-lite',
    'gemini-2.5-flash-lite',
    'gemini-3.8-flash',
    'gemini-3.6-flash',
    'gemini-2.5-flash'
];
const GROQ_VISION_MODELS = ['qwen/qwen3.8-27b'];
const OPENROUTER_VISION_MODELS = ['qwen/qwen2.5-vl-72b-instruct:free'];

const API_URL = 'https://generativelanguage.googleapis.com/v1beta/models';
const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';
const OPENROUTER_API_URL = 'https://openrouter.ai/api/v1/chat/completions';

/* ── Rotation + block registry ── */
const _aiRot = { gemini: 0, groq: 0, openrouter: 0 };
const _aiBlocks = new Map();
const _aiTail = k => k.slice(-8);
const _aiBlocked = id => (_aiBlocks.get(id) || 0) > Date.now();
const _aiBlock = (id, ms) => _aiBlocks.set(id, Date.now() + ms);
const AI_PROVIDER_KEYS = { gemini: GEMINI_KEYS, groq: GROQ_KEYS, openrouter: OPENROUTER_KEYS };
const AI_PROVIDER_MODELS = { gemini: VISION_MODELS, groq: GROQ_VISION_MODELS, openrouter: OPENROUTER_VISION_MODELS };

function _aiBuildJobs() {
    const make = provider => {
        const keys = AI_PROVIDER_KEYS[provider].filter(Boolean);
        const shift = keys.length ? _aiRot[provider] % keys.length : 0;
        const rotated = keys.slice(shift).concat(keys.slice(0, shift));
        const out = [];
        for (const model of AI_PROVIDER_MODELS[provider]) {
            for (const key of rotated) {
                const job = { provider, model, key };
                if (_aiBlocked(`k:${provider}:${_aiTail(key)}`) || _aiBlocked(`m:${provider}:${model}`)) continue;
                out.push(job);
            }
        }
        return out;
    };
    const [g, q, o] = ['gemini', 'groq', 'openrouter'].map(make);
    /* same order as ai.js: Gemini, Gemini, Groq, Gemini, OpenRouter, Gemini, Groq ... */
    const out = [];
    let gi = 0, qi = 0, oi = 0;
    const order = ['g', 'g', 'q', 'g', 'o', 'g', 'q'];
    for (const t of order) {
        if (t === 'g' && gi < g.length) out.push(g[gi++]);
        else if (t === 'q' && qi < q.length) out.push(q[qi++]);
        else if (t === 'o' && oi < o.length) out.push(o[oi++]);
    }
    while (gi < g.length) out.push(g[gi++]);
    while (qi < q.length) out.push(q[qi++]);
    while (oi < o.length) out.push(o[oi++]);
    return out;
}

function _aiParseJSON(raw) {
    const clean = String(raw || '').replace(/<think>[\s\S]*?<\/think>/gi, '')
        .replace(/```json/gi, '').replace(/```/g, '').trim();
    try { return JSON.parse(clean); }
    catch (_) {
        const m = clean.match(/\{[\s\S]*\}/);
        return m ? JSON.parse(m[0]) : null;
    }
}

async function _aiCallOne(job, imageDataUrl, prompt) {
    const { provider, model, key } = job;
    const imageData = imageDataUrl.includes(',') ? imageDataUrl.split(',')[1] : imageDataUrl;
    const mime = imageDataUrl.includes('data:') ? imageDataUrl.split(';')[0].split(':')[1] : 'image/jpeg';
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 5500);
    try {
        let res;
        if (provider === 'gemini') {
            res = await fetch(`${API_URL}/${model}:generateContent?key=${key}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ role: 'user', parts: [
                        { inline_data: { mime_type: mime, data: imageData } },
                        { text: prompt }
                    ] }],
                    generationConfig: { temperature: 0.1, responseMimeType: 'application/json' }
                }),
                signal: controller.signal
            });
        } else {
            const body = {
                model, temperature: 0.1, max_tokens: 600,
                messages: [{ role: 'user', content: [
                    { type: 'text', text: prompt },
                    { type: 'image_url', image_url: { url: `data:${mime};base64,${imageData}` } }
                ] }]
            };
            if (provider === 'groq') body.response_format = { type: 'json_object' };
            const headers = { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` };
            if (provider === 'openrouter') {
                headers['HTTP-Referer'] = location.origin || 'https://dailyvet.app';
                headers['X-Title'] = 'DailyVet Carbon';
            }
            res = await fetch(provider === 'groq' ? GROQ_API_URL : OPENROUTER_API_URL, {
                method: 'POST', headers, body: JSON.stringify(body), signal: controller.signal
            });
        }
        clearTimeout(timer);
        if (!res.ok) {
            const s = res.status;
            const kid = `k:${provider}:${_aiTail(key)}`;
            if (s === 429) _aiBlock(kid, 30e3);
            else if (s === 401 || s === 402 || s === 403) _aiBlock(kid, 6 * 3600e3);
            else if (s === 404) _aiBlock(`m:${provider}:${model}`, 3600e3);
            else if (s >= 500) _aiBlock(kid, 10e3);
            return null;
        }
        const data = await res.json();
        const raw = provider === 'gemini'
            ? (data.candidates?.[0]?.content?.parts || []).filter(p => p && p.text && !p.thought).map(p => p.text).join('')
            : (data.choices?.[0]?.message?.content || '');
        const parsed = raw ? _aiParseJSON(raw) : null;
        if (!parsed || typeof parsed.valid !== 'boolean') return null;
        _aiRot[provider] = AI_PROVIDER_KEYS[provider].indexOf(key);
        return parsed;
    } catch (e) {
        clearTimeout(timer);
        _aiBlock(`k:${provider}:${_aiTail(key)}`, 8e3);
        return null;
    }
}

/* Hedged cascade: next slot starts immediately on failure, a backup starts every 1.8s if slow */
function _aiVision(imageDataUrl, prompt, totalMs = 12000, hedgeMs = 1800) {
    const jobs = _aiBuildJobs();
    return new Promise(resolve => {
        let next = 0, active = 0, done = false, hedge = null;
        const finish = v => {
            if (done) return;
            done = true;
            clearTimeout(total); clearTimeout(hedge);
            resolve(v);
        };
        const total = setTimeout(() => finish(null), totalMs);
        const launch = () => {
            if (done) return;
            if (next >= jobs.length) { if (active === 0) finish(null); return; }
            const job = jobs[next++];
            active++;
            clearTimeout(hedge);
            hedge = setTimeout(launch, hedgeMs);
            _aiCallOne(job, imageDataUrl, prompt).then(r => {
                active--;
                if (done) return;
                if (r) finish(r); else launch();
            });
        };
        launch();
    });
}

document.addEventListener('DOMContentLoaded', async () => {
    currentUserPhone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
    if (!currentUserPhone) {
        window.location.href = 'login.html';
        return;
    }

    try {
        const doc = await _fs().collection('users').doc(currentUserPhone).get();
        if (doc.exists && doc.data().riskProfile) {
            currentUserRiskProfile = doc.data().riskProfile;
        }
    } catch (e) { console.warn(e); }

    loadInvestmentPortfolio();
    loadCarbonBalance();
    loadLiveFundingData();
});

/* ============================================================
   TAB SWITCH
   ============================================================ */
function switchExtraTab(tab) {
    document.getElementById('tabFrac').classList.remove('active');
    document.getElementById('tabCarbon').classList.remove('active');
    document.getElementById('contentFrac').style.display = 'none';
    document.getElementById('contentCarbon').style.display = 'none';

    if (tab === 'frac') {
        document.getElementById('tabFrac').classList.add('active');
        document.getElementById('contentFrac').style.display = 'block';
    } else {
        document.getElementById('tabCarbon').classList.add('active');
        document.getElementById('contentCarbon').style.display = 'block';
    }
}

/* ============================================================
   1. LIVE FUNDING DATA
   ============================================================ */
async function loadLiveFundingData() {
    let targets = { cow: 120000, goat: 15000, buffalo: 200000, sheep: 12000, chicken: 10000 };
    let raised = { cow: 0, goat: 0, buffalo: 0, sheep: 0, chicken: 0 };

    try {
        const poolDoc = await _fs().collection('meta').doc('funding_pools').get();

        if (poolDoc.exists) {
            const d = poolDoc.data();

            if (d.targets) {
                targets = {
                    cow: d.targets.cow || targets.cow,
                    goat: d.targets.goat || targets.goat,
                    buffalo: d.targets.buffalo || targets.buffalo,
                    sheep: d.targets.sheep || targets.sheep,
                    chicken: d.targets.chicken || targets.chicken
                };
            }

            raised = {
                cow: d.cowRaised || 0,
                goat: d.goatRaised || 0,
                buffalo: d.buffaloRaised || 0,
                sheep: d.sheepRaised || 0,
                chicken: d.chickenRaised || 0
            };
        } else {
            raised = { cow: 85000, goat: 6000, buffalo: 50000, sheep: 3000, chicken: 2000 };
        }

        updateProgressBar('cow', raised.cow, targets.cow);
        updateProgressBar('goat', raised.goat, targets.goat);
        updateProgressBar('buffalo', raised.buffalo, targets.buffalo);
        updateProgressBar('sheep', raised.sheep, targets.sheep);
        updateProgressBar('chicken', raised.chicken, targets.chicken);

    } catch (err) {
        console.warn('Failed to load live pool data', err);
    }
}

function updateProgressBar(type, raised, target) {
    const pct = Math.min(100, Math.round((raised / target) * 100));

    const pctEl = document.getElementById(`${type}FundedPercent`);
    const amtEl = document.getElementById(`${type}FundedAmount`);
    const barEl = document.getElementById(`${type}ProgressBar`);
    const targetEl = document.getElementById(`${type}TargetAmount`);

    if (pctEl) pctEl.textContent = `${pct}%`;
    if (amtEl) amtEl.textContent = `৳${raised.toLocaleString('en-IN')}`;
    if (barEl) barEl.style.width = `${pct}%`;
    if (targetEl) targetEl.textContent = `৳${target.toLocaleString('en-IN')}`;
}

/* ============================================================
   2. PAYMENT GATEWAY
   ============================================================ */
function openPaymentModal(assetName, targetValue, minInvestment) {
    currentAssetName = assetName;
    currentTargetValue = targetValue;
    currentMinInvestment = minInvestment || 5000;

    document.getElementById('paymentSubTitle').textContent = `Investing in ${assetName}`;
    document.getElementById('paymentAmountInput').value = '';
    document.getElementById('paymentAmountInput').min = currentMinInvestment;
    document.getElementById('paymentAmountInput').placeholder = currentMinInvestment;

    const minLabel = document.getElementById('minInvestmentLabel');
    if (minLabel) {
        minLabel.textContent = `Minimum investment: ৳${currentMinInvestment.toLocaleString('en-IN')}`;
    }

    document.getElementById('payNowBtn').disabled = true;
    document.getElementById('paymentModal').style.display = 'flex';

    const firstMethod = document.querySelector('.pm-card');
    if (firstMethod) selectPaymentMethod(firstMethod);
}

function closePaymentModal() {
    document.getElementById('paymentModal').style.display = 'none';
}

function selectPaymentMethod(el) {
    document.querySelectorAll('.pm-card').forEach(c => c.classList.remove('active'));
    el.classList.add('active');
    currentPaymentMethod = el.querySelector('input').value;
}

function updatePaymentButton() {
    const amount = Number(document.getElementById('paymentAmountInput').value);
    document.getElementById('payNowBtn').disabled = !(amount >= currentMinInvestment);
}

async function processRealPayment() {
    const amount = Number(document.getElementById('paymentAmountInput').value);
    if (amount < currentMinInvestment) return;

    const btn = document.getElementById('payNowBtn');
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Connecting to Gateway...';
    btn.disabled = true;

    setTimeout(async () => {
        try {
            const investRef = _fs().collection('users').doc(currentUserPhone).collection('investments').doc();
            await investRef.set({
                animalName: currentAssetName,
                amount,
                targetValue: currentTargetValue,
                sharePercentage: ((amount / currentTargetValue) * 100).toFixed(2),
                status: 'active',
                paymentMethod: currentPaymentMethod,
                transactionId: 'TXN-' + Date.now().toString().slice(-8),
                roiPercent: 15,
                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                createdAtMs: Date.now()
            });

            try {
                const poolRef = _fs().collection('meta').doc('funding_pools');
                const poolDoc = await poolRef.get();

                let field = 'cowRaised';
                if (currentAssetName.includes('Goat')) field = 'goatRaised';
                else if (currentAssetName.includes('Buffalo')) field = 'buffaloRaised';
                else if (currentAssetName.includes('Sheep')) field = 'sheepRaised';
                else if (currentAssetName.includes('Chicken')) field = 'chickenRaised';

                if (poolDoc.exists) {
                    await poolRef.update({ [field]: firebase.firestore.FieldValue.increment(amount) });
                } else {
                    await poolRef.set({ [field]: amount });
                }
            } catch (poolErr) { console.warn('[Payment] Pool update failed:', poolErr.message); }

            try {
                await _fs().collection('users').doc(currentUserPhone).collection('ai_action_plans').add({
                    action: 'micro_investment',
                    summary: `Invested ৳${amount.toLocaleString('en-IN')} in ${currentAssetName} via ${currentPaymentMethod.toUpperCase()}`,
                    status: 'executed',
                    createdAtMs: Date.now(),
                    createdAt: firebase.firestore.FieldValue.serverTimestamp()
                });
            } catch (logErr) { console.warn('Log failed:', logErr.message); }

            btn.innerHTML = '<i class="fas fa-check-circle"></i> Payment Successful';
            btn.style.background = '#059669';

            setTimeout(() => {
                closePaymentModal();
                loadInvestmentPortfolio();
                loadLiveFundingData();
                alert(`✅ Payment Successful!\n\nYou invested ৳${amount.toLocaleString('en-IN')} in ${currentAssetName} using ${currentPaymentMethod.toUpperCase()}.`);
                btn.innerHTML = 'Pay Securely';
                btn.style.background = '';
            }, 1200);

        } catch (err) {
            console.error('Payment failed:', err);
            alert('❌ Payment failed: ' + (err.message || 'Please try again.'));
            btn.innerHTML = 'Pay Securely';
            btn.disabled = false;
        }
    }, 2000);
}

/* ============================================================
   3. PORTFOLIO & TRANSACTIONS
   ============================================================ */
async function loadInvestmentPortfolio() {
    const list = document.getElementById('investmentLedger');
    if (!list) return;

    try {
        const snap = await _fs().collection('users').doc(currentUserPhone)
            .collection('investments').orderBy('createdAtMs', 'desc').get();

        if (snap.empty) {
            list.innerHTML = '<div style="text-align:center; padding:1rem; color:#64748b;">No active investments yet.</div>';
            loadTransactions();
            return;
        }

        let html = '';
        snap.forEach(doc => {
            const d = doc.data();
            const date = _fmtDate(d.createdAtMs);

            // ROI Calculation (1.25% monthly based on 15% annual)
            const monthlyROI = Math.round(d.amount * 0.0125);

            html += `
                <div class="ledger-item">
                    <div class="li-left">
                        <div class="li-title">${d.animalName}</div>
                        <div class="li-date">${date} • Share: ${d.sharePercentage}%</div>
                    </div>
                    <div class="li-right" style="display:flex; align-items:center; gap:10px;">
                        <div style="text-align:right;">
                            <div class="li-val">৳ ${d.amount.toLocaleString('en-IN')}</div>
                            <div class="li-status">ACTIVE</div>
                        </div>
                        <button onclick="withdrawROI('${d.animalName}', ${monthlyROI})" style="padding:6px 10px; background:#10b981; color:#fff; border:none; border-radius:6px; font-weight:bold; font-size:0.75rem; cursor:pointer;">
                            Claim ROI
                        </button>
                    </div>
                </div>`;
        });
        list.innerHTML = html;
        loadTransactions();
    } catch (e) { console.warn(e); }
}

async function withdrawROI(assetName, roiAmount) {
    if (!confirm(`Claim ৳${roiAmount} ROI for ${assetName} to your bKash?`)) return;

    try {
        const now = Date.now();
        await _fs().collection('users').doc(currentUserPhone).collection('transactions').add({
            type: 'ROI Claim',
            assetName: assetName,
            amount: roiAmount,
            method: 'bKash',
            status: 'completed',
            date: _fmtDate(now),
            createdAtMs: now
        });

        alert(`✅ Success! ৳${roiAmount} has been sent to your bKash account.`);
        loadTransactions();

        await _fs().collection('users').doc(currentUserPhone).collection('ai_action_plans').add({
            action: 'roi_claim',
            summary: `Claimed ৳${roiAmount} ROI from ${assetName}.`,
            status: 'executed',
            createdAtMs: Date.now(),
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } catch (e) { console.error(e); }
}

async function loadTransactions() {
    const list = document.getElementById('transactionHistory');
    if (!list) return;

    const snap = await _fs().collection('users').doc(currentUserPhone)
        .collection('transactions').orderBy('createdAtMs', 'desc').get();

    if (snap.empty) {
        list.innerHTML = '<div style="text-align:center; padding:1rem; color:#64748b;">No transactions yet.</div>';
        return;
    }

    list.innerHTML = snap.docs.map(doc => {
        const d = doc.data();
        // Always build the date from createdAtMs so old Bengali-digit strings are never shown
        const dateStr = d.createdAtMs ? _fmtDate(d.createdAtMs) : (d.date || '');
        return `
            <div class="ledger-item" style="background:#f0fdf4; border-color:#bbf7d0;">
                <div class="li-left">
                    <div class="li-title" style="color:#166534;">${d.type}: ${d.assetName}</div>
                    <div class="li-date">${dateStr} • ${d.method}</div>
                </div>
                <div class="li-right">
                    <div class="li-val" style="color:#166534;">+ ৳ ${d.amount}</div>
                    <div class="li-status" style="background:#dcfce7;">${d.status}</div>
                </div>
            </div>
        `;
    }).join('');
}

/* ============================================================
   4. CARBON CREDITS & SELLING
   ============================================================ */
function openCarbonUpload(source) {
    currentCarbonSource = source;
    document.getElementById('modalSourceName').textContent = source;
    document.getElementById('carbonModal').style.display = 'flex';

    carbonImageBase64 = null;
    document.getElementById('carbonPreviewImg').style.display = 'none';
    document.getElementById('carbonPreviewImg').src = '';
    document.getElementById('carbonAiStatus').style.display = 'none';
    document.getElementById('carbonSubmitBtn').disabled = true;
}

function closeCarbonModal() {
    document.getElementById('carbonModal').style.display = 'none';
}

async function handleCarbonImage(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
        carbonImageBase64 = e.target.result;
        const img = document.getElementById('carbonPreviewImg');
        img.src = carbonImageBase64;
        img.style.display = 'block';
        document.getElementById('carbonSubmitBtn').disabled = false;
    };
    reader.readAsDataURL(file);
}

async function processCarbonVerification() {
    if (!carbonImageBase64) return;

    const btn = document.getElementById('carbonSubmitBtn');
    const statusBox = document.getElementById('carbonAiStatus');

    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> AI Analyzing...';
    statusBox.style.display = 'block';
    statusBox.className = 'ai-status ai-loading';
    statusBox.innerHTML = 'Verifying image with AI Vision... Please wait.';

    const prompt = `You are a carbon credit verification AI. The user claims they have a "${currentCarbonSource}" setup.
Analyze this image. Does the image clearly show a ${currentCarbonSource}?
If yes, reply ONLY with valid JSON: {"valid": true, "credits": 50, "reason": "Verified ${currentCarbonSource}"}
If no, reply ONLY: {"valid": false, "reason": "Image does not match ${currentCarbonSource}"}`;

    try {
        const resultData = await _aiVision(carbonImageBase64, prompt);
        if (!resultData) throw new Error('AI service unavailable.');

        if (resultData.valid === true) {
            const credits = resultData.credits || 50;
            const valueBdt = credits * 250;

            await _fs().collection('users').doc(currentUserPhone).collection('carbon_credits').add({
                source: currentCarbonSource,
                credits,
                valueBdt,
                status: 'verified',
                aiReason: resultData.reason,
                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                createdAtMs: Date.now()
            });

            await _fs().collection('users').doc(currentUserPhone).collection('ai_action_plans').add({
                action: 'carbon_credit',
                summary: `AI verified ${currentCarbonSource}. Earned ${credits} credits.`,
                status: 'executed',
                createdAtMs: Date.now(),
                createdAt: firebase.firestore.FieldValue.serverTimestamp()
            });

            statusBox.className = 'ai-status ai-success';
            statusBox.innerHTML = `<i class="fas fa-check-circle"></i> Verified! You earned ${credits} Carbon Credits (≈ ৳${valueBdt.toLocaleString()}).`;

            setTimeout(() => {
                closeCarbonModal();
                loadCarbonBalance();
            }, 2000);
        } else {
            statusBox.className = 'ai-status ai-error';
            statusBox.innerHTML = `<i class="fas fa-times-circle"></i> Fraud Detected: ${resultData.reason || 'Image does not match.'}`;
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-robot"></i> AI Verify & Claim Credits';
        }

    } catch (err) {
        console.error(err);
        statusBox.className = 'ai-status ai-error';
        statusBox.innerHTML = `<i class="fas fa-exclamation-triangle"></i> Verification failed. Please try again.`;
        btn.disabled = false;
        btn.innerHTML = '<i class="fas fa-robot"></i> AI Verify & Claim Credits';
    }
}

async function loadCarbonBalance() {
    const list = document.getElementById('carbonLedger');
    const totalEl = document.getElementById('totalCarbonCredits');
    if (!list || !totalEl) return;

    try {
        const snap = await _fs().collection('users').doc(currentUserPhone)
            .collection('carbon_credits').orderBy('createdAtMs', 'desc').get();

        let totalCredits = 0;
        let totalValue = 0;
        let html = '';

        snap.forEach(doc => {
            const d = doc.data();
            totalCredits += d.credits;
            totalValue += d.valueBdt;

            const date = new Date(d.createdAtMs).toLocaleDateString('en-GB', { day: '2-digit', month: 'short' });
            html += `
                <div class="ledger-item">
                    <div class="li-left">
                        <div class="li-title">${d.source}</div>
                        <div class="li-date">${date} • AI Verified</div>
                    </div>
                    <div class="li-right">
                        <div class="li-val">${d.credits} Credits</div>
                        <div class="li-status">৳ ${d.valueBdt.toLocaleString()}</div>
                    </div>
                </div>`;
        });

        totalEl.textContent = totalCredits.toFixed(2);
        const usdEl = document.querySelector('.cb-usd');
        if (usdEl) usdEl.textContent = `≈ ৳${totalValue.toLocaleString('en-IN')} BDT`;

        list.innerHTML = html || '<div style="text-align:center; padding:1rem; color:#64748b;">No carbon credits yet.</div>';
    } catch (e) { console.warn(e); }
}

async function sellCarbonCredits() {
    const totalEl = document.getElementById('totalCarbonCredits');
    const credits = parseFloat(totalEl.textContent) || 0;

    if (credits <= 0) return alert("You don't have any carbon credits to sell.");

    const valueUSD = (credits * 2).toFixed(2); // 1 Credit = $2
    const valueBDT = Math.round(valueUSD * 120); // 1 USD = 120 BDT

    if (!confirm(`Sell ${credits} Carbon Credits for $${valueUSD} (≈ ৳${valueBDT})?`)) return;

    try {
        const now = Date.now();
        await _fs().collection('users').doc(currentUserPhone).collection('transactions').add({
            type: 'Carbon Sale',
            assetName: `${credits} Credits`,
            amount: valueBDT,
            method: 'Bank Transfer',
            status: 'completed',
            date: _fmtDate(now),
            createdAtMs: now
        });

        const snap = await _fs().collection('users').doc(currentUserPhone).collection('carbon_credits').get();
        const batch = _fs().batch();
        snap.forEach(doc => batch.delete(doc.ref));
        await batch.commit();

        alert(`✅ Sold Successfully!\n\nYou received $${valueUSD} (৳${valueBDT}) in your bank.`);
        loadCarbonBalance();
        loadTransactions();

    } catch (e) { console.error(e); }
}

/* ============================================================
   EXPORTS
   ============================================================ */
window.openPaymentModal = openPaymentModal;
window.closePaymentModal = closePaymentModal;
window.selectPaymentMethod = selectPaymentMethod;
window.updatePaymentButton = updatePaymentButton;
window.processRealPayment = processRealPayment;
window.switchExtraTab = switchExtraTab;
window.openCarbonUpload = openCarbonUpload;
window.closeCarbonModal = closeCarbonModal;
window.handleCarbonImage = handleCarbonImage;
window.processCarbonVerification = processCarbonVerification;
window.withdrawROI = withdrawROI;
window.sellCarbonCredits = sellCarbonCredits;