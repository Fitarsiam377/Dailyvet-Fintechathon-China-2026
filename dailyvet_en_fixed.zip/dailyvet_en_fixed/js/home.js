/* ========================================
 DAILYVET — HOME DASHBOARD JS v2.1
 ✅ Profile cards, Pet/Name/City search
 ✅ Notification system (bell badge + dropdown)
 ✅ Unified Finance & Insurance Widget (with Skeleton Loader)
 ======================================== */
(function () {
'use strict';

let allUsers = [];
let unsubscribeProfileCards = null;
let _unsubNotifs = null;

const _el = id => document.getElementById(id);
const _fs = () => firebase.firestore();

/* =============================================
 SKELETON SHIMMER INJECTOR (For initial page load)
 ============================================= */
(function injectShimmerCSS() {
 if (document.getElementById('shimmer-style')) return;
 const style = document.createElement('style');
 style.id = 'shimmer-style';
 style.textContent = `@keyframes shimmer {
 0% { background-position: -200% 0; }
 100% { background-position: 200% 0; }
 }`;
 document.head.appendChild(style);
})();

function showInitialSkeletons() {
 const el = _el('profileCardContainer');
 if (!el) return;

 let html = '';
 for (let i = 0; i < 3; i++) {
 html += `<div class="cm-skeleton-card"></div>`;
 }
 el.innerHTML = html;
}

/* =============================================
 HELPERS
 ============================================= */
function escapeHtml(text) {
 const div = document.createElement('div');
 div.textContent = String(text ?? '');
 return div.innerHTML;
}

function isPlaceholderPhoto(url) {
 if (!url) return true;
 return url.indexOf('dailyvetlogo') !== -1 || url.indexOf('data:image/svg+xml') === 0;
}

function getUserPetsString(user) {
 if (Array.isArray(user.pets) && user.pets.length) return user.pets.join(', ');
 return user.petType || '';
}

const _cleanPhone = p => String(p || '').replace(/[^0-9+]/g, '');
const _myPhone = () => _cleanPhone(sessionStorage.getItem('userPhone') || localStorage.getItem('userPhone'));

/* =============================================
 NOTIFICATION DROPDOWN
 ============================================= */
window.toggleNotificationDropdown = function () {
 if (window.closeProfileDropdown) window.closeProfileDropdown();
 const dropdown = _el('notificationDropdown');
 if (!dropdown) return;
 dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
};

document.addEventListener('click', function (e) {
 const dropdown = _el('notificationDropdown');
 const bell = document.querySelector('.bell-wrapper');
 if (!dropdown || !bell) return;
 if (!dropdown.contains(e.target) && !bell.contains(e.target)) {
 dropdown.style.display = 'none';
 }
});

/* =============================================
 🔔 NOTIFICATION SYSTEM
 ============================================= */
function initNotifications() {
 const phone = sessionStorage.getItem('userPhone') || localStorage.getItem('userPhone');
 if (!phone) {
 console.warn('🔔 No phone — notification skipped');
 return;
 }

 console.log('🔔 Init notifications for:', phone);

 const ref = _fs().collection('users').doc(phone).collection('notifications');

 if (_unsubNotifs) _unsubNotifs();
 _unsubNotifs = ref.onSnapshot(snap => {
 const items = [];
 let unread = 0;

 snap.forEach(d => {
 const n = { id: d.id, ...d.data() };
 items.push(n);
 if (!n.read && n.active !== false) unread++;
 });

 items.sort((a, b) => (b.createdAtMs || 0) - (a.createdAtMs || 0));

 console.log('🔔 Notifications:', items.length, '| Unread:', unread);

 _updateBadge(unread);
 _renderNotifList(items);
 _updateMarkAllBtn(unread);
 _updateClearBtn(items.length);

 }, err => {
 console.warn('🔔 Notification listener failed:', err.message);
 });

 if (window.DVNotifications?.checkAndFireReminders) {
 setTimeout(() => window.DVNotifications.checkAndFireReminders(), 2000);
 }
}

function _updateBadge(count) {
 const badge = _el('notificationBadge');
 if (!badge) return;
 if (count > 0) {
 badge.textContent = count > 9 ? '9+' : count;
 badge.style.display = 'flex';
 } else {
 badge.style.display = 'none';
 }
}

function _updateMarkAllBtn(unread) {
 const btn = _el('markAllReadBtn');
 if (!btn) return;
 btn.disabled = unread === 0;
 btn.style.opacity = unread === 0 ? '0.5' : '1';
}

function _updateClearBtn(total) {
 const btn = _el('clearAllNotifBtn');
 if (!btn) return;
 btn.disabled = total === 0;
 btn.style.opacity = total === 0 ? '0.5' : '1';
}

function _renderNotifList(items) {
 const list = _el('notificationList');
 if (!list) return;

 if (!items.length) {
 list.innerHTML = '<div class="notif-empty">No notifications</div>';
 return;
 }

 list.innerHTML = items.map(n => {
 const isUnread = !n.read && n.active !== false;
 const isDone = n.active === false;
 const time = _relativeTime(n.createdAtMs);
 const safeId = String(n.id).replace(/'/g, "\\'");
 const safeUrl = String(n.actionUrl || 'ai.html').replace(/'/g, "\\'");

 return `
 <div class="notif-item ${isUnread ? 'is-unread' : ''} ${isDone ? 'is-done' : ''}">
 <div class="notif-item-icon">${n.icon || '🔔'}</div>
 <div class="notif-item-body" onclick="window.__openNotification('${safeId}', '${safeUrl}')">
 <div class="notif-item-title">${escapeHtml(n.title || '')}</div>
 <div class="notif-item-text">${escapeHtml(n.body || '')}</div>
 <div class="notif-item-time">${time}${n.remindCount ? ` • ${n.remindCount}×` : ''}</div>
 </div>
 ${isUnread ? '<div class="notif-dot"></div>' : ''}
 <button class="notif-delete-btn"
 title="Delete notification"
 onclick="event.stopPropagation(); window.__deleteNotification('${safeId}')">
 <i class="fas fa-trash-alt"></i>
 </button>
 </div>
 `;
 }).join('');
}

function _relativeTime(ms) {
 if (!ms) return '';
 const diff = Date.now() - ms;
 const min = 60 * 1000, hour = 60 * min, day = 24 * hour;
 if (diff < min) return 'Just now';
 if (diff < hour) return Math.floor(diff / min) + 'm ago';
 if (diff < day) return Math.floor(diff / hour) + 'h ago';
 return Math.floor(diff / day) + 'd ago';
}

window.__openNotification = async function (notifId, url) {
 try {
 const phone = sessionStorage.getItem('userPhone') || localStorage.getItem('userPhone');
 await _fs().collection('users').doc(phone)
 .collection('notifications').doc(notifId)
 .update({
 read: true,
 readAt: firebase.firestore.FieldValue.serverTimestamp(),
 readAtMs: Date.now()
 });
 } catch (e) {
 console.warn('Mark read failed:', e.message);
 }
 const dd = _el('notificationDropdown');
 if (dd) dd.style.display = 'none';
 if (url) window.location.href = url;
};

window.__deleteNotification = async function (notifId) {
 if (!notifId) return;
 if (!confirm('🗑️ Delete this notification?')) return;

 const phone = sessionStorage.getItem('userPhone') || localStorage.getItem('userPhone');
 if (!phone) return;

 try {
 await _fs().collection('users').doc(phone)
 .collection('notifications').doc(notifId)
 .delete();
 } catch (err) {
 console.warn('❌ Delete failed:', err.message);
 alert('Failed to delete. Please try again.');
 }
};

async function markAllNotificationsRead() {
 const phone = sessionStorage.getItem('userPhone') || localStorage.getItem('userPhone');
 if (!phone) return;

 const btn = _el('markAllReadBtn');
 const originalHTML = btn ? btn.innerHTML : '';
 if (btn) {
 btn.disabled = true;
 btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
 }

 try {
 const ref = _fs().collection('users').doc(phone).collection('notifications');
 const snap = await ref.where('read', '==', false).get();

 if (snap.empty) return;

 const batch = _fs().batch();
 snap.forEach(d => {
 batch.update(d.ref, {
 read: true,
 readAt: firebase.firestore.FieldValue.serverTimestamp(),
 readAtMs: Date.now()
 });
 });
 await batch.commit();

 _updateBadge(0);
 _updateMarkAllBtn(0);

 } catch (err) {
 console.warn('❌ Mark all read failed:', err.message);
 alert('Failed to mark as read. Please try again.');
 } finally {
 if (btn) btn.innerHTML = originalHTML;
 }
}
window.markAllNotificationsRead = markAllNotificationsRead;

async function clearAllNotifications() {
 const phone = sessionStorage.getItem('userPhone') || localStorage.getItem('userPhone');
 if (!phone) return;

 if (!confirm('🗑️ Delete ALL notifications?\n\nThis cannot be undone.')) return;

 const btn = _el('clearAllNotifBtn');
 const originalHTML = btn ? btn.innerHTML : '';
 if (btn) {
 btn.disabled = true;
 btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
 }

 try {
 const ref = _fs().collection('users').doc(phone).collection('notifications');
 const snap = await ref.get();

 if (snap.empty) return;

 const batch = _fs().batch();
 snap.forEach(d => batch.delete(d.ref));
 await batch.commit();

 _updateBadge(0);
 _updateMarkAllBtn(0);
 _updateClearBtn(0);

 const list = _el('notificationList');
 if (list) list.innerHTML = '<div class="notif-empty">No notifications</div>';

 } catch (err) {
 console.warn('❌ Clear all failed:', err.message);
 alert('Failed to clear. Please try again.');
 } finally {
 if (btn) btn.innerHTML = originalHTML;
 }
}
window.clearAllNotifications = clearAllNotifications;

/* =============================================
 SEARCH
 ============================================= */
let _searchTimer;

function initSearchHandler() {
 const input = _el('petSearchInput');
 const clearBtn = _el('clearSearchBtn');
 if (!input) return;

 input.addEventListener('input', function () {
 const val = this.value.trim();
 if (clearBtn) clearBtn.style.display = val ? 'flex' : 'none';

 clearTimeout(_searchTimer);
 _searchTimer = setTimeout(() => applyFilter(val), 200);
 });

 input.addEventListener('keypress', function (e) {
 if (e.key !== 'Enter') return;
 e.preventDefault();
 clearTimeout(_searchTimer);
 applyFilter(this.value.trim());
 });
}

function clearPetSearch() {
 const input = _el('petSearchInput');
 if (input) input.value = '';
 const clearBtn = _el('clearSearchBtn');
 if (clearBtn) clearBtn.style.display = 'none';
 applyFilter('');
}

/* =============================================
 FILTER
 ============================================= */
function applyFilter(searchText) {
 const q = (searchText || '').toLowerCase().trim();

 const filtered = !q ? allUsers : allUsers.filter(user => {
 const haystack = [
 user.name || '',
 getUserPetsString(user),
 user.city || '',
 user.area || ''
 ].join(' ').toLowerCase();
 return haystack.includes(q);
 });

 const infoEl = _el('searchResultInfo');
 if (infoEl) {
 if (q) {
 infoEl.textContent = `${filtered.length} result${filtered.length !== 1 ? 's' : ''} for "${searchText}"`;
 infoEl.style.display = 'block';
 } else {
 infoEl.style.display = 'none';
 }
 }

 renderProfileCards(filtered);
}

/* =============================================
 LOAD PROFILE CARDS — Live via onSnapshot
 ============================================= */
function loadProfileCards() {
 const container = _el('profileCardContainer');
 if (!container) return;

 if (unsubscribeProfileCards) {
 unsubscribeProfileCards();
 unsubscribeProfileCards = null;
 }

 unsubscribeProfileCards = _fs()
 .collection('users')
 .orderBy('createdAt', 'desc')
 .limit(50)
 .onSnapshot(snapshot => {
 if (snapshot.empty) {
 allUsers = [];
 container.innerHTML = `
 <div class="cm-empty-inline">
 <i class="fas fa-users"></i>
 <span>No users yet</span>
 </div>`;
 return;
 }

 allUsers = [];
 snapshot.forEach(doc => {
 const data = doc.data();
 if (!data.name) return;

 const petsArray = Array.isArray(data.pets)
 ? data.pets
 : (data.petType ? [data.petType] : []);

 allUsers.push({
 id: doc.id,
 name: data.name,
 pets: petsArray,
 petType: data.petType || '',
 city: data.city || '',
 area: data.area || '',
 photoURL: isPlaceholderPhoto(data.photoURL) ? null : data.photoURL,
 phone: data.phone || doc.id
 });
 });

 const input = _el('petSearchInput');
 applyFilter(input ? input.value.trim() : '');

 }, error => {
 console.error('Error loading profile cards:', error);
 container.innerHTML = `
 <div class="cm-empty-inline">
 <i class="fas fa-exclamation-circle"></i>
 <span>Could not load users</span>
 </div>`;
 });
}

/* =============================================
 RENDER PROFILE CARDS
 ============================================= */
function renderProfileCards(users) {
 const container = _el('profileCardContainer');
 const noUsers = _el('noUsersMessage');
 if (!container) return;

 if (!users.length) {
 container.innerHTML = '';
 if (noUsers) noUsers.style.display = 'flex';
 return;
 }

 if (noUsers) noUsers.style.display = 'none';

 const myPhone = _myPhone();

 container.innerHTML = users.map(user => {
 const petsStr = getUserPetsString(user);
 const roleText = petsStr ? `Pet Owner · ${petsStr}` : 'Pet Owner';
 const location = [user.city, user.area].filter(Boolean).join(', ') || 'Location not set';

 const imgHTML = user.photoURL
 ? `<img src="${user.photoURL}" alt="${escapeHtml(user.name)}" loading="lazy" onerror="this.parentElement.innerHTML='<i class=\\'fas fa-user\\'></i>';" />`
 : `<i class="fas fa-user"></i>`;

 const safePhone = (user.phone || '').replace(/'/g, "\\'");
 const isMe = myPhone && _cleanPhone(user.phone) === myPhone;

 const isCommunity = typeof window !== 'undefined' && window.location.pathname.includes('community.html');
 const fromParam = isCommunity ? '?from=community' : '';

 const viewAction = isMe
 ? `onclick="window.location.href='profile.html${fromParam}'"`
 : `onclick="viewUserProfile('${safePhone}')"`;

 return `
 <div class="profile-card-item">
 <div class="profile-card-top">
 <div class="profile-card-avatar" ${viewAction}>
 ${imgHTML}
 </div>
 <div class="profile-card-info">
 <h5 class="profile-card-name">
 ${escapeHtml(user.name)}${isMe ? ' <span class="profile-card-you">(You)</span>' : ''}
 </h5>
 <div class="profile-card-role">${escapeHtml(roleText)}</div>
 <p class="profile-card-location">${escapeHtml(location)}</p>
 </div>
 </div>
 <div class="profile-card-actions">
 <button class="profile-card-btn" title="Call" onclick="callUser('${safePhone}')">
 <i class="fas fa-phone"></i>
 </button>
 <button class="profile-card-btn" title="Chat on WhatsApp" onclick="whatsappUser('${safePhone}')">
 <i class="fab fa-whatsapp"></i>
 </button>
 <button class="profile-card-btn profile-card-btn-primary" title="View Profile" ${viewAction}>
 <i class="fas fa-user"></i>
 </button>
 </div>
 </div>`;
 }).join('');
}

/* =============================================
 PROFILE ACTIONS
 ============================================= */
function formatPhoneForLink(phone) {
 if (!phone) return '';
 let clean = String(phone).replace(/[\s\-+]/g, '');
 if (clean.startsWith('880')) clean = '+880' + clean.slice(3);
 else if (clean.startsWith('0')) clean = '+880' + clean.slice(1);
 else clean = '+880' + clean;
 return clean;
}

window.callUser = function (phone) {
 if (!phone) return alert('Phone not available');
 window.location.href = 'tel:' + formatPhoneForLink(phone);
};

window.whatsappUser = function (phone) {
 if (!phone) return alert('Phone not available');
 const clean = formatPhoneForLink(phone).replace('+', '');
 const message = encodeURIComponent('Hello! I found you on DailyVet. Can we talk?');
 window.open('https://wa.me/' + clean + '?text=' + message, '_blank');
};

window.viewUserProfile = function (phone) {
 if (!phone) return alert('User not found');

 const myPhone = _myPhone();
 const cleanPhone = _cleanPhone(phone);
 const isCommunity = typeof window !== 'undefined' && window.location.pathname.includes('community.html');

 if (myPhone && cleanPhone === myPhone) {
 window.location.href = isCommunity ? 'profile.html?from=community' : 'profile.html';
 return;
 }

 const fromParam = isCommunity ? '&from=community' : '';
 window.location.href = 'profile.html?phone=' + encodeURIComponent(phone) + fromParam;
};

/* =============================================
 MY PROFILE CARD
 ============================================= */
function renderMyProfileCard(data, fallbackName) {
 const name = (data && data.name) || fallbackName || 'User';

 const nameEl = _el('userName');
 if (nameEl) nameEl.textContent = name;

 const img = _el('profileIconImg');
 const initialEl = _el('profileAvatarInitial');
 const hasPhoto = data && !isPlaceholderPhoto(data.photoURL);
 if (initialEl) initialEl.textContent = name.trim().charAt(0).toUpperCase() || '?';
 if (img) {
 if (hasPhoto) {
 img.onerror = function () { img.style.display = 'none'; if (initialEl) initialEl.style.display = ''; };
 img.src = data.photoURL;
 img.style.display = 'block';
 if (initialEl) initialEl.style.display = 'none';
 } else {
 img.removeAttribute('src');
 img.style.display = 'none';
 if (initialEl) initialEl.style.display = '';
 }
 }

 const phoneBox = _el('profilePhone');
 if (phoneBox) {
 const ph = (data && data.phone) || sessionStorage.getItem('userPhone') || localStorage.getItem('userPhone') || '';
 phoneBox.style.display = ph ? 'flex' : 'none';
 const sp = phoneBox.querySelector('span');
 if (sp) sp.textContent = ph;
 }

 const locBox = _el('profileLocation');
 if (locBox) {
 const loc = [data && data.area, data && data.city].filter(Boolean).join(', ');
 locBox.style.display = loc ? 'flex' : 'none';
 const sp = locBox.querySelector('span');
 if (sp) sp.textContent = loc;
 }

 const petsArr = data && Array.isArray(data.pets) && data.pets.length
 ? data.pets
 : (data && data.petType ? [data.petType] : []);
 
 const petsLine = _el('myPetsLine');
 const petsChips = _el('myPetsChips');
 if (petsLine) {
 petsLine.removeAttribute('data-bn');
 petsLine.removeAttribute('data-en');
 petsLine.textContent = petsArr.length
 ? 'My pets'
 : 'No pets added yet';
 }
 if (petsChips) {
 petsChips.innerHTML = petsArr.map(p =>
 `<span class="dvp-chip"><i class="fas fa-paw"></i>${escapeHtml(p)}</span>`
 ).join('');
 }

 const menuAvatar = _el('profileMenuAvatar');
 if (menuAvatar) {
 menuAvatar.src = hasPhoto
 ? data.photoURL
 : `https://ui-avatars.com/api/?name=${encodeURIComponent(name.charAt(0).toUpperCase())}&background=035D69&color=fff&size=100`;
 }
 const menuName = _el('profileMenuName');
 if (menuName) menuName.textContent = name;
}

/* =============================================
 ✅ UNIFIED FINANCE & INSURANCE WIDGET
 ============================================= */
async function loadUnifiedWidget() {
    const contentEl = _el('widgetContent');
    const badgeEl = _el('widgetRiskBadge');
    const phone = sessionStorage.getItem('userPhone') || localStorage.getItem('userPhone');
    
    if (!contentEl || !phone) return;

    // Ensure Skeleton Loader is visible before fetching (fallback for JS execution)
    if (!contentEl.querySelector('.widget-skeleton-box')) {
        contentEl.innerHTML = `
            <div class="widget-skeleton-box">
                <div class="widget-skeleton-line short"></div>
                <div class="widget-skeleton-line"></div>
                <div class="widget-skeleton-line medium"></div>
            </div>
            <div class="widget-skeleton-box">
                <div class="widget-skeleton-line short"></div>
                <div class="widget-skeleton-line"></div>
            </div>
        `;
    }

    try {
        const db = _fs();

        // 1. Fetch Finance Data (Current Month)
        const ledgerSnap = await db.collection('users').doc(phone).collection('ledger').get();
        let income = 0, expense = 0;
        const now = new Date();
        
        ledgerSnap.forEach(doc => {
            const d = doc.data();
            const dt = d.timestamp ? d.timestamp.toDate() : now;
            if (dt.getMonth() === now.getMonth() && dt.getFullYear() === now.getFullYear()) {
                if (d.type === 'income') income += Number(d.amount);
                if (d.type === 'expense') expense += Number(d.amount);
            }
        });
        const netProfit = income - expense;

        // 2. Fetch Insurance Data
        const insSnap = await db.collection('users').doc(phone).collection('insurance_policies')
            .where('status', '==', 'active').limit(1).get();
        
        let insuranceHtml = '';
        let isProtected = false;
        let paidOut = 0;

        if (!insSnap.empty) {
            isProtected = true;
            const p = insSnap.docs[0].data();
            paidOut = p.totalPaidOut || 0;
            insuranceHtml = `
                <div style="display: flex; justify-content: space-between; font-size: 0.75rem;">
                    <span style="color: #475569; font-weight: 600;">🛡️ Covered:</span>
                    <b style="color: #1E40AF;">${(p.animalType || 'cow').toUpperCase()} (${(p.district || '').toUpperCase()})</b>
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 0.75rem;">
                    <span style="color: #475569; font-weight: 600;">💰 Total Payouts:</span>
                    <b style="color: #047857;">৳${paidOut.toLocaleString('en-IN')}</b>
                </div>
            `;
        } else {
            insuranceHtml = `
                <div style="display: flex; justify-content: space-between; font-size: 0.75rem;">
                    <span style="color: #475569; font-weight: 600;">🛡️ Coverage:</span>
                    <b style="color: #DC2626;">Not Protected</b>
                </div>
            `;
        }

        // 3. Update Badge (Risk/Protection Level)
        if (badgeEl) {
            if (isProtected) {
                badgeEl.innerText = 'PROTECTED';
                badgeEl.style.background = '#ECFDF5';
                badgeEl.style.color = '#047857';
            } else {
                badgeEl.innerText = 'UNPROTECTED';
                badgeEl.style.background = '#FEF2F2';
                badgeEl.style.color = '#DC2626';
            }
        }

        // 4. Render Content
        contentEl.innerHTML = `
            <div style="background: #fff; padding: 0.75rem; border-radius: 10px; border: 1px solid #E2E8F0; display: flex; flex-direction: column; gap: 0.5rem;">
                <div style="display: flex; justify-content: space-between; font-size: 0.75rem;">
                    <span style="color: #475569; font-weight: 600;">📈 Monthly Income:</span>
                    <b style="color: #059669;">৳${income.toLocaleString('en-IN')}</b>
                </div>
                <div style="display: flex; justify-content: space-between; font-size: 0.75rem;">
                    <span style="color: #475569; font-weight: 600;">📉 Monthly Expense:</span>
                    <b style="color: #DC2626;">৳${expense.toLocaleString('en-IN')}</b>
                </div>
                <div style="height: 1px; background: #E2E8F0; margin: 2px 0;"></div>
                <div style="display: flex; justify-content: space-between; font-size: 0.8125rem;">
                    <span style="color: #0F172A; font-weight: 800;">Net Profit:</span>
                    <b style="color: ${netProfit >= 0 ? '#047857' : '#DC2626'}; font-size: 0.875rem;">
                        ${netProfit < 0 ? '-' : ''}৳${Math.abs(netProfit).toLocaleString('en-IN')}
                    </b>
                </div>
            </div>
            <div style="background: #fff; padding: 0.75rem; border-radius: 10px; border: 1px solid #E2E8F0; display: flex; flex-direction: column; gap: 0.375rem;">
                ${insuranceHtml}
            </div>
        `;

    } catch (err) {
        console.warn('[Home Widget] Load failed:', err.message);
        contentEl.innerHTML = `<div style="color: #DC2626; font-size: 0.75rem; text-align: center; padding: 1rem;">Failed to load data. Please try again.</div>`;
        if (badgeEl) badgeEl.style.display = 'none';
    }
}

/* =============================================
 AUTH STATE
 ============================================= */
let _unsubMyProfile = null;

firebase.auth().onAuthStateChanged(function () {
 const userPhone = sessionStorage.getItem('userPhone') || localStorage.getItem('userPhone');

 if (!userPhone) {
 window.location.href = 'login.html';
 return;
 }
 try {
 sessionStorage.setItem('userPhone', userPhone);
 localStorage.setItem('userPhone', userPhone);
 } catch (_) {}

 const cachedName = sessionStorage.getItem('userName') || localStorage.getItem('userName') || '';

 renderMyProfileCard({ name: cachedName || 'User', phone: userPhone }, cachedName);

 if (_unsubMyProfile) _unsubMyProfile();
 _unsubMyProfile = _fs().collection('users').doc(userPhone).onSnapshot(doc => {
 if (!doc.exists) return;
 const data = doc.data();
 const finalName = data.name || cachedName || 'User';
 try {
 sessionStorage.setItem('userName', finalName);
 localStorage.setItem('userName', finalName);
 } catch (_) {}
 renderMyProfileCard(data, finalName);
 }, err => console.warn('Profile load failed:', err.message));

 loadProfileCards();

 setTimeout(initNotifications, 800);
 
 // Load Unified Widget
 setTimeout(loadUnifiedWidget, 1500);
});

/* =============================================
 INIT
 ============================================= */
document.addEventListener('DOMContentLoaded', function () {
 showInitialSkeletons();
 initSearchHandler();
});

/* ========================================
 GLOBAL EXPORTS
 ======================================== */
window.clearPetSearch = clearPetSearch;

})();