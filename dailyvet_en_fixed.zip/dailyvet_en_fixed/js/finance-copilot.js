/* ============================================================
   DailyVet — SME Finance Copilot v4.2 (Strict English Only)
   ✅ 64 districts + Area picker (LocationIQ)
   ✅ Voice Ledger + AI Parse + Firestore
   ✅ Live NASA Weather -> Dynamic Income Projection
   ✅ Statement import (bKash / Nagad / bank — CSV)
   ✅ Credit Readiness card integration
   ============================================================ */

const _fs = () => firebase.firestore();
const _el = id => document.getElementById(id);

let _fcPhone = null;
let _fcIncome = 0;
let _fcExpense = 0;
let lastBatchIds = [];
let processing = false;

/* Location tracking */
let _fcDistrict = localStorage.getItem('userDistrict') || 'dhaka';
let _fcArea = localStorage.getItem('userArea') || '';
let _fcAreaLat = null;
let _fcAreaLng = null;

/* Business type */
let _fcBusinessType = localStorage.getItem('financeBusinessType') || 'livestock';

const BASE_MONTHLY_INCOME = 30000;

const GROQ_API_KEY = _dvDec('Z3NrX21WVXRJQThxTHdXUGNIZkFvNHNkV0dkeWIzRllkUk1rTlppMUxYT2gxb1RITVlIM0w3WXI=');
const GROQ_CHAT_URL = 'https://api.groq.com/openai/v1/chat/completions';
const GROQ_STT_URL = 'https://api.groq.com/openai/v1/audio/transcriptions';
const HIGH_VALUE_LIMIT = 50000;

const IDLE_MSG = 'Tap the mic and speak';

/* ============================================================
   BUSINESS TYPE
   ============================================================ */
const BUSINESS_TYPES = {
    livestock: {
        label: 'Livestock / Dairy farm',
        incomeSample: 'Sold milk 2000 taka',
        example: '"Sold milk 2000 taka and bought feed 1500"',
        incomeWords: ['milk', 'egg', 'animal', 'cattle', 'goat', 'chicken', 'subsidy', 'sold'],
        expenseWords: ['feed', 'medicine', 'vet', 'labour', 'vaccine', 'fodder'],
        expenseFallback: 'feed'
    },
    retail: {
        label: 'Retail / Shop',
        incomeSample: 'Sold goods 5000 taka',
        example: '"Sold goods 5000 taka and paid shop rent 2000"',
        incomeWords: ['sold', 'sale', 'received', 'customer', 'cash'],
        expenseWords: ['purchase', 'stock', 'rent', 'utility', 'salary', 'transport', 'bill'],
        expenseFallback: 'purchases'
    },
    service: {
        label: 'Service business',
        incomeSample: 'Got payment 3000 taka',
        example: '"Got service payment 3000 taka and paid helper 1000"',
        incomeWords: ['payment', 'received', 'fee', 'service', 'client'],
        expenseWords: ['salary', 'rent', 'utility', 'transport', 'materials', 'bill'],
        expenseFallback: 'overhead'
    }
};

const _bt = () => BUSINESS_TYPES[_fcBusinessType] || BUSINESS_TYPES.livestock;

/* ============================================================
   HELPERS
   ============================================================ */
const _ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
const escapeHtml = t => String(t ?? '').replace(/[&<>"']/g, c => _ESC[c]);
const joinText = (...p) => p.map(s => (s || '').trim()).filter(Boolean).join(' ');
const fmt = n => '৳ ' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 });
const hasGroqKey = () => !!GROQ_API_KEY && !GROQ_API_KEY.startsWith('PASTE_');

function setStatus(text, kind) {
    const el = _el('voiceStatus');
    if (!el) return;
    const colors = { idle: '#64748B', ok: '#059669', warn: '#D97706', err: '#DC2626' };
    el.innerText = text;
    el.style.color = colors[kind] || colors.idle;
}

function setListeningUI(on, msg) {
    const btn = _el('voiceBtn');
    if (btn) btn.classList.toggle('listening', on);
    const icon = btn && btn.querySelector('i');
    if (icon) icon.className = on ? 'fas fa-microphone-lines' : 'fas fa-microphone';
    if (on) setStatus(msg || 'Listening... speak now', 'ok');
}

function setBusy(on) {
    const b = _el('smartAddBtn');
    if (b) b.disabled = on;
}

/* ============================================================
   INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', () => {
    _fcPhone = localStorage.getItem('userPhone') || sessionStorage.getItem('userPhone');
    if (!_fcPhone) {
        window.location.href = 'login.html';
        return;
    }

    /* Voice language preference */
    const langSel = _el('voiceLang');
    if (langSel) {
        const saved = localStorage.getItem('financeVoiceLang');
        if (saved) langSel.value = saved;
        langSel.addEventListener('change', () => localStorage.setItem('financeVoiceLang', langSel.value));
    }

    /* Business type selector */
    const btSel = _el('businessType');
    if (btSel) {
        btSel.value = _fcBusinessType;
        btSel.addEventListener('change', () => {
            _fcBusinessType = btSel.value;
            localStorage.setItem('financeBusinessType', _fcBusinessType);
            updateBusinessTypeHints();
        });
        updateBusinessTypeHints();
    }

    /* Enter = Add & Calculate */
    const input = _el('smartInput');
    if (input) {
        input.addEventListener('keydown', e => {
            if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) {
                e.preventDefault();
                processSmartInput();
            }
        });
    }

    /* Statement import button */
    const csvBtn = _el('csvImportBtn');
    if (csvBtn) csvBtn.addEventListener('click', () => _el('csvFileInput')?.click());
    const csvInput = _el('csvFileInput');
    if (csvInput) csvInput.addEventListener('change', handleCsvImport);

    if (!SpeechRecognitionCtor && !canUseWhisper()) {
        setStatus('Voice not supported here — type below', 'warn');
    } else {
        setStatus(IDLE_MSG, 'idle');
    }

    loadLedgerFromFirestore();

    /* Initial Weather Load */
    loadWeatherForecast();
});

function updateBusinessTypeHints() {
    const cfg = _bt();
    const input = _el('smartInput');
    if (input) input.placeholder = `e.g. ${cfg.incomeSample}`;
    const hint = _el('businessTypeHint');
    if (hint) {
        hint.innerHTML = `Examples: ${escapeHtml(cfg.example)}`;
    }
}

/* ============================================================
   PICKER CALLBACK (District + Area)
   ============================================================ */
window.onFinanceLocationChange = function (payload) {
    if (!payload || !payload.districtKey) return;

    _fcDistrict = payload.districtKey;
    _fcArea = payload.hasArea ? payload.area : '';
    _fcAreaLat = payload.hasArea ? payload.lat : null;
    _fcAreaLng = payload.hasArea ? payload.lng : null;

    localStorage.setItem('userDistrict', _fcDistrict);
    if (_fcArea) localStorage.setItem('userArea', _fcArea);
    else localStorage.removeItem('userArea');

    weatherForecastCache = null;
    loadWeatherForecast();
};

/* ============================================================
   VOICE -> TEXT
   ============================================================ */
const SpeechRecognitionCtor = window.SpeechRecognition || window.webkitSpeechRecognition;
const SILENCE_SUBMIT_MS = 1800;
const REC_IDLE_STOP_MS = 7000;

let recognition = null;
let wantListening = false;
let submitOnEnd = false;
let recBase = '';
let recSession = '';
let recLastActivity = 0;
let recAborted = false;
let silenceTimer = null;

let usingWhisper = false;
let mediaRecorder = null;
let mediaStream = null;
let audioChunks = [];
let whisperTimer = null;
let audioCtx = null;
let vadTimer = null;
let whisperHeard = false;
let recGotResult = false;

const getLang = () => (_el('voiceLang') && _el('voiceLang').value) || 'en-US';

function initRecognition() {
    if (!SpeechRecognitionCtor) return false;
    recognition = new SpeechRecognitionCtor();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;

    recognition.onstart = () => setListeningUI(true);

    recognition.onresult = event => {
        if (recAborted) return;
        let finalText = '', interim = '';
        for (let i = 0; i < event.results.length; i++) {
            const r = event.results[i];
            if (r.isFinal) finalText += r[0].transcript + ' ';
            else interim += r[0].transcript;
        }
        recGotResult = true;
        recSession = joinText(finalText, interim);
        recLastActivity = Date.now();

        const input = _el('smartInput');
        if (input) input.value = joinText(recBase, recSession);

        clearTimeout(silenceTimer);
        silenceTimer = setTimeout(finishVoiceAndProcess, SILENCE_SUBMIT_MS);
    };

    recognition.onerror = event => {
        const err = event && event.error;
        if (err === 'no-speech' || err === 'aborted') return;
        wantListening = false;

        if (err === 'not-allowed') {
            alert('Please allow microphone access.');
            return;
        }
        if (canUseWhisper()) {
            usingWhisper = true;
            setStatus('Switching to cloud voice...', 'warn');
            startWhisper();
        } else if (err === 'network') {
            alert('Voice input needs an internet connection.');
        }
    };

    recognition.onend = () => {
        recBase = joinText(recBase, recSession);
        recSession = '';
        if (usingWhisper) return;

        const idle = Date.now() - recLastActivity > REC_IDLE_STOP_MS;
        if (wantListening && !recAborted && !idle && !submitOnEnd) {
            setTimeout(() => {
                if (!wantListening || recAborted) return;
                try { recognition.start(); } catch (_) { wantListening = false; setListeningUI(false); setStatus(IDLE_MSG, 'idle'); }
            }, 120);
            return;
        }

        clearTimeout(silenceTimer);
        if (idle && !recGotResult && !submitOnEnd) {
            wantListening = false;
            setListeningUI(false);
            if (canUseWhisper()) {
                usingWhisper = true;
                setStatus('Switching to cloud voice...', 'warn');
                startWhisper();
            } else {
                setStatus("Didn't catch any speech. Try English or type below.", 'err');
            }
            return;
        }
        const shouldSubmit = (submitOnEnd || idle) && !recAborted;
        wantListening = false;
        submitOnEnd = false;
        setListeningUI(false);
        if (shouldSubmit) processSmartInput();
        else setStatus(IDLE_MSG, 'idle');
    };
    return true;
}

function startVoiceLedger() {
    if (mediaRecorder && mediaRecorder.state === 'recording') { stopWhisper(); return; }
    if (wantListening) { finishVoiceAndProcess(); return; }

    if (!SpeechRecognitionCtor) {
        if (canUseWhisper()) { usingWhisper = true; startWhisper(); }
        else alert('Voice recognition is not supported in this browser. Please type.');
        return;
    }
    if (!recognition && !initRecognition()) return;

    const input = _el('smartInput');
    try { recognition.lang = getLang(); } catch (_) {}
    recBase = input ? input.value.trim() : '';
    recSession = '';
    recAborted = false;
    recGotResult = false;
    submitOnEnd = false;
    wantListening = true;
    recLastActivity = Date.now();
    try {
        recognition.start();
    } catch (err) {
        wantListening = false;
        setListeningUI(false);
        setStatus(IDLE_MSG, 'idle');
    }
}

function finishVoiceAndProcess() {
    clearTimeout(silenceTimer);
    if (!wantListening) return;
    submitOnEnd = true;
    wantListening = false;
    try { recognition.stop(); } catch (_) {
        submitOnEnd = false;
        setListeningUI(false);
        processSmartInput();
    }
}

function canUseWhisper() {
    return hasGroqKey() && !!(navigator.mediaDevices && window.MediaRecorder);
}

function pickMimeType() {
    const types = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg'];
    return types.find(t => MediaRecorder.isTypeSupported(t)) || '';
}

async function startWhisper() {
    if (!canUseWhisper()) {
        usingWhisper = false;
        alert('Voice is not supported in this browser. Please type below.');
        return;
    }
    try {
        mediaStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (err) {
        usingWhisper = false;
        setListeningUI(false);
        setStatus('Microphone permission denied', 'err');
        return;
    }

    usingWhisper = true;
    audioChunks = [];
    const mimeType = pickMimeType();
    mediaRecorder = new MediaRecorder(mediaStream, mimeType ? { mimeType } : undefined);
    mediaRecorder.ondataavailable = e => { if (e.data && e.data.size) audioChunks.push(e.data); };

    mediaRecorder.onstop = async () => {
        clearTimeout(whisperTimer);
        stopVad();
        mediaStream.getTracks().forEach(t => t.stop());
        setListeningUI(false);
        const blob = new Blob(audioChunks, { type: mediaRecorder.mimeType || 'audio/webm' });
        try {
            if (!whisperHeard || blob.size < 1000) {
                setStatus("Didn't catch any speech. Try again.", 'err');
                return;
            }
            setStatus('Converting voice to text...', 'warn');
            const text = await transcribeWithGroq(blob);
            const input = _el('smartInput');
            if (input) input.value = joinText(input.value, text);
            usingWhisper = false;
            await processSmartInput();
        } catch (err) {
            console.error('Whisper failed', err);
            setStatus('Cloud voice failed: ' + String(err.message || err).slice(0, 90), 'err');
        } finally {
            usingWhisper = false;
        }
    };

    mediaRecorder.start();
    startVad(mediaStream);
    setListeningUI(true, 'Listening... speak now');
    whisperTimer = setTimeout(stopWhisper, 20000);
}

function startVad(stream) {
    whisperHeard = false;
    try {
        const AC = window.AudioContext || window.webkitAudioContext;
        audioCtx = new AC();
        if (audioCtx.resume) audioCtx.resume();
        const src = audioCtx.createMediaStreamSource(stream);
        const analyser = audioCtx.createAnalyser();
        analyser.fftSize = 1024;
        src.connect(analyser);
        const buf = new Uint8Array(analyser.fftSize);
        const started = Date.now();
        let lastVoice = 0;
        vadTimer = setInterval(() => {
            analyser.getByteTimeDomainData(buf);
            let sum = 0;
            for (let i = 0; i < buf.length; i++) { const v = (buf[i] - 128) / 128; sum += v * v; }
            const rms = Math.sqrt(sum / buf.length);
            const now = Date.now();
            if (rms > 0.015) { whisperHeard = true; lastVoice = now; }
            if (whisperHeard && now - lastVoice > 1500) stopWhisper();
            else if (!whisperHeard && now - started > 8000) stopWhisper();
        }, 100);
    } catch (e) {
        whisperHeard = true;
    }
}

function stopVad() {
    clearInterval(vadTimer);
    vadTimer = null;
    if (audioCtx) { try { audioCtx.close(); } catch (_) {} audioCtx = null; }
}

function stopWhisper() {
    if (mediaRecorder && mediaRecorder.state === 'recording') mediaRecorder.stop();
}

async function transcribeWithGroq(blob) {
    const ext = blob.type.includes('mp4') ? 'mp4' : blob.type.includes('ogg') ? 'ogg' : 'webm';
    const form = new FormData();
    form.append('file', blob, `voice.${ext}`);
    form.append('model', 'whisper-large-v3');
    form.append('language', getLang().split('-')[0]);
    form.append('response_format', 'json');
    form.append('temperature', '0');

    const res = await fetch(GROQ_STT_URL, {
        method: 'POST',
        headers: { Authorization: `Bearer ${GROQ_API_KEY}` },
        body: form
    });
    if (!res.ok) throw new Error('Groq STT ' + res.status + ': ' + (await res.text()));
    return (await res.json()).text;
}

/* ============================================================
   SMART PARSE
   ============================================================ */
async function parseWithGroq(text) {
    const cfg = _bt();
    const system =
        `You are a bookkeeping assistant for a Bangladeshi ${cfg.label} business. ` +
        "The input (English or mixed) can contain ONE OR MORE money transactions. " +
        'Return ONLY JSON: {"transactions":[{"type":"income" or "expense","amount":number,"description":"short English description"}]}. ' +
        `income = money received (${cfg.incomeWords.join(', ')}). expense = money spent (${cfg.expenseWords.join(', ')}). ` +
        'Convert number words to a plain BDT number. Quantities like "2 goats" or "5 kg" are NOT the amount; use the money amount. ' +
        'If a part has no clear money amount, skip it. If nothing is found return {"transactions":[]}.';

    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 9000);
    try {
        const res = await fetch(GROQ_CHAT_URL, {
            method: 'POST',
            signal: ctrl.signal,
            headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${GROQ_API_KEY}` },
            body: JSON.stringify({
                model: 'llama-3.3-70b-versatile',
                temperature: 0,
                response_format: { type: 'json_object' },
                messages: [
                    { role: 'system', content: system },
                    { role: 'user', content: text }
                ]
            })
        });
        if (!res.ok) throw new Error('Groq chat ' + res.status + ': ' + (await res.text()));
        const data = await res.json();
        const parsed = JSON.parse(data.choices[0].message.content);
        return normalizeItems(parsed.transactions);
    } finally {
        clearTimeout(timer);
    }
}

function normalizeItems(list) {
    if (!Array.isArray(list)) return [];
    return list.map(t => ({
        type: String(t.type || '').toLowerCase() === 'income' ? 'income'
            : String(t.type || '').toLowerCase() === 'expense' ? 'expense' : null,
        amount: Math.round(Number(t.amount) * 100) / 100,
        description: String(t.description || '').trim().slice(0, 80)
    })).filter(t => t.type && isFinite(t.amount) && t.amount > 0)
        .map(t => ({ ...t, description: t.description || (t.type === 'income' ? 'Income' : 'Expense') }));
}

/* Local rule-based parser */
const MULT = {
    k: 1e3, thousand: 1e3, hajar: 1e3,
    lakh: 1e5, lac: 1e5,
    hundred: 100,
    crore: 1e7
};
const AMOUNT_RE = /(\d+(?:\.\d+)?)\s*((?:thousand|hajar|lakh|lac|hundred|crore|k)(?![a-z]))?/gi;
const SEG_SPLIT_RE = /[;\n]+|,\s+|\s+(?:and|then|also)\s+/i;

const INCOME_WORDS = ['sold', 'sell', 'sale', 'received', 'earned', 'income', 'profit', 'collected'];
const EXPENSE_WORDS = ['bought', 'buy', 'purchase', 'paid', 'spent', 'spend', 'cost', 'expense', 'bill', 'feed', 'medicine', 'salary', 'wage', 'rent', 'stock', 'utility'];

function wordHits(lower, words) {
    return words.reduce((n, w) => {
        const ascii = /^[a-z ]+$/.test(w);
        const hit = ascii ? new RegExp('\\b' + w + '\\b').test(lower) : lower.includes(w);
        return n + (hit ? 1 : 0);
    }, 0);
}

function detectType(seg) {
    const l = seg.toLowerCase();
    const i = wordHits(l, INCOME_WORDS), e = wordHits(l, EXPENSE_WORDS);
    if (i > e) return 'income';
    if (e > i) return 'expense';
    return null;
}

function extractAmount(seg) {
    const s = seg.replace(/(\d),(?=\d)/g, '$1');

    const re = new RegExp(AMOUNT_RE.source, 'gi');
    const found = [];
    let m, prev = null;
    while ((m = re.exec(s))) {
        const mult = m[2] ? MULT[m[2].toLowerCase()] : 1;
        const value = parseFloat(m[1]) * mult;
        const start = m.index, end = m.index + m[0].length;
        if (prev && prev.mult > 1 && !m[2] && /^\s*$/.test(s.slice(prev.end, start)) && value < prev.mult) {
            prev.value += value;
            prev.end = end;
            continue;
        }
        prev = { value, mult, start, end };
        found.push(prev);
    }

    const isMoney = c =>
        /^\s*(?:taka|tk|bdt|৳)/i.test(s.slice(c.end)) ||
        /(?:৳|tk\.?|taka|bdt)\s*$/i.test(s.slice(0, c.start));
    const money = found.filter(isMoney);
    const pool = money.length ? money : found.filter(c => c.mult > 1 || c.value >= 10);
    if (!pool.length) return null;
    return Math.round(Math.max(...pool.map(c => c.value)) * 100) / 100;
}

function cleanDescription(seg, type) {
    let d = seg
        .replace(new RegExp(AMOUNT_RE.source, 'gi'), ' ')
        .replace(/৳|\btaka\b|\btk\.?|\bbdt\b/gi, ' ')
        .replace(/[.,!?]+/g, ' ')
        .replace(/\s+/g, ' ')
        .trim()
        .replace(/\s+(?:for|of|at|and|to)$/i, '')
        .slice(0, 50);
    if (!d) return type === 'income' ? 'Income' : 'Expense';
    return d.charAt(0).toUpperCase() + d.slice(1);
}

function parseLocally(text) {
    const norm = text.replace(/(\d),(?=\d)/g, '$1');
    const raw = norm.split(SEG_SPLIT_RE).map(s => (s || '').trim()).filter(Boolean);

    const segs = [];
    let buf = '';
    raw.forEach(seg => {
        const cand = buf ? buf + ' ' + seg : seg;
        if (extractAmount(cand) != null) { segs.push(cand); buf = ''; } else buf = cand;
    });

    const out = [];
    let lastType = null;
    segs.forEach(seg => {
        const type = detectType(seg) || lastType;
        if (!type) return;
        lastType = type;
        out.push({ type, amount: extractAmount(seg), description: cleanDescription(seg, type) });
    });
    return out;
}

/* ============================================================
   ADD & AUTO-CALCULATE
   ============================================================ */
async function processSmartInput() {
    if (processing) return;
    const input = _el('smartInput');
    const text = input ? input.value.trim() : '';
    if (!text) {
        setStatus('Nothing to add — speak or type first.', 'warn');
        return;
    }

    processing = true;
    setBusy(true);
    try {
        setStatus('Calculating...', 'warn');

        let items = [];
        if (hasGroqKey()) {
            try { items = await parseWithGroq(text); }
            catch (err) { console.warn('AI parse failed, using local parser:', err); }
        }
        if (!items.length) items = parseLocally(text);

        if (!items.length) {
            setStatus(`Couldn't find an amount. Try: "${_bt().incomeSample}"`, 'err');
            return;
        }

        const approved = items.filter(it =>
            it.amount <= HIGH_VALUE_LIMIT ||
            confirm(`High-value: ${it.description} — ${fmt(it.amount)}. Add anyway?`)
        );
        if (!approved.length) {
            setStatus('Nothing added.', 'warn');
            return;
        }

        await saveBatch(approved);
        input.value = '';
        recBase = '';
        showResult(approved);
        setStatus('Added · heard: "' + text.slice(0, 90) + '"', 'ok');
        await loadLedgerFromFirestore();
    } catch (err) {
        console.error('Save failed', err);
        setStatus('Failed to save. Check Firebase rules or internet.', 'err');
    } finally {
        processing = false;
        setBusy(false);
    }
}

async function saveBatch(items) {
    const col = _fs().collection('users').doc(_fcPhone).collection('ledger');
    const batch = _fs().batch();
    const ids = [];
    items.forEach(it => {
        const ref = col.doc();
        ids.push(ref.id);
        batch.set(ref, {
            type: it.type,
            amount: it.amount,
            description: it.description,
            businessType: _fcBusinessType,
            source: it.source || 'manual',
            timestamp: firebase.firestore.FieldValue.serverTimestamp()
        });
    });
    await batch.commit();
    lastBatchIds = ids;
}

function showResult(items) {
    const box = _el('smartResult');
    if (!box) return;
    const inc = items.filter(i => i.type === 'income').reduce((s, i) => s + i.amount, 0);
    const exp = items.filter(i => i.type === 'expense').reduce((s, i) => s + i.amount, 0);
    const net = inc - exp;

    const chips = items.map(it =>
        `<span class="smart-chip ${it.type}">${it.type === 'income' ? '+' : '−'}${fmt(it.amount)} · ${escapeHtml(it.description)}</span>`
    ).join('');

    box.innerHTML = `
        <div class="smart-chips">${chips}</div>
        <div class="smart-sum">
            Income ${fmt(inc)} · Expense ${fmt(exp)} ·
            <b style="color:${net < 0 ? '#DC2626' : '#059669'}">Net ${net < 0 ? '−' : '+'}${fmt(Math.abs(net))}</b>
            <button class="smart-undo" onclick="undoLastBatch()"><i class="fas fa-rotate-left"></i> Undo</button>
        </div>`;
}

async function undoLastBatch() {
    if (!lastBatchIds.length) return;
    try {
        const col = _fs().collection('users').doc(_fcPhone).collection('ledger');
        const batch = _fs().batch();
        lastBatchIds.forEach(id => batch.delete(col.doc(id)));
        await batch.commit();
        lastBatchIds = [];
        const box = _el('smartResult');
        if (box) box.innerHTML = '<div class="smart-sum">Last entry undone.</div>';
        setStatus(IDLE_MSG, 'idle');
        await loadLedgerFromFirestore();
    } catch (err) {
        console.error('Undo failed', err);
        alert('Could not undo. Please try again.');
    }
}

async function addManualTransaction() {
    const type = _el('manualType').value;
    const desc = _el('manualDesc').value.trim();
    const amount = parseFloat(_el('manualAmount').value);

    if (!desc || isNaN(amount) || amount <= 0) {
        alert('Please enter a valid description and amount.');
        return;
    }
    if (amount > HIGH_VALUE_LIMIT && !confirm(`High-value: ${fmt(amount)}. Add anyway?`)) return;

    try {
        await saveBatch([{ type, amount, description: desc, source: 'manual' }]);
        showResult([{ type, amount, description: desc }]);
        _el('manualDesc').value = '';
        _el('manualAmount').value = '';
        await loadLedgerFromFirestore();
    } catch (err) {
        console.error('Save failed', err);
        alert('Failed to save. Check Firebase rules or internet.');
    }
}

/* ============================================================
   STATEMENT IMPORT
   ============================================================ */
function _csvParseLine(line) {
    const out = [];
    let cur = '', inQ = false;
    for (let i = 0; i < line.length; i++) {
        const c = line[i];
        if (c === '"') {
            if (inQ && line[i + 1] === '"') { cur += '"'; i++; }
            else inQ = !inQ;
        } else if (c === ',' && !inQ) {
            out.push(cur); cur = '';
        } else {
            cur += c;
        }
    }
    out.push(cur);
    return out.map(s => s.trim());
}

function _normalizeCsvType(raw) {
    const t = String(raw || '').toLowerCase().trim();
    if (['income', 'in', 'credit', 'received', 'cr'].includes(t)) return 'income';
    if (['expense', 'out', 'debit', 'paid', 'dr'].includes(t)) return 'expense';
    return null;
}

function _parseCsvDate(raw) {
    if (!raw) return null;
    const s = String(raw).trim();

    let m = s.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
    if (m) {
        const d = new Date(+m[1], +m[2] - 1, +m[3]);
        return isNaN(d) ? null : d;
    }

    m = s.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})/);
    if (m) {
        const d = new Date(+m[3], +m[2] - 1, +m[1]);
        return isNaN(d) ? null : d;
    }

    const d = new Date(s);
    return isNaN(d) ? null : d;
}

async function handleCsvImport(event) {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;

    setStatus('Parsing statement...', 'warn');

    try {
        const text = await file.text();
        const lines = text.split(/\r?\n/).filter(l => l.trim());
        if (lines.length < 2) throw new Error('File has no data rows');

        const header = _csvParseLine(lines[0]).map(h => h.toLowerCase());
        const idx = {
            date: header.indexOf('date'),
            type: header.indexOf('type'),
            amount: header.indexOf('amount'),
            description: header.indexOf('description')
        };
        if (idx.type < 0 || idx.amount < 0) {
            throw new Error('Missing required columns: type, amount');
        }

        const items = [];
        for (let i = 1; i < lines.length; i++) {
            const cols = _csvParseLine(lines[i]);
            const type = _normalizeCsvType(cols[idx.type]);
            const amount = Number(String(cols[idx.amount] || '').replace(/[^0-9.\-]/g, ''));
            if (!type || !isFinite(amount) || amount <= 0) continue;

            const parsedDate = idx.date >= 0 ? _parseCsvDate(cols[idx.date]) : null;

            items.push({
                type,
                amount: Math.round(amount * 100) / 100,
                description: (idx.description >= 0 ? cols[idx.description] : '') ||
                             (type === 'income' ? 'Income' : 'Expense'),
                source: 'csv',
                date: parsedDate || new Date()
            });
        }

        if (!items.length) {
            setStatus('No valid transactions found in CSV.', 'err');
            return;
        }

        if (!confirm(`Import ${items.length} transactions from "${file.name}"?`)) return;

        const col = _fs().collection('users').doc(_fcPhone).collection('ledger');
        let batch = _fs().batch();
        let count = 0;
        for (const it of items) {
            batch.set(col.doc(), {
                type: it.type,
                amount: it.amount,
                description: it.description.slice(0, 80),
                businessType: _fcBusinessType,
                source: 'csv',
                timestamp: firebase.firestore.Timestamp.fromDate(it.date)
            });
            count++;
            if (count % 400 === 0) {
                await batch.commit();
                batch = _fs().batch();
            }
        }
        await batch.commit();

        setStatus(`Imported ${items.length} transactions.`, 'ok');
        await loadLedgerFromFirestore();
    } catch (err) {
        console.error('Statement import failed:', err);
        setStatus('Statement import failed: ' + (err.message || 'unknown'), 'err');
    }
}

/* ============================================================
   LEDGER + MONTHLY P&L
   ============================================================ */
async function loadLedgerFromFirestore() {
    const ledgerDiv = _el('ledgerList');
    if (!ledgerDiv) return;

    try {
        const snap = await _fs().collection('users').doc(_fcPhone).collection('ledger')
            .orderBy('timestamp', 'desc').limit(300).get();

        if (snap.empty) {
            ledgerDiv.innerHTML = '<p style="color:#64748B; font-size:0.9rem; text-align:center;">No transactions yet.</p>';
            updatePandL(0, 0);
            return;
        }

        const docs = [];
        snap.forEach(doc => docs.push(doc.data()));

        const now = new Date();
        let inc = 0, exp = 0;
        docs.forEach(d => {
            const dt = d.timestamp ? d.timestamp.toDate() : now;
            if (dt.getFullYear() !== now.getFullYear() || dt.getMonth() !== now.getMonth()) return;
            if (d.type === 'income') inc += Number(d.amount);
            if (d.type === 'expense') exp += Number(d.amount);
        });

        ledgerDiv.innerHTML = docs.slice(0, 10).map(d => {
            const color = d.type === 'income' ? '#059669' : '#DC2626';
            const icon = d.type === 'income' ? 'fa-arrow-down' : 'fa-arrow-up';
            const srcBadge = d.source === 'csv'
                ? '<span style="font-size:10px;background:#eff6ff;color:#1e40af;padding:1px 6px;border-radius:6px;margin-left:4px;">CSV</span>'
                : '';
            return `
            <div class="ledger-row">
                <div class="ledger-desc"><i class="fas ${icon}" style="color:${color}"></i> ${escapeHtml(d.description)}${srcBadge}</div>
                <b class="ledger-amt" style="color:${color}">${fmt(d.amount)}</b>
            </div>`;
        }).join('');

        updatePandL(inc, exp);
    } catch (err) {
        console.error('Firestore Error: ', err);
        ledgerDiv.innerHTML = '<div style="color:#DC2626; font-size:0.85rem; text-align:center;">Error loading. Check Firebase Rules.</div>';
    }
}

function updatePandL(income, expense) {
    _fcIncome = income;
    _fcExpense = expense;
    const net = income - expense;

    const incEl = _el('totalIncome');
    const expEl = _el('totalExpense');
    const netEl = _el('netProfit');
    if (incEl) incEl.innerText = fmt(income);
    if (expEl) expEl.innerText = fmt(expense);
    if (netEl) {
        netEl.innerText = (net < 0 ? '−' : '') + fmt(Math.abs(net));
        netEl.style.color = net < 0 ? '#DC2626' : '#0F5132';
    }

    _renderCreditReadiness();
}

function _renderCreditReadiness() {
    if (!window.DVCreditReadiness) return;
    const host = _el('creditReadinessCard');
    if (!host) return;
    try {
        window.DVCreditReadiness.render('creditReadinessCard', _fcPhone);
    } catch (err) {
        console.warn('[CreditReadiness] render failed:', err.message);
    }
}

function calculateCreditScore() {
    const scoreDiv = _el('creditScore');
    const statusDiv = _el('loanStatus');
    if (!scoreDiv || !statusDiv) return;

    scoreDiv.innerText = '...';

    setTimeout(() => {
        let score = 500;
        const profit = _fcIncome - _fcExpense;

        if (_fcIncome > 0) score += 200;
        if (profit > 0) score += 250;
        if (profit > 5000) score += 49;

        score = Math.min(999, score);
        scoreDiv.innerText = score;

        if (score > 700) {
            statusDiv.innerText = 'Excellent! Eligible for Bank Loan.';
            statusDiv.className = 'status-text success';
        } else if (score > 600) {
            statusDiv.innerText = 'Good. Eligible for Micro-finance.';
            statusDiv.className = 'status-text warning';
        } else {
            statusDiv.innerText = 'Needs Improvement.';
            statusDiv.className = 'status-text danger';
            showDebtRestructuring();
        }
    }, 1000);
}

function showDebtRestructuring() {
    const debtSection = _el('debtFraudSection');
    const debtAdvice = _el('debtAdvice');
    if (!debtSection || !debtAdvice) return;

    debtSection.style.display = 'block';
    debtAdvice.innerHTML = '<i class="fas fa-spinner fa-spin"></i> AI Agent is analyzing your cash flow...';

    setTimeout(() => {
        const cfg = _bt();
        debtAdvice.innerText =
            `You have ${fmt(_fcExpense)} expense and ${fmt(_fcIncome)} income. ` +
            `AI Suggestion: Cut non-essential ${cfg.expenseFallback}, ` +
            'prioritise paying 40% of the loan now, and schedule the rest against next month\'s expected income.';
    }, 1500);
}

/* ============================================================
   LIVE DYNAMIC WEATHER -> CASHFLOW BRIDGE
   ============================================================ */
let weatherForecastCache = null;

async function loadWeatherForecast() {
    const host = _el('weatherForecastCard');
    if (!host) return;

    host.innerHTML = `
        <div class="weather-loading">
            <i class="fas fa-satellite-dish fa-bounce"></i>
            <div>Reading NASA satellite data for ${_fcArea ? _fcArea + ', ' : ''}${_fcDistrict}...</div>
        </div>`;

    try {
        const coords = (window.BD_DISTRICTS_LIST && window.BD_DISTRICTS_LIST[_fcDistrict]) || { lat: 23.8103, lng: 90.4125 };
        const lat = (_fcAreaLat !== null) ? _fcAreaLat : coords.lat;
        const lng = (_fcAreaLng !== null) ? _fcAreaLng : coords.lng;

        if (typeof fetchLiveRiskData !== 'function') {
            throw new Error('Insurance NASA engine not loaded');
        }

        const risk = await Promise.race([
            fetchLiveRiskData(_fcDistrict, lat, lng),
            new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 12000))
        ]);

        const floodScore = risk.flood?.score || 0;
        const thi = risk.heat?.thi || 0;
        const thiLevel = risk.heat?.level || 'normal';

        const displayLocation = _fcArea ? `${_fcArea}, ${_fcDistrict}` : _fcDistrict;

        let incomeFactor = 1.0;
        let riskReason = 'Optimal conditions';
        let riskColor = '#059669';
        let adviceText = '';
        let adviceIcon = '✅';

        if (floodScore > 70 || thiLevel === 'severe') {
            incomeFactor = 0.65;
            riskReason = 'High Flood/Heat Risk';
            riskColor = '#dc2626';
            adviceText = `Extreme weather detected in ${displayLocation}. ${_bt().label} income may drop. Consider parametric insurance to protect your cashflow.`;
            adviceIcon = '🚨';
        } else if (floodScore > 40 || thiLevel === 'moderate') {
            incomeFactor = 0.85;
            riskReason = 'Moderate Weather Risk';
            riskColor = '#d97706';
            adviceText = `Moderate weather risk in ${displayLocation}. Keep an eye on operations and secure outdoor equipment.`;
            adviceIcon = '⚠️';
        } else if (floodScore > 20 || thiLevel === 'mild') {
            incomeFactor = 0.95;
            riskReason = 'Slight Weather Impact';
            riskColor = '#f59e0b';
            adviceText = `Conditions are mostly favorable in ${displayLocation}. Continue regular operations.`;
            adviceIcon = '🌤️';
        } else {
            adviceText = `Excellent weather conditions in ${displayLocation}. Good time to expand production.`;
            adviceIcon = '🌟';
        }

        const monthlyIncome = _fcIncome > 0 ? _fcIncome : BASE_MONTHLY_INCOME;
        const forecastIncome = Math.round(monthlyIncome * incomeFactor);

        weatherForecastCache = { floodScore, thi, thiLevel, riskReason, incomeFactor, forecastIncome, districtName: _fcDistrict, areaName: _fcArea };

        host.innerHTML = `
            <div class="weather-card-header">
                <div>
                    <div class="weather-card-title">
                        <i class="fas fa-cloud-sun-rain"></i>
                        30-Day Cashflow Forecast
                    </div>
                    <div class="weather-card-sub">
                        📍 ${escapeHtml(_fcArea ? _fcArea + ', ' : '')}${escapeHtml(_fcDistrict.toUpperCase())} • NASA POWER
                    </div>
                </div>
            </div>

            <div class="weather-metrics">
                <div class="weather-metric" style="border-color:${floodScore > 40 ? '#dc2626' : '#059669'};">
                    <div class="weather-metric-icon">🌊</div>
                    <div class="weather-metric-value" style="color:${floodScore > 40 ? '#dc2626' : '#059669'};">${floodScore}%</div>
                    <div class="weather-metric-label">Flood Risk</div>
                </div>

                <div class="weather-metric" style="border-color:${thi > 78 ? '#dc2626' : '#d97706'};">
                    <div class="weather-metric-icon">🌡️</div>
                    <div class="weather-metric-value" style="color:${thi > 78 ? '#dc2626' : '#d97706'};">${Math.round(thi)}</div>
                    <div class="weather-metric-label">Heat THI</div>
                </div>

                <div class="weather-metric" style="border-color:#0891b2;">
                    <div class="weather-metric-icon">📉</div>
                    <div class="weather-metric-value" style="color:#0891b2;">${Math.round(incomeFactor * 100)}%</div>
                    <div class="weather-metric-label">Income Health</div>
                </div>
            </div>

            <div style="background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%); border: 1px solid #e2e8f0; border-left: 4px solid ${riskColor}; border-radius: 12px; padding: 1.25rem; margin-bottom: 1rem; flex: 1; display: flex; flex-direction: column; justify-content: center;">
                <div style="display: flex; align-items: flex-start; gap: 10px;">
                    <span style="font-size: 1.5rem; line-height: 1;">${adviceIcon}</span>
                    <div>
                        <div style="font-size: 0.875rem; font-weight: 800; color: #1e293b; margin-bottom: 4px;">Financial Impact Insight</div>
                        <div style="font-size: 0.8125rem; color: #475569; line-height: 1.5;">${escapeHtml(adviceText)}</div>
                    </div>
                </div>
            </div>

            <div class="weather-forecast-result">
                <div class="weather-forecast-label">
                    📊 Predicted Next 30-Day Income
                </div>
                <div class="weather-forecast-value">
                    ${fmt(forecastIncome)}
                </div>
                <div class="weather-forecast-basis">
                    Based on ${fmt(monthlyIncome)} baseline •
                    <span style="color:${riskColor}; font-weight: 800;">
                        ${incomeFactor < 1 ? `−${Math.round((1 - incomeFactor) * 100)}% ${riskReason}` : riskReason}
                    </span>
                </div>
            </div>

            <div class="weather-actions">
                <button type="button" class="weather-btn weather-btn-primary" onclick="refreshWeatherForecast()">
                    <i class="fas fa-rotate-right"></i> Refresh
                </button>
                <button type="button" class="weather-btn" onclick="showScenarioPlanning()">
                    <i class="fas fa-flask"></i> What-If Scenarios
                </button>
            </div>
        `;
    } catch (err) {
        console.error('[Finance] Weather fetch failed:', err);
        host.innerHTML = `
            <div class="weather-error">
                <i class="fas fa-exclamation-triangle" style="color:#dc2626; font-size: 2rem; margin-bottom: 1rem;"></i>
                <div>⚠️ Failed to load satellite data for <b>${escapeHtml(_fcDistrict)}</b>.</div>
                <div style="font-size: 12px; color: #64748B; margin-top: 8px;">${escapeHtml(err.message)}</div>
                <button type="button" class="weather-btn" onclick="refreshWeatherForecast()" style="margin-top: 12px; width: auto;">Try Again</button>
            </div>`;
    }
}

window.refreshWeatherForecast = function () {
    weatherForecastCache = null;
    loadWeatherForecast();
};

window.showScenarioPlanning = function () {
    const host = _el('weatherForecastCard');
    if (!host || !weatherForecastCache) return;

    const weather = weatherForecastCache;
    const monthlyIncome = _fcIncome > 0 ? _fcIncome : BASE_MONTHLY_INCOME;
    const locationStr = (weather.areaName ? weather.areaName + ', ' : '') + weather.districtName;

    const scenarios = [
        { name: 'If No Rain Next 2 Weeks', icon: '🏜️', condition: 'Drought stress', factor: 0.75, color: '#dc2626' },
        { name: 'If Extreme Heat (THI > 85)', icon: '🔥', condition: 'Heat stress', factor: 0.80, color: '#dc2626' },
        { name: 'If Normal Conditions', icon: '✅', condition: 'Optimal', factor: 1.0, color: '#059669' },
        { name: 'If Good Rain', icon: '🌧️', condition: 'Favorable', factor: 1.10, color: '#059669' }
    ];

    const scenariosHtml = scenarios.map(s => `
        <div class="scenario-card" style="border-left-color:${s.color};">
            <div class="scenario-icon">${s.icon}</div>
            <div class="scenario-body">
                <div class="scenario-name">${s.name}</div>
                <div class="scenario-condition">${s.condition}</div>
            </div>
            <div class="scenario-result" style="color:${s.color};">
                ${fmt(Math.round(monthlyIncome * s.factor))}
            </div>
        </div>
    `).join('');

    host.innerHTML = `
        <div class="weather-card-header">
            <div>
                <div class="weather-card-title">
                    <i class="fas fa-flask"></i>
                    Scenario Planning — ${escapeHtml(locationStr)}
                </div>
                <div class="weather-card-sub">
                    How weather affects your income
                </div>
            </div>
        </div>

        <div class="scenario-list">
            ${scenariosHtml}
        </div>

        <div class="scenario-note">
            💡 These are estimates. Actual income depends on your ${_bt().label.toLowerCase()} scale and market prices.
        </div>

        <div class="weather-actions">
            <button type="button" class="weather-btn weather-btn-primary" onclick="refreshWeatherForecast()">
                <i class="fas fa-arrow-left"></i> Back to Forecast
            </button>
        </div>
    `;
};

window.addEventListener('load', () => {
    setTimeout(() => {
        if (!weatherForecastCache) loadWeatherForecast();
    }, 3000);
});
