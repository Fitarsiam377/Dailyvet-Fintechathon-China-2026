/* ============================================================
   DailyVet — Insurance Risk Map Sidebar v6.2
   ✅ Proper click handling
   ✅ Syncs with map's risk logic (window.DVRisk)
   ✅ Graceful loading & error states
   ============================================================ */

/* ============================================================
   MAIN CALLBACK (ম্যাপ থেকে ক্লিক করলে এটি কল হবে)
   ============================================================ */
window.onRiskMapLocationChange = async function (payload) {
    if (!payload || !payload.districtKey) return;

    const sidebar = document.getElementById('sidebarContent');
    if (!sidebar) return;

    // ১. লোডিং স্টেট দেখানো
    sidebar.innerHTML = `
        <div style="text-align:center; color:#64748B; padding: 2.5rem 1rem;">
            <i class="fas fa-satellite-dish fa-bounce" style="font-size: 2.5rem; margin-bottom: 1rem; color: #0891B2;"></i>
            <div style="font-weight: 700; font-size: 1.05rem;">Fetching live NASA data...</div>
            <div style="color:#0F2C59; font-size:1.25rem; font-weight: 900; margin-top: 0.5rem;">
                ${payload.districtName}${payload.area ? ', ' + payload.area : ''}
            </div>
        </div>`;

    try {
        // ২. নাসা ডাটা ফেচ (এরিয়া থাকলে এরিয়ার lat/lng, না থাকলে জেলার lat/lng)
        const lat = payload.hasArea ? payload.lat : undefined;
        const lng = payload.hasArea ? payload.lng : undefined;
        
        if (typeof fetchLiveRiskData !== 'function') {
            throw new Error('Insurance engine (fetchLiveRiskData) not loaded');
        }

        const riskData = await fetchLiveRiskData(payload.districtKey, lat, lng);
        if (!riskData) throw new Error('No data received from NASA');

        // ৩. প্রিমিয়াম ক্যালকুলেশন (insurance.js থেকে)
        if (typeof calculatePremiumFromRisk !== 'function') {
            throw new Error('Premium calculator not loaded');
        }
        const calc = calculatePremiumFromRisk(riskData, 'cow');

        // ৪. সাইডবার রেন্ডার
        renderSidebarData(
            payload.districtName + (payload.area ? ', ' + payload.area : ''),
            riskData, 
            calc
        );

    } catch (err) {
        console.error('[RiskMap] Sidebar fetch failed:', err);
        sidebar.innerHTML = `
            <div style="color:#DC2626; padding:1.5rem 1rem; text-align:center;">
                <i class="fas fa-exclamation-triangle" style="font-size: 2rem; margin-bottom: 0.5rem;"></i>
                <div style="font-weight: 700;">Could not load data for ${payload.districtName}.</div>
                <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 4px;">${err.message}</div>
                <button onclick="window.onRiskMapLocationChange({districtKey: '${payload.districtKey}', districtName: '${payload.districtName}', hasArea: false})" style="margin-top: 12px; padding: 6px 12px; background: #f1f5f9; border: none; border-radius: 6px; font-weight: 700; cursor: pointer; color: #0f172a;">Try Again</button>
            </div>`;
    }
};

/* ============================================================
   RENDER SIDEBAR (প্রিমিয়াম ডিজাইন)
   ============================================================ */
function renderSidebarData(title, riskData, calc) {
    const sidebar = document.getElementById('sidebarContent');
    if (!sidebar) return;

    const flood = riskData.flood?.score || 0;
    const thi = riskData.heat?.thi || 0;
    const aqi = riskData.air?.aqi || '--';
    
    // ম্যাপের ওভারঅল রিস্ক (insurance-policy-map.js থেকে আসা DVRisk)
    // যদি DVRisk না থাকে, তবে calc.riskScore ব্যবহার করব
    const overallScore = window.DVRisk ? window.DVRisk.overall(flood, thi) : calc.riskScore;
    const riskLevel = window.DVRisk ? window.DVRisk.level(flood, thi) : 'safe';
    
    // কালার ডিফাইন করা
    const riskColor = calc.color;
    const riskBg = calc.bg;

    const floodColor = flood > 30 ? '#DC2626' : flood > 15 ? '#D97706' : '#059669';
    const thiColor = thi > 78 ? '#DC2626' : thi > 76 ? '#D97706' : '#059669';

    sidebar.innerHTML = `
        <div style="animation: ipmFade 0.3s ease; display: flex; flex-direction: column; height: 100%;">
            
            <div style="flex: 1;">
                <h4 style="font-size: 1.35rem; font-weight: 900; color: #0F172A; margin: 0 0 0.25rem; line-height: 1.2;">${title}</h4>
                <p style="font-size: 0.8125rem; color: #64748B; margin-bottom: 1.5rem;">Live NASA satellite risk assessment</p>

                <!-- Overall Risk Box -->
                <div style="border: 1.5px solid ${riskColor}40; background: ${riskBg}; border-radius: 12px; padding: 1rem; display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.25rem;">
                    <span style="font-size: 0.875rem; font-weight: 800; color: ${riskColor};">Overall Risk</span>
                    <span style="font-size: 1.5rem; font-weight: 900; color: ${riskColor};">${overallScore}/100</span>
                </div>

                <!-- Metrics -->
                <div class="irm-detail-row" style="border: 1px solid #e2e8f0; background: #fff;">
                    <span class="irm-detail-label">🌊 Flood Risk</span>
                    <span class="irm-detail-val" style="color: ${floodColor};">${flood}%</span>
                </div>
                <div class="irm-detail-row" style="border: 1px solid #e2e8f0; background: #fff;">
                    <span class="irm-detail-label">🌡️ Heat Stress</span>
                    <span class="irm-detail-val" style="color: ${thiColor};">THI ${thi}</span>
                </div>
                <div class="irm-detail-row" style="border: 1px solid #e2e8f0; background: #fff;">
                    <span class="irm-detail-label">💨 Air Quality</span>
                    <span class="irm-detail-val">AQI ${aqi}</span>
                </div>
            </div>

            <!-- Premium Result (নিচে ফিক্সড) -->
            <div style="margin-top: 2rem; padding-top: 1.5rem; border-top: 1.5px dashed #CBD5E1; text-align: center;">
                <div style="font-size: 0.8125rem; color: #64748B; font-weight: 800; margin-bottom: 0.25rem; text-transform: uppercase;">Estimated Premium</div>
                <div style="font-size: 2.75rem; font-weight: 900; color: #0F2C59; line-height: 1;">৳ ${calc.premium}</div>
                <a href="insurance-policy.html" style="display: flex; align-items: center; justify-content: center; gap: 0.5rem; margin-top: 1.25rem; background: #0F2C59; color: #fff; padding: 0.875rem 1.5rem; border-radius: 12px; font-weight: 800; text-decoration: none; font-size: 0.9375rem; width: 100%; box-shadow: 0 4px 12px rgba(15,44,89,0.2); transition: all 0.2s;">
                    <i class="fas fa-shield-halved"></i> Buy Policy Now
                </a>
            </div>

        </div>
    `;
}
