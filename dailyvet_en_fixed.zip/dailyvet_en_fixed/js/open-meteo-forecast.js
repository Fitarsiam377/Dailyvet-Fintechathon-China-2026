/* DailyVet — Open-Meteo Multi-API Integration v3.0 (Production + Flood + Past Days)
   Data sources (all key-free, unlimited):
   • Weather forecast   : api.open-meteo.com/v1/forecast
   • Air quality        : air-quality-api.open-meteo.com/v1/air-quality
   • Historical archive : archive-api.open-meteo.com/v1/archive

   Provides: temp, humidity, rainfall, wind, UV, PM2.5, PM10, AQI, solar radiation,
             ammonia (NH3), + 48h/72h cumulative rainfall (flood early warning),
             + past N days archive (for THI / risk comparison)

   Cache: localStorage, per-endpoint TTL (see CACHE_TTL below)
   Fallback: null (caller decides)

   ── v2.1 (Flood Early Warning) ──────────────────────────────
   • getRainfallCumulative(lat, lng, hours) → 48h/72h/96h totals + hourly array
   • getRainfallHourly(lat, lng, hours)     → hourly raw array
   • classifyFloodRisk(score)               → level + color + advice

   ── v3.0 additions ──────────────────────────────────────────
   • getPastDays(lat, lng, days)            → archive data (past N days) for
                                              Yesterday/Today THI comparison
   • Per-endpoint CACHE_TTL (weather 6h, aqi 60m, solar 12h, rainfall 60m, archive 24h)
   • AQI now includes ammonia (NH3) — critical for livestock shed ventilation
   • Backward compatible — all v2.0 / v2.1 APIs unchanged
*/
(function () {
'use strict';

const CACHE_KEY = 'dvOpenMeteoCache_v3';

/* ===== START: PER-ENDPOINT CACHE TTL =====
   Different data types change at different rates:
   - AQI / air pollution: ~hourly updates → 1h TTL
   - Weather forecast: refresh ~6h → 6h TTL
   - Solar (reanalysis): stable → 12h TTL
   - Rainfall hourly forecast: changes often → 1h TTL
   - Historical archive: immutable once published → 24h TTL
*/
const CACHE_TTL = {
    weather:  6 * 60 * 60 * 1000,   // 6h
    aqi:      60 * 60 * 1000,       // 1h
    solar:    12 * 60 * 60 * 1000,  // 12h
    rainfall: 60 * 60 * 1000,       // 1h
    archive:  24 * 60 * 60 * 1000   // 24h
};

// Legacy export — some code may reference OpenMeteo.CACHE_TTL_MS
const CACHE_TTL_MS = CACHE_TTL.weather;
/* ===== END: PER-ENDPOINT CACHE TTL ===== */

/* ============================================================
   CACHE HELPERS — per-entry TTL aware
   ============================================================ */
function _readCache(key, ttl) {
    try {
        const raw = localStorage.getItem(CACHE_KEY);
        if (!raw) return null;
        const cache = JSON.parse(raw);
        const hit = cache[key];
        if (!hit) return null;
        const age = Date.now() - hit.at;
        const effectiveTTL = Number.isFinite(ttl) ? ttl : CACHE_TTL.weather;
        if (age < effectiveTTL) return hit.data;
        return null;
    } catch (_) { return null; }
}

function _writeCache(key, data) {
    try {
        const raw = localStorage.getItem(CACHE_KEY);
        const cache = raw ? JSON.parse(raw) : {};
        cache[key] = { at: Date.now(), data };
        const keys = Object.keys(cache);
        if (keys.length > 40) {
            // keep most recent 40 entries
            keys
                .sort((a, b) => (cache[a].at || 0) - (cache[b].at || 0))
                .slice(0, keys.length - 40)
                .forEach(k => delete cache[k]);
        }
        localStorage.setItem(CACHE_KEY, JSON.stringify(cache));
    } catch (_) {}
}

/* ============================================================
   FETCH HELPER with timeout
   ============================================================ */
async function _fetchJSON(url) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 8000);
    try {
        const res = await fetch(url, { signal: controller.signal });
        clearTimeout(timer);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    } catch (err) {
        clearTimeout(timer);
        throw err;
    }
}

/* ============================================================
   1. WEATHER FORECAST
   ============================================================ */
async function fetchWeatherForecast(lat, lng, days) {
    days = Math.max(1, Math.min(days || 7, 16));
    const cacheKey = `weather_${lat.toFixed(2)}_${lng.toFixed(2)}_${days}`;

    const cached = _readCache(cacheKey, CACHE_TTL.weather);
    if (cached) return cached;

    try {
        const url = `https://api.open-meteo.com/v1/forecast` +
                    `?latitude=${lat.toFixed(4)}&longitude=${lng.toFixed(4)}` +
                    `&daily=` +
                    `temperature_2m_max,temperature_2m_min,` +
                    `relative_humidity_2m_mean,precipitation_sum,` +
                    `wind_speed_10m_max,uv_index_max,` +
                    `shortwave_radiation_sum,` +
                    `sunrise,sunset` +
                    `&hourly=relative_humidity_2m,temperature_2m` +
                    `&timezone=Asia%2FDhaka&forecast_days=${days}`;

        const data = await _fetchJSON(url);
        if (!data.daily || !Array.isArray(data.daily.time)) {
            throw new Error('Bad response');
        }

        const forecast = data.daily.time.map((date, i) => ({
            date,
            tempMax: data.daily.temperature_2m_max[i],
            tempMin: data.daily.temperature_2m_min[i],
            tempMean: (data.daily.temperature_2m_max[i] + data.daily.temperature_2m_min[i]) / 2,
            humidity: data.daily.relative_humidity_2m_mean[i],
            precipitation: data.daily.precipitation_sum[i],
            windMax: data.daily.wind_speed_10m_max[i],
            uvIndexMax: data.daily.uv_index_max[i],
            solarRadiation: data.daily.shortwave_radiation_sum[i],
            sunrise: data.daily.sunrise[i],
            sunset: data.daily.sunset[i]
        }));

        _writeCache(cacheKey, forecast);
        return forecast;
    } catch (err) {
        console.warn('[OpenMeteo] Weather fetch failed:', err.message);
        return null;
    }
}

/* ============================================================
   2. AIR QUALITY — includes ammonia (NH3) for livestock sheds
   ============================================================ */
async function fetchAirQuality(lat, lng) {
    const cacheKey = `aqi_${lat.toFixed(2)}_${lng.toFixed(2)}`;

    const cached = _readCache(cacheKey, CACHE_TTL.aqi);
    if (cached) return cached;

    try {
        const url = `https://air-quality-api.open-meteo.com/v1/air-quality` +
                    `?latitude=${lat.toFixed(4)}&longitude=${lng.toFixed(4)}` +
                    `&current=` +
                    `pm10,pm2_5,carbon_monoxide,nitrogen_dioxide,` +
                    `sulphur_dioxide,ozone,us_aqi,european_aqi,` +
                    `dust,aerosol_optical_depth,ammonia` +
                    `&timezone=Asia%2FDhaka`;

        const data = await _fetchJSON(url);
        if (!data.current) throw new Error('Bad AQI response');

        const c = data.current;
        const result = {
            time: c.time,
            pm10: c.pm10,
            pm25: c.pm2_5,
            co: c.carbon_monoxide,
            no2: c.nitrogen_dioxide,
            so2: c.sulphur_dioxide,
            o3: c.ozone,
            dust: c.dust,
            aod: c.aerosol_optical_depth,
            ammonia: c.ammonia,          /* μg/m³ — shed ventilation key */
            usAqi: c.us_aqi,
            euAqi: c.european_aqi
        };

        _writeCache(cacheKey, result);
        return result;
    } catch (err) {
        console.warn('[OpenMeteo] AQI fetch failed:', err.message);
        return null;
    }
}

/* ============================================================
   3. SOLAR RADIATION
   ============================================================ */
async function fetchSolarForecast(lat, lng, days) {
    days = Math.max(1, Math.min(days || 7, 16));
    const cacheKey = `solar_${lat.toFixed(2)}_${lng.toFixed(2)}_${days}`;

    const cached = _readCache(cacheKey, CACHE_TTL.solar);
    if (cached) return cached;

    try {
        const url = `https://api.open-meteo.com/v1/forecast` +
                    `?latitude=${lat.toFixed(4)}&longitude=${lng.toFixed(4)}` +
                    `&hourly=shortwave_radiation,direct_normal_irradiance,` +
                    `diffuse_radiation,terrestrial_radiation` +
                    `&timezone=Asia%2FDhaka&forecast_days=${days}`;

        const data = await _fetchJSON(url);
        if (!data.hourly) throw new Error('Bad solar response');

        const solar = data.hourly.time.map((time, i) => ({
            time,
            shortwave: data.hourly.shortwave_radiation[i],
            directNormal: data.hourly.direct_normal_irradiance[i],
            diffuse: data.hourly.diffuse_radiation[i],
            terrestrial: data.hourly.terrestrial_radiation[i]
        }));

        _writeCache(cacheKey, solar);
        return solar;
    } catch (err) {
        console.warn('[OpenMeteo] Solar fetch failed:', err.message);
        return null;
    }
}

/* ============================================================
   4. RAINFALL CUMULATIVE FORECAST (Flood Early Warning)
   ------------------------------------------------------------
   Returns 48h / 72h / 96h cumulative precipitation + hourly
   array + peak-hour info. Used by js/nasa-flood-engine.js to
   feed the flood risk calculator.
   ============================================================ */
async function getRainfallCumulative(lat, lng, hours) {
    hours = Math.max(24, Math.min(hours || 72, 120));
    const cacheKey = `rain_${lat.toFixed(2)}_${lng.toFixed(2)}_${hours}`;

    const cached = _readCache(cacheKey, CACHE_TTL.rainfall);
    if (cached) return cached;

    try {
        const url = `https://api.open-meteo.com/v1/forecast` +
                    `?latitude=${lat.toFixed(4)}&longitude=${lng.toFixed(4)}` +
                    `&hourly=precipitation,precipitation_probability` +
                    `&timezone=Asia%2FDhaka&forecast_days=5`;

        const data = await _fetchJSON(url);
        if (!data.hourly || !Array.isArray(data.hourly.precipitation)) {
            throw new Error('Bad rainfall response');
        }

        const precip = data.hourly.precipitation || [];
        const prob   = data.hourly.precipitation_probability || [];
        const times  = data.hourly.time || [];

        let total24 = 0, total48 = 0, total72 = 0, total96 = 0;
        let peakHourly = 0;
        let peakTime = null;
        let maxProb = 0;

        for (let i = 0; i < Math.min(precip.length, 96); i++) {
            const p = Number(precip[i]) || 0;
            const pr = Number(prob[i]) || 0;
            if (p > peakHourly) {
                peakHourly = p;
                peakTime = times[i];
            }
            if (pr > maxProb) maxProb = pr;
            if (i < 24) total24 += p;
            if (i < 48) total48 += p;
            if (i < 72) total72 += p;
            if (i < 96) total96 += p;
        }

        const result = {
            /* Cumulative totals */
            rain24hMm: Math.round(total24 * 10) / 10,
            rain48hMm: Math.round(total48 * 10) / 10,
            rain72hMm: Math.round(total72 * 10) / 10,
            rain96hMm: Math.round(total96 * 10) / 10,

            /* Peak / probability */
            peakHourlyMm: Math.round(peakHourly * 10) / 10,
            peakAt: peakTime,
            maxProbabilityPct: Math.round(maxProb),

            /* Hourly arrays (first N hours) */
            hourly: precip.slice(0, hours).map((p, i) => ({
                time: times[i],
                mm: Math.round((Number(p) || 0) * 10) / 10,
                probPct: Number(prob[i]) || 0
            })),

            /* Metadata */
            fetchedAt: Date.now(),
            hours: hours
        };

        _writeCache(cacheKey, result);
        return result;
    } catch (err) {
        console.warn('[OpenMeteo] Rainfall cumulative fetch failed:', err.message);
        return null;
    }
}

/* ============================================================
   5. RAINFALL HOURLY (raw array for chart rendering)
   ============================================================ */
async function getRainfallHourly(lat, lng, hours) {
    const data = await getRainfallCumulative(lat, lng, hours);
    if (!data || !Array.isArray(data.hourly)) return null;
    return data.hourly.map(h => h.mm);
}

/* ============================================================
   6. FLOOD RISK CLASSIFIER
   ------------------------------------------------------------
   Small helper for UI display. The real risk calculation lives
   in js/nasa-flood-engine.js — this is just a display helper.
   ============================================================ */
function classifyFloodRisk(score) {
    if (!Number.isFinite(score)) {
        return {
            level: 'unknown', label: 'Unknown', labelEn: 'Unknown',
            color: '#94a3b8', bg: '#f1f5f9', border: '#e2e8f0',
            icon: '⚪', action: 'No data'
        };
    }
    if (score >= 75) return {
        level: 'critical', label: 'Critical Flood Risk', labelEn: 'Critical',
        color: '#dc2626', bg: '#fef2f2', border: '#fecaca', icon: '🚨',
        action: 'Move livestock immediately — relocate to higher ground within 24 hours'
    };
    if (score >= 55) return {
        level: 'alert', label: 'High Flood Risk', labelEn: 'Alert',
        color: '#c2410c', bg: '#fff7ed', border: '#fdba74', icon: '⚠️',
        action: 'Move livestock to safe shelter within 48 hours, stockpile feed'
    };
    if (score >= 35) return {
        level: 'watch', label: 'Moderate Flood Risk', labelEn: 'Watch',
        color: '#d97706', bg: '#fef9e7', border: '#fcd34d', icon: '👀',
        action: 'Water level may rise — prepare feed, medicine and shelter'
    };
    return {
        level: 'safe', label: 'Normal Condition', labelEn: 'Safe',
        color: '#059669', bg: '#ecfdf5', border: '#86efac', icon: '✅',
        action: 'No immediate flood risk — continue normal operations'
    };
}

/* ============================================================
   7. 🆕 PAST DAYS (Archive API) — for THI / risk comparison
   ------------------------------------------------------------
   Fetches the last N days of real (not forecast) weather from
   Open-Meteo's Historical Weather API. Used by:
   - climate-feature.js renderTHI() → Yesterday's THI
   - climate-feature.js renderOutbreak() → Yesterday's outbreak risk
   - dvmShowArea() → Past trend comparison

   Returns array (oldest → newest) of daily summaries, or null.
   Each item has the same shape as fetchWeatherForecast() daily items.
   ============================================================ */
async function getPastDays(lat, lng, days) {
    days = Math.max(1, Math.min(days || 3, 30));
    const cacheKey = `archive_${lat.toFixed(2)}_${lng.toFixed(2)}_${days}`;

    const cached = _readCache(cacheKey, CACHE_TTL.archive);
    if (cached) return cached;

    try {
        // Compute date range: from (today - days) to yesterday
        const today = new Date();
        const endDate = new Date(today);
        endDate.setDate(endDate.getDate() - 1); // yesterday (archive has no today)
        const startDate = new Date(endDate);
        startDate.setDate(startDate.getDate() - (days - 1));

        const fmt = d =>
            `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

        const startStr = fmt(startDate);
        const endStr = fmt(endDate);

        const url = `https://archive-api.open-meteo.com/v1/archive` +
                    `?latitude=${lat.toFixed(4)}&longitude=${lng.toFixed(4)}` +
                    `&start_date=${startStr}&end_date=${endStr}` +
                    `&daily=` +
                    `temperature_2m_max,temperature_2m_min,temperature_2m_mean,` +
                    `relative_humidity_2m_mean,precipitation_sum,` +
                    `wind_speed_10m_max,shortwave_radiation_sum` +
                    `&timezone=Asia%2FDhaka`;

        const data = await _fetchJSON(url);
        if (!data.daily || !Array.isArray(data.daily.time)) {
            throw new Error('Bad archive response');
        }

        const archive = data.daily.time.map((date, i) => ({
            date,
            tempMax: data.daily.temperature_2m_max[i],
            tempMin: data.daily.temperature_2m_min[i],
            tempMean: data.daily.temperature_2m_mean[i],
            humidity: data.daily.relative_humidity_2m_mean[i],
            precipitation: data.daily.precipitation_sum[i],
            windMax: data.daily.wind_speed_10m_max[i],
            solarRadiation: data.daily.shortwave_radiation_sum[i]
        }));

        _writeCache(cacheKey, archive);
        return archive;
    } catch (err) {
        console.warn('[OpenMeteo] Past days (archive) fetch failed:', err.message);
        return null;
    }
}

/* ============================================================
   CONVENIENCE GETTERS
   ============================================================ */
async function getWeather(lat, lng, days) {
    return await fetchWeatherForecast(lat, lng, days || 7);
}

async function getToday(lat, lng) {
    const f = await fetchWeatherForecast(lat, lng, 2);
    return f && f[0] ? f[0] : null;
}

async function getTomorrow(lat, lng) {
    const f = await fetchWeatherForecast(lat, lng, 2);
    return f && f[1] ? f[1] : null;
}

async function getWeek(lat, lng) {
    return await fetchWeatherForecast(lat, lng, 7);
}

async function getAQI(lat, lng) {
    return await fetchAirQuality(lat, lng);
}

/* ============================================================
   CLASSIFICATIONS
   ============================================================ */
function classifyAQI(aqi) {
    if (!Number.isFinite(aqi)) {
        return { label: 'Unknown', labelEn: 'Unknown', color: '#94a3b8', icon: '⚪', advice: 'No data' };
    }
    if (aqi <= 50) return { label: 'Good', labelEn: 'Good', color: '#059669', icon: '🟢',
        advice: 'Air is clean — continue normal farm operations.' };
    if (aqi <= 100) return { label: 'Moderate', labelEn: 'Moderate', color: '#d97706', icon: '🟡',
        advice: 'Keep sensitive animals (young, sick) indoors when possible.' };
    if (aqi <= 150) return { label: 'Sensitive Groups', labelEn: 'Unhealthy for Sensitive Groups', color: '#ea580c', icon: '🟠',
        advice: 'Do not keep animals outdoors for long periods. Provide extra water.' };
    if (aqi <= 200) return { label: 'Unhealthy', labelEn: 'Unhealthy', color: '#dc2626', icon: '🔴',
        advice: 'Keep animals indoors, ensure shed ventilation is running.' };
    if (aqi <= 300) return { label: 'Very Unhealthy', labelEn: 'Very Unhealthy', color: '#991b1b', icon: '🟣',
        advice: 'Keep all animals indoors, maintain air circulation in sheds.' };
    return { label: 'Hazardous', labelEn: 'Hazardous', color: '#7f1d1d', icon: '☠️',
        advice: 'Emergency — keep all animals indoors, contact your veterinarian.' };
}

function classifyUV(uv) {
    if (!Number.isFinite(uv)) {
        return { label: 'Unknown', labelEn: 'Unknown', color: '#94a3b8', icon: '⚪', advice: 'No data' };
    }
    if (uv < 3) return { label: 'Low', labelEn: 'Low', color: '#059669', icon: '🟢',
        advice: 'Normal care — morning sunlight is beneficial for calves and cows.' };
    if (uv < 6) return { label: 'Moderate', labelEn: 'Moderate', color: '#d97706', icon: '🟡',
        advice: 'Provide shade during harsh midday sun. Ensure plenty of drinking water.' };
    if (uv < 8) return { label: 'High', labelEn: 'High', color: '#dc2626', icon: '🟠',
        advice: 'Keep animals in shade from 11 AM to 4 PM. Protect udders from direct sun.' };
    if (uv < 11) return { label: 'Very High', labelEn: 'Very High', color: '#991b1b', icon: '🔴',
        advice: 'Avoid direct sunlight. Provide water twice as often.' };
    return { label: 'Extreme', labelEn: 'Extreme', color: '#7f1d1d', icon: '☠️',
        advice: 'Emergency — keep animals fully shaded, double water supply.' };
}

/* ============================================================
   PUBLIC API
   ============================================================ */
window.OpenMeteo = {
    /* Weather */
    fetchWeatherForecast,
    getWeather,
    getToday,
    getTomorrow,
    getWeek,

    /* Air Quality */
    fetchAirQuality,
    getAQI,

    /* Solar */
    fetchSolarForecast,

    /* Flood (v2.1) */
    getRainfallCumulative,
    getRainfallHourly,
    classifyFloodRisk,

    /* Past days archive (v3.0 — NEW) */
    getPastDays,

    /* Classifiers */
    classifyAQI,
    classifyUV,

    /* Config */
    CACHE_TTL,
    CACHE_TTL_MS
};

/* Backward compat alias for existing code */
window.OpenMeteoForecast = {
    fetchForecast: fetchWeatherForecast,
    getToday,
    getTomorrow,
    getWeek,
    getPastDays,             /* NEW */
    getRainfallCumulative,
    CACHE_TTL_MS
};

console.log('✅ OpenMeteo v3.0 loaded (Weather + AQI + Ammonia + Solar + Flood Rainfall + Past Days Archive)');

})();
